package com.uprr.lic.test.base;

import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.uprr.lic.auth.EQMSUserSession;
import com.uprr.lic.config.spring.MainConfig;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { MainConfig.class })
@WebAppConfiguration
public class BaseJUnit {
	 
	protected static final String LDAP_SYSTEM_ADMIN = "EQM-SYSTEM-ADMIN";

	protected static final String LDAP_MANAGER = "EQM_Manager";
	
	protected static final String EMP_ID = "9000018";

	protected MockMvc mockMvc; 
	
	@Mock
	protected EQMSUserSession eQMSUserSession;
	
	@Autowired
	protected WebApplicationContext context;
	
	@Before
	public void setUp() throws Exception {
		mockMvc = MockMvcBuilders.webAppContextSetup(context).build();
	    MockitoAnnotations.initMocks(this);	    
	}
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		 System.setProperty("uprr.implementation.environment", "local");
		 System.setProperty("jbs.name", "localhost");
	}
	
	@After
	public void tearDown() throws Exception {
	}
}
