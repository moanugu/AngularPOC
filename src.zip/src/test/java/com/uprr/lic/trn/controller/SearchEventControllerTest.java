/*package com.uprr.lic.trn.controller;

import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.uprr.lic.decert.rest.constant.ControllerConstants;
import com.uprr.lic.springconfig.MainConfig;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { MainConfig.class })
@WebAppConfiguration

public class SearchEventControllerTest {
  
  private static final String LDAP_SYSTEM_ADMIN = "EQM-SYSTEM-ADMIN";

  private static final String LDAP_USER = "EQM-USER";

  private static final String LDAP_MANAGER = "EQM_Manager";
  static {
    System.setProperty("uprr.implementation.environment", "local");
    System.setProperty("jbs.name", "localhost");
  }

  @Autowired
  private WebApplicationContext webApplicationContext;

  private MockMvc mockMvc;

  @Before
  public void setUp() {
    MockitoAnnotations.initMocks(this); // Places the mocked trainServiceMock into the controller
    mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
  }
  
  @Ignore
  @Test
  public void testMarkInvalid() throws Exception {
    MvcResult result = this.mockMvc
        .perform(post("/updatedComments").accept(MediaType.APPLICATION_JSON).header("emplId", "9000018").header("ldapRoleList", LDAP_SYSTEM_ADMIN+","+LDAP_MANAGER) // requests a JSON
        ).andExpect(status().isOk()).andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8))

        .andExpect(jsonPath("$", hasSize(2))) // see:
                                              // http://www.petrikainulainen.net/programming/spring-framework/integration-testing-of-spring-mvc-applications-write-clean-assertions-with-jsonpath/

        .andExpect(jsonPath("$[0].id", is("1234"))).andExpect(jsonPath("$[0].symbol", is("ZTEST")))
        .andExpect(jsonPath("$[0].day", is("01"))).andExpect(jsonPath("$[0].arrivalLocation", is("WH123")))
        .andExpect(jsonPath("$[0].arrived", is(false)))

        .andExpect(jsonPath("$[1].id", is("2234"))).andExpect(jsonPath("$[1].symbol", is("XTEST")))
        .andExpect(jsonPath("$[1].day", is("28"))).andExpect(jsonPath("$[1].arrivalLocation", is("WH234")))
        .andExpect(jsonPath("$[1].arrived", is(true)))

        .andReturn();
  }
}
*/