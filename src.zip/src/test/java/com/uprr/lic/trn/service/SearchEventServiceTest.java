/*package com.uprr.lic.trn.service;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;
import org.junit.*;

import com.uprr.lic.trn.dto.*;
import com.uprr.lic.trn.service.SearchEventService;

public class SearchEventServiceTest {

    Train train1 = new Train();
    Train train2 = new Train();
    Train train3 = new Train();
    Train train4 = new Train();

    @Before
    public void setUp(){
        train1.setSymbol("HTEST");
        train1.setDay("21");
        train1.setArrivalLocation("NX001");
        train1.setId("1");

        train2.setSymbol("MTEST");
        train2.setDay("23");
        train2.setArrivalLocation("MX283");
        train2.setId("2");

        train3.setSymbol("HTEST");
        train3.setDay("24");
        train3.setArrivalLocation("MX283");
        train3.setId("3");

        train4.setSymbol("MTEST");
        train4.setDay("22");
        train4.setArrivalLocation("NX001");
        train4.setId("4");
    }


    @Test public void savedTrainsAreFoundInTrainList(){
        SearchEventService trainService = new SearchEventService();

        trainService.save(train1);
        trainService.save(train2);

        List<Train> list = trainService.list();
        assertThat(list).containsOnly(train1,train2);
    }

    @Test
    public void queryCanFindBasedOnSymbol(){
        SearchEventService trainService = new SearchEventService();

        trainService.save(train1);
        trainService.save(train2);
        trainService.save(train3);
        trainService.save(train4);

        List<Train> list = trainService.query(new TrainQuery.Builder().withSymbol("HTEST").build());
        assertThat(list).containsOnly(train1, train3);        
    }

    @Test
    public void queryCanFindBasedOnArrivalLocation(){
        SearchEventService trainService = new SearchEventService();

        trainService.save(train1);
        trainService.save(train2);
        trainService.save(train3);
        trainService.save(train4);

        List<Train> list = trainService.query(new TrainQuery.Builder().withArrivalLocation("MX283").build());
        assertThat(list).containsOnly(train2,train3);
    }

    @Test
    public void queryCanFindBasedOnSymbolAndArrivalLocationTogether(){
        SearchEventService trainService = new SearchEventService();

        trainService.save(train1);
        trainService.save(train2);
        trainService.save(train3);
        trainService.save(train4);

        List<Train> list = trainService.query(new TrainQuery.Builder().withSymbol("MTEST").withArrivalLocation("NX001").build());
        assertThat(list).containsOnly(train4);
    }

    @Test
    public void queryWithBlankParametersReturnsAllTrains(){
        SearchEventService trainService = new SearchEventService();

        trainService.save(train1);
        trainService.save(train2);
        trainService.save(train3);
        trainService.save(train4);

        List<Train> list = trainService.query(new TrainQuery.Builder().build());
        assertThat(list).contains(train1, train2, train3, train4);
    }

    @Test
    public void queryTreatsEmptyStringsSameAsNull(){
        SearchEventService trainService = new SearchEventService();

        trainService.save(train1);
        trainService.save(train2);
        trainService.save(train3);
        trainService.save(train4);

        List<Train> list = trainService.query(new TrainQuery.Builder().withSymbol("").withArrivalLocation("").build());
        assertThat(list).contains(train1, train2, train3, train4);
    }
}
*/