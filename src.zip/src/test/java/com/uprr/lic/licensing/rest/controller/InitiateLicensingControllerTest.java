package com.uprr.lic.licensing.rest.controller;


import static org.hamcrest.CoreMatchers.is;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.uprr.lic.auth.EQMSUserSession;
import com.uprr.lic.config.spring.MainConfig;
import com.uprr.lic.dataaccess.Licensing.model.EmployeeDetailLicInit;
import com.uprr.lic.dataaccess.Licensing.model.InitiateLicensingRequestBean;
import com.uprr.lic.dataaccess.common.model.EqmEmplDtls;
import com.uprr.lic.dataaccess.common.model.EqmTestDtls;
import com.uprr.lic.dataaccess.common.model.PersonBean;
import com.uprr.lic.licensing.rest.service.IInitiateLicensingService;
import com.uprr.lic.util.DDChoice;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { MainConfig.class })
@WebAppConfiguration
@Ignore
public class InitiateLicensingControllerTest {
 
	private static final String LDAP_SYSTEM_ADMIN = "EQM-SYSTEM-ADMIN";

	private static final String LDAP_MANAGER = "EQM_Manager"; 
	
	private static final String EMP_ID = "9000018";

	private MockMvc mockMvc;

	@Mock
	private EQMSUserSession session;
	
	@Mock
	IInitiateLicensingService initiateLicensingService;
	/*@Mock
	private PersonBean personBean;
	
	@Mock
	private InitiateLicensingRequestBean initiateLicensingRequestBean;
	
	@Mock
	private InitiateLicensingRequest initiateLicensingRequest;
	
	
	@Mock
	private EqmTestDtls eqmTestDtls;
	
	@Mock
	private EqmEmplDtls eqmEmplDtls;
	*/
	@Autowired
	@InjectMocks
	InitiateLicensingController controller;

	@Autowired
	private WebApplicationContext context;

	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		 System.setProperty("uprr.implementation.environment", "local");
		 System.setProperty("jbs.name", "localhost");
	}

	@Before
	public void setUp() throws Exception {
		mockMvc = MockMvcBuilders.webAppContextSetup(context).build();
	    MockitoAnnotations.initMocks(this);
	}
	
	@Test
	public void testGetAllLicenseTypeListByKey() throws Exception{
	
		String CON = "CON";
		List<DDChoice> mockLicenseTypeList = new ArrayList<>();
		DDChoice ddCon = new DDChoice();
		ddCon.setStrKey(CON);
		ddCon.setValue("Conductor");
		mockLicenseTypeList.add(ddCon);
		
		when(initiateLicensingService.getAllLicenseTypeList(CON)).thenReturn(mockLicenseTypeList);
		
		MvcResult result = this.mockMvc.perform(get("/licensing/getAllLicenseTypeList").contentType(MediaType.APPLICATION_JSON_VALUE)
				.param("licenseType", CON)
				.header("emplId", EMP_ID)
		        .header("ldapRoleList", LDAP_SYSTEM_ADMIN + "," + LDAP_MANAGER)).andExpect(status().isOk())
				.andExpect(jsonPath("$").isArray())
				.andExpect(jsonPath("$[0].strKey",is(CON)))
				.andExpect(jsonPath("$[0].value",is("Conductor")))
				.andReturn();
		
		String content = result.getResponse().getContentAsString();
	}
	
	
	@Test
	public void testGetAllLicenseTypeList() throws Exception {
		
		List<DDChoice> mockLicenseTypeList = new ArrayList<>();
		DDChoice ddCon = new DDChoice();
		ddCon.setStrKey("CON");
		ddCon.setValue("Conductor");
		mockLicenseTypeList.add(ddCon);
		DDChoice ddEng = new DDChoice();
		ddEng.setStrKey("ENG");
		ddEng.setValue("Engineer");
		mockLicenseTypeList.add(ddEng);
		DDChoice ddRco = new DDChoice();
		ddRco.setStrKey("RCO");
		ddRco.setValue("Remote Control Operator");
		mockLicenseTypeList.add(ddRco);
		DDChoice ddHost = new DDChoice();
		ddHost.setStrKey("HOS");
		ddHost.setValue("Hostler");
		mockLicenseTypeList.add(ddHost);
		
		when(initiateLicensingService.getAllLicenseTypeList(null)).thenReturn(mockLicenseTypeList);
		
		MvcResult result = this.mockMvc.perform(get("/licensing/getAllLicenseTypeList").contentType(MediaType.APPLICATION_JSON_VALUE)
				.header("emplId", EMP_ID)
		        .header("ldapRoleList", LDAP_SYSTEM_ADMIN + "," + LDAP_MANAGER)).andExpect(status().isOk())
				.andExpect(jsonPath("$").isArray())
				.andExpect(jsonPath("$[0].strKey",is("CON")))
				.andExpect(jsonPath("$[0].value",is("Conductor")))
				.andExpect(jsonPath("$[1].strKey",is("ENG")))
				.andExpect(jsonPath("$[1].value",is("Engineer")))
				.andExpect(jsonPath("$[2].strKey",is("RCO")))
				.andExpect(jsonPath("$[2].value",is("Remote Control Operator")))
				.andExpect(jsonPath("$[3].strKey",is("HOS")))
				.andExpect(jsonPath("$[3].value",is("Hostler")))
				.andReturn();
		
		String content = result.getResponse().getContentAsString();
	}

	@Test
	public void testInsertNewEmployee() throws Exception{
		PersonBean personBean = new PersonBean();
		
		when(initiateLicensingService.insertNewEmployee(personBean)).thenReturn(new Boolean(false));
		this.mockMvc.perform(post("/licensing/insertNewEmployee").contentType(MediaType.APPLICATION_JSON_VALUE)
				.content("{}")
				.header("emplId", EMP_ID)
		        .header("ldapRoleList", LDAP_SYSTEM_ADMIN + "," + LDAP_MANAGER)).andExpect(status().isOk())
				.andExpect(jsonPath("$", is(false)))
				.andReturn();
				
	}

	/**
	 * InitializeLicensingRequest and CreateInitiateLicenseRequest mearged in single method
	 */
	@Test
	public void testInitializeAndCreateLicensingRequest() throws Exception {
			
		InitiateLicensingRequestBean initiateLicensingRequestBean =  new InitiateLicensingRequestBean(); 
		
		EmployeeDetailLicInit employeeDetailLicInit =  new EmployeeDetailLicInit();
		employeeDetailLicInit.setEmpFirstName("Ravi");
		employeeDetailLicInit.setEmpLastName("Kushwaha");
		List<EmployeeDetailLicInit> employeeDetailLicInitList = Arrays.asList(employeeDetailLicInit);
		
		Map<String, Map<String, EmployeeDetailLicInit>> resultMap= new HashMap<String, Map<String, EmployeeDetailLicInit>>();
		Map<String, EmployeeDetailLicInit> value = new HashMap<String, EmployeeDetailLicInit>();
		value.put("test", employeeDetailLicInit);
		resultMap.put("test", value);
		
		when(initiateLicensingService.initializeAndCreateLicensingRequest(initiateLicensingRequestBean, employeeDetailLicInitList)).thenReturn(resultMap);
		
		 MvcResult result =this.mockMvc.perform(post("/licensing/initializeAndCreateLicensingRequest").contentType(MediaType.APPLICATION_JSON_VALUE)
				.content("{\"employeeID\": \"0448625\", \"licenseType\": {\"strKey\":\"CON\",\"value\":\"Conductor\"},\"finalList\":[{\"employeeID\":\"0448625\",\"employeeName\":\"Nguyen, Tam N\",\"serviceUnitNbr\":99,\"serviceUnit\":\"UNKNOWN\",\"licenseAll\":[{\"licenseClassDescription\":\"-\",\"licenseType\":\"CON\"}],\"hireDate\":\"08/22/2011\",\"passengerConTrainee\":\"No\",\"pass\":false,\"hearing\":false,\"notApplicable\":false,\"coach\":false}]}")
				.header("emplId", EMP_ID)
		        .header("ldapRoleList", LDAP_SYSTEM_ADMIN + "," + LDAP_MANAGER)).andExpect(status().isOk())
				/*.andExpect(jsonPath("$.test").isNotEmpty())
				.andExpect(jsonPath("$.test.empFirstName",is("Ravi")))
				.andExpect(jsonPath("$.test.empLastName",is("Kushwaha")))*/
				.andReturn();
		 String content = result.getResponse().getContentAsString();
	}
	
	

	@Test
	public void testIsEmployeeLicensed() throws Exception {
		 when(initiateLicensingService.isEmployeeLicensed("123304", false)).thenReturn(true);
		 
		 MvcResult result =	this.mockMvc.perform(get("/licensing/isEmployeeLicensed").contentType(MediaType.APPLICATION_JSON_VALUE)
					.param("employeeID", "123304")
					.param("flagHist", "false")
					.header("emplId", EMP_ID)
			        .header("ldapRoleList", LDAP_SYSTEM_ADMIN + "," + LDAP_MANAGER)).andExpect(status().isOk())
					.andExpect(jsonPath("$").isBoolean())
					.andExpect(jsonPath("$",is(true)))
					.andReturn();
		 String content = result.getResponse().getContentAsString();
		 
	}

	@Test
	public void testCheckForValidTestDetailsAvailability() throws Exception {
		EqmTestDtls eqmTestDtls =  new EqmTestDtls();
		eqmTestDtls.setTestId(14);
		eqmTestDtls.setCrtnEmplId(EMP_ID);
		when(initiateLicensingService.checkForValidTestDetailsAvailability(EMP_ID, 14)).thenReturn(eqmTestDtls);
				
		this.mockMvc.perform(get("/licensing/checkValidTestAvailability").contentType(MediaType.APPLICATION_JSON_VALUE)
						.param("employeeID", EMP_ID)
						.param("selection", "14")
						.header("emplId", EMP_ID)
				        .header("ldapRoleList", LDAP_SYSTEM_ADMIN + "," + LDAP_MANAGER)).andExpect(status().isOk())
						.andExpect(jsonPath("$.testId", is(14)))
						.andExpect(jsonPath("$.crtnEmplId",is(EMP_ID)));						
		
	}

	@Test
	public void testGetEmployeeDetailsForInitiateLicenseRequest() throws Exception {
	EmployeeDetailLicInit employeeDetailLicInit =  new EmployeeDetailLicInit();
	employeeDetailLicInit.setEmpFirstName("Ravi");
	employeeDetailLicInit.setEmpLastName("Kushwaha");
	
	InitiateLicensingRequestBean initiateLicensingRequestBean =  new InitiateLicensingRequestBean(); 
	initiateLicensingRequestBean.setEmployeeID("0448625");
	DDChoice ddCon = new DDChoice();
	ddCon.setStrKey("CON");
	ddCon.setValue("Conductor");
	initiateLicensingRequestBean.setLicenseType(ddCon);
	
	when(initiateLicensingService.getEmployeeDetailsForInitiateLicenseRequest(initiateLicensingRequestBean)).thenReturn(employeeDetailLicInit);
		
	 MvcResult result =	this.mockMvc.perform(post("/licensing/getEmployeeDetailsForInitiateLicenseRequest").contentType(MediaType.APPLICATION_JSON_VALUE)
				.content("{\"employeeID\": \"0448625\", \"licenseType\": {\"strKey\":\"CON\",\"value\":\"Conductor\"}}")
				.header("emplId", EMP_ID)
		        .header("ldapRoleList", LDAP_SYSTEM_ADMIN + "," + LDAP_MANAGER)).andExpect(status().isOk())
			 	.andExpect(jsonPath("$.empFirstName",is("Ravi")))
				.andExpect(jsonPath("$.empLastName",is("Kushwaha")))
				.andReturn();
	 String content = result.getResponse().getContentAsString();
	}

	/**
	 * External service in not implemented
	 */
	@Test
	public void testGetEmployeeDetails() throws Exception{
		PersonBean personBean = new PersonBean();
		when(initiateLicensingService.insertNewEmployee(personBean)).thenReturn(new Boolean(true));
		MvcResult result =	 this.mockMvc.perform(get("/licensing/getPersonDetails").contentType(MediaType.APPLICATION_JSON_VALUE)
				.param("employeeID",EMP_ID)
				.header("emplId", EMP_ID)
		        .header("ldapRoleList", LDAP_SYSTEM_ADMIN + "," + LDAP_MANAGER)).andExpect(status().isOk())
				/*.andExpect(jsonPath("$", is(true)))*/
				.andReturn();		
		 String content = result.getResponse().getContentAsString();
	}

	@Test
	public void testGetEmplDtls() throws Exception{
		EqmEmplDtls eqmEmplDtls =  new EqmEmplDtls();
		eqmEmplDtls.setEmplFirName("Ravi");
		eqmEmplDtls.setEmplLastName("Kushwaha");
		when(initiateLicensingService.getEmplDtls(EMP_ID)).thenReturn(eqmEmplDtls);
		this.mockMvc.perform(get("/licensing/getEmployeeDetails").contentType(MediaType.APPLICATION_JSON_VALUE)
					.param("employeeID", EMP_ID)
					.header("emplId", EMP_ID)
			        .header("ldapRoleList", LDAP_SYSTEM_ADMIN + "," + LDAP_MANAGER)).andExpect(status().isOk())
					.andExpect(jsonPath("$.emplFirName",is("Ravi")))
					.andExpect(jsonPath("$.emplLastName",is("Kushwaha")));				
		
	} 
}
