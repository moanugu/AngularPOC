package com.uprr.lic.licensing.rest.controller;

import static org.hamcrest.Matchers.is;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.hamcrest.core.IsNull;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.uprr.lic.config.spring.MainConfig;
import com.uprr.lic.dataaccess.Licensing.model.MvrNdrDetails;
import com.uprr.lic.dataaccess.Licensing.model.MvrNdrPopupPacketGridDetail;
import com.uprr.lic.dataaccess.Licensing.model.MvrNdrReplyPopupDetail;
import com.uprr.lic.licensing.rest.model.EqmLicensingMvrReportDetailsResponse;
import com.uprr.lic.licensing.rest.model.LicensingRequest;
import com.uprr.lic.licensing.rest.service.IMVRAndNDRRestService;
import com.uprr.lic.test.base.BaseJUnit;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes={MainConfig.class})
@WebAppConfiguration
@Ignore
public class MVRAndNDRControllerTest extends BaseJUnit {

	private static final String LDAP_SYSTEM_ADMIN = "EQM-SYSTEM-ADMIN";
	private static final String LDAP_MANAGER = "EQM_Manager";

	private MockMvc mockMvc;

	@Autowired
	private WebApplicationContext applicationContext;

	@Mock
	private List<Integer> listOfRegion;

	@Mock
	private IMVRAndNDRRestService mvrAndNdrRestService;

	@Autowired
	@InjectMocks
	private MVRAndNDRController mvrAndNDRController;


	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		System.setProperty("uprr.implementation.environment", "local");
		System.setProperty("jbs.name", "localhost");
	}

	@Before
	public void setUp() throws Exception {
		this.mockMvc = MockMvcBuilders.webAppContextSetup(applicationContext).build();
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testIsEmployeeAlreadyLicensed() throws Exception {

		when(mvrAndNdrRestService.isEmployeeAlreadyLicensed(any(String.class))).thenReturn(true);

		this.mockMvc.perform(get("/licensing/isEmployeeAlreadyLicensed/0298376")
				.contentType(MediaType.APPLICATION_JSON_VALUE)
				.header("emplId", "9000018").header("ldapRoleList", LDAP_SYSTEM_ADMIN + "," + LDAP_MANAGER))
		.andExpect(status().isOk())
		.andExpect(jsonPath("$").isBoolean())
		.andExpect(jsonPath("$", is(true)))
		.andReturn();
	}

	@Test
	public void testGetPackDtlsResn() throws Exception {
		listOfRegion = new ArrayList<Integer>();
		listOfRegion.add(187);
		listOfRegion.add(121);
		listOfRegion.add(122);


		when(mvrAndNdrRestService.getPackDtlsResn(any(String.class), any(List.class))).thenReturn(listOfRegion);
		this.mockMvc.perform(post("/licensing/getPackDtlsResn")
				.contentType(MediaType.APPLICATION_JSON_VALUE)
				.content("{\"employeeId\":\"0298376\",\"regionIdList\":[120,187,121,122,123,125,155,156,130,131]}")
				.header("emplId", "9000018").header("ldapRoleList", LDAP_SYSTEM_ADMIN + "," + LDAP_MANAGER))
		.andExpect(status().isOk())
		.andExpect(jsonPath("$").isArray())
		//.andExpect(jsonPath("$", equalTo(listOfRegion)))
		.andReturn();
	}

	@Test
	public void testOprnForCallbackOption() throws Exception {
		when(mvrAndNdrRestService.oprnForCallbackOption(any(String.class),any(String.class), any(String.class))).thenReturn(true);

		this.mockMvc.perform(post("/licensing/oprnForCallbackOption")
				.contentType(MediaType.APPLICATION_JSON_VALUE)
				.content("{\"workItemCode\":\"123456\",\"employeeId\":\"0298376\", \"comments\":\"Comment on operationForCallBack\"}")
				.header("emplId", "9000018").header("ldapRoleList", LDAP_SYSTEM_ADMIN + "," + LDAP_MANAGER))
		.andExpect(status().isOk())
		.andExpect(jsonPath("$", is(true))).andReturn();
	}

	@Test
	public void testInsertEmployeeAuthorizationDetails() throws Exception {
		when(mvrAndNdrRestService.insertEmployeeAuthorizationDetails(any(List.class), any(Integer.class), any(String.class), any(String.class), any(Boolean.class))).thenReturn(2030);

		this.mockMvc.perform(post("/licensing/insertEmployeeAuthorizationDetails")
				.contentType(MediaType.APPLICATION_JSON_VALUE)
				.content("{\"empPacketStatusDetails\":[{\"employeeID\":\"0466220\"}],\"number\":14,\"mvrNdrCode\":\"NDR\",\"comments\":\"This is testing point\", \"fromSupervision\":true}")
				.header("emplId", "9000018").header("ldapRoleList", LDAP_SYSTEM_ADMIN + "," + LDAP_MANAGER))
		.andExpect(status().isOk())
		.andExpect(jsonPath("$", is(2030))).andReturn();
	}

	@Test
	public void testSetMvrNdrResult() throws Exception {
	when(mvrAndNdrRestService.setMvrNdrResult(any(MvrNdrReplyPopupDetail.class), any(String.class),any(Integer.class), any(Integer.class))).thenReturn(true);

		this.mockMvc.perform(post("/licensing/setMvrNdrResult")
				.contentType(MediaType.APPLICATION_JSON_VALUE)
				.content("{\"mvrNdrPopupDtls\":{\"employeeID\":\"0466220\",\"licenseCode\":\"Class 3\",\"resultDetails\":\"Pass\"},\"rqmtId\":141497,\"serviceUnitNumber\":14,\"codeStr\":\"NDR\"}")
				.header("emplId", "9000018").header("ldapRoleList", LDAP_SYSTEM_ADMIN + "," + LDAP_MANAGER))
		.andExpect(status().isOk())
		.andExpect(jsonPath("$", is(true))).andReturn();
	}

	@Test
	public void testGetNdrDetails_For_Pass_FAIL() throws Exception {

		List<MvrNdrPopupPacketGridDetail> packetHistoryList = new  ArrayList<>();
		MvrNdrDetails mvrNdrDetails = new MvrNdrDetails();
		mvrNdrDetails.setCallbackCmnt("This is mock comment");
		mvrNdrDetails.setComments("This is mock test for comments");
		mvrNdrDetails.setCommentsLabel("This is comments label");
		mvrNdrDetails.setDate("01/17/2017");
		mvrNdrDetails.setResult("Pass");
		mvrNdrDetails.setPacketHistoryList(packetHistoryList);
		mvrNdrDetails.setResultDetails("Pass Mvr Result");
		mvrNdrDetails.setUploadedBy("Beckwith, Edward E(0428407)");

		when(mvrAndNdrRestService.getNdrDetails(any(Integer.class), any(String.class))).thenReturn(mvrNdrDetails);
		this.mockMvc.perform(get("/licensing/getNdrDetails/143408/0298376")
				.contentType(MediaType.APPLICATION_JSON_VALUE)
				.header("emplId", "9000018").header("ldapRoleList", LDAP_SYSTEM_ADMIN + "," + LDAP_MANAGER))
		.andExpect(status().isOk())
		.andExpect(jsonPath("$.packetHistoryList").isArray())
		.andExpect(jsonPath("$.result", is("Pass")))
		.andExpect(jsonPath("$.date", is("01/17/2017")))
		.andExpect(jsonPath("$.uploadedBy", is("Beckwith, Edward E(0428407)")))
		.andReturn();
	}


	@Test
	public void testGetNdrDetails_For_NA() throws Exception {

		MvrNdrDetails mvrNdrDetails = new MvrNdrDetails();
		List<MvrNdrPopupPacketGridDetail> packetHistoryList = new  ArrayList<>();
		mvrNdrDetails.setPacketHistoryList(packetHistoryList);
		when(mvrAndNdrRestService.getNdrDetails(any(Integer.class), any(String.class))).thenReturn(mvrNdrDetails);

		this.mockMvc.perform(get("/licensing/getNdrDetails/143066/0000518")
				.contentType(MediaType.APPLICATION_JSON_VALUE)
				.header("emplId", "9000018").header("ldapRoleList", LDAP_SYSTEM_ADMIN + "," + LDAP_MANAGER))
		.andExpect(status().isOk())
		.andExpect(jsonPath("$.packetHistoryList").isArray())
		.andExpect(jsonPath("$.result", is(IsNull.nullValue())))
		.andExpect(jsonPath("$.date", is(IsNull.nullValue())))
		.andExpect(jsonPath("$.uploadedBy", is(IsNull.nullValue())))
		.andReturn();
	}

	@Test
	public void testGetMVRReportDetails() throws Exception {

		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
		when(mvrAndNdrRestService.getMVRReportDetails(any(List.class))).thenReturn(list);
		this.mockMvc.perform(post("/licensing/getMVRReportDetails")
				.contentType(MediaType.APPLICATION_JSON_VALUE)
				.content("{\"employeeIdList\":[\"0298376\"]}")
				.header("emplId", "9000018").header("ldapRoleList", LDAP_SYSTEM_ADMIN + "," + LDAP_MANAGER))
		.andExpect(status().isOk()).andExpect(jsonPath("$").isArray())
		.andReturn();
	}

	@Test
	public void testInsertMvrNdrResultWithDate() throws Exception {

		when(mvrAndNdrRestService.insertMvrNdrResultWithDate(any(LicensingRequest.class))).thenReturn(true);
		this.mockMvc.perform(post("/licensing/insertMvrNdrResultWithDate")
				.contentType(MediaType.APPLICATION_JSON_VALUE)
				.content("{\"empPacketStatusDetails\":[{\"employeeID\":\"0466220\", \"employeeAction\":\"Test this case\"}}],\"documentTypeCode\":\"NDR\",\"mvrNdrResultPass\":\"Pass\", \"packetDate\":null}")
				.header("emplId", "9000018").header("ldapRoleList", LDAP_SYSTEM_ADMIN + "," + LDAP_MANAGER))
		.andExpect(status().isOk()).andExpect(jsonPath("$", is(true)))
		.andReturn();
	}


	

	@Test 
	public void testDoGetMvrRptDtl_Pass() throws Exception {
		
		EqmLicensingMvrReportDetailsResponse response = new EqmLicensingMvrReportDetailsResponse();
		response.setMvrRptId(new Long(12727));
		response.setEmplId("0298376");
		response.setMvrReqTxt("N");
		response.setMvrRespTxt("N");
		response.setGufnId("{C2AD4AC4-C055-413E-BDF0-48B7FE09276A}");
		response.setHistRcdFlag("Y");
		response.setCrtnEmplId("0071972");
		response.setLastUpdtEmplId("0071972");
		
		when(mvrAndNdrRestService.doGetMvrReportDtl(any(String.class))).thenReturn(response);
		this.mockMvc
		.perform(get("/licensing/getMvrReportDetails/0298376").contentType(
				MediaType.APPLICATION_JSON_VALUE) .header("emplId",
						"9000018").header("ldapRoleList", LDAP_SYSTEM_ADMIN + "," +
								LDAP_MANAGER))
		.andExpect(status().isOk()).andExpect(jsonPath("$.mvrRptId",
				is("12727"))) .andExpect(jsonPath("$.emplId", is("0298376")))

		.andExpect(jsonPath("$.mvrReqTxt", is("N")))
		.andExpect(jsonPath("$.mvrRespTxt", is("N")))

		.andExpect(jsonPath("$.gufnId",
				is("{C2AD4AC4-C055-413E-BDF0-48B7FE09276A}")))
		.andExpect(jsonPath("$.histRcdFlag",
				is("Y"))).andExpect(jsonPath("$.crtnEmplId", is("0071972"))) //
		.andExpect(jsonPath("$.lastUpdtEmplId", is("0071972"))) //
		.andReturn(); }

	@Test 
	public void testGetMVRDetails() throws Exception { 
		
		List<MvrNdrPopupPacketGridDetail> packetHistoryList = new  ArrayList<>();
		MvrNdrDetails mvrNdrDetails = new MvrNdrDetails();
		mvrNdrDetails.setCallbackCmnt("This is mock comment");
		mvrNdrDetails.setComments("This is mock test for comments");
		mvrNdrDetails.setCommentsLabel("This is comments label");
		mvrNdrDetails.setDate("01/17/2017");
		mvrNdrDetails.setResult("Pass");
		mvrNdrDetails.setPacketHistoryList(packetHistoryList);
		mvrNdrDetails.setResultDetails("Pass Mvr Result");
		mvrNdrDetails.setUploadedBy("Beckwith, Edward E(0428407)");
		
		when(mvrAndNdrRestService.getMVRDetails(any(Integer.class), any(String.class))).thenReturn(mvrNdrDetails);
		this.mockMvc
		.perform(get("/licensing/getMVRDetails/143408/0298376").contentType(
				MediaType.APPLICATION_JSON_VALUE) .header("emplId",
						"9000018").header("ldapRoleList", LDAP_SYSTEM_ADMIN + "," +
								LDAP_MANAGER))
		.andExpect(status().isOk()).andExpect(jsonPath("$.packetHistoryList").isArray())
		.andExpect(jsonPath("$.result", is("Pass")))
		.andExpect(jsonPath("$.date", is("01/17/2017")))
		.andExpect(jsonPath("$.uploadedBy", is("Beckwith, Edward E(0428407)"))).andReturn(); }

	@Test 
	public void testGetMVRAuthDetailsFromReorpts() throws Exception
	{ this.mockMvc
		.perform(get("/licensing/getMVRAuthDetailsFromReorpts/0298376")
				.contentType(MediaType.APPLICATION_JSON_VALUE).header("emplId",
						"9000018") .header("ldapRoleList", LDAP_SYSTEM_ADMIN + "," +
								LDAP_MANAGER))
		.andExpect(status().isOk()).andExpect(jsonPath("$").isArray()).
		andReturn(); 
	}


	@Test
	public void insertEmployeeAuthorizationPacketDetails() throws Exception {
		when(mvrAndNdrRestService.insertEmployeeAuthorizationPacketDetails(any(List.class), any(Integer.class), any(String.class), any(String.class), any(Boolean.class))).thenReturn(2030);

		this.mockMvc.perform(post("/licensing/insertEmployeeAuthorizationPacketDetails")
				.contentType(MediaType.APPLICATION_JSON_VALUE)
				.content("{\"empPacketStatusDetails\":[{\"employeeID\":\"0466220\", \"employeeAction\":\"Test this case\"}],\"number\":14,\"mvrNdrCode\":\"NDR\",\"comments\":\"This is testing point\", \"fromSupervision\":true}")
				.header("emplId", "9000018").header("ldapRoleList", LDAP_SYSTEM_ADMIN + "," + LDAP_MANAGER))
		.andExpect(status().isOk())
		.andExpect(jsonPath("$", is(2030))).andReturn();
	}
	

	@Test
	public void testDoAuthAndCreateMVRReq() throws Exception {

		when(mvrAndNdrRestService.isEmployeeAlreadyLicensed(any(String.class))).thenReturn(true);

		this.mockMvc.perform(post("/licensing/doAuthAndCreateMVRReq")
				.content("{\"emplIdLst\":[\"0419366\"], \"fromErrWrkItm\":true, \"fromSendRequest\":false}")
				.contentType(MediaType.APPLICATION_JSON_VALUE)
				.header("emplId", "9000018").header("ldapRoleList", LDAP_SYSTEM_ADMIN + "," + LDAP_MANAGER))
		.andExpect(status().isOk())
		.andReturn();
	}

}
