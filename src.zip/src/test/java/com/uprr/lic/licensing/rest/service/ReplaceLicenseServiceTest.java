package com.uprr.lic.licensing.rest.service;

import static org.fest.assertions.Assertions.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.uprr.lic.auth.EQMSUserBean;
import com.uprr.lic.auth.EQMSUserSession;
import com.uprr.lic.config.spring.MainConfig;
import com.uprr.lic.dataaccess.Licensing.model.InitiateReplaceLicenseBean;
import com.uprr.lic.dataaccess.components.licensing.service.LicensingServiceImpl;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { MainConfig.class })
@WebAppConfiguration
public class ReplaceLicenseServiceTest {
	
	private MockMvc mockMvc;

	@Autowired
	private WebApplicationContext applicationContext;

	@Mock
	private LicensingServiceImpl licenseService;

	@Mock
	private EQMSUserBean eqmsUserBean;
	
	@Mock
	private EQMSUserSession eqmsUserSession;

	@Autowired
	@InjectMocks
	private ReplaceLicenseService service;
	

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		System.setProperty("uprr.implementation.environment", "local");
		System.setProperty("jbs.name", "localhost");
	}

	@Before
	public void setUp() throws Exception {
		this.mockMvc = MockMvcBuilders.webAppContextSetup(applicationContext).build();
		MockitoAnnotations.initMocks(this);
		when(eqmsUserBean.getEmplId()).thenReturn("9000018");
		when(eqmsUserSession.getUser()).thenReturn(eqmsUserBean);
	}

	@Test
	public void testIsReplaceLicenseRequestInitiated() {
		
		List<String> arrayList = Arrays.asList("Class 8","Class 9","Class 1","Class 2","Class 3","Class 5",
				"Class 6","Class 7");
		Set<String> set= new HashSet<String>(arrayList);
		when(licenseService.isReplaceLicenseRequestInitiated(any(String.class))).thenReturn(set);
		
		Set<String> reponse = service.isReplaceLicenseRequestInitiated("006019");
		assertThat(reponse.size()).isEqualTo(8);
		assertThat(reponse.containsAll(set)).isEqualTo(true);	
	}

	@Test
	public void testInsertReplaceLicenseWorkItemEntry() {
		List<InitiateReplaceLicenseBean> reponseList = new ArrayList<InitiateReplaceLicenseBean>();
		InitiateReplaceLicenseBean initiateReplaceLicenseBean = new InitiateReplaceLicenseBean();
		initiateReplaceLicenseBean.setEmployeeID("006019");
		initiateReplaceLicenseBean.setEmployeeName("Sampeck, Michael V");
		initiateReplaceLicenseBean.setServiceUnit("NORTH PLATTE");
		initiateReplaceLicenseBean.setReason("License Lost");
		reponseList.add(initiateReplaceLicenseBean);
		when(licenseService.insertReplaceLicenseWorkItemEntry(any(String.class), any(List.class), any(String.class))).thenReturn(1);
		
		Integer integer = service.insertReplaceLicenseWorkItemEntry("License Lost", reponseList);
		assertThat(integer).isEqualTo(1);	
	}

	@Test
	public void testGetReplaceLicenseEmployeeDetails() {
	
		InitiateReplaceLicenseBean initiateReplaceLicenseBeanRequest = new InitiateReplaceLicenseBean();
		initiateReplaceLicenseBeanRequest.setEmployeeID("006019");
		initiateReplaceLicenseBeanRequest.setReason("License Lost");

		List<InitiateReplaceLicenseBean> reponseList = new ArrayList<InitiateReplaceLicenseBean>();
		InitiateReplaceLicenseBean initiateReplaceLicenseBean = new InitiateReplaceLicenseBean();
		initiateReplaceLicenseBean.setEmployeeID("006019");
		initiateReplaceLicenseBean.setEmployeeName("Sampeck, Michael V");
		initiateReplaceLicenseBean.setServiceUnit("NORTH PLATTE");
		initiateReplaceLicenseBean.setReason("License Lost");
		reponseList.add(initiateReplaceLicenseBean);

		when(licenseService.getReplaceLicenseEmployeeDetails(any(InitiateReplaceLicenseBean.class), any(Set.class))).thenReturn(reponseList);
	
		List<String> arrayList = Arrays.asList("Class 8","Class 9","Class 1","Class 2","Class 3","Class 5",
				"Class 6","Class 7");
		Set<String> set= new HashSet<String>(arrayList);
		List<InitiateReplaceLicenseBean> listOfEmployeeDetails = service.getReplaceLicenseEmployeeDetails("006019", set);
		assertThat(listOfEmployeeDetails.size()).isEqualTo(1);
		
		assertThat(listOfEmployeeDetails.get(0).getEmployeeID()).isEqualTo("0006019");
		assertThat(listOfEmployeeDetails.get(0).getEmployeeName()).isEqualTo("Sampeck, Michael V");
		assertThat(listOfEmployeeDetails.get(0).getServiceUnit()).isEqualTo("NORTH PLATTE");
		assertThat(listOfEmployeeDetails.get(0).getReason()).isEqualTo("License Lost");
	}

}
