package com.uprr.lic.licensing.rest.service;

import static org.junit.Assert.fail;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
@Ignore
public class EmployeePacketStatusServiceTest {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}
	
	@Ignore
	@Test
	public void testGetEmpPackStatusListForEmpl() {
		fail("Not yet implemented");
	}

	@Ignore
	@Test
	public void testCancelRevokeRequest() {
		fail("Not yet implemented");
	}

	@Ignore
	@Test
	public void testSendStatusReport() {
		fail("Not yet implemented");
		
	}

}
