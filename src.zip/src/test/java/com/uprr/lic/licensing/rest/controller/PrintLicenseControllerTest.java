package com.uprr.lic.licensing.rest.controller;

import static org.hamcrest.CoreMatchers.is;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.uprr.lic.auth.EQMSUserBean;
import com.uprr.lic.auth.EQMSUserSession;
import com.uprr.lic.config.spring.MainConfig;
import com.uprr.lic.dataaccess.Licensing.model.License;
import com.uprr.lic.dataaccess.Licensing.model.PendingActionListGridDetail;
import com.uprr.lic.dataaccess.Licensing.model.PrintTemporaryLicense;
import com.uprr.lic.dataaccess.Licensing.model.PrintTemporaryLicenseGrid;
import com.uprr.lic.licensing.rest.service.PrintLicenseService;
import com.uprr.lic.util.LicensingConstant;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { MainConfig.class })
@WebAppConfiguration
@Ignore
public class PrintLicenseControllerTest {

	private static final String LDAP_SYSTEM_ADMIN = "EQM-SYSTEM-ADMIN";

	private static final String LDAP_MANAGER = "EQM_Manager";
	
	private static final String EMP_ID = "9000018";

	private MockMvc mockMvc;
	
	@Mock
	private PrintLicenseService  printLicenseService;
	
	@Mock
	private PrintTemporaryLicenseGrid printTemporaryLicenseGrid;
		
	@Mock
	private EQMSUserSession eQMSUserSession;
	
	@Mock
	private EQMSUserBean eQMSUserBean;
	
	@Mock
	private License licesne;
	
	@Mock
	private PrintTemporaryLicense printTemporaryLicense;
	
	@Mock
	private PendingActionListGridDetail pendingActionListGridDetail;
	
	
	
	@Autowired
	@InjectMocks
	private PrintLicenseController printLicenseController;

	@Autowired
	private WebApplicationContext context;

	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		 System.setProperty("uprr.implementation.environment", "local");
		 System.setProperty("jbs.name", "localhost");
	}


	@Before
	public void setUp() throws Exception {
		mockMvc = MockMvcBuilders.webAppContextSetup(context).build();
	    MockitoAnnotations.initMocks(this);
	}


	@Test
	public void testIsExpnDateSameForAllLcns() {
		
		when(printLicenseController.isExpnDateSameForAllLcns(EMP_ID)).thenReturn(true);
		
		try {
			this.mockMvc.perform(get("/licensing/isExpnDateSameForAllLcns/"+EMP_ID).contentType(MediaType.APPLICATION_JSON_VALUE)
					.header("emplId", EMP_ID)
			        .header("ldapRoleList", LDAP_SYSTEM_ADMIN + "," + LDAP_MANAGER)).andExpect(status().isOk())
					.andExpect(jsonPath("$", is(true)))
					.andReturn();				
					
		} catch (Exception e) {
			e.printStackTrace();
		} 
	}

	@Test
	public void testGetPrintLicenseService()  throws Exception{
		List<PrintTemporaryLicenseGrid> list =  new ArrayList<PrintTemporaryLicenseGrid>();
		when(printTemporaryLicense.getEmployeeID()).thenReturn(EMP_ID);
		when(printTemporaryLicenseGrid.getEmployeeID()).thenReturn(EMP_ID);
		when(printTemporaryLicenseGrid.getLicenseClass()).thenReturn("Class 8");
		when(printTemporaryLicenseGrid.getEmployeeName()).thenReturn("Ravi");
		list.add(printTemporaryLicenseGrid);
		when(printTemporaryLicense.getPrintTemporaryLicenseGridAll()).thenReturn(list);		
		when(printLicenseService.getPrintLicenseService(printTemporaryLicense, 1, EMP_ID, "false")).thenReturn(printTemporaryLicense);
		
		this.mockMvc.perform(post("/licensing/getPrintLicenseService").contentType(MediaType.APPLICATION_JSON_VALUE)
				.content("{\"employeeID\": \"0412160\"}")
				.param("choice", "1")
				.param("employeeID", "0412160")
				.param("printFlag", "false")
				.header("emplId", EMP_ID)
		        .header("ldapRoleList", LDAP_SYSTEM_ADMIN + "," + LDAP_MANAGER)).andExpect(status().isOk())
				.andExpect(jsonPath("$.employeeID", is(EMP_ID)))
				.andExpect(jsonPath("$.printTemporaryLicenseGridAll").isArray())
				.andExpect(jsonPath("$.printTemporaryLicenseGridAll[0].employeeID", is(EMP_ID)))
				.andExpect(jsonPath("$.printTemporaryLicenseGridAll[0].licenseClass", is("Class 8")))
				.andExpect(jsonPath("$.printTemporaryLicenseGridAll[0].employeeName", is("Ravi")))
				.andReturn();
		
		/*try {
			MvcResult result = this.mockMvc.perform(post("/licensing/getPrintLicenseService").contentType(MediaType.APPLICATION_JSON_VALUE)
					.content("{\"employeeID\": \"0412160\"}")
					.param("choice", "1")
					.param("employeeID", "0412160")
					.param("printFlag", "false")
					.header("emplId", EMP_ID)
			        .header("ldapRoleList", LDAP_SYSTEM_ADMIN + "," + LDAP_MANAGER)).andExpect(status().isOk())
					.andExpect(jsonPath("$.printTemporaryLicenseGridAll").isArray())
					.andExpect(jsonPath("$.printTemporaryLicenseGridAll[0].lcnsMailDate").isNotEmpty())
					.andExpect(jsonPath("$.printTemporaryLicenseGridAll[0].employeeID").isNotEmpty())
					.andExpect(jsonPath("$.printTemporaryLicenseGridAll[0].licenseClass").isNotEmpty())
					.andExpect(jsonPath("$.printTemporaryLicenseGridAll[0].employeeName").isNotEmpty())
					.andReturn();
					
					String content = result.getResponse().getContentAsString();
					//{"printCount":0,"checkLicFlag":false,"print":null,"flag":false,"eqmsWorkItemBeanList":null,"printTemporaryLicenseGridAll":[{"emplPhotoimage":false,"lcnsMailDate":"09/16/2015","flag":false,"reason":"-","eqmsWorkItemBean":null,"emplMedicalNotClear":false,"licenseClass":"Class 1","issueDate":null,"lcnsOprnId":null,"lcnsOprnCode":null,"workFlag":"O","replaceLicence":null,"employeeName":"Castaneda, Martin A","employeeID":"0412160","reasonId":null,"serviceUnit":"LOS ANGELES","workItemId":null,"serviceUnitNbr":20,"licenseClassDesc":"Class 1,"},{"emplPhotoimage":false,"lcnsMailDate":"09/16/2015","flag":false,"reason":"-","eqmsWorkItemBean":null,"emplMedicalNotClear":false,"licenseClass":"Class 6","issueDate":null,"lcnsOprnId":null,"lcnsOprnCode":null,"workFlag":"O","replaceLicence":null,"employeeName":"Castaneda, Martin A","employeeID":"0412160","reasonId":null,"serviceUnit":"LOS ANGELES","workItemId":null,"serviceUnitNbr":20,"licenseClassDesc":"Class 1,Class 6,"},{"emplPhotoimage":false,"lcnsMailDate":"09/16/2015","flag":false,"reason":"-","eqmsWorkItemBean":null,"emplMedicalNotClear":false,"licenseClass":"Class 8","issueDate":null,"lcnsOprnId":null,"lcnsOprnCode":null,"workFlag":"O","replaceLicence":null,"employeeName":"Castaneda, Martin A","employeeID":"0412160","reasonId":null,"serviceUnit":"LOS ANGELES","workItemId":null,"serviceUnitNbr":20,"licenseClassDesc":"Class 1,Class 6,Class 8"}],"employeeID":null}
		} catch (Exception e) {
			e.printStackTrace();
		}*/
	}

	@Test
	public void testUpdateLicenseMailedStatus() throws Exception {
		
		List<PrintTemporaryLicenseGrid> list =  new ArrayList<PrintTemporaryLicenseGrid>();
		when(printTemporaryLicense.getEmployeeID()).thenReturn(EMP_ID);
		when(printTemporaryLicenseGrid.getEmployeeID()).thenReturn(EMP_ID);
		when(printTemporaryLicenseGrid.getLicenseClass()).thenReturn("Class 8 - Freight Conductor");
		when(printTemporaryLicenseGrid.getEmployeeName()).thenReturn("Sill, Heath C");
		when(printTemporaryLicenseGrid.getServiceUnit()).thenReturn("ST. LOUIS");
		when(printTemporaryLicenseGrid.getReasonId()).thenReturn(107);
		when(printTemporaryLicenseGrid.getLcnsOprnCode()).thenReturn("PRT");
		when(printTemporaryLicenseGrid.getLcnsOprnId()).thenReturn(365140);
		when(printTemporaryLicenseGrid.getWorkItemId()).thenReturn(10937006);
		when(printTemporaryLicenseGrid.getServiceUnitNbr()).thenReturn(4);
		
		Map<String, List<String>> successFailureMap = new HashMap<String, List<String>>();
		successFailureMap.put(LicensingConstant.SUCCESS_KEY, new ArrayList<String>());
		successFailureMap.put(LicensingConstant.FAILURE_KEY, new ArrayList<String>());
		
		List<String> employeeIdList = successFailureMap.get(LicensingConstant.FAILURE_KEY);
		employeeIdList.add(printTemporaryLicenseGrid.getEmployeeID());
		successFailureMap.put(LicensingConstant.FAILURE_KEY, employeeIdList);
		
		//when(list.get(0)).thenReturn(printTemporaryLicenseGrid);
		list.add(printTemporaryLicenseGrid);
		 when(eQMSUserBean.getEmplId()).thenReturn(EMP_ID);
		 when(eQMSUserSession.getUser()).thenReturn(eQMSUserBean);
		 when(printLicenseService.updateLicenseMailedStatus(list)).thenReturn(successFailureMap);
		
		 MvcResult result = this.mockMvc.perform(post("/licensing/updateLicenseMailedStatus").contentType(MediaType.APPLICATION_JSON_VALUE)
				 .content("[{\"employeeName\":\"Sill, Heath C\",\"licenseClass\":\"Class 8 - Freight Conductor\",\"serviceUnit\":\"ST. LOUIS\",\"reasonId\":107,\"lcnsOprnCode\":\"PRT\",\"lcnsOprnId\":365140,\"employeeID\":\"0451581\",\"workItemId\":10937006,\"serviceUnitNbr\":4}]")
					.header("emplId", EMP_ID)
			        .header("ldapRoleList", LDAP_SYSTEM_ADMIN + "," + LDAP_MANAGER)).andExpect(status().isOk())
		 			/*.andExpect(jsonPath("$.success").isNotEmpty())
		 			.andExpect(jsonPath("$.success").isArray())
		 			.andExpect(jsonPath("$.success[0].employeeID",is(EMP_ID)))
		 			.andExpect(jsonPath("$.failure").isNotEmpty())*/
					.andReturn();
		 String content = result.getResponse().getContentAsString();
		
		/*try {
			
			MvcResult result = this.mockMvc.perform(post("/licensing/updateLicenseMailedStatus").contentType(MediaType.APPLICATION_JSON_VALUE)
					.content("[{\"employeeName\":\"Sill, Heath C\",\"licenseClass\":\"Class 8 - Freight Conductor\",\"serviceUnit\":\"ST. LOUIS\",\"reasonId\":107,\"lcnsOprnCode\":\"PRT\",\"lcnsOprnId\":365140,\"employeeID\":\"0451581\",\"workItemId\":10937006,\"serviceUnitNbr\":4},{\"employeeName\":\"Cole, Randy J\",\"licenseClass\":\"Class 8 - Freight Conductor\",\"serviceUnit\":\"PORTLAND\",\"reasonId\":107,\"lcnsOprnCode\":\"PRT\",\"lcnsOprnId\":365142,\"employeeID\":\"0019619\",\"workItemId\":10937008,\"serviceUnitNbr\":18},{\"employeeName\":\"Barry Jr, Wayne E\",\"licenseClass\":\"Class 8 - Freight Conductor\",\"serviceUnit\":\"LOS ANGELES\",\"reasonId\":107,\"lcnsOprnCode\":\"PRT\",\"lcnsOprnId\":365143,\"employeeID\":\"0211860\",\"workItemId\":10937009,\"serviceUnitNbr\":20}]")
					.header("emplId", EMP_ID)
			        .header("ldapRoleList", LDAP_SYSTEM_ADMIN + "," + LDAP_MANAGER)).andExpect(status().isOk())
					.andReturn();
					
					String content = result.getResponse().getContentAsString();
		} catch (Exception e) {
			e.printStackTrace();
		}*/
	}

	@Test
	@Ignore
	public void testRemoveWorkItemForPrintWorkItem() {
		
		//Return type is void 
		
	}

	@Test
	public void testGeneratePdf() {
		try {
			MvcResult result = this.mockMvc.perform(post("/licensing/generatePdf").contentType(MediaType.APPLICATION_JSON_VALUE)
					.content("{\"emplIdList\":[\"0264042\"], \"condFlag\": \"true\",\"license\":\"true\"}")
					.header("emplId", EMP_ID)
			        .header("ldapRoleList", LDAP_SYSTEM_ADMIN + "," + LDAP_MANAGER)).andExpect(status().isOk())
					.andReturn();	
			
					String content = result.getResponse().getContentAsString();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	public void testUpdatePendingActionPrintLicense() {
		
		List<PendingActionListGridDetail> detailList = new ArrayList<PendingActionListGridDetail>();
		when(pendingActionListGridDetail.getEmployeeID()).thenReturn(EMP_ID);
		detailList.add(pendingActionListGridDetail);
		//when(detailList.get(0)).thenReturn(pendingActionListGridDetail);
		when(printLicenseService.updatePendingActionPrintLicense( detailList)).thenReturn(true);
			try {
				MvcResult result =	this.mockMvc.perform(post("/licensing/updatePendingActionPrintLicense").contentType(MediaType.APPLICATION_JSON_VALUE)
						.content("[{\"employeeID\":\"0412160\", \"license\":{\"licenseClass\" :\" -Class 6\"}}]")
						.header("emplId", EMP_ID)
				        .header("ldapRoleList", LDAP_SYSTEM_ADMIN + "," + LDAP_MANAGER)).andExpect(status().isOk())
						.andExpect(jsonPath("$").isBoolean())
						.andExpect(jsonPath("$").value(is(Matchers.eq(true))))
						.andReturn();
			 String content = result.getResponse().getContentAsString();
			} catch (Exception e) {
				e.printStackTrace();
			}
	}

}
