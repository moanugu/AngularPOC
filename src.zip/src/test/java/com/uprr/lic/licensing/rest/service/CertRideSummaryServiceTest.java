package com.uprr.lic.licensing.rest.service;

import static org.fest.assertions.Assertions.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;

import com.uprr.lic.auth.EQMSUserBean;
import com.uprr.lic.auth.EQMSUserSession;
import com.uprr.lic.dataaccess.decertification.model.CategoryInformationDetail;
import com.uprr.lic.dataaccess.decertification.model.CertRideSummaryDetails;
import com.uprr.lic.dataaccess.decertification.services.interfaces.IDecertificationService;
import com.uprr.lic.licensing.rest.model.CategoryInformationDetailResponse;
import com.uprr.lic.licensing.rest.model.CertRideSummaryResponse;
import com.uprr.lic.test.base.BaseJUnit;

public class CertRideSummaryServiceTest extends BaseJUnit {

	@Mock
	private IDecertificationService decertificationService;

	@Mock
	private EQMSUserBean eqmsUserBean;

	@Mock
	private EQMSUserSession eqmsUserSession;

	@Autowired
	@InjectMocks
	private CertRideSummaryService service;

	@Test
	public void testGetSummaryDetail() {
		CertRideSummaryDetails  certRideSummaryResponse = new CertRideSummaryDetails();
		certRideSummaryResponse.setManager( "Johnson, Justin R(0407655)") ; 
		certRideSummaryResponse.setEvaluationDate("12/12/2012" ) ; 
		certRideSummaryResponse.setServiceUnit( "NART"  ) ; 
		certRideSummaryResponse.setTrainID("089786" ) ; 
		certRideSummaryResponse.setTotalLoads((long)5000) ; 
		certRideSummaryResponse.setCrewOnDutyCirc7( "crewOnDutyCirc7" ) ; 
		certRideSummaryResponse.setServiceType( "serviceType"  ) ; 
		certRideSummaryResponse.setLength((long) 1000) ; 
		certRideSummaryResponse.setSimulator("simulator"  ) ; 
		certRideSummaryResponse.setDPU("dpu" ) ; 
		certRideSummaryResponse.setForignInitial("forignInitial" ) ; 
		certRideSummaryResponse.setWeight((long)500 ) ; 
		certRideSummaryResponse.setTotalEmpties((long)500); 
		certRideSummaryResponse.setRemoteControl("remoteControl" ) ; 
		certRideSummaryResponse.setHelper("helper" ) ; 
		certRideSummaryResponse.setCrewMember( "crewMember" ) ; 
		certRideSummaryResponse.setPosition("pos") ; 
		certRideSummaryResponse.setStudent("student" ) ; 
		certRideSummaryResponse.setReason("reason" ) ; 
		certRideSummaryResponse.setTotalMiles( (long)100.00 ) ; 
		certRideSummaryResponse.setStartDate("12/12/2012" ) ; 
		certRideSummaryResponse.setStopDate( "12/12/2012" ) ; 
		certRideSummaryResponse.setOriginCirc7("originCirc7"  ) ; 
		certRideSummaryResponse.setDestCirc7("destCirc7" ) ; 
		certRideSummaryResponse.setOverAllScore(100.00 ) ; 
		certRideSummaryResponse.setTrainHandlingScore( 50 ) ; 
		certRideSummaryResponse.setMngrComments("This is test case") ;

		when(decertificationService.getSummaryDetail(any(String.class), any(Integer.class))).thenReturn(certRideSummaryResponse);

		
		CertRideSummaryResponse certRideSummary = service.getSummaryDetail("0006019",1358092);

		assertThat(certRideSummary.getManager()).isEqualTo("Johnson, Justin R(0407655)");
		assertThat(certRideSummary.getManager()).isEqualTo("Johnson, Justin R(0407655)");
		assertThat(certRideSummary.getEvaluationDate()).isEqualTo("12/12/2012");
		assertThat(certRideSummary.getServiceUnit()).isEqualTo("NART");
		assertThat(certRideSummary.getTrainID()).isEqualTo("089786");
		assertThat(certRideSummary.getTotalLoads()).isEqualTo(5000);
		assertThat(certRideSummary.getCrewOnDutyCirc7()).isEqualTo("crewOnDutyCirc7");
		assertThat(certRideSummary.getServiceType()).isEqualTo("serviceType");
		assertThat(certRideSummary.getLength()).isEqualTo(1000);
		assertThat(certRideSummary.getSimulator()).isEqualTo("simulator");
		
		assertThat(certRideSummary.getdPU()).isEqualTo("dpu");
		assertThat(certRideSummary.getMngrComments()).isEqualTo("This is test case");
		assertThat(certRideSummary.getTrainHandlingScore()).isEqualTo(50);
		assertThat(certRideSummary.getOverAllScore()).isEqualTo(100.00);
		assertThat(certRideSummary.getDestCirc7()).isEqualTo("destCirc7");
		assertThat(certRideSummary.getOriginCirc7()).isEqualTo("originCirc7");
		
		assertThat(certRideSummary.getStopDate()).isEqualTo("12/12/2012");
		assertThat(certRideSummary.getStartDate()).isEqualTo("12/12/2012");
		assertThat(certRideSummary.getTotalMiles()).isEqualTo(100);
		assertThat(certRideSummary.getReason()).isEqualTo("reason");
		assertThat(certRideSummary.getStudent()).isEqualTo("student");
		assertThat(certRideSummary.getPosition()).isEqualTo("pos");
		assertThat(certRideSummary.getForignInitial()).isEqualTo("forignInitial");
		assertThat(certRideSummary.getWeight()).isEqualTo(500);
		assertThat(certRideSummary.getTotalEmpties()).isEqualTo(500);
		assertThat(certRideSummary.getRemoteControl()).isEqualTo("remoteControl");
		
	}

	@Test
	public void testGetCategoryInformationList() {
		List<CategoryInformationDetail> categoryInformationDetailResponseList = new ArrayList<>();
		CategoryInformationDetail categoryInformationDetailResponse = new CategoryInformationDetail();
		categoryInformationDetailResponse.setCategory1("Bell") ; 
		categoryInformationDetailResponse.setAction1("P") ; 
		categoryInformationDetailResponse.setCategory2(null) ; 
		categoryInformationDetailResponse.setAction2(null) ;
		categoryInformationDetailResponseList.add(categoryInformationDetailResponse);
		when(decertificationService.getCategoryInformationList(any(String.class), any(Integer.class))).thenReturn(categoryInformationDetailResponseList);
	
		List<CategoryInformationDetailResponse> list = service.getCategoryInformationList("0006019",1358092);
		
		
		assertThat(list.get(0).getActionFirst()).isEqualTo("P");
		assertThat(list.get(0).getCategoryFirst()).isEqualTo("Bell");
		assertThat(list.get(0).getCategorySecond()).isEqualTo(null);
		assertThat(list.get(0).getActionSecond()).isEqualTo(null);
	
	}

}
