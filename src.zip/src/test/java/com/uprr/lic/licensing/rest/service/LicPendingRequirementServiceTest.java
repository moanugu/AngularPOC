package com.uprr.lic.licensing.rest.service;

import static org.fest.assertions.Assertions.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.uprr.lic.auth.EQMSUserSession;
import com.uprr.lic.config.spring.MainConfig;
import com.uprr.lic.dataaccess.components.licensing.service.LicensingServiceImpl;
import com.uprr.lic.dataaccess.masters.service.SysParamServiceImpl;
import com.uprr.lic.decert.rest.model.DropdownChoice;
import com.uprr.lic.util.DDChoice;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { MainConfig.class })
@WebAppConfiguration
public class LicPendingRequirementServiceTest {

	private MockMvc mockMvc;

	@Autowired
	private WebApplicationContext applicationContext;

	@Mock
	private LicensingServiceImpl licenseService;

	@Mock
	private EQMSUserSession eqmsUserSession;

	@Mock
	private SysParamServiceImpl sysParamService;

	@Autowired
	@InjectMocks
	private LicPendingRequirementService service;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		System.setProperty("uprr.implementation.environment", "local");
		System.setProperty("jbs.name", "localhost");
	}

	@Before
	public void setUp() throws Exception {
		this.mockMvc = MockMvcBuilders.webAppContextSetup(applicationContext).build();
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testGetLicenseClassList() {

		List<String> arrayList = Arrays.asList("Class 8", "Class 9", "Class 1", "Class 2", "Class 3", "Class 5",
				"Class 6", "Class 7");
		when(licenseService.getLicenseClassList()).thenReturn(arrayList);

		List<String> licenseClassList = service.getLicenseClassList();
		assertThat(licenseClassList.size()).isEqualTo(8);
		assertThat(licenseClassList.get(0)).isEqualTo("Class 8");
	}
	@Test
	public void testGetServiceUnitListByRegion() {
		
		List<DDChoice> mockServiceUnitList = new ArrayList<>();
		DDChoice ddChoice = new DDChoice();
		ddChoice.setIntKey(1);
		ddChoice.setStrKey("1");
		ddChoice.setValue("Chicago");
		mockServiceUnitList.add(ddChoice);
		when(licenseService.getServiceUnitListByRegion(any(Integer.class))).thenReturn(mockServiceUnitList);
		
		List<DropdownChoice> serviceUnitList = service.getServiceUnitListByRegion(1);
		assertThat(serviceUnitList.size()).isEqualTo(1);
		assertThat(serviceUnitList.get(0).getIntKey()).isEqualTo(1);
		assertThat(serviceUnitList.get(0).getStrKey()).isEqualTo("1");
		assertThat(serviceUnitList.get(0).getValue()).isEqualTo("Chicago");
	}

	/*
	 * @Test public void testGetPendingRequirementsList() { fail(
	 * "Not yet implemented"); }
	 * 
	 * @Test public void testGetServiceUnitListByRegion() { fail(
	 * "Not yet implemented"); }
	 * 
	 * @Test public void testIsExistingEmployee() { fail("Not yet implemented");
	 * }
	 * 
	 * @Test public void testGetPendingRequirementsEmpDetailsList() { fail(
	 * "Not yet implemented"); }
	 * 
	 * @Test public void testGetEmployeeLicHistoryDetails() { fail(
	 * "Not yet implemented"); }
	 * 
	 * @Test public void testGetRulesExamCodes() { fail("Not yet implemented");
	 * }
	 * 
	 * @Test public void testGetMedicalResultInteger() { fail(
	 * "Not yet implemented"); }
	 * 
	 * @Test public void testGetMedicalResultStringString() { fail(
	 * "Not yet implemented"); }
	 * 
	 * @Test public void testGetEvaluationDetailsForConductor() { fail(
	 * "Not yet implemented"); }
	 * 
	 * @Test public void testGetPinsForConductorLicense() { fail(
	 * "Not yet implemented"); }
	 * 
	 * @Test public void testCancelLicensingRequirement() { fail(
	 * "Not yet implemented"); }
	 */

}
