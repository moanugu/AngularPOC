package com.uprr.lic.licensing.rest.controller;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.isA;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.uprr.lic.config.spring.MainConfig;
import com.uprr.lic.dataaccess.Licensing.model.CoverLetterForPrintDocsTemplate;
import com.uprr.lic.dataaccess.common.model.EqmLcnsRqmt;
import com.uprr.lic.licensing.rest.model.NdrTemplateDetail;
import com.uprr.lic.licensing.rest.service.IPrintPacketService;
import com.uprr.lic.util.LicensingConstant;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { MainConfig.class })
@WebAppConfiguration
@Ignore
public class PrintPacketControllerTest {

	private static final String LDAP_SYSTEM_ADMIN = "EQM-SYSTEM-ADMIN";
	private static final String LDAP_MANAGER = "EQM_Manager";

	private MockMvc mockMvc;

	@Autowired
	private WebApplicationContext applicationContext;

	@Mock
	private IPrintPacketService printPacketService;
	
	@Autowired
	@InjectMocks
	private PrintPacketController printPacketController;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		System.setProperty("uprr.implementation.environment", "local");
		System.setProperty("jbs.name", "localhost");
	}

	@Before
	public void setUp() throws Exception {
		this.mockMvc = MockMvcBuilders.webAppContextSetup(applicationContext).build();
		MockitoAnnotations.initMocks(this);
	}


	@Test
	public void testIsStudentLicense() throws Exception {

		when(printPacketService.isStudentLicense(any(String.class))).thenReturn(true);

		this.mockMvc
		.perform(post("/licensing/isStudentLicense?").contentType(MediaType.APPLICATION_JSON_VALUE)
				.param("employeeId", "0006019")
				.header("emplId", "9000018").header("ldapRoleList", LDAP_SYSTEM_ADMIN + "," + LDAP_MANAGER))
		.andExpect(status().isOk()).andExpect(jsonPath("$").isBoolean()).andReturn();
	}

	@Test
	public void testGetAddressInfoForEmplCoverLetterFromTeradata() throws Exception {
		String  jsonString ="{\"sysLicDeptManagerName\":\"Kimberly A. Doggett\",\"state\":\"WY\",\"country\":\"US\""
				+ ",\"address1\":\"3112 terry rd\",\"address2\":\"\",\"zip\":\"82007\",\"city\":\"cheyenne\"}";
		when(printPacketService.getAddressInfoForEmplCoverLetterFromTeradata(any(String.class), any(String.class))).thenReturn((CoverLetterForPrintDocsTemplate)convertJsonStringToObject(jsonString, CoverLetterForPrintDocsTemplate.class));

		this.mockMvc
		.perform(get("/licensing/getAddressInfoForEmplCoverLetterFromTeradata?").contentType(MediaType.APPLICATION_JSON_VALUE)
				.param("employeeId", "0006019")
				.param("sysParamName", LicensingConstant.LICENSING_DEPT_MANAGER_NAME)
				.header("emplId", "9000018").header("ldapRoleList", LDAP_SYSTEM_ADMIN + "," + LDAP_MANAGER))
		.andExpect(status().isOk())
		.andExpect(jsonPath("$.sysLicDeptManagerName", is("Kimberly A. Doggett")))
		.andExpect(jsonPath("$.state", is("WY")))
		.andExpect(jsonPath("$.country", is("US")))
		.andExpect(jsonPath("$.address1", is("3112 terry rd")))
		.andExpect(jsonPath("$.zip", is("82007")))
		.andExpect(jsonPath("$.city", is("cheyenne")))
		
		.andReturn();
	}

	@Test
	public void testGetEmployeeDetailsForNDRTemplate() throws Exception {
		
		String  jsonString ="{\"employeeID\":\"0006019\", \"address\":\"3112 terry rd\", \"state\":\"\", \"licenseNumber\":\"\", \"addressCity\":\"cheyenne\", \"addressState\":\"WY\", \"addressZip\":\"82007\","
				+ " \"dateOfBirth\":\"10/31/1951\", \"weight\":0.0,\"employeeName\":\"Michael Vernon Sampeck\", \"nickName\":\"\", \"ssn\":\"\", \"heightFt\":\"\", \"heightInches\":\"\"}";
		when(printPacketService.getEmployeeDetailsForNDRTemplate("0006019")).thenReturn((NdrTemplateDetail)convertJsonStringToObject(jsonString, NdrTemplateDetail.class));

		this.mockMvc
		.perform(post("/licensing/getEmployeeDetailsForNDRTemplate?").contentType(MediaType.APPLICATION_JSON_VALUE)
				.param("employeeId", "0006019")
				.header("emplId", "9000018").header("ldapRoleList", LDAP_SYSTEM_ADMIN + "," + LDAP_MANAGER))
		.andExpect(status().isOk())
		
		.andExpect(jsonPath("$.employeeID", is("0006019")))
		.andExpect(jsonPath("$.address", is("3112 terry rd")))
		.andExpect(jsonPath("$.employeeName", is("Michael Vernon Sampeck")))
		.andExpect(jsonPath("$.address", is("3112 terry rd")))
		.andExpect(jsonPath("$.dateOfBirth", is("10/31/1951")))
		.andExpect(jsonPath("$.addressZip", is("82007")))
		.andExpect(jsonPath("$.addressCity", is("cheyenne")))
		.andReturn();
	}
	
	@Test
	public void testPrintLataPacket() throws Exception {
		
		Map<String, String> messageMap = new HashMap<>();
		messageMap.put("Success", "Success");
	
		when(printPacketService.printLataPacket(any(String.class),any(String.class))).thenReturn(messageMap);

		this.mockMvc
		.perform(post("/licensing/printLataPackets?").contentType(MediaType.APPLICATION_JSON_VALUE)
				.param("iLataNumber", "N100616")
				.header("emplId", "9000018").header("ldapRoleList", LDAP_SYSTEM_ADMIN + "," + LDAP_MANAGER))
		.andExpect(status().isOk()).andExpect(jsonPath("$.Success", is("Success")))
	
		.andReturn();
	}

	
	@Test
	public void getAOTRoleSet() throws Exception {
		
		Set<Integer> integers = new HashSet<Integer>();
		integers.add(5);
		integers.add(6);
		integers.add(7);
		integers.add(8);
		integers.add(9);
		integers.add(10);
		integers.add(11);
		when(printPacketService.getAOTRoleSet()).thenReturn(integers);

		this.mockMvc
		.perform(post("/licensing/getAOTRoleSet?").contentType(MediaType.APPLICATION_JSON_VALUE)
				.header("emplId", "9000018").header("ldapRoleList", LDAP_SYSTEM_ADMIN + "," + LDAP_MANAGER))
		.andExpect(status().isOk())
		.andReturn();
	}

	
	

	@Test
	public void testGetRecertificationInitiatedDetailsForEmployee() throws Exception {
	when(printPacketService.getRecertificationInitiatedDetailsForEmployee(any(String.class), any(String.class))).thenReturn(convertJsonArrayToList());

		this.mockMvc
		.perform(post("/licensing/getRecertificationInitiatedDetailsForEmployee?").contentType(MediaType.APPLICATION_JSON_VALUE)
				.param("employeeId", "0006019")
				.header("emplId", "9000018").header("ldapRoleList", LDAP_SYSTEM_ADMIN + "," + LDAP_MANAGER))
		.andExpect(status().isOk()).andExpect(jsonPath("$",isA(List.class))).andReturn();
	}

	private List<EqmLcnsRqmt> convertJsonArrayToList() {
		String response = "[{\"lcnsRqmtId\":143136,\"eqmDrvRcdHistByMotrDrivRcd\":null,\"eqmDrvRcdHistByNatlDrivRcd\":null,\"eqmTestDtlsByMedId\":null,\"eqmTestDtlsByRulesId\":null,\"eqmTestDtlsByStopTestId\":null,\"eqmTestDtlsByFTXEvntId\":null,\"eqmTestDtlsByKnlgExamId\":null,\"conExamFlag\":null,\"conExamType\":null,\"eqmEmplDtls\":{\"emplId\":\"0006019\",\"eqmSvcUnit\":{\"svcUnitNbr\":13,\"eqmReg\":{\"regNbr\":1,\"eqmDept\":null,\"regName\":\"NORTHERN\",\"histRcdFlag\":\"N\",\"crtnDate\":1233451368000,\"crtnEmplId\":\"0414986\",\"lastUptdDate\":1233451368000,\"lastUptdEmplId\":\"0414986\",\"rowVrsnNbr\":0,\"eqmEdrChkls\":[],\"eqmActnPlanTmpts\":[],\"eqmSvcUnits\":[],\"eqmEmplRoleAreas\":[]},\"svcUnitName\":\"NORTH PLATTE\",\"svcUnitCode\":\"NP\",\"histRcdFlag\":\"N\",\"crtnDate\":1233452435000,\"crtnEmplId\":\"0414986\",\"lastUptdDate\":1233452435000,\"lastUptdEmplId\":\"0414986\",\"rowVrsnNbr\":0,\"eqmSvcUnitOvrdHistsForOldSvcUnitNbr\":null,\"eqmWunts\":null,\"eqmActnPlanTmpts\":null,\"eqmEvntDtlses\":null,\"eqmEmplDtlsHists\":null,\"eqmEmplRoleAreas\":null,\"eqmSvcUnitOvrdHistsForNewSvcUnitNbr\":null,\"eqmAsgnDtlses\":null,\"eqmEmplDtlses\":null,\"eqmLcnsInits\":null,\"eqmBitEvnt\":null,\"eqmBitEvntDtlsForEvnt\":null,\"eqmBitEvntDtls\":null,\"eqmThrcYardSvcUnitMpng\":null},\"emplLastName\":\"SAMPECK\",\"emplFirName\":\"MICHAEL\",\"emplMidName\":\"VERNON\",\"cmtsStatCode\":\"OD\",\"emplCrc7\":\"WX510\",\"actFlag\":\"Y\",\"emplBordName\":\"XE04\",\"histRcdFlag\":\"N\",\"agrmNaInd\":\"Y\",\"birDate\":-573456600000,\"crftCode\":\"E\",\"waveFlag\":\"N\",\"ovrdFlag\":\"N\",\"emplHireDate\":215634600000,\"cntrFlag\":\"N\",\"ertCode\":\"E\",\"emplStatCode\":\"A\",\"crtnDate\":1248286893000,\"crtnEmplId\":\"9999999\",\"lastUptdDate\":1493857882000,\"lastUptdEmplId\":\"EQMS999\",\"rowVrsnNbr\":2908,\"ovrdErtDate\":null,\"eqmActnPlanEmplMps\":null,\"ovrdErtFlag\":\"N\",\"jobCode\":\"TEY617\",\"posTitle\":\"ENGINEER\",\"workCity\":null,\"deptDesc\":\"TRANSPORTATION NORTHERN REGION\",\"posNbr\":null,\"ovrdErtCode\":\"E\",\"emplTotlScorNbr\":997,\"emplScorCalcDate\":1493836200000,\"deptCode\":69,\"eqmDsgnRvkeReqs\":null,\"eqmWuntMgrMpngs\":null,\"eqmDcrtOthEvntDtlses\":null,\"eqmLcnsRqmts\":null,\"eqmEmplCmntDtlsesForActnTakeBy\":null,\"eqmLcnsDtlses\":null,\"eqmPackDtlsesForEmplId\":null,\"eqmSvcUnitOvrdHists\":null,\"eqmTestDtlses\":null,\"eqmEvntCmntDtlses\":null,\"eqmEmplDocs\":null,\"eqmAsgnDtlsesForMgrId\":null,\"eqmDrvRcdHistsForEmplId\":null,\"eqmLcnsOprns\":null,\"eqmEmplDtlsHists\":null,\"eqmRmdlTrngDtlses\":[],\"eqmEmplRoleMpngs\":null,\"eqmDenyDtlses\":[],\"eqmPackDtlsesForActnTakeBy\":null,\"eqmLcnsPrntDtlses\":null,\"eqmDrvRcdHistsForActnTakeBy\":null,\"eqmEmplEvntDtlses\":null,\"eqmEmplCmntDtlsesForEmplId\":null,\"eqmDcrtEmplStats\":[],\"eqmEdrEmplMpngs\":null,\"eqmEmplSleDsgns\":null,\"eqmAsgnDtlsesForEmplId\":null,\"eqmChngClases\":[],\"eqmFaxDtls\":[],\"eqmEmplRestDtlses\":[],\"eqmEmplPndgRuDtlses\":null,\"eqmFtxMgrGrpEmpls\":null,\"eqmFtxEmplPlanMpngs\":null,\"eqmFtxEmplGoalMpngs\":null,\"eqmFtxEmplCatgRules\":null,\"eqmFtxPlanTracs\":null,\"eqmUserMsgsAckm\":[],\"eqmFteUserAccs\":null,\"eqmThrcStatDtls\":null,\"eqmThrcCrewDtls\":null,\"eqmBitEvntEmplDtls\":null},\"eqmTestDtlsByOr6aRslt\":null,\"eqmLcnsClas\":{\"lcnsClasCode\":\"Class 8\",\"eqmJobType\":null,\"clasDesc\":\"Freight Conductor\",\"parClasCode\":\"Class 8\",\"prntLcnsFlag\":\"Y\",\"histRcdFlag\":\"N\",\"crtnDate\":1311666320000,\"crtnEmplId\":\"DEQM999\",\"lastUptdDate\":1311666320000,\"lastUptdEmplId\":\"DEQM999\",\"rowVrsnNbr\":0,\"eqmLcnsDtlses\":null,\"eqmLcnsInitRqmts\":null,\"eqmLcnsOprns\":null,\"eqmLcnsRqmts\":null},\"eqmSkilGrd\":null,\"certRideFlag\":null,\"reCertFlag\":\"Y\",\"histRcdFlag\":\"N\",\"crtnDate\":1496354093000,\"crtnEmplId\":\"DEQM999\",\"lastUptdDate\":1496354093000,\"lastUptdEmplId\":\"DEQM999\",\"rowVrsnNbr\":0,\"eqmPackDtlses\":null,\"eqmLcnsOprns\":null,\"evntEmplSeq\":null},{\"lcnsRqmtId\":142825,\"eqmDrvRcdHistByMotrDrivRcd\":null,\"eqmDrvRcdHistByNatlDrivRcd\":null,\"eqmTestDtlsByMedId\":null,\"eqmTestDtlsByRulesId\":null,\"eqmTestDtlsByStopTestId\":null,\"eqmTestDtlsByFTXEvntId\":null,\"eqmTestDtlsByKnlgExamId\":null,\"conExamFlag\":null,\"conExamType\":null,\"eqmEmplDtls\":{\"emplId\":\"0006019\",\"eqmSvcUnit\":{\"svcUnitNbr\":13,\"eqmReg\":{\"regNbr\":1,\"eqmDept\":null,\"regName\":\"NORTHERN\",\"histRcdFlag\":\"N\",\"crtnDate\":1233451368000,\"crtnEmplId\":\"0414986\",\"lastUptdDate\":1233451368000,\"lastUptdEmplId\":\"0414986\",\"rowVrsnNbr\":0,\"eqmEdrChkls\":[],\"eqmActnPlanTmpts\":[],\"eqmSvcUnits\":[],\"eqmEmplRoleAreas\":[]},\"svcUnitName\":\"NORTH PLATTE\",\"svcUnitCode\":\"NP\",\"histRcdFlag\":\"N\",\"crtnDate\":1233452435000,\"crtnEmplId\":\"0414986\",\"lastUptdDate\":1233452435000,\"lastUptdEmplId\":\"0414986\",\"rowVrsnNbr\":0,\"eqmSvcUnitOvrdHistsForOldSvcUnitNbr\":null,\"eqmWunts\":null,\"eqmActnPlanTmpts\":null,\"eqmEvntDtlses\":null,\"eqmEmplDtlsHists\":null,\"eqmEmplRoleAreas\":null,\"eqmSvcUnitOvrdHistsForNewSvcUnitNbr\":null,\"eqmAsgnDtlses\":null,\"eqmEmplDtlses\":null,\"eqmLcnsInits\":null,\"eqmBitEvnt\":null,\"eqmBitEvntDtlsForEvnt\":null,\"eqmBitEvntDtls\":null,\"eqmThrcYardSvcUnitMpng\":null},\"emplLastName\":\"SAMPECK\",\"emplFirName\":\"MICHAEL\",\"emplMidName\":\"VERNON\",\"cmtsStatCode\":\"OD\",\"emplCrc7\":\"WX510\",\"actFlag\":\"Y\",\"emplBordName\":\"XE04\",\"histRcdFlag\":\"N\",\"agrmNaInd\":\"Y\",\"birDate\":-573456600000,\"crftCode\":\"E\",\"waveFlag\":\"N\",\"ovrdFlag\":\"N\",\"emplHireDate\":215634600000,\"cntrFlag\":\"N\",\"ertCode\":\"E\",\"emplStatCode\":\"A\",\"crtnDate\":1248286893000,\"crtnEmplId\":\"9999999\",\"lastUptdDate\":1493857882000,\"lastUptdEmplId\":\"EQMS999\",\"rowVrsnNbr\":2908,\"ovrdErtDate\":null,\"eqmActnPlanEmplMps\":null,\"ovrdErtFlag\":\"N\",\"jobCode\":\"TEY617\",\"posTitle\":\"ENGINEER\",\"workCity\":null,\"deptDesc\":\"TRANSPORTATION NORTHERN REGION\",\"posNbr\":null,\"ovrdErtCode\":\"E\",\"emplTotlScorNbr\":997,\"emplScorCalcDate\":1493836200000,\"deptCode\":69,\"eqmDsgnRvkeReqs\":null,\"eqmWuntMgrMpngs\":null,\"eqmDcrtOthEvntDtlses\":null,\"eqmLcnsRqmts\":null,\"eqmEmplCmntDtlsesForActnTakeBy\":null,\"eqmLcnsDtlses\":null,\"eqmPackDtlsesForEmplId\":null,\"eqmSvcUnitOvrdHists\":null,\"eqmTestDtlses\":null,\"eqmEvntCmntDtlses\":null,\"eqmEmplDocs\":null,\"eqmAsgnDtlsesForMgrId\":null,\"eqmDrvRcdHistsForEmplId\":null,\"eqmLcnsOprns\":null,\"eqmEmplDtlsHists\":null,\"eqmRmdlTrngDtlses\":[],\"eqmEmplRoleMpngs\":null,\"eqmDenyDtlses\":[],\"eqmPackDtlsesForActnTakeBy\":null,\"eqmLcnsPrntDtlses\":null,\"eqmDrvRcdHistsForActnTakeBy\":null,\"eqmEmplEvntDtlses\":null,\"eqmEmplCmntDtlsesForEmplId\":null,\"eqmDcrtEmplStats\":[],\"eqmEdrEmplMpngs\":null,\"eqmEmplSleDsgns\":null,\"eqmAsgnDtlsesForEmplId\":null,\"eqmChngClases\":[],\"eqmFaxDtls\":[],\"eqmEmplRestDtlses\":[],\"eqmEmplPndgRuDtlses\":null,\"eqmFtxMgrGrpEmpls\":null,\"eqmFtxEmplPlanMpngs\":null,\"eqmFtxEmplGoalMpngs\":null,\"eqmFtxEmplCatgRules\":null,\"eqmFtxPlanTracs\":null,\"eqmUserMsgsAckm\":[],\"eqmFteUserAccs\":null,\"eqmThrcStatDtls\":null,\"eqmThrcCrewDtls\":null,\"eqmBitEvntEmplDtls\":null},\"eqmTestDtlsByOr6aRslt\":null,\"eqmLcnsClas\":{\"lcnsClasCode\":\"Class 1\",\"eqmJobType\":null,\"clasDesc\":\"Engineer\",\"parClasCode\":\"Class 1\",\"prntLcnsFlag\":\"Y\",\"histRcdFlag\":\"N\",\"crtnDate\":1233677558000,\"crtnEmplId\":\"0414986\",\"lastUptdDate\":1233677558000,\"lastUptdEmplId\":\"0414986\",\"rowVrsnNbr\":0,\"eqmLcnsDtlses\":null,\"eqmLcnsInitRqmts\":null,\"eqmLcnsOprns\":null,\"eqmLcnsRqmts\":null},\"eqmSkilGrd\":null,\"certRideFlag\":\"E\",\"reCertFlag\":\"Y\",\"histRcdFlag\":\"N\",\"crtnDate\":1496352201000,\"crtnEmplId\":\"DEQM999\",\"lastUptdDate\":1496352201000,\"lastUptdEmplId\":\"DEQM999\",\"rowVrsnNbr\":0,\"eqmPackDtlses\":null,\"eqmLcnsOprns\":null,\"evntEmplSeq\":null}]";
		
		List<EqmLcnsRqmt> responseList = null;
		try {
			ObjectMapper mapper = new ObjectMapper();
			responseList  = mapper.readValue(response, new TypeReference<List<EqmLcnsRqmt>>() {});
		} catch (IOException e) {
			e.printStackTrace();
		}
		return  responseList;
	}
	
	private Object convertJsonStringToObject(String jsonString, Class<?> className) {
		
		Object object = null;
		try {
			ObjectMapper mapper = new ObjectMapper();
			object  = mapper.readValue(jsonString, className);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return  object;
	}
	
}
