package com.uprr.lic.licensing.rest.service;

import static org.fest.assertions.Assertions.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;

import com.uprr.lic.auth.EQMSUserBean;
import com.uprr.lic.auth.EQMSUserSession;
import com.uprr.lic.dataaccess.common.model.EqmLcnsInit;
import com.uprr.lic.dataaccess.components.licensing.service.ILicensingService;
import com.uprr.lic.test.base.BaseJUnit;

public class PrintDocsServiceTest extends BaseJUnit {
	
	@Mock
	private ILicensingService licensingService;
	
	@Mock
	private EQMSUserBean eqmsUserBean;
	
	@Mock
	Map<Boolean, Integer> map;
	
	@Mock
	private EQMSUserSession eqmsUserSession;
	
	@Autowired
	@InjectMocks
	private PrintDocsService printDocsService;
	
	
	@Override
	public void setUp() throws Exception {
		super.setUp();
		when(eqmsUserBean.getEmplId()).thenReturn("9000018");
		when(eqmsUserSession.getUser()).thenReturn(eqmsUserBean);
	}

	@Test
	public void testInsertPacketPrintingDetailsWithValidation() {
		
		List<String> arrayList = Arrays.asList("Class 8", "Class 9", "Class 1", "Class 2", "Class 3", "Class 5",
				"Class 6", "Class 7");
		when(licensingService.insertPacketPrintingDetailsWithValidation(any(String.class),any(String.class), any(String.class))).thenReturn(arrayList);
	
		List<String> listOfString =printDocsService.insertPacketPrintingDetailsWithValidation("0298376", "0298376");
	
		assertThat(listOfString.size()).isEqualTo(8);
		assertThat(listOfString).isEqualTo(arrayList);
	}

	@Test
	public void testGetEmployeesLicenseInitiationDetails() {
		
		when(licensingService.getEmployeesLicenseInitiationDetails(any(Integer.class))).thenReturn("License Found");
		String listOfString =printDocsService.getEmployeesLicenseInitiationDetails(1);
		assertThat(listOfString).isEqualTo("License Found");
	}

	@Test
	public void testUpdatePendingActionMarkAsPacketSent() {
		when(licensingService.updatePendingActionMarkAsPacketSent(any(String.class), any(String.class), any(Integer.class), any(Integer.class), any(Integer.class), any(String.class))).thenReturn("License Found");
	
		String listOfString =printDocsService.updatePendingActionMarkAsPacketSent("2089898", "Class 8", 1, 10, 10);
	
		assertThat(listOfString).isEqualTo("License Found");
	}

	@Test
	public void testGetInitDtlsByOprnId() {
		
		when(licensingService.getInitDtlsByOprnId(any(Integer.class))).thenReturn( new EqmLcnsInit());
	
		EqmLcnsInit eqmLcnsInitReponse =printDocsService.getInitDtlsByOprnId(976);
	
		assertThat(eqmLcnsInitReponse.getLcnsInitId()).isEqualTo(null);

		assertThat(eqmLcnsInitReponse.getEqmLcnsOprn()).isEqualTo(null);

		assertThat(eqmLcnsInitReponse.getStrtDt()).isEqualTo(null);

		assertThat(eqmLcnsInitReponse.getCity()).isEqualTo(null);

		assertThat(eqmLcnsInitReponse.getClasNbr()).isEqualTo(null);

		assertThat(eqmLcnsInitReponse.getSt()).isEqualTo(null);

		assertThat(eqmLcnsInitReponse.getClasDesc()).isEqualTo(null);

		assertThat(eqmLcnsInitReponse.getBulLoc()).isEqualTo(null);

		assertThat(eqmLcnsInitReponse.getMgrTrne()).isEqualTo(null);

		assertThat(eqmLcnsInitReponse.getCrtnDate()).isEqualTo(null);

		assertThat(eqmLcnsInitReponse.getCrtnEmplId()).isEqualTo(null);

		assertThat(eqmLcnsInitReponse.getLastUptdDate()).isEqualTo(null);

		assertThat(eqmLcnsInitReponse.getLastUptdEmplId()).isEqualTo(null);

		assertThat(eqmLcnsInitReponse.getRowVrsnNbr()).isEqualTo(0);

		assertThat(eqmLcnsInitReponse.getEqmSvcUnit()).isEqualTo(null);
		assertThat(eqmLcnsInitReponse.getEqmLcnsOprn()).isEqualTo(null);
	}

	@Test
	public void testGetOprnIdforExistingLicense() {
		
		Map<Boolean, Integer> map = new HashMap<Boolean, Integer>();
		map.put(true, 1);
		map.put(false, 2);
		
		when(licensingService.getOprnIdforExistingLicense((any(String.class)))).thenReturn(map);
	
		Map<Boolean, Integer> reponseMap =printDocsService.getOprnIdforExistingLicense("0298376");
	
		assertThat(reponseMap.size()).isEqualTo(2);
		assertThat(reponseMap.get(true)).isEqualTo(1);
		assertThat(map.get(false)).isEqualTo(2);
	}

	@Test
	public void testIsRecertificationInitiatedForEmployee() {
		when(licensingService.isRecertificationInitiatedForEmployee(any(String.class),any(String.class), any(Integer.class))).thenReturn(true);
	
		Boolean listOfString =printDocsService.isRecertificationInitiatedForEmployee("0298376", "Class 6", 1);
	
		assertThat(listOfString).isEqualTo(true);
	}

}
