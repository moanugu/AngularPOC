package com.uprr.lic.licensing.rest.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.uprr.lic.auth.EQMSUserBean;
import com.uprr.lic.auth.EQMSUserSession;
import com.uprr.lic.config.spring.MainConfig;
import com.uprr.lic.dataaccess.Licensing.model.PendingActionListGridDetail;
import com.uprr.lic.dataaccess.Licensing.model.PrintTemporaryLicense;
import com.uprr.lic.dataaccess.Licensing.model.PrintTemporaryLicenseGrid;
import com.uprr.lic.dataaccess.components.licensing.service.LicensingServiceImpl;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { MainConfig.class })
@WebAppConfiguration
public class PrintLicenseServiceTest {
	
private static final String EMP_ID = "9000018";
	
	private MockMvc mockMvc;
	
	@Autowired
	private WebApplicationContext applicationContext;
	
	@Mock
	private PrintTemporaryLicense printTemporaryLicense;
	
	@Mock
	private EQMSUserSession eqmsUserSession;
	
	@Mock
	private LicensingServiceImpl licensingService;
	
	@Mock
	private PrintTemporaryLicenseGrid printTemporaryLicenseGrid;
	
	@Mock
	private PendingActionListGridDetail pendingActionListGridDetail;
	
	@Mock
	private EQMSUserBean eQMSUserBean;
	
	@InjectMocks
	private PrintLicenseService printLicenseService;
		 
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		System.setProperty("uprr.implementation.environment", "local");
		 System.setProperty("jbs.name", "localhost");
	}

	
	
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		this.mockMvc = MockMvcBuilders.webAppContextSetup(applicationContext).build();
		MockitoAnnotations.initMocks(this);
		when(eQMSUserBean.getEmplId()).thenReturn(EMP_ID); 
		when(eqmsUserSession.getUser()).thenReturn(eQMSUserBean);
		when(printTemporaryLicense.getEmployeeID()).thenReturn(EMP_ID);
		when(printTemporaryLicense.getPrintCount()).thenReturn(1);		
		when(printTemporaryLicense.getEmployeeID()).thenReturn(EMP_ID);
		when(printTemporaryLicenseGrid.getEmployeeID()).thenReturn(EMP_ID);
		when(printTemporaryLicenseGrid.getLicenseClass()).thenReturn("Class 8");
		when(printTemporaryLicenseGrid.getEmployeeName()).thenReturn("Ravi");
		 
	}

	@Test
	public void testIsExpnDateSameForAllLcns() {
		when(licensingService.isExpnDateSameForAllLcns(EMP_ID)).thenReturn(true);
		Boolean result = printLicenseService.isExpnDateSameForAllLcns(EMP_ID);
		assertThat(result).isEqualTo(true);
	}

	@Test
	public void testGetPrintLicenseService() {
		List<PrintTemporaryLicenseGrid> list =  new ArrayList<PrintTemporaryLicenseGrid>();		
		list.add(printTemporaryLicenseGrid);
		when(printTemporaryLicense.getPrintTemporaryLicenseGridAll()).thenReturn(list);		
		when(licensingService.getPrintLicenseService(printTemporaryLicense, 1, EMP_ID, "true", eqmsUserSession.getUser().getEmplId())).thenReturn(printTemporaryLicense);
		
		PrintTemporaryLicense result = licensingService.getPrintLicenseService(printTemporaryLicense, 1, EMP_ID, "true", eqmsUserSession.getUser().getEmplId());
		assertThat(result.getEmployeeID()).isEqualTo(EMP_ID);
		assertThat(result.getPrintCount()).isEqualTo(1);
		assertThat(result.getPrintTemporaryLicenseGridAll()).isEqualTo(list);
		
	}

	@Test
	public void testUpdateLicenseMailedStatus() {
		String[] emailIds ={"test@up.com"};
		when(licensingService.updateLicenseMailedStatus(printTemporaryLicenseGrid,emailIds,  eqmsUserSession.getUser().getEmplId())).thenReturn(1);
		Integer result = licensingService.updateLicenseMailedStatus(printTemporaryLicenseGrid,emailIds,  eqmsUserSession.getUser().getEmplId());
		assertThat(result).isEqualTo(1);
	}

	//@Test(expected = Exception.class)
	@Test //It's a void method 
	public void testRemoveWorkItemForPrintWorkItem() {
		List<String> empIds = Arrays.asList(EMP_ID);
		licensingService.removeWorkItemForPrintWorkItem(empIds,"true",1,  eqmsUserSession.getUser().getEmplId());
	}

	@Test
	public void testUpdatePendingActionPrintLicense() {
		List<PendingActionListGridDetail> list =  new ArrayList<PendingActionListGridDetail>();	
		list.add(pendingActionListGridDetail);
		when(licensingService.updatePendingActionPrintLicense(list,eqmsUserSession.getUser().getEmplId())).thenReturn(true);
		Boolean result = licensingService.updatePendingActionPrintLicense(list,eqmsUserSession.getUser().getEmplId());
		assertThat(result).isEqualTo(true);
	}

}
