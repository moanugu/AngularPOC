package com.uprr.lic.licensing.rest.service;
import static org.fest.assertions.Assertions.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.uprr.lic.auth.EQMSUserBean;
import com.uprr.lic.auth.EQMSUserSession;
import com.uprr.lic.config.spring.MainConfig;
import com.uprr.lic.dataaccess.Licensing.model.CoverLetterForPrintDocsTemplate;
import com.uprr.lic.dataaccess.Licensing.model.NdrTemplatePageDetail;
import com.uprr.lic.dataaccess.common.model.EqmLcnsRqmt;
import com.uprr.lic.dataaccess.common.model.EqmSysParm;
import com.uprr.lic.dataaccess.components.licensing.service.ILicensingService;
import com.uprr.lic.licensing.rest.model.NdrTemplateDetail;
import com.uprr.lic.util.LicensingConstant;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { MainConfig.class })
@WebAppConfiguration
public class PrintPacketServiceTest {


	//private MockMvc mockMvc;

	/*@Autowired
	private WebApplicationContext applicationContext;*/

	@Mock
	private ILicensingService licensingService;

	@Mock
	private EqmSysParm eqmSysParm;
	
	@Mock
	private EQMSUserBean eqmsUserBean;
	
	@Mock
	private EQMSUserSession eqmsUserSession;

	@Autowired
	@InjectMocks
	private PrintPacketService printPacketService;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		System.setProperty("uprr.implementation.environment", "local");
		System.setProperty("jbs.name", "localhost");
	}

	@Before
	public void setUp() throws Exception {
		//	this.mockMvc = MockMvcBuilders.webAppContextSetup(applicationContext).build();
		MockitoAnnotations.initMocks(this);

		when(eqmSysParm.getParmValu()).thenReturn("Test ParamValue");
		when(eqmsUserBean.getEmplId()).thenReturn("9000018");
		when(eqmsUserSession.getUser()).thenReturn(eqmsUserBean);
	}


	@Test
	public void testIsStudentLicense() throws Exception {

		when(licensingService.isStudentLicense(any(String.class))).thenReturn(true);

		boolean isStudent = printPacketService.isStudentLicense("0006019");
		assertThat(isStudent).isEqualTo(true);

	}

	@Test
	public void testGetAddressInfoForEmplCoverLetterFromTeradata() throws Exception {

		when(licensingService.getSysParmValue(any(String.class))).thenReturn(eqmSysParm);
		String  jsonString ="{\"sysLicDeptManagerName\":\"Kimberly A. Doggett\",\"state\":\"WY\",\"country\":\"US\",\"address1\":\"3112 terry rd\",\"address2\":\"\",\"zip\":\"82007\",\"city\":\"cheyenne\"}";
		when(licensingService.getAddressInfoForEmplCoverLetterFromTeradata(any(String.class), any(String.class))).thenReturn((CoverLetterForPrintDocsTemplate)convertJsonStringToObject(jsonString, CoverLetterForPrintDocsTemplate.class));


		CoverLetterForPrintDocsTemplate coverLetterForPrintDocsTemplate = printPacketService.getAddressInfoForEmplCoverLetterFromTeradata("0006019", LicensingConstant.LICENSING_DEPT_MANAGER_NAME);
		assertThat(coverLetterForPrintDocsTemplate.getAddress1()).isEqualTo("3112 terry rd");
		assertThat(coverLetterForPrintDocsTemplate.getCity()).isEqualTo("cheyenne");
		assertThat(coverLetterForPrintDocsTemplate.getState()).isEqualTo("WY");
		assertThat(coverLetterForPrintDocsTemplate.getCountry()).isEqualTo("US");
		assertThat(coverLetterForPrintDocsTemplate.getSysLicDeptManagerName()).isEqualTo("Kimberly A. Doggett");
		assertThat(coverLetterForPrintDocsTemplate.getZip()).isEqualTo("82007");
		assertThat(coverLetterForPrintDocsTemplate.getAddress2()).isEqualTo("");
	}

	@Test
	public void testGetEmployeeDetailsForNDRTemplate() throws Exception {

		String  jsonString ="{\"employeeID\":\"0006019\", \"address\":\"3112 terry rd\", \"state\":\"\", \"licenseNumber\":\"\", \"addressCity\":\"cheyenne\", \"addressState\":\"WY\", \"addressZip\":\"82007\", \"dateOfBirth\":\"10/31/1951\", \"weight\":0.0,\"employeeName\":\"Michael Vernon Sampeck\", \"nickName\":\"\", \"ssn\":\"\", \"heightFt\":\"\", \"heightInches\":\"\"}";
		when(licensingService.getEmployeeDetailsForNDRTemplate(any(String.class))).thenReturn((NdrTemplatePageDetail)convertJsonStringToObject(jsonString, NdrTemplatePageDetail.class));

		NdrTemplateDetail coverLetterForPrintDocsTemplate = printPacketService.getEmployeeDetailsForNDRTemplate("0006019");
		assertThat(coverLetterForPrintDocsTemplate.getAddress()).isEqualTo("3112 terry rd");
		assertThat(coverLetterForPrintDocsTemplate.getEmployeeID()).isEqualTo("0006019");
		assertThat(coverLetterForPrintDocsTemplate.getEmployeeName()).isEqualTo("Michael Vernon Sampeck");
	}

	@Test
	public void testGetRecertificationInitiatedDetailsForEmployee() throws Exception {
		when(licensingService.getRecertificationInitiatedDetailsForEmployee(any(String.class), any(String.class))).thenReturn(convertJsonArrayToList());

		List<EqmLcnsRqmt> listOfData = printPacketService.getRecertificationInitiatedDetailsForEmployee("0006019", "Class 8");

		assertThat(listOfData.size()).isEqualTo(2);
		assertThat(listOfData.get(0).getLcnsRqmtId()).isEqualTo(143136);
		assertThat(listOfData.get(0).getEqmDrvRcdHistByMotrDrivRcd()).isEqualTo(null);
		assertThat(listOfData.get(0).getEqmDrvRcdHistByNatlDrivRcd()).isEqualTo(null);
		assertThat(listOfData.get(0).getEqmTestDtlsByMedId()).isEqualTo(null);
		assertThat(listOfData.get(0).getEqmTestDtlsByRulesId()).isEqualTo(null);
		assertThat(listOfData.get(0).getEqmTestDtlsByStopTestId()).isEqualTo(null);
		assertThat(listOfData.get(0).getEqmTestDtlsByFTXEvntId()).isEqualTo(null);
		assertThat(listOfData.get(0).getEqmTestDtlsByKnlgExamId()).isEqualTo(null);
		assertThat(listOfData.get(0).getConExamFlag()).isEqualTo(null);
		assertThat(listOfData.get(0).getConExamType()).isEqualTo(null);
		assertThat(listOfData.get(0).getEqmSkilGrd()).isEqualTo(null);
		assertThat(listOfData.get(0).getCertRideFlag()).isEqualTo(null);
		assertThat(listOfData.get(0).getReCertFlag()).isEqualTo("Y");
		assertThat(listOfData.get(0).getHistRcdFlag()).isEqualTo("N");
		assertThat(listOfData.get(0).getCrtnEmplId()).isEqualTo("DEQM999");
		assertThat(listOfData.get(0).getLastUptdEmplId()).isEqualTo("DEQM999");
		assertThat(listOfData.get(0).getRowVrsnNbr()).isEqualTo(0);
		assertThat(listOfData.get(0).getEqmPackDtlses()).isEqualTo(null);
		assertThat(listOfData.get(0).getEqmLcnsOprns()).isEqualTo(null);
		assertThat(listOfData.get(0).getEvntEmplSeq()).isEqualTo(null);

	}
	
	@Test
	public void getAOTRoleSet() throws Exception {
		
		Set<Integer> integers = new HashSet<Integer>();
		integers.add(5);
		integers.add(6);
		integers.add(7);
		integers.add(8);
		integers.add(9);
		integers.add(10);
		integers.add(11);
		
		when(licensingService.getAOTRoleSet(any(String.class))).thenReturn(integers);
		Set<Integer> integersResponse = printPacketService.getAOTRoleSet();
		assertThat(integersResponse.size()).isEqualTo(7);
		assertThat(integersResponse.containsAll(integers)).isEqualTo(true);
	}

	private List<EqmLcnsRqmt> convertJsonArrayToList() {
		String response = "[{\"lcnsRqmtId\":143136,\"eqmDrvRcdHistByMotrDrivRcd\":null,\"eqmDrvRcdHistByNatlDrivRcd\":null,\"eqmTestDtlsByMedId\":null,\"eqmTestDtlsByRulesId\":null,\"eqmTestDtlsByStopTestId\":null,\"eqmTestDtlsByFTXEvntId\":null,\"eqmTestDtlsByKnlgExamId\":null,\"conExamFlag\":null,\"conExamType\":null,\"eqmEmplDtls\":{\"emplId\":\"0006019\",\"eqmSvcUnit\":{\"svcUnitNbr\":13,\"eqmReg\":{\"regNbr\":1,\"eqmDept\":null,\"regName\":\"NORTHERN\",\"histRcdFlag\":\"N\",\"crtnDate\":1233451368000,\"crtnEmplId\":\"0414986\",\"lastUptdDate\":1233451368000,\"lastUptdEmplId\":\"0414986\",\"rowVrsnNbr\":0,\"eqmEdrChkls\":[],\"eqmActnPlanTmpts\":[],\"eqmSvcUnits\":[],\"eqmEmplRoleAreas\":[]},\"svcUnitName\":\"NORTH PLATTE\",\"svcUnitCode\":\"NP\",\"histRcdFlag\":\"N\",\"crtnDate\":1233452435000,\"crtnEmplId\":\"0414986\",\"lastUptdDate\":1233452435000,\"lastUptdEmplId\":\"0414986\",\"rowVrsnNbr\":0,\"eqmSvcUnitOvrdHistsForOldSvcUnitNbr\":null,\"eqmWunts\":null,\"eqmActnPlanTmpts\":null,\"eqmEvntDtlses\":null,\"eqmEmplDtlsHists\":null,\"eqmEmplRoleAreas\":null,\"eqmSvcUnitOvrdHistsForNewSvcUnitNbr\":null,\"eqmAsgnDtlses\":null,\"eqmEmplDtlses\":null,\"eqmLcnsInits\":null,\"eqmBitEvnt\":null,\"eqmBitEvntDtlsForEvnt\":null,\"eqmBitEvntDtls\":null,\"eqmThrcYardSvcUnitMpng\":null},\"emplLastName\":\"SAMPECK\",\"emplFirName\":\"MICHAEL\",\"emplMidName\":\"VERNON\",\"cmtsStatCode\":\"OD\",\"emplCrc7\":\"WX510\",\"actFlag\":\"Y\",\"emplBordName\":\"XE04\",\"histRcdFlag\":\"N\",\"agrmNaInd\":\"Y\",\"birDate\":-573456600000,\"crftCode\":\"E\",\"waveFlag\":\"N\",\"ovrdFlag\":\"N\",\"emplHireDate\":215634600000,\"cntrFlag\":\"N\",\"ertCode\":\"E\",\"emplStatCode\":\"A\",\"crtnDate\":1248286893000,\"crtnEmplId\":\"9999999\",\"lastUptdDate\":1493857882000,\"lastUptdEmplId\":\"EQMS999\",\"rowVrsnNbr\":2908,\"ovrdErtDate\":null,\"eqmActnPlanEmplMps\":null,\"ovrdErtFlag\":\"N\",\"jobCode\":\"TEY617\",\"posTitle\":\"ENGINEER\",\"workCity\":null,\"deptDesc\":\"TRANSPORTATION NORTHERN REGION\",\"posNbr\":null,\"ovrdErtCode\":\"E\",\"emplTotlScorNbr\":997,\"emplScorCalcDate\":1493836200000,\"deptCode\":69,\"eqmDsgnRvkeReqs\":null,\"eqmWuntMgrMpngs\":null,\"eqmDcrtOthEvntDtlses\":null,\"eqmLcnsRqmts\":null,\"eqmEmplCmntDtlsesForActnTakeBy\":null,\"eqmLcnsDtlses\":null,\"eqmPackDtlsesForEmplId\":null,\"eqmSvcUnitOvrdHists\":null,\"eqmTestDtlses\":null,\"eqmEvntCmntDtlses\":null,\"eqmEmplDocs\":null,\"eqmAsgnDtlsesForMgrId\":null,\"eqmDrvRcdHistsForEmplId\":null,\"eqmLcnsOprns\":null,\"eqmEmplDtlsHists\":null,\"eqmRmdlTrngDtlses\":[],\"eqmEmplRoleMpngs\":null,\"eqmDenyDtlses\":[],\"eqmPackDtlsesForActnTakeBy\":null,\"eqmLcnsPrntDtlses\":null,\"eqmDrvRcdHistsForActnTakeBy\":null,\"eqmEmplEvntDtlses\":null,\"eqmEmplCmntDtlsesForEmplId\":null,\"eqmDcrtEmplStats\":[],\"eqmEdrEmplMpngs\":null,\"eqmEmplSleDsgns\":null,\"eqmAsgnDtlsesForEmplId\":null,\"eqmChngClases\":[],\"eqmFaxDtls\":[],\"eqmEmplRestDtlses\":[],\"eqmEmplPndgRuDtlses\":null,\"eqmFtxMgrGrpEmpls\":null,\"eqmFtxEmplPlanMpngs\":null,\"eqmFtxEmplGoalMpngs\":null,\"eqmFtxEmplCatgRules\":null,\"eqmFtxPlanTracs\":null,\"eqmUserMsgsAckm\":[],\"eqmFteUserAccs\":null,\"eqmThrcStatDtls\":null,\"eqmThrcCrewDtls\":null,\"eqmBitEvntEmplDtls\":null},\"eqmTestDtlsByOr6aRslt\":null,\"eqmLcnsClas\":{\"lcnsClasCode\":\"Class 8\",\"eqmJobType\":null,\"clasDesc\":\"Freight Conductor\",\"parClasCode\":\"Class 8\",\"prntLcnsFlag\":\"Y\",\"histRcdFlag\":\"N\",\"crtnDate\":1311666320000,\"crtnEmplId\":\"DEQM999\",\"lastUptdDate\":1311666320000,\"lastUptdEmplId\":\"DEQM999\",\"rowVrsnNbr\":0,\"eqmLcnsDtlses\":null,\"eqmLcnsInitRqmts\":null,\"eqmLcnsOprns\":null,\"eqmLcnsRqmts\":null},\"eqmSkilGrd\":null,\"certRideFlag\":null,\"reCertFlag\":\"Y\",\"histRcdFlag\":\"N\",\"crtnDate\":1496354093000,\"crtnEmplId\":\"DEQM999\",\"lastUptdDate\":1496354093000,\"lastUptdEmplId\":\"DEQM999\",\"rowVrsnNbr\":0,\"eqmPackDtlses\":null,\"eqmLcnsOprns\":null,\"evntEmplSeq\":null},{\"lcnsRqmtId\":142825,\"eqmDrvRcdHistByMotrDrivRcd\":null,\"eqmDrvRcdHistByNatlDrivRcd\":null,\"eqmTestDtlsByMedId\":null,\"eqmTestDtlsByRulesId\":null,\"eqmTestDtlsByStopTestId\":null,\"eqmTestDtlsByFTXEvntId\":null,\"eqmTestDtlsByKnlgExamId\":null,\"conExamFlag\":null,\"conExamType\":null,\"eqmEmplDtls\":{\"emplId\":\"0006019\",\"eqmSvcUnit\":{\"svcUnitNbr\":13,\"eqmReg\":{\"regNbr\":1,\"eqmDept\":null,\"regName\":\"NORTHERN\",\"histRcdFlag\":\"N\",\"crtnDate\":1233451368000,\"crtnEmplId\":\"0414986\",\"lastUptdDate\":1233451368000,\"lastUptdEmplId\":\"0414986\",\"rowVrsnNbr\":0,\"eqmEdrChkls\":[],\"eqmActnPlanTmpts\":[],\"eqmSvcUnits\":[],\"eqmEmplRoleAreas\":[]},\"svcUnitName\":\"NORTH PLATTE\",\"svcUnitCode\":\"NP\",\"histRcdFlag\":\"N\",\"crtnDate\":1233452435000,\"crtnEmplId\":\"0414986\",\"lastUptdDate\":1233452435000,\"lastUptdEmplId\":\"0414986\",\"rowVrsnNbr\":0,\"eqmSvcUnitOvrdHistsForOldSvcUnitNbr\":null,\"eqmWunts\":null,\"eqmActnPlanTmpts\":null,\"eqmEvntDtlses\":null,\"eqmEmplDtlsHists\":null,\"eqmEmplRoleAreas\":null,\"eqmSvcUnitOvrdHistsForNewSvcUnitNbr\":null,\"eqmAsgnDtlses\":null,\"eqmEmplDtlses\":null,\"eqmLcnsInits\":null,\"eqmBitEvnt\":null,\"eqmBitEvntDtlsForEvnt\":null,\"eqmBitEvntDtls\":null,\"eqmThrcYardSvcUnitMpng\":null},\"emplLastName\":\"SAMPECK\",\"emplFirName\":\"MICHAEL\",\"emplMidName\":\"VERNON\",\"cmtsStatCode\":\"OD\",\"emplCrc7\":\"WX510\",\"actFlag\":\"Y\",\"emplBordName\":\"XE04\",\"histRcdFlag\":\"N\",\"agrmNaInd\":\"Y\",\"birDate\":-573456600000,\"crftCode\":\"E\",\"waveFlag\":\"N\",\"ovrdFlag\":\"N\",\"emplHireDate\":215634600000,\"cntrFlag\":\"N\",\"ertCode\":\"E\",\"emplStatCode\":\"A\",\"crtnDate\":1248286893000,\"crtnEmplId\":\"9999999\",\"lastUptdDate\":1493857882000,\"lastUptdEmplId\":\"EQMS999\",\"rowVrsnNbr\":2908,\"ovrdErtDate\":null,\"eqmActnPlanEmplMps\":null,\"ovrdErtFlag\":\"N\",\"jobCode\":\"TEY617\",\"posTitle\":\"ENGINEER\",\"workCity\":null,\"deptDesc\":\"TRANSPORTATION NORTHERN REGION\",\"posNbr\":null,\"ovrdErtCode\":\"E\",\"emplTotlScorNbr\":997,\"emplScorCalcDate\":1493836200000,\"deptCode\":69,\"eqmDsgnRvkeReqs\":null,\"eqmWuntMgrMpngs\":null,\"eqmDcrtOthEvntDtlses\":null,\"eqmLcnsRqmts\":null,\"eqmEmplCmntDtlsesForActnTakeBy\":null,\"eqmLcnsDtlses\":null,\"eqmPackDtlsesForEmplId\":null,\"eqmSvcUnitOvrdHists\":null,\"eqmTestDtlses\":null,\"eqmEvntCmntDtlses\":null,\"eqmEmplDocs\":null,\"eqmAsgnDtlsesForMgrId\":null,\"eqmDrvRcdHistsForEmplId\":null,\"eqmLcnsOprns\":null,\"eqmEmplDtlsHists\":null,\"eqmRmdlTrngDtlses\":[],\"eqmEmplRoleMpngs\":null,\"eqmDenyDtlses\":[],\"eqmPackDtlsesForActnTakeBy\":null,\"eqmLcnsPrntDtlses\":null,\"eqmDrvRcdHistsForActnTakeBy\":null,\"eqmEmplEvntDtlses\":null,\"eqmEmplCmntDtlsesForEmplId\":null,\"eqmDcrtEmplStats\":[],\"eqmEdrEmplMpngs\":null,\"eqmEmplSleDsgns\":null,\"eqmAsgnDtlsesForEmplId\":null,\"eqmChngClases\":[],\"eqmFaxDtls\":[],\"eqmEmplRestDtlses\":[],\"eqmEmplPndgRuDtlses\":null,\"eqmFtxMgrGrpEmpls\":null,\"eqmFtxEmplPlanMpngs\":null,\"eqmFtxEmplGoalMpngs\":null,\"eqmFtxEmplCatgRules\":null,\"eqmFtxPlanTracs\":null,\"eqmUserMsgsAckm\":[],\"eqmFteUserAccs\":null,\"eqmThrcStatDtls\":null,\"eqmThrcCrewDtls\":null,\"eqmBitEvntEmplDtls\":null},\"eqmTestDtlsByOr6aRslt\":null,\"eqmLcnsClas\":{\"lcnsClasCode\":\"Class 1\",\"eqmJobType\":null,\"clasDesc\":\"Engineer\",\"parClasCode\":\"Class 1\",\"prntLcnsFlag\":\"Y\",\"histRcdFlag\":\"N\",\"crtnDate\":1233677558000,\"crtnEmplId\":\"0414986\",\"lastUptdDate\":1233677558000,\"lastUptdEmplId\":\"0414986\",\"rowVrsnNbr\":0,\"eqmLcnsDtlses\":null,\"eqmLcnsInitRqmts\":null,\"eqmLcnsOprns\":null,\"eqmLcnsRqmts\":null},\"eqmSkilGrd\":null,\"certRideFlag\":\"E\",\"reCertFlag\":\"Y\",\"histRcdFlag\":\"N\",\"crtnDate\":1496352201000,\"crtnEmplId\":\"DEQM999\",\"lastUptdDate\":1496352201000,\"lastUptdEmplId\":\"DEQM999\",\"rowVrsnNbr\":0,\"eqmPackDtlses\":null,\"eqmLcnsOprns\":null,\"evntEmplSeq\":null}]";

		List<EqmLcnsRqmt> responseList = null;
		try {
			ObjectMapper mapper = new ObjectMapper();
			responseList  = mapper.readValue(response, new TypeReference<List<EqmLcnsRqmt>>() {});
		} catch (IOException e) {
			e.printStackTrace();
		}
		return  responseList;
	}

	private Object convertJsonStringToObject(String jsonString, Class<?> className) {

		Object object = null;
		try {
			ObjectMapper mapper = new ObjectMapper();
			object  = mapper.readValue(jsonString, className);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return  object;
	}

}
