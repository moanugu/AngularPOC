package com.uprr.lic.licensing.rest.controller;

import static org.hamcrest.Matchers.is;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Ignore;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;

import com.uprr.lic.dataaccess.common.model.EqmSysParm;
import com.uprr.lic.licensing.rest.service.ILicensingCommonRestService;
import com.uprr.lic.test.base.BaseJUnit;

@Ignore
public class LicensingCommonControllerTest extends BaseJUnit {

	@Mock
	private ILicensingCommonRestService licPendingRequirementService;

	@Autowired
	@InjectMocks
	private LicensingCommonController controller;
	
	@Test
	public void testGetSysParmValue() throws Exception {
		
		EqmSysParm eqmsSysParm = new EqmSysParm();
		eqmsSysParm.setParmValu("Mock Testing");
		eqmsSysParm.setHistRcdFlag("N");
		eqmsSysParm.setLastUptdEmplId("N");
		eqmsSysParm.setParmName("Yes");
	
		
		when(licPendingRequirementService.getSysParmValue(any(String.class))).thenReturn(eqmsSysParm);
		this.mockMvc
		.perform(post("/licensing/getSysParmValue?").contentType(MediaType.APPLICATION_JSON_VALUE)
				.param("sysParamName", "Yes")
				.header("emplId", "9000018").header("ldapRoleList", LDAP_SYSTEM_ADMIN + "," + LDAP_MANAGER))
		.andExpect(status().isOk()).andExpect(jsonPath("$.parmValu", is("Mock Testing"))).andReturn();
	}

}
