package com.uprr.lic.licensing.rest.service;

import static org.fest.assertions.Assertions.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.List;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.uprr.lic.auth.EQMSUserSession;
import com.uprr.lic.config.spring.MainConfig;
import com.uprr.lic.dataaccess.common.model.EqmEmplDtls;
import com.uprr.lic.dataaccess.twic.model.TwicBean;
import com.uprr.lic.dataaccess.twic.service.TwicService;
import com.uprr.lic.licensing.rest.model.TwicDetailResponse;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { MainConfig.class })
@WebAppConfiguration
public class TwicRestServiceTest {

	private MockMvc mockMvc;

	@Autowired
	private WebApplicationContext applicationContext;

	@Mock
	private TwicService twicService;

	@Mock
	private EQMSUserSession eqmsUserSession;


	@Autowired
	@InjectMocks
	private TwicRestService service;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		System.setProperty("uprr.implementation.environment", "local");
		System.setProperty("jbs.name", "localhost");
	}

	@Before
	public void setUp() throws Exception {
		this.mockMvc = MockMvcBuilders.webAppContextSetup(applicationContext).build();
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testGetEmplName() {
		when(twicService.getEmplName(any(String.class))).thenReturn(convertJsonArrayToList());
		List<EqmEmplDtls> employeeList = service.getEmplName("0298376");
		
		assertThat(employeeList.size()).isEqualTo(1);
		assertThat(employeeList.get(0).getEmplId()).isEqualTo("0298376");
		assertThat(employeeList.containsAll(convertJsonArrayToList())).isEqualTo(true);
	}

	@Test
	@Ignore
	public void testSubmitTwicDetails() {
		//when(twicService.submitTwicDetails(any(List.class), any(String.class), any(Integer.class))).thenReturn((TwicBean)convertJsonStringToObject(mockResponseString, TwicBean.class));

	}

	@Test
	public void testGetTwicDtls() {
		String mockResponseString = "{\"employeeID\":null,\"empFirstName\":null,\"empMiddleName\":null,\"empLastName\":null,\"expireDate\":null,\"renewCheckbox\":false,\"employeeName\":null,\"updateFlag\":false}";
		when(twicService.getTwicDtls(any(String.class))).thenReturn((TwicBean)convertJsonStringToObject(mockResponseString, TwicBean.class));
		TwicDetailResponse twicBean = service.getTwicDtls("0298376");
		
		assertThat(twicBean.getEmpFirstName()).isEqualTo(null);
		assertThat(twicBean.getEmpLastName()).isEqualTo(null);
		assertThat(twicBean.getEmployeeID()).isEqualTo(null);
		assertThat(twicBean.getEmpMiddleName()).isEqualTo(null);
		assertThat(twicBean.getExpireDate()).isEqualTo(null);
		assertThat(twicBean.isRenewCheckbox()).isEqualTo(false);
	
	}
	
	private Object convertJsonStringToObject(String jsonString, Class<?> className) {

		Object object = null;
		try {
			ObjectMapper mapper = new ObjectMapper();
			object  = mapper.readValue(jsonString, className);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return  object;
	}

	private List<EqmEmplDtls> convertJsonArrayToList() {
		String mockedResponseString = "[{\"emplId\":\"0298376\",\"eqmSvcUnit\":{\"svcUnitNbr\":6,\"eqmReg\":null,\"svcUnitName\":null,\"svcUnitCode\":null,\"histRcdFlag\":\"N\",\"crtnDate\":null,\"crtnEmplId\":null,\"lastUptdDate\":null,\"lastUptdEmplId\":null,\"rowVrsnNbr\":0,\"eqmSvcUnitOvrdHistsForOldSvcUnitNbr\":[],\"eqmWunts\":[],\"eqmActnPlanTmpts\":[],\"eqmEvntDtlses\":[],\"eqmEmplDtlsHists\":[],\"eqmEmplRoleAreas\":[],\"eqmSvcUnitOvrdHistsForNewSvcUnitNbr\":[],\"eqmAsgnDtlses\":[],\"eqmEmplDtlses\":[],\"eqmLcnsInits\":[],\"eqmBitEvnt\":[],\"eqmBitEvntDtlsForEvnt\":[],\"eqmBitEvntDtls\":[],\"eqmThrcYardSvcUnitMpng\":[]},\"emplLastName\":\"LAWRENCE\",\"emplFirName\":\"BRYAN\",\"emplMidName\":\"GREGORY\",\"cmtsStatCode\":null,\"emplCrc7\":null,\"actFlag\":\"N\",\"emplBordName\":null,\"histRcdFlag\":\"N\",\"agrmNaInd\":\"Y\",\"birDate\":null,\"crftCode\":null,\"waveFlag\":\"N\",\"ovrdFlag\":\"N\",\"emplHireDate\":null,\"cntrFlag\":\"N\",\"ertCode\":null,\"emplStatCode\":null,\"crtnDate\":null,\"crtnEmplId\":null,\"lastUptdDate\":null,\"lastUptdEmplId\":null,\"rowVrsnNbr\":0,\"ovrdErtDate\":null,\"eqmActnPlanEmplMps\":[],\"ovrdErtFlag\":\"N\",\"jobCode\":null,\"posTitle\":null,\"workCity\":null,\"deptDesc\":null,\"posNbr\":null,\"ovrdErtCode\":null,\"emplTotlScorNbr\":null,\"emplScorCalcDate\":null,\"deptCode\":null,\"eqmDsgnRvkeReqs\":[],\"eqmWuntMgrMpngs\":[],\"eqmDcrtOthEvntDtlses\":[],\"eqmLcnsRqmts\":[],\"eqmEmplCmntDtlsesForActnTakeBy\":[],\"eqmLcnsDtlses\":[],\"eqmPackDtlsesForEmplId\":[],\"eqmSvcUnitOvrdHists\":[],\"eqmTestDtlses\":[],\"eqmEvntCmntDtlses\":[],\"eqmEmplDocs\":[],\"eqmAsgnDtlsesForMgrId\":[],\"eqmDrvRcdHistsForEmplId\":[],\"eqmLcnsOprns\":[],\"eqmEmplDtlsHists\":[],\"eqmRmdlTrngDtlses\":[],\"eqmEmplRoleMpngs\":[],\"eqmDenyDtlses\":[],\"eqmPackDtlsesForActnTakeBy\":[],\"eqmLcnsPrntDtlses\":[],\"eqmDrvRcdHistsForActnTakeBy\":[],\"eqmEmplEvntDtlses\":[],\"eqmEmplCmntDtlsesForEmplId\":[],\"eqmDcrtEmplStats\":[],\"eqmEdrEmplMpngs\":[],\"eqmEmplSleDsgns\":[],\"eqmAsgnDtlsesForEmplId\":[],\"eqmChngClases\":[],\"eqmFaxDtls\":[],\"eqmEmplRestDtlses\":[],\"eqmEmplPndgRuDtlses\":[],\"eqmFtxMgrGrpEmpls\":[],\"eqmFtxEmplPlanMpngs\":[],\"eqmFtxEmplGoalMpngs\":[],\"eqmFtxEmplCatgRules\":[],\"eqmFtxPlanTracs\":[],\"eqmUserMsgsAckm\":[],\"eqmFteUserAccs\":[],\"eqmThrcStatDtls\":[],\"eqmThrcCrewDtls\":[],\"eqmBitEvntEmplDtls\":[]}]";

		List<EqmEmplDtls> responseList = null;
		try {
			ObjectMapper mapper = new ObjectMapper();
			responseList  = mapper.readValue(mockedResponseString, new TypeReference<List<EqmEmplDtls>>() {});
		} catch (IOException e) {
			e.printStackTrace();
		}
		return  responseList;
	}

}
