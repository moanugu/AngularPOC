package com.uprr.lic.licensing.rest.service;

import static org.fest.assertions.Assertions.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;

import com.uprr.lic.dataaccess.common.model.EqmSysParm;
import com.uprr.lic.dataaccess.components.licensing.service.ILicensingService;
import com.uprr.lic.test.base.BaseJUnit;

public class LicensingCommonRestServiceTest extends BaseJUnit {

	@Mock
	private ILicensingService licensing;
	
	@Autowired
	@InjectMocks
	private LicensingCommonRestService  licensingCommonRestService;

	@Test
	public void testGetSysParmValue() {
		
		EqmSysParm eqmsSysParm = new EqmSysParm();
		eqmsSysParm.setParmValu("Mock Testing");
		eqmsSysParm.setHistRcdFlag("N");
		eqmsSysParm.setLastUptdEmplId("N");
		eqmsSysParm.setParmName("Yes");
	
		
		when(licensing.getSysParmValue(any(String.class))).thenReturn(eqmsSysParm);
		
		EqmSysParm eqmsSysParmResponse = licensingCommonRestService.getSysParmValue("MVR_START_VALIDITY");
		
		assertThat(eqmsSysParmResponse.getParmValu()).isEqualTo("Mock Testing");
		assertThat(eqmsSysParmResponse.getHistRcdFlag()).isEqualTo("N");
		assertThat(eqmsSysParmResponse.getLastUptdEmplId()).isEqualTo("N");
		assertThat(eqmsSysParmResponse.getParmName()).isEqualTo("Yes");
	}

}
