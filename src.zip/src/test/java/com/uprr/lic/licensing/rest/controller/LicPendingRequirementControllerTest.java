package com.uprr.lic.licensing.rest.controller;

import static org.hamcrest.Matchers.is;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Arrays;
import java.util.List;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.uprr.lic.config.spring.MainConfig;
import com.uprr.lic.dataaccess.Licensing.model.PendingRequirementResult;
import com.uprr.lic.licensing.rest.service.LicPendingRequirementService;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { MainConfig.class })
@WebAppConfiguration
@Ignore
public class LicPendingRequirementControllerTest {

	private static final String LDAP_SYSTEM_ADMIN = "EQM-SYSTEM-ADMIN";
	private static final String LDAP_MANAGER = "EQM_Manager";

	private MockMvc mockMvc;

	@Autowired
	private WebApplicationContext applicationContext;

	@Mock
	LicPendingRequirementService licPendingRequirementService;

	@Autowired
	@InjectMocks
	private LicPendingRequirementController controller;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		System.setProperty("uprr.implementation.environment", "local");
		System.setProperty("jbs.name", "localhost");
	}

	@Before
	public void setUp() throws Exception {
		this.mockMvc = MockMvcBuilders.webAppContextSetup(applicationContext).build();
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testGetLicenseClassList() throws Exception {
		List<String> arrayList = Arrays.asList("Class 8", "Class 9", "Class 1", "Class 2", "Class 3", "Class 5",
				"Class 6", "Class 7");

		when(licPendingRequirementService.getLicenseClassList()).thenReturn(
				Arrays.asList("Class 8", "Class 9", "Class 1", "Class 2", "Class 3", "Class 5", "Class 6", "Class 7"));
		this.mockMvc
		.perform(get("/licensing/getLicenseClassList").contentType(MediaType.APPLICATION_JSON_VALUE)
				.header("emplId", "9000018").header("ldapRoleList", LDAP_SYSTEM_ADMIN + "," + LDAP_MANAGER))
		.andExpect(status().isOk()).andExpect(jsonPath("$", is(arrayList))).andReturn();
	}
	/*
	 @Test public void testGetPendingRequirementsList() throws Exception {
	 ArrayList<String> pendingRequirementsList = new ArrayList<String>();

	 * pendingRequirementsList.add(LicensingConstant.OPTION_NEW_LCNS_REQ);
	 * pendingRequirementsList.add(LicensingConstant.OPTION_RECERT_REQ);
	 * 
	 * this.mockMvc
	 * .perform(get("/licensing/getPendingRequirementsList").contentType(
	 * MediaType.APPLICATION_JSON_VALUE) .header("emplId",
	 * "9000018").header("ldapRoleList", LDAP_SYSTEM_ADMIN + "," +
	 * LDAP_MANAGER)) .andExpect(status().isOk()).andExpect(jsonPath("$",
	 * is(pendingRequirementsList))).andReturn(); }
	 * 
	 * @Test public void testGetServiceUnitListByRegion_Intermodal() throws
	 * Exception {
	 * 
	 * this.mockMvc
	 * .perform(get("/licensing/getServiceUnitListByRegion/1").contentType(
	 * MediaType.APPLICATION_JSON_VALUE) .header("emplId",
	 * "9000018").header("ldapRoleList", LDAP_SYSTEM_ADMIN + "," +
	 * LDAP_MANAGER))
	 * .andExpect(status().isOk()).andExpect(jsonPath("$").isArray())
	 * .andExpect(jsonPath("$[0].intKey", is(101))).andReturn(); }
	 * 
	 * @Test public void testGetServiceUnitListByRegion_NORTHERN() throws
	 * Exception {
	 * 
	 * this.mockMvc
	 * .perform(get("/licensing/getServiceUnitListByRegion/2").contentType(
	 * MediaType.APPLICATION_JSON_VALUE) .header("emplId",
	 * "9000018").header("ldapRoleList", LDAP_SYSTEM_ADMIN + "," +
	 * LDAP_MANAGER))
	 * .andExpect(status().isOk()).andExpect(jsonPath("$").isArray()).andExpect(
	 * jsonPath("$[0].intKey", is(1))) .andReturn(); }
	 * 
	 * @Test public void testGetServiceUnitListByRegion_SOUTHERN() throws
	 * Exception {
	 * 
	 * this.mockMvc
	 * .perform(get("/licensing/getServiceUnitListByRegion/3").contentType(
	 * MediaType.APPLICATION_JSON_VALUE) .header("emplId",
	 * "9000018").header("ldapRoleList", LDAP_SYSTEM_ADMIN + "," +
	 * LDAP_MANAGER))
	 * .andExpect(status().isOk()).andExpect(jsonPath("$").isArray()).andExpect(
	 * jsonPath("$[0].intKey", is(6))) .andReturn();
	 * 
	 * }
	 * 
	 * @Test public void testGetServiceUnitListByRegion_WESTERN() throws
	 * Exception {
	 * 
	 * this.mockMvc
	 * .perform(get("/licensing/getServiceUnitListByRegion/4").contentType(
	 * MediaType.APPLICATION_JSON_VALUE) .header("emplId",
	 * "9000018").header("ldapRoleList", LDAP_SYSTEM_ADMIN + "," +
	 * LDAP_MANAGER))
	 * .andExpect(status().isOk()).andExpect(jsonPath("$").isArray())
	 * .andExpect(jsonPath("$[0].intKey", is(16))).andReturn();
	 * 
	 * }
	 * 
	 * @Test public void testGetServiceUnitListByRegion_OPERATING() throws
	 * Exception {
	 * 
	 * // TODO this.mockMvc
	 * .perform(get("/licensing/getServiceUnitListByRegion/" + "TODO")
	 * .contentType(MediaType.APPLICATION_JSON_VALUE).header("emplId",
	 * "9000018") .header("ldapRoleList", LDAP_SYSTEM_ADMIN + "," +
	 * LDAP_MANAGER))
	 * .andExpect(status().isOk()).andExpect(jsonPath("$").isArray())
	 * .andExpect(jsonPath("$[0].intKey", is(75))).andReturn();
	 * 
	 * }
	 */
	@Test public void testIsExistingEmployee() throws Exception {
		this.mockMvc
		.perform(get("/licensing/isExistingEmployee/0045172").contentType(
				MediaType.APPLICATION_JSON_VALUE) .header("emplId",
						"9000018").header("ldapRoleList", LDAP_SYSTEM_ADMIN + "," +
								LDAP_MANAGER)) .andExpect(status().isOk()).andExpect(jsonPath("$",
										is(false))).andReturn(); 
	}

	@Test public void testIsNotExistingEmployee() throws Exception {
		this.mockMvc
		.perform(get("/licensing/isExistingEmployee/0006019").contentType(
				MediaType.APPLICATION_JSON_VALUE) .header("emplId",
						"9000018").header("ldapRoleList", LDAP_SYSTEM_ADMIN + "," +
								LDAP_MANAGER)) .andExpect(status().isOk()).andExpect(jsonPath("$",
										is(false))).andReturn();

	}

	// This is a FTX event so testId should be null and ftxEvntTestId should
	// be null vice versa

	/* @Test public void
	 * testGetPendingRequirementsEmpDetailsList_With_employeeID() throws
	 * Exception { MvcResult result = this.mockMvc
	 * .perform(post("/licensing/getPendingRequirementsEmpDetailsList")
	 * .contentType(MediaType.APPLICATION_JSON_VALUE).content(
	 * "{\"employeeID\":\"0000518\"}") .header("emplId",
	 * "9000018").header("ldapRoleList", LDAP_SYSTEM_ADMIN + "," +
	 * LDAP_MANAGER))
	 * .andExpect(status().isOk()).andExpect(jsonPath("$").isArray())
	 * .andExpect(jsonPath("$[0].employeeName", is("Holland, Mark H")))
	 * .andExpect(jsonPath("$[0].serviceUnitNbr", is(18)))
	 * .andExpect(jsonPath("$[0].serviceUnit", is("PORTLAND")))
	 * .andExpect(jsonPath("$[0].lcnsRqmtId", is(143066)))
	 * .andExpect(jsonPath("$[0].testId", is(IsNull.nullValue())))
	 * .andExpect(jsonPath("$[0].ftxEvntTestId", is(1786884))).andReturn();
	 * 
	 * // This is a FTX event so testId should be null and ftxEvntTestId should
	 * not // be null vice versa
	 * 
	 * @Test public void
	 * testGetPendingRequirementsEmpDetailsList_With_License_Class_9() throws
	 * Exception { MvcResult result = this.mockMvc
	 * .perform(post("/licensing/getPendingRequirementsEmpDetailsList")
	 * .contentType(MediaType.APPLICATION_JSON_VALUE).content(
	 * "{\"licenseClass\":\"Class 9\"}") .header("emplId",
	 * "9000018").header("ldapRoleList", LDAP_SYSTEM_ADMIN + "," +
	 * LDAP_MANAGER))
	 * .andExpect(status().isOk()).andExpect(jsonPath("$").isArray()).andReturn(
	 * 
	 * MvcResult result = this.mockMvc
	 * .perform(get("/licensing/getEmployeeLicHistoryDetails/0000518")
	 * .contentType(MediaType.APPLICATION_JSON_VALUE).header("emplId",
	 * "9000018") .header("ldapRoleList", LDAP_SYSTEM_ADMIN + "," +
	 * LDAP_MANAGER))
	 * .andExpect(status().isOk()).andExpect(jsonPath("$.employeeId",
	 * is(IsNull.nullValue()))) .andExpect(jsonPath("$.managerId",
	 * is("0000518"))) .andExpect(jsonPath("$.employeeName", is(
	 * "Holland, Mark H(0000518)"))) .andExpect(jsonPath("$.serviceUnit",
	 * is("PORTLAND"))).andExpect(jsonPath("$.licenseList").isArray())
	 * .andExpect(jsonPath("$.licenseList[0].licenseClass", is("Class 2-Hostler"
	 * ))) .andExpect(jsonPath("$.licenseList[0].issueDate", is("10/30/1992")))
	 * .andExpect(jsonPath("$.licenseList[0].effectiveDate", is("10/30/1992")))
	 * .andExpect(jsonPath("$.licenseList[0].expireDate", is("10/31/1992")))
	 * .andExpect(jsonPath("$.licenseList[0].issuedBy", is("")))
	 * .andExpect(jsonPath("$.licenseList[0].reason", is("Not Certified")))
	 * .andExpect(jsonPath("$.licenseList[1].licenseClass", is(
	 * "Class 8-Freight Conductor")))
	 * .andExpect(jsonPath("$.licenseList[1].issueDate", is("11/05/2014")))
	 * .andExpect(jsonPath("$.licenseList[1].effectiveDate", is("11/05/2014")))
	 * .andExpect(jsonPath("$.licenseList[1].expireDate", is("10/31/2017")))
	 * .andExpect(jsonPath("$.licenseList[1].issuedBy", is("Beckwith, Edward E"
	 * ))) .andExpect(jsonPath("$.licenseList[1].reason",
	 * is(IsNull.nullValue()))).andReturn();
	 * 
	 *//**
	 * If requirement id is not valid then We will get HTTP status 500
	 * 
	 * @throws Exception
	 */
	/*
	 * @Test public void testGetMedicalResultInteger_NA() throws Exception {
	 * MvcResult result = this.mockMvc
	 * .perform(get("/licensing/getMedicalResult/143066").contentType(MediaType.
	 * APPLICATION_JSON_VALUE) .header("emplId",
	 * "9000018").header("ldapRoleList", LDAP_SYSTEM_ADMIN + "," +
	 * LDAP_MANAGER)) .andExpect(status().is(500)).andReturn();
	 * 
	 * }
	 * 
	 * @Test public void testGetMedicalResultInteger_PASS_FAIL() throws
	 * Exception { MvcResult result = this.mockMvc
	 * .perform(get("/licensing/getMedicalResult/143410").contentType(MediaType.
	 * APPLICATION_JSON_VALUE) .header("emplId",
	 * "9000018").header("ldapRoleList", LDAP_SYSTEM_ADMIN + "," +
	 * LDAP_MANAGER)) .andExpect(status().isOk()).andExpect(jsonPath("$.empId",
	 * is(IsNull.nullValue()))) .andExpect(jsonPath("$.medical.medicalDate",
	 * is("04/11/2017"))) .andExpect(jsonPath("$.medical.medicalResult",
	 * is("Pass"))) .andExpect(jsonPath("$.medical.medicalRestriction",
	 * is(IsNull.nullValue()))) .andExpect(jsonPath("$.medical.type",
	 * is(IsNull.nullValue()))) .andExpect(jsonPath("$.medical.restriction", is(
	 * "CLDVB-Corrective Lens - Dist Vision Both Eyes, ")))
	 * 
	 * .andReturn();
	 * 
	 * }
	 * 
	 * @Test public void testGetMedicalResultString() throws Exception {
	 * MvcResult result = this.mockMvc .perform(get(
	 * "/licensing/getMedicalResult/0095192/Class 7")
	 * .contentType(MediaType.APPLICATION_JSON_VALUE).header("emplId",
	 * "9000018") .header("ldapRoleList", LDAP_SYSTEM_ADMIN + "," +
	 * LDAP_MANAGER)) .andExpect(status().isOk()).andExpect(jsonPath("$.empId",
	 * is(IsNull.nullValue()))) .andExpect(jsonPath("$.medical.medicalDate",
	 * is("01/20/2017"))) .andExpect(jsonPath("$.medical.medicalResult",
	 * is("Pass"))) .andExpect(jsonPath("$.medical.medicalRestriction",
	 * is(IsNull.nullValue()))) .andExpect(jsonPath("$.medical.type",
	 * is(IsNull.nullValue()))) .andExpect(jsonPath("$.medical.restriction",
	 * is("-"))).andReturn();
	 * 
	 *//**
	 * This test case will get fail due to license code is class-8
	 * 
	 * @throws Exception
	 */
	/*
	 * @Test(expected = IllegalArgumentException.class) public void
	 * testGetPinsForConductorLicense_otherThanClass9() throws Exception {
	 * this.mockMvc
	 * .perform(post("/licensing/getPinsForConductorLicense").contentType(
	 * MediaType.APPLICATION_JSON_VALUE) .content(
	 * "{\"employeeID\":\"0000518\",\"employeeName\":\"Holland, Mark H\",\"serviceUnit\":\"PORTLAND\",\"serviceUnitNbr\":18,\"licenseClass\":\"Class 8\",\"medicalResult\":\"NA\",\"rulesResult\":\"NA\",\"certRideResult\":\"NR\",\"mvrResult\":\"Inc\",\"ndrResult\":\"NR\",\"rules\":null,\"lcnsRqmtId\":143066,\"licenseClassDesc\":\"Class 8 - Freight Conductor\",\"checkWorkItemForMvrOrNdr\":false,\"checkWorkItemForPeaMvr\":false,\"checkWorkItemForPeaNdr\":false,\"employeeAlreadyLicensedFlag\":false,\"jobTypeCode\":\"CON\",\"testId\":null,\"ftxEventResult\":\"Pass\",\"conExamFlag\":\"NR\",\"condLicType\":\"NR\",\"ftxEvntTestId\":1786884,\"ftxEvntQlfnCodeId\":9,\"ftxEventDate\":\"01/23/2017\",\"or6aExamResult\":\"NR\",\"or6aExamDate\":null,\"description\":null,\"knlgExamResult\":\"NA\",\"knlgExamDate\":\"NA\",\"knlgExamType\":null,\"ertCode\":\"T\",\"agrmntFlag\":\"Agreement\",\"reCertFlag\":\"Recertification\",\"opccValue\":\"NR\",\"oprcValue\":\"NR\",\"opecValue\":\"NR\",\"rcnmCode\":\"NR\"}"
	 * ) .header("emplId", "9000018").header("ldapRoleList", LDAP_SYSTEM_ADMIN +
	 * "," + LDAP_MANAGER)) .andExpect(status().isOk()).andExpect(jsonPath("$",
	 * is(false))).andReturn(); }
	 * 
	 *//**
	 * This test case will get fail due to license code is class-8
	 * 
	 * @throws Exception
	 */
	/*
	 * @Test public void testGetPinsForConductorLicense_forLicenseClass9()
	 * throws Exception { this.mockMvc
	 * .perform(post("/licensing/getPinsForConductorLicense").contentType(
	 * MediaType.APPLICATION_JSON_VALUE) .content(
	 * "{\"employeeID\":\"0045301\",\"employeeName\":\"Stemp, B. E\",\"serviceUnit\":\"CHICAGO\",\"serviceUnitNbr\":2,\"licenseClass\":\"Class 9\",\"medicalResult\":\"Pass\",\"rulesResult\":\"Pass\",\"certRideResult\":\"NR\",\"mvrResult\":\"Pass\",\"ndrResult\":\"NR\",\"rules\":null,\"lcnsRqmtId\":53956,\"licenseClassDesc\":\"Class 9 - Passenger Conductor\",\"checkWorkItemForMvrOrNdr\":false,\"checkWorkItemForPeaMvr\":false,\"checkWorkItemForPeaNdr\":false,\"employeeAlreadyLicensedFlag\":false,\"jobTypeCode\":\"CON\",\"testId\":null,\"ftxEventResult\":\"NR\",\"conExamFlag\":\"NA\",\"condLicType\":\"Passenger Conductor\",\"ftxEvntTestId\":null,\"ftxEvntQlfnCodeId\":null,\"ftxEventDate\":null,\"or6aExamResult\":\"NR\",\"or6aExamDate\":null,\"description\":null,\"knlgExamResult\":\"Pass\",\"knlgExamDate\":\"03/09/2017\",\"knlgExamType\":\"OPTER\",\"ertCode\":\"E\",\"agrmntFlag\":\"Agreement\",\"reCertFlag\":\"Certification\",\"opccValue\":\"NA\",\"oprcValue\":\"NR\",\"opecValue\":\"NR\",\"rcnmCode\":\"NR\"}"
	 * ) .header("emplId", "9000018").header("ldapRoleList", LDAP_SYSTEM_ADMIN +
	 * "," + LDAP_MANAGER)) .andExpect(status().isOk()).andExpect(jsonPath("$",
	 * is("N"))).andReturn(); }
	 * 
	 *//**
	 * Removed all the parameter except than employeeId and license code
	 * from pendingRequirmentResult JSON object
	 * 
	 * @throws Exception
	 *//*
	 * @Test public void
	 * testGetPinsForConductorLicense_forEmployeeIdAndLicenseCode() throws
	 * Exception { this.mockMvc
	 * .perform(post("/licensing/getPinsForConductorLicense").contentType(
	 * MediaType.APPLICATION_JSON_VALUE) .content(
	 * "{\"employeeID\":\"0045301\",\"licenseClass\":\"Class 9\"}")
	 * .header("emplId", "9000018").header("ldapRoleList", LDAP_SYSTEM_ADMIN
	 * + "," + LDAP_MANAGER))
	 * .andExpect(status().isOk()).andExpect(jsonPath("$",
	 * is("N"))).andReturn(); }
	 * 
	 * @Test public void testGetRulesExamCodes() throws Exception {
	 * this.mockMvc
	 * .perform(get("/licensing/getRulesExamCodes/0000638").contentType(
	 * MediaType.APPLICATION_JSON_VALUE) .header("emplId",
	 * "9000018").header("ldapRoleList", LDAP_SYSTEM_ADMIN + "," +
	 * LDAP_MANAGER))
	 * .andExpect(status().isOk()).andExpect(jsonPath("$[0].employeeId",
	 * is(IsNull.nullValue()))) .andExpect(jsonPath("$[0].examDate",
	 * is("04/12/2017"))) .andExpect(jsonPath("$[0].qlfnCode",
	 * is(IsNull.nullValue()))) .andExpect(jsonPath("$[0].rulesCode",
	 * is("RXABE"))).andExpect(jsonPath("$[0].rstflag", is("Pass")))
	 * .andReturn(); }
	 * 
	 * @Test public void testGetEvaluationDetailsForConductor() throws
	 * Exception { this.mockMvc .perform(get(
	 * "/licensing/getEvaluationDetailsForConductor/0346839/1797509")
	 * .contentType(MediaType.APPLICATION_JSON_VALUE).header("emplId",
	 * "9000018") .header("ldapRoleList", LDAP_SYSTEM_ADMIN + "," +
	 * LDAP_MANAGER))
	 * .andExpect(status().isOk()).andExpect(jsonPath("$").exists()).
	 * andReturn(); }
	 * 
	 *
	 * 
	 * // If requirement is not Applicable then we will get null response //
	 * Then We will get illigalArumentException
	 * 
	 * @Test(expected = AssertionError.class) public void
	 * testDoGetMvrRptDtl_NA() throws Exception { this.mockMvc
	 * .perform(get("/licensing/getMvrReportDetails/143408").contentType(
	 * MediaType.APPLICATION_JSON_VALUE) .header("emplId",
	 * "9000018").header("ldapRoleList", LDAP_SYSTEM_ADMIN + "," +
	 * LDAP_MANAGER)) .andExpect(status().isOk()).andReturn(); }
	 * 
	 * // If requirement is pass then we will get valid response // Then We
	 * will get illigalArumentException
	 * 
	 * @Test public void testDoGetMvrRptDtl_Pass() throws Exception {
	 * this.mockMvc
	 * .perform(get("/licensing/getMvrReportDetails/0298376").contentType(
	 * MediaType.APPLICATION_JSON_VALUE) .header("emplId",
	 * "9000018").header("ldapRoleList", LDAP_SYSTEM_ADMIN + "," +
	 * LDAP_MANAGER))
	 * .andExpect(status().isOk()).andExpect(jsonPath("$.mvrRptId",
	 * is("12727"))) .andExpect(jsonPath("$.emplId", is("0298376")))
	 * 
	 * .andExpect(jsonPath("$.mvrReqTxt", is("N")))
	 * .andExpect(jsonPath("$.mvrRespTxt", is("N")))
	 * 
	 * .andExpect(jsonPath("$.gufnId",
	 * is("{C2AD4AC4-C055-413E-BDF0-48B7FE09276A}")))
	 * .andExpect(jsonPath("$.histRcdFlag",
	 * is("Y"))).andExpect(jsonPath("$.crtnEmplId", is("0071972"))) //
	 * .andExpect(jsonPath("$.crtnDate", is("3/20/2017 1:49:54 // PM")))
	 * .andExpect(jsonPath("$.lastUpdtEmplId", is("0071972"))) //
	 * .andExpect(jsonPath("$.lastUptdDate", is("3/20/2017 3:02:50 // PM")))
	 * .andReturn(); }
	 * 
	 * @Test public void testGetMVRDetails() throws Exception { this.mockMvc
	 * .perform(get("/licensing/getMVRDetails/143408/0298376").contentType(
	 * MediaType.APPLICATION_JSON_VALUE) .header("emplId",
	 * "9000018").header("ldapRoleList", LDAP_SYSTEM_ADMIN + "," +
	 * LDAP_MANAGER))
	 * .andExpect(status().isOk()).andExpect(jsonPath("$.packetHistoryList")
	 * .isArray()).andReturn(); }
	 * 
	 * @Test public void testGetMVRAuthDetailsFromReorpts() throws Exception
	 * { this.mockMvc
	 * .perform(get("/licensing/getMVRAuthDetailsFromReorpts/0298376")
	 * .contentType(MediaType.APPLICATION_JSON_VALUE).header("emplId",
	 * "9000018") .header("ldapRoleList", LDAP_SYSTEM_ADMIN + "," +
	 * LDAP_MANAGER))
	 * .andExpect(status().isOk()).andExpect(jsonPath("$").isArray()).
	 * andReturn(); }
	 * 
	 * 
	 */


	@Test
	public void testCancelLicensingRequirement() throws Exception { 

		String licenseRequest = "{\"comments\":\"Add for Tesing\",\"pendingRequirementResultList\":[{\"employeeID\":\"0045301\",\"employeeName\":\"Stemp, B. E\",\"serviceUnit\":\"CHICAGO\",\"serviceUnitNbr\":2,\"licenseClass\":\"Class 9\",\"medicalResult\":\"Pass\",\"rulesResult\":\"Pass\",\"certRideResult\":\"NR\",\"mvrResult\":\"Pass\",\"ndrResult\":\"NR\",\"rules\":null,\"lcnsRqmtId\":53956,\"licenseClassDesc\":\"Class 9 - Passenger Conductor\",\"checkWorkItemForMvrOrNdr\":false,\"checkWorkItemForPeaMvr\":false,\"checkWorkItemForPeaNdr\":false,\"employeeAlreadyLicensedFlag\":false,\"jobTypeCode\":\"CON\",\"testId\":null,\"ftxEventResult\":\"NR\",\"conExamFlag\":\"NA\",\"condLicType\":\"Passenger Conductor\",\"ftxEvntTestId\":null,\"ftxEvntQlfnCodeId\":null,\"ftxEventDate\":null,\"or6aExamResult\":\"NR\",\"or6aExamDate\":null,\"description\":null,\"knlgExamResult\":\"Pass\",\"knlgExamDate\":\"03/09/2017\",\"knlgExamType\":\"OPTER\",\"ertCode\":\"E\",\"agrmntFlag\":\"Agreement\",\"reCertFlag\":\"Certification\",\"opccValue\":\"NA\",\"oprcValue\":\"NR\",\"opecValue\":\"NR\",\"rcnmCode\":\"NR\"}]}";

		when(licPendingRequirementService.cancelLicensingRequirement(any(List.class), any(String.class))).thenReturn(true);
		this.mockMvc
		.perform(post("/licensing/cancelLicensingRequirement")
				.content(licenseRequest)
				.contentType(MediaType.APPLICATION_JSON_VALUE).header("emplId",
						"9000018") .header("ldapRoleList", LDAP_SYSTEM_ADMIN + "," +
								LDAP_MANAGER))
		.andExpect(status().isOk()).andExpect(jsonPath("$", is(true))).
		andReturn();
	}

	@Test(expected = IllegalArgumentException.class) public void
	testGetPinsForConductorLicense_otherThanClass9() throws Exception {
		
		PendingRequirementResult pendingRequirementResult = new PendingRequirementResult();
		pendingRequirementResult.setEmployeeID("0045301");
		pendingRequirementResult.setLicenseClass("Class 9");
	
		doThrow(new IllegalArgumentException()).when(licPendingRequirementService).getPinsForConductorLicense(pendingRequirementResult);
		
		this.mockMvc
		.perform(post("/licensing/getPinsForConductorLicense").contentType(
				MediaType.APPLICATION_JSON_VALUE) .content(
						"{\"employeeID\":\"0000518\",\"employeeName\":\"Holland, Mark H\",\"serviceUnit\":\"PORTLAND\",\"serviceUnitNbr\":18,\"licenseClass\":\"Class 8\",\"medicalResult\":\"NA\",\"rulesResult\":\"NA\",\"certRideResult\":\"NR\",\"mvrResult\":\"Inc\",\"ndrResult\":\"NR\",\"rules\":null,\"lcnsRqmtId\":143066,\"licenseClassDesc\":\"Class 8 - Freight Conductor\",\"checkWorkItemForMvrOrNdr\":false,\"checkWorkItemForPeaMvr\":false,\"checkWorkItemForPeaNdr\":false,\"employeeAlreadyLicensedFlag\":false,\"jobTypeCode\":\"CON\",\"testId\":null,\"ftxEventResult\":\"Pass\",\"conExamFlag\":\"NR\",\"condLicType\":\"NR\",\"ftxEvntTestId\":1786884,\"ftxEvntQlfnCodeId\":9,\"ftxEventDate\":\"01/23/2017\",\"or6aExamResult\":\"NR\",\"or6aExamDate\":null,\"description\":null,\"knlgExamResult\":\"NA\",\"knlgExamDate\":\"NA\",\"knlgExamType\":null,\"ertCode\":\"T\",\"agrmntFlag\":\"Agreement\",\"reCertFlag\":\"Recertification\",\"opccValue\":\"NR\",\"oprcValue\":\"NR\",\"opecValue\":\"NR\",\"rcnmCode\":\"NR\"}"
						) .header("emplId", "9000018").header("ldapRoleList", LDAP_SYSTEM_ADMIN +
								"," + LDAP_MANAGER)) .andExpect(status().isOk()).andExpect(jsonPath("$",
										is(false))).andReturn(); }


	@Test(expected = IllegalArgumentException.class) 
	public void testGetPinsForConductorLicense_forEmployeeIdAndLicenseCode() throws
	Exception { 
		
		PendingRequirementResult pendingRequirementResult = new PendingRequirementResult();
		pendingRequirementResult.setEmployeeID("0045301");
		pendingRequirementResult.setLicenseClass("Class 9");
	
		doThrow(new IllegalArgumentException()).when(licPendingRequirementService).getPinsForConductorLicense(pendingRequirementResult);
		
		this.mockMvc
		.perform(post("/licensing/getPinsForConductorLicense").contentType(
				MediaType.APPLICATION_JSON_VALUE) .content(
						"{\"employeeID\":\"0045301\",\"licenseClass\":\"Class 9\"}")
				.header("emplId", "9000018").header("ldapRoleList", LDAP_SYSTEM_ADMIN
						+ "," + LDAP_MANAGER))
		.andExpect(status().isOk()).andExpect(jsonPath("$",
				is("N"))).andReturn(); }

}
