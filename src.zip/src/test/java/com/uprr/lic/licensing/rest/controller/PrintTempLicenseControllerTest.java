package com.uprr.lic.licensing.rest.controller;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Ignore;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MvcResult;

import com.uprr.lic.dataaccess.Licensing.model.TempLicenseTemplate;
import com.uprr.lic.dataaccess.Licensing.model.TempLicenseTemplateList;
import com.uprr.lic.licensing.rest.service.IPrintTempLicenseService;
import com.uprr.lic.test.base.BaseJUnit;

@Ignore
public class PrintTempLicenseControllerTest extends BaseJUnit {
	
	/*@Autowired
	private PerosnGetJobHistory perosnGetJobHistory;*/
	
	@Mock
	private IPrintTempLicenseService printTempLicenseService;
	@Autowired
	@InjectMocks
	private PrintTempLicenseController controller;
	
	@Test
	public void testGetTemporaryLicenseTemplateForPortal() throws Exception {
		
		TempLicenseTemplate tempLicenseTemplate = new TempLicenseTemplate();
		List<TempLicenseTemplateList> tempLicenseTemplateLists = new ArrayList<TempLicenseTemplateList>();
		TempLicenseTemplateList tempLicenseTemplateList = new TempLicenseTemplateList();
		tempLicenseTemplateList.setSrNo(1);
		tempLicenseTemplateList.setLicenseClassCode("Class 8");
		tempLicenseTemplateList.setLastRideInfo("Past Info");
		tempLicenseTemplateList.setExpiryDate(new Date().toLocaleString());
		tempLicenseTemplateLists.add(tempLicenseTemplateList);
		tempLicenseTemplate.setTempLicenseTemplateList(tempLicenseTemplateLists);
		
		when(printTempLicenseService.getTemporaryLicenseTemplateForPortal("0412160")).thenReturn(tempLicenseTemplate);
		
		 MvcResult result =	 this.mockMvc.perform(post("/licensing/getTemporaryLicenseTemplateForPortal").contentType(MediaType.APPLICATION_JSON_VALUE)
				.param("employeeID", "0412160")
				.header("emplId", EMP_ID)
		        .header("ldapRoleList", LDAP_SYSTEM_ADMIN + "," + LDAP_MANAGER)).andExpect(status().isOk())
				.andExpect(jsonPath("$.employeeID").isNotEmpty())
				.andExpect(jsonPath("$.tempLicenseTemplateList").isArray())
				.andExpect(jsonPath("$.tempLicenseTemplateList[0].srNo").isNotEmpty())
				.andExpect(jsonPath("$.tempLicenseTemplateList[0].lastRideInfo").isNotEmpty())
				.andExpect(jsonPath("$.tempLicenseTemplateList[0].licenseClassCode").isNotEmpty())				
				.andReturn();
		 
		 String content = result.getResponse().getContentAsString();
	}
	/*@Test
	public void testJobHistoryCall(){ 
		 
		Float result = perosnGetJobHistory.getJobHistory("0412160");
	}*/

}
