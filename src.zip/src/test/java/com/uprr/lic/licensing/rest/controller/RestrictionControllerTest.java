package com.uprr.lic.licensing.rest.controller;

import static org.hamcrest.Matchers.is;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Arrays;
import java.util.List;

import org.junit.Ignore;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;

import com.uprr.lic.dataaccess.Licensing.model.Restriction;
import com.uprr.lic.licensing.rest.service.IRestrictionService;
import com.uprr.lic.test.base.BaseJUnit;
@Ignore
public class RestrictionControllerTest extends BaseJUnit {

	@Mock
	private IRestrictionService restrictionService;
	
	@Autowired
	@InjectMocks
	private RestrictionController restrictionController;

	@Test
	public void testGetEmployeeDetailsForRestriction() throws Exception {
		Restriction restriction = new Restriction();
		restriction.setAssignedManager("Abhishek");
		restriction.setEmployeeName("Girish");
		restriction.setEmployeeId("0400901");
		
		restriction.setIndustries(Arrays.asList("Test1"));
		restriction.setQualifiedPassenger("Yes");
		restriction.setYard("No");
		restriction.setRailRoad(Arrays.asList("\"Rail Road1\",\"Rail Road1\""));
		restriction.setServiceUnit("Narth");
		when(restrictionService.getEmployeeDetailsForRestriction(any(String.class))).thenReturn(restriction);
		this.mockMvc
		.perform(post("/licensing/getEmployeeDetailsForRestriction?").contentType(MediaType.APPLICATION_JSON_VALUE)
				.param("employeeId", "0400901")
				.header("emplId", "9000018").header("ldapRoleList", LDAP_SYSTEM_ADMIN + "," + LDAP_MANAGER))
		.andExpect(status().isOk()).andExpect(jsonPath("$.assignedManager", is("Abhishek")))
		.andExpect(jsonPath("$.employeeName", is("Girish")))
		.andExpect(jsonPath("$.employeeId", is("0400901")))
		.andExpect(jsonPath("$.yard", is("No")))
		.andExpect(jsonPath("$.qualifiedPassenger", is("Yes")))
		.andExpect(jsonPath("$.railRoad[0]", is("Rail Road1")))
		.andExpect(jsonPath("$.railRoad[1]", is("Rail Road2")))
		.andExpect(jsonPath("$.industries", is("Test1"))).andDo(print()).andReturn();
	}

	@Test
	public void testInsertEmpRestrictionData() throws Exception {
		when(restrictionService.insertEmpRestrictionData(any(Restriction.class))).thenReturn(true);
		this.mockMvc
		.perform(post("/licensing/insertEmpRestrictionData?").contentType(MediaType.APPLICATION_JSON_VALUE)
				.param("employeeId", "006019")
				.header("emplId", "9000018").header("ldapRoleList", LDAP_SYSTEM_ADMIN + "," + LDAP_MANAGER))
		.andExpect(status().isOk()).andExpect(jsonPath("$", is(true)))
		.andReturn();
	}

	@Test
	public void testGetRailRoadList() throws Exception {
		List<String> arrayList = Arrays.asList("Class 8", "Class 9", "Class 1", "Class 2", "Class 3", "Class 5",
				"Class 6", "Class 7");
		when(restrictionService.getRailRoadList()).thenReturn(arrayList);
		this.mockMvc
		.perform(get("/licensing/getRailRoadList").contentType(MediaType.APPLICATION_JSON_VALUE)
				.header("emplId", "9000018").header("ldapRoleList", LDAP_SYSTEM_ADMIN + "," + LDAP_MANAGER))
		.andExpect(status().isOk()).andExpect(jsonPath("$", is(arrayList))).andReturn();
	}

}
