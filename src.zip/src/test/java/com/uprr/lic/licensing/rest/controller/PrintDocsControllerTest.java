package com.uprr.lic.licensing.rest.controller;

import static org.hamcrest.Matchers.is;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hamcrest.core.IsNull;
import org.junit.Ignore;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;

import com.uprr.lic.dataaccess.common.model.EqmLcnsInit;
import com.uprr.lic.licensing.rest.service.IPrintDocsService;
import com.uprr.lic.test.base.BaseJUnit;
@Ignore
public class PrintDocsControllerTest extends BaseJUnit {
	
	@Mock
	private IPrintDocsService printDocService;
	
	@Autowired
	@InjectMocks
	private PrintDocsController printDocsController;

	@Test
	public void testInsertPacketPrintingDetailsWithValidation() throws Exception {
		List<String> arrayList = Arrays.asList("Class 8", "Class 9", "Class 1", "Class 2", "Class 3", "Class 5",
				"Class 6", "Class 7");
		when(printDocService.insertPacketPrintingDetailsWithValidation(any(String.class),any(String.class))).thenReturn(arrayList);
		
				this.mockMvc
				.perform(post("/licensing/insertPacketPrintDocs?").contentType(MediaType.APPLICATION_JSON_VALUE)
						.param("employeeId", "0006019")
						.param("comments", "Test is good")
						.header("emplId", "9000018").header("ldapRoleList", LDAP_SYSTEM_ADMIN + "," + LDAP_MANAGER))
				.andExpect(status().isOk()).andExpect(jsonPath("$[0]", is("Class 8"))).andReturn();
	
	}

	@Test
	public void testGetEmployeesLicenseInitiationDetails() throws Exception {
		when(printDocService.getEmployeesLicenseInitiationDetails(any(Integer.class))).thenReturn("License Found");
		
		this.mockMvc
		.perform(get("/licensing/getLicenseInitiationDetails/10").contentType(MediaType.APPLICATION_JSON_VALUE)
				.header("emplId", "9000018").header("ldapRoleList", LDAP_SYSTEM_ADMIN + "," + LDAP_MANAGER))
		.andExpect(status().isOk()).andExpect(jsonPath("$", is("License Found"))).andReturn();
	}

	@Test
	public void testUpdatePendingActionMarkAsPacketSent() throws Exception {
		when(printDocService.updatePendingActionMarkAsPacketSent(any(String.class), any(String.class), any(Integer.class), any(Integer.class), any(Integer.class))).thenReturn("License Found");
		
		this.mockMvc
		.perform(post("/licensing/updateMarkAsPacketSent?").contentType(MediaType.APPLICATION_JSON_VALUE)
				.param("employeeID", "0006019")
				.param("licenseClass", "0006019")
				.param("reasonID", "19")
				.param("workItemID", "19")
				.param("oprnID", "19")
				.header("emplId", "9000018").header("ldapRoleList", LDAP_SYSTEM_ADMIN + "," + LDAP_MANAGER))
		.andExpect(status().isOk()).andExpect(jsonPath("$", is("License Found"))).andReturn();
	
	}
	
	@Test
	public void testGetOprnIdforExistingLicense() throws Exception {
		
		when(printDocService.getInitDtlsByOprnId(any(Integer.class))).thenReturn( new EqmLcnsInit());
		
		this.mockMvc
		.perform(post("/licensing/getInitDtlsByOprnId?").contentType(MediaType.APPLICATION_JSON_VALUE)
				.param("oprnID", "10")
				.header("emplId", "9000018").header("ldapRoleList", LDAP_SYSTEM_ADMIN + "," + LDAP_MANAGER))
		.andExpect(status().isOk())
		.andExpect(jsonPath("$.lcnsInitId", is(IsNull.nullValue())))

		.andExpect(jsonPath("$.eqmLcnsOprn", is(IsNull.nullValue())))

		.andExpect(jsonPath("$.city", is(IsNull.nullValue())))

		.andExpect(jsonPath("$.clasNbr", is(IsNull.nullValue())))

		.andExpect(jsonPath("$.st", is(IsNull.nullValue())))

		.andExpect(jsonPath("$.clasDesc", is(IsNull.nullValue())))

		.andExpect(jsonPath("$.bulLoc", is(IsNull.nullValue())))

		.andExpect(jsonPath("$.mgrTrne", is(IsNull.nullValue())))

		.andExpect(jsonPath("$.crtnDate", is(IsNull.nullValue())))

		.andExpect(jsonPath("$.crtnEmplId", is(IsNull.nullValue())))

		.andExpect(jsonPath("$.lastUptdDate", is(IsNull.nullValue())))

		.andExpect(jsonPath("$.lastUptdEmplId", is(IsNull.nullValue())))

		.andExpect(jsonPath("$.rowVrsnNbr", is(0)))

		.andExpect(jsonPath("$.eqmSvcUnit", is(IsNull.nullValue())))
		.andExpect(jsonPath("$.eqmLcnsOprn", is(IsNull.nullValue()))).andReturn();
			
	}

	@Test
	public void testGetInitDtlsByOprnId() throws Exception {
		Map<Boolean, Integer> map = new HashMap<Boolean, Integer>();
		map.put(true, 1);
		map.put(false, 2);
		
		when(printDocService.getOprnIdforExistingLicense((any(String.class)))).thenReturn(map);
	
		this.mockMvc
		.perform(post("/licensing/getOprnIdforExistingLicense?").contentType(MediaType.APPLICATION_JSON_VALUE)
				.param("employeeID", "0006019")
				.header("emplId", "9000018").header("ldapRoleList", LDAP_SYSTEM_ADMIN + "," + LDAP_MANAGER))
		.andExpect(status().isOk()).andExpect(jsonPath("$.false", is(2)))
		.andExpect(jsonPath("$.true", is(1))).andReturn();
	}

	@Test
	public void testIsRecertificationInitiatedForEmployee() throws Exception {
		
		when(printDocService.isRecertificationInitiatedForEmployee(any(String.class),any(String.class), any(Integer.class))).thenReturn(true);
		
		this.mockMvc
		.perform(post("/licensing/isRecertificationInitiatedForEmployee?").contentType(MediaType.APPLICATION_JSON_VALUE)
				.param("employeeId", "0006019")
				.param("licenseClassCode", "Class 8")
				.param("selection", "1")
				.header("emplId", "9000018").header("ldapRoleList", LDAP_SYSTEM_ADMIN + "," + LDAP_MANAGER))
		.andExpect(status().isOk()).andExpect(jsonPath("$").isBoolean()).andReturn();
	
	}

}
