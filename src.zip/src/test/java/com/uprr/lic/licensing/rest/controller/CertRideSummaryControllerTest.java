/**
 * 
 */
package com.uprr.lic.licensing.rest.controller;

import static org.hamcrest.Matchers.is;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.hamcrest.core.IsNull;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.uprr.lic.config.spring.MainConfig;
import com.uprr.lic.licensing.rest.model.CategoryInformationDetailResponse;
import com.uprr.lic.licensing.rest.model.CertRideSummaryResponse;
import com.uprr.lic.licensing.rest.service.ICertRideSummaryService;



/**
 * @author xsat956
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes={MainConfig.class})
@WebAppConfiguration
@Ignore
public class CertRideSummaryControllerTest {

	private static final String LDAP_SYSTEM_ADMIN = "EQM-SYSTEM-ADMIN";

	private static final String LDAP_MANAGER = "EQM_Manager";

	private MockMvc mockMvc;

	@Autowired
	private WebApplicationContext context;
	
	
	@Mock
	private ICertRideSummaryService certRideSummaryService;
	
	@Autowired
	@InjectMocks
	private CertRideSummaryController certRideSummaryController;

	/**
	 * @throws java.lang.Exception
	 */
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		System.setProperty("uprr.implementation.environment", "local");
		System.setProperty("jbs.name", "localhost");
	}

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {

		this.mockMvc = MockMvcBuilders.webAppContextSetup(context).build();
		MockitoAnnotations.initMocks(this);
	}

	/**
	 * Test method for {@link com.uprr.lic.licensing.rest.controller.CertRideSummaryController#getSummaryDetail(java.lang.String, java.lang.Integer)}.
	 * @throws Exception 
	 */
	@Test
	public void testGetSummaryDetailPassRide() throws Exception {
		
		CertRideSummaryResponse  certRideSummaryResponse = new CertRideSummaryResponse();
		certRideSummaryResponse.setManager( "Johnson, Justin R(0407655)") ; 
		certRideSummaryResponse.setEvaluationDate("12/12/2012" ) ; 
		certRideSummaryResponse.setServiceUnit( "NART"  ) ; 
		certRideSummaryResponse.setTrainID("089786" ) ; 
		certRideSummaryResponse.setTotalLoads((long)5000) ; 
		certRideSummaryResponse.setCrewOnDutyCirc7( "crewOnDutyCirc7" ) ; 
		certRideSummaryResponse.setServiceType( "serviceType"  ) ; 
		certRideSummaryResponse.setLength((long) 1000) ; 
		certRideSummaryResponse.setSimulator("simulator"  ) ; 
		certRideSummaryResponse.setdPU("dpu" ) ; 
		certRideSummaryResponse.setForignInitial("forignInitial" ) ; 
		certRideSummaryResponse.setWeight((long)500 ) ; 
		certRideSummaryResponse.setTotalEmpties((long)500); 
		certRideSummaryResponse.setRemoteControl("remoteControl" ) ; 
		certRideSummaryResponse.setHelper("helper" ) ; 
		certRideSummaryResponse.setCrewMember( "crewMember" ) ; 
		certRideSummaryResponse.setPosition("pos") ; 
		certRideSummaryResponse.setStudent("student" ) ; 
		certRideSummaryResponse.setReason("reason" ) ; 
		certRideSummaryResponse.setTotalMiles( (long)100.00 ) ; 
		certRideSummaryResponse.setStartDate("12/12/2012" ) ; 
		certRideSummaryResponse.setStopDate( "12/12/2012" ) ; 
		certRideSummaryResponse.setOriginCirc7("originCirc7"  ) ; 
		certRideSummaryResponse.setDestCirc7("destCirc7" ) ; 
		certRideSummaryResponse.setOverAllScore(100.00 ) ; 
		certRideSummaryResponse.setTrainHandlingScore( 50 ) ; 
		certRideSummaryResponse.setMngrComments("This is test case") ;
		
		when(certRideSummaryService.getSummaryDetail(any(String.class), any(Integer.class))).thenReturn(certRideSummaryResponse);

				this.mockMvc.perform(get("/licensing/getSummaryDetail/0006019/1358092")
						.contentType(MediaType.APPLICATION_JSON_VALUE)
						.header("emplId", "9000018").header("ldapRoleList", LDAP_SYSTEM_ADMIN + "," + LDAP_MANAGER))
				.andExpect(status().isOk()).andExpect(jsonPath("$.manager", is("Johnson, Justin R(0407655)")))
				.andExpect(jsonPath("$.manager", is("Johnson, Justin R(0407655)")))
				.andExpect(jsonPath("$.evaluationDate", is("12/12/2012")))
				.andExpect(jsonPath("$.serviceUnit", is("NART")))
				.andExpect(jsonPath("$.trainID", is("089786")))
				.andExpect(jsonPath("$.totalLoads", is(5000)))
				.andExpect(jsonPath("$.crewOnDutyCirc7", is("crewOnDutyCirc7")))
				.andExpect(jsonPath("$.serviceType", is("serviceType")))
				.andExpect(jsonPath("$.length", is(1000)))
				.andExpect(jsonPath("$.simulator", is("simulator")))
				
				.andExpect(jsonPath("$.dPU", is("dpu")))
				.andExpect(jsonPath("$.mngrComments", is("This is test case")))
				.andExpect(jsonPath("$.trainHandlingScore", is(50)))
				.andExpect(jsonPath("$.overAllScore", is(100.00)))
				.andExpect(jsonPath("$.destCirc7", is("destCirc7")))
				.andExpect(jsonPath("$.originCirc7", is("originCirc7")))
				
				.andExpect(jsonPath("$.stopDate", is("12/12/2012")))
				.andExpect(jsonPath("$.startDate", is("12/12/2012")))
				.andExpect(jsonPath("$.totalMiles", is(100)))
				.andExpect(jsonPath("$.reason", is("reason")))
				.andExpect(jsonPath("$.student", is("student")))
				.andExpect(jsonPath("$.position", is("pos")))
				.andExpect(jsonPath("$.forignInitial", is("forignInitial")))
				.andExpect(jsonPath("$.weight", is(500)))
				.andExpect(jsonPath("$.totalEmpties", is(500)))
				.andExpect(jsonPath("$.remoteControl", is("remoteControl")))
			.andReturn();

	}
	
	/**
	 * Test method for {@link com.uprr.lic.licensing.rest.controller.CertRideSummaryController#getSummaryDetail(java.lang.String, java.lang.Integer)}.
	 * @throws Exception 
	 */
	@Test
	public void testGetSummaryDetailNARide() throws Exception {

		CertRideSummaryResponse  certRideSummaryResponse = new CertRideSummaryResponse();
		when(certRideSummaryService.getSummaryDetail(any(String.class), any(Integer.class))).thenReturn(certRideSummaryResponse);
				MvcResult result = this.mockMvc.perform(get("/licensing/getSummaryDetail/0009339/0")
						.contentType(MediaType.APPLICATION_JSON_VALUE)
						.header("emplId", "9000018").header("ldapRoleList", LDAP_SYSTEM_ADMIN + "," + LDAP_MANAGER))
				.andExpect(status().isOk()).andExpect(jsonPath("$.manager", is(IsNull.nullValue())))
				.andExpect(jsonPath("$.manager", is(IsNull.nullValue())))
				.andExpect(jsonPath("$.evaluationDate", is(IsNull.nullValue())))
				.andExpect(jsonPath("$.serviceUnit", is(IsNull.nullValue())))
				.andExpect(jsonPath("$.trainID", is(IsNull.nullValue())))
				.andExpect(jsonPath("$.totalLoads", is(IsNull.nullValue())))
				.andExpect(jsonPath("$.crewOnDutyCirc7", is(IsNull.nullValue())))
				.andExpect(jsonPath("$.serviceType", is(IsNull.nullValue())))
				.andExpect(jsonPath("$.length", is(IsNull.nullValue())))
				.andExpect(jsonPath("$.simulator", is(IsNull.nullValue())))
				
				.andExpect(jsonPath("$.dPU", is(IsNull.nullValue())))
				.andExpect(jsonPath("$.mngrComments", is(IsNull.nullValue())))
				.andExpect(jsonPath("$.trainHandlingScore", is(IsNull.nullValue())))
				.andExpect(jsonPath("$.overAllScore", is(IsNull.nullValue())))
				.andExpect(jsonPath("$.destCirc7", is(IsNull.nullValue())))
				.andExpect(jsonPath("$.originCirc7", is(IsNull.nullValue())))
				
				.andExpect(jsonPath("$.stopDate", is(IsNull.nullValue())))
				.andExpect(jsonPath("$.startDate", is(IsNull.nullValue())))
				.andExpect(jsonPath("$.totalMiles", is(IsNull.nullValue())))
				.andExpect(jsonPath("$.reason", is(IsNull.nullValue())))
				.andExpect(jsonPath("$.student", is(IsNull.nullValue())))
				.andExpect(jsonPath("$.position", is(IsNull.nullValue())))
				.andExpect(jsonPath("$.forignInitial", is(IsNull.nullValue())))
				.andExpect(jsonPath("$.weight", is(IsNull.nullValue())))
				.andExpect(jsonPath("$.totalEmpties", is(IsNull.nullValue())))
				.andExpect(jsonPath("$.remoteControl", is(IsNull.nullValue())))
			.andReturn();

	}

	
	/**
	 * This Case is for Ride is not applicable
	 * Test method for {@link com.uprr.lic.licensing.rest.controller.CertRideSummaryController#getCategoryInformationList(java.lang.String, java.lang.Integer)}.
	 * @throws Exception 
	 */
	@Test
	public void testGetCategoryInformationList_ResultIsEmpty() throws Exception {
		List<CategoryInformationDetailResponse> categoryInformationDetailResponseList = new ArrayList<>();
		
		
		when(certRideSummaryService.getCategoryInformationList(any(String.class), any(Integer.class))).thenReturn(categoryInformationDetailResponseList);
		this.mockMvc.perform(get("/licensing/getCategoryInformationList/0009339/1358092")
				.contentType(MediaType.APPLICATION_JSON_VALUE)
				.header("emplId", "9000018").header("ldapRoleList", LDAP_SYSTEM_ADMIN + "," + LDAP_MANAGER))
				.andExpect(status().isOk()).andExpect(jsonPath("$").isEmpty()).andReturn();
	}
	
	/**
	 * This Case is for pass Ride
	 * Test method for {@link com.uprr.lic.licensing.rest.controller.CertRideSummaryController#getCategoryInformationList(java.lang.String, java.lang.Integer)}.
	 * @throws Exception 
	 */
	@Test
	public void testGetCategoryInformationList_isArray() throws Exception {
		
		List<CategoryInformationDetailResponse> categoryInformationDetailResponseList = new ArrayList<>();
		CategoryInformationDetailResponse categoryInformationDetailResponse = new CategoryInformationDetailResponse();
		categoryInformationDetailResponse.setCategoryFirst("Bell") ; 
		categoryInformationDetailResponse.setActionFirst("P") ; 
		categoryInformationDetailResponse.setCategorySecond(null) ; 
		categoryInformationDetailResponse.setActionSecond(null) ;
		categoryInformationDetailResponseList.add(categoryInformationDetailResponse);
		when(certRideSummaryService.getCategoryInformationList(any(String.class), any(Integer.class))).thenReturn(categoryInformationDetailResponseList);
		
		this.mockMvc.perform(get("/licensing/getCategoryInformationList/0006019/1358092")
				.contentType(MediaType.APPLICATION_JSON_VALUE)
				.header("emplId", "9000018").header("ldapRoleList", LDAP_SYSTEM_ADMIN + "," + LDAP_MANAGER))
				.andExpect(status().isOk()).andExpect(jsonPath("$").isArray()).andReturn();
	}
	
	/**
	 * This Case is for pass Ride
	 * Test method for {@link com.uprr.lic.licensing.rest.controller.CertRideSummaryController#getCategoryInformationList(java.lang.String, java.lang.Integer)}.
	 * @throws Exception 
	 */
	@Test
	public void testGetCategoryInformationLisForPassResult() throws Exception {
		
		List<CategoryInformationDetailResponse> categoryInformationDetailResponseList = new ArrayList<>();
		CategoryInformationDetailResponse categoryInformationDetailResponse = new CategoryInformationDetailResponse();
		categoryInformationDetailResponse.setCategoryFirst("Bell") ; 
		categoryInformationDetailResponse.setActionFirst("P") ; 
		categoryInformationDetailResponse.setCategorySecond(null) ; 
		categoryInformationDetailResponse.setActionSecond(null) ;
		categoryInformationDetailResponseList.add(categoryInformationDetailResponse);
		when(certRideSummaryService.getCategoryInformationList(any(String.class), any(Integer.class))).thenReturn(categoryInformationDetailResponseList);
		this.mockMvc.perform(get("/licensing/getCategoryInformationList/0006019/1358092")
				.contentType(MediaType.APPLICATION_JSON_VALUE)
				.header("emplId", "9000018").header("ldapRoleList", LDAP_SYSTEM_ADMIN + "," + LDAP_MANAGER))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$[0].categoryFirst", is("Bell")))
				.andExpect(jsonPath("$[0].actionSecond", is(IsNull.nullValue())))
				.andExpect(jsonPath("$[0].actionFirst", is("P")))
				.andExpect(jsonPath("$[0].categorySecond", is(IsNull.nullValue()))).andReturn();
	}
	
	
}
