package com.uprr.lic.licensing.rest.controller;

import static org.hamcrest.Matchers.is;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.uprr.lic.config.spring.MainConfig;
import com.uprr.lic.dataaccess.Licensing.model.InitiateReplaceLicenseBean;
import com.uprr.lic.licensing.rest.model.LicensingRequest;
import com.uprr.lic.licensing.rest.service.IReplaceLicenseService;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { MainConfig.class })
@WebAppConfiguration
@Ignore
public class ReplaceLicensingControllerTest {


	private static final String LDAP_SYSTEM_ADMIN = "EQM-SYSTEM-ADMIN";
	private static final String LDAP_MANAGER = "EQM_Manager";

	private MockMvc mockMvc;

	@Autowired
	private WebApplicationContext applicationContext;

	@Mock
	private IReplaceLicenseService replaceLicenseService;

	@Autowired
	@InjectMocks
	private ReplaceLicensingController replaceLicensingController;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		System.setProperty("uprr.implementation.environment", "local");
		System.setProperty("jbs.name", "localhost");
	}

	@Before
	public void setUp() throws Exception {
		this.mockMvc = MockMvcBuilders.webAppContextSetup(applicationContext).build();
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testGetReplaceLicenseEmployeeDetails() throws Exception {

		InitiateReplaceLicenseBean initiateReplaceLicenseBeanRequest = new InitiateReplaceLicenseBean();
		initiateReplaceLicenseBeanRequest.setEmployeeID("006019");
		initiateReplaceLicenseBeanRequest.setReason("License Lost");

		List<InitiateReplaceLicenseBean> reponseList = new ArrayList<InitiateReplaceLicenseBean>();
		InitiateReplaceLicenseBean initiateReplaceLicenseBean = new InitiateReplaceLicenseBean();
		initiateReplaceLicenseBean.setEmployeeID("006019");
		initiateReplaceLicenseBean.setEmployeeName("Sampeck, Michael V");
		initiateReplaceLicenseBean.setServiceUnit("NORTH PLATTE");
		initiateReplaceLicenseBean.setReason("License Lost");
		reponseList.add(initiateReplaceLicenseBean);

		when(replaceLicenseService.getReplaceLicenseEmployeeDetails(any(String.class), any(Set.class))).thenReturn(reponseList);
		this.mockMvc
		.perform(post("/licensing/getReplaceLicenseEmployeeDetails?").contentType(MediaType.APPLICATION_JSON_VALUE)
				.param("employeeId", "006019")
				.header("emplId", "9000018").header("ldapRoleList", LDAP_SYSTEM_ADMIN + "," + LDAP_MANAGER))
		.andExpect(status().isOk()).andExpect(jsonPath("$[0].employeeID", is("0006019")))
		.andExpect(jsonPath("$[0].employeeName", is("Sampeck, Michael V")))
		.andExpect(jsonPath("$[0].reason", is("License Lost"))).andDo(print()).andReturn();
	}

	//content().string("[{\"conExamType\":null,\"conExamPinAval\":null,\"eventTypeDesc\":null,\"hostlerFlag\":null,\"eventReason\":null,\"part218TestResult\":null,\"stopTestResult\":null,\"frgnEvntSeq\":null,\"mapOfEmplIdAndWrkItemDtl\":null,\"lcnsOprnId\":null,\"studReason\":null,\"serviceUnitNbr\":null,\"reasonAll\":null,\"reason\":\"License Lost\",\"licenseAll\":null,\"license\":null,\"licenseClass\":null,\"address\":null,\"region\":null,\"position\":null,\"count\":null,\"rules\":null,\"employeeID\":\"0006019\",\"serviceUnit\":\"NORTH PLATTE\",\"action\":null,\"workItemID\":null,\"employeeName\":\"Sampeck, Michael V\",\"resultFlag\":null,\"status\":null,\"ftxEvntPart218Test\":false,\"ftxEvntStopTest\":false,\"ftxEventValidForDSAEvnt\":false,\"onDutyDateAndTime\":null,\"selectedAction\":null,\"prevEmployeePosition\":null,\"serviceUnitAll\":null,\"tempEmployeeID\":null,\"flagForFteEventExeption\":null,\"employeeIDForDisplay\":null,\"empPositionSlected\":null,\"positionForFteEvent\":null,\"empMiddleInitial\":null,\"previouslySelecAction\":null,\"newAddedEmplFlag\":null,\"circ7\":null,\"hireDate\":null,\"managerId\":null,\"medical\":null,\"crewCallCirc7\":null,\"faxNumber\":null,\"mvr\":null,\"skillRide\":null,\"lastFaxDate\":null,\"rolesAll\":null,\"regionAll\":null,\"evalScore\":null,\"isEvaluated\":null,\"employeeEvent\":null,\"empMiddleName\":null,\"board\":null,\"pass\":false,\"hearing\":false,\"notApplicable\":false,\"coach\":false,\"empFirstName\":null,\"empLastName\":null,\"emplTiupPos\":null,\"dateOfBirth\":null,\"managerName\":null,\"student\":null,\"state\":\" \",\"country\":\" \",\"firstLine\":\" \",\"postCode\":\" \",\"secondLine\":\" \",\"phoneno\":\" \",\"city\":\" \"}]")
	@Test
	public void testIsReplaceLicenseRequestInitiated() throws Exception {
		List<String> arrayList = Arrays.asList("Class 8","Class 9","Class 1","Class 2","Class 3","Class 5",
				"Class 6","Class 7");
		Set<String> set= new HashSet<String>(arrayList);

		when(replaceLicenseService.isReplaceLicenseRequestInitiated(any(String.class))).thenReturn(set);
		this.mockMvc
		.perform(post("/licensing/isReplaceLicenseRequestInitiated?").contentType(MediaType.APPLICATION_JSON_VALUE)
				.param("employeeId", "006019")
				.header("emplId", "9000018").header("ldapRoleList", LDAP_SYSTEM_ADMIN + "," + LDAP_MANAGER))
		.andExpect(status().isOk()).andExpect(content().string("[\"Class 1\",\"Class 3\",\"Class 2\",\"Class 5\",\"Class 7\",\"Class 6\",\"Class 9\",\"Class 8\"]")).andDo(print()).andReturn();
	}

	@Test
	public void testInsertReplaceLicenseWorkItemEntry() throws Exception {


		LicensingRequest licensingRequest = new LicensingRequest();
		List<InitiateReplaceLicenseBean> reponseList = new ArrayList<InitiateReplaceLicenseBean>();
		InitiateReplaceLicenseBean initiateReplaceLicenseBean = new InitiateReplaceLicenseBean();
		initiateReplaceLicenseBean.setEmployeeID("006019");
		initiateReplaceLicenseBean.setEmployeeName("Sampeck, Michael V");
		initiateReplaceLicenseBean.setServiceUnit("NORTH PLATTE");
		initiateReplaceLicenseBean.setReason("License Lost");
		reponseList.add(initiateReplaceLicenseBean);

		licensingRequest.setInitiateReplaceLicenseList(reponseList);

		when(replaceLicenseService.insertReplaceLicenseWorkItemEntry(any(String.class), any(List.class))).thenReturn(0);
		this.mockMvc
		.perform(post("/licensing/insertReplaceLicenseWorkItemEntry?").contentType(MediaType.APPLICATION_JSON_VALUE)
				.param("reason", "Sampeck, Michael V")
				.content("{\"initiateReplaceLicenseList\":[{\"employeeID\":\"0006019\",\"licenseClass\":\"Class9\",\"employeeName\":\"Sampeck, Michael V\", \"serviceUnit\":\"NORTH PLATTE\", \"reason\":\"Licnese Lost\"}]}")
				.header("emplId", "9000018").header("ldapRoleList", LDAP_SYSTEM_ADMIN + "," + LDAP_MANAGER))
		.andExpect(status().isOk()).andExpect(jsonPath("$", is(0))).andDo(print()).andReturn();
	}

}
