package com.uprr.lic.licensing.rest.service;

import java.util.Arrays;
import java.util.Map;

import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.uprr.lic.auth.EQMSUserSession;
import com.uprr.lic.config.spring.MainConfig;
import com.uprr.lic.config.xmf.util.XMFTestHelper;
import com.uprr.lic.dataaccess.Licensing.model.EmployeeDetailLicInit;
import com.uprr.lic.dataaccess.masters.dao.SysParamDao;
import com.uprr.lic.licensing.jms.mvr.MvrRestrictionMessageConvertor;
import com.uprr.lic.util.SysParamBean;

//Please add any new service to the list here: http://wiki.www.uprr.com/confluence/display/~xsat414/LIC+XMF+Services
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { MainConfig.class })
@WebAppConfiguration
public class XMFConfigTest {

  @Autowired
  private XMFTestHelper helper;

  Logger LOGGER = LoggerFactory.getLogger(XMFConfigTest.class);

  @Mock
  protected EQMSUserSession eQMSUserSession;

  @Autowired
  protected WebApplicationContext context;

  @Autowired
  public SysParamDao sysParamDao;
  
  @Before
  public void setUp() throws Exception {
    MockMvcBuilders.webAppContextSetup(context).build();
    MockitoAnnotations.initMocks(this);
  }

  @BeforeClass
  public static void setUpBeforeClass() throws Exception {
    System.setProperty("uprr.implementation.environment", "dev");
    System.setProperty("jbs.name", "dev");
  }

  @After
  public void tearDown() throws Exception {
  }

  @Ignore
  @Test
  public void testDosPut() {
    // TODO xmf client DossPutServiceClientXmfImpl is ignoring errors on
    // invalid instance id. but the xmf reply is returning errors.
    LOGGER.debug(helper.testDosPutService());
  }

   @Ignore
  @Test
  public void testDosGet() {

    // TODO xmf client DossGetServiceClientXmfImpl is ignoring errors on
    // invalid gufnId. but the xmf reply is returning errors.
    // String gufnID
    // ="PROD01/UP/EQMS/DE/EQMS/20100502/171317/20100502102347045.pdf";
    String gufnID = "DEV01/UP/EQMS/DE/EQMS/20171017/201002/TESTDOSPUT.XML";
    LOGGER.debug(helper.testDosGetService(gufnID));
  }

 
  @Ignore
  @Test
  public void testGetEmployeeDetails() { 
    LOGGER.debug(helper.testgetEmployeeDetails());
  }

  @Ignore
  @Test
  public void testjobHistory() {
    LOGGER.debug(helper.testjobHistory());
  }

  @Ignore
  @Test
  public void testNBAGetEmployeePhoto() {
    LOGGER.debug(helper.testNBAgetEmployeePhoto());
  }

  @Ignore
  @Test
  public void testGetQualification() {
    LOGGER.debug(helper.testQualificationService());
  }

  @Ignore
  @Test
  public void testSearchLearningHistory() {
    LOGGER.debug(helper.testsearchLearningHistory());
  }

  @Ignore
  @Test
  public void testMedicalQualification() {
    LOGGER.debug(helper.testMedicalQualification());
  }

   @Ignore
  @Test
  public void testDisciplineInvestigation() {
    LOGGER.debug(helper.testDisciplineInvestigation());
  }

  @Ignore
  @Test
  public void testMyupMessaging() {
    LOGGER.debug(helper.testMyupService());
  }

  @Ignore
  @Test
  public void testSendLataMessage() {
    LOGGER.debug(helper.testSendLataMessage());
  }

  @Ignore
  @Test
  public void testEmailNotifcation() {
    LOGGER.debug(helper.testEmailNotifcation());
  }

  @Ignore
  @Test
  public void testGetQualificationService() {
    for (String employeeId : Arrays.asList("0413297")) {
      EmployeeDetailLicInit test = helper.testGetQualificationService(employeeId);
      LOGGER.debug(test.getBoard());
    }
  }
  @Ignore
  @Test
  public void testDownloadMVRForm() {
      helper.testDownloadMVRForm();
    }
  @Test
  public void testMVRRequestResponse() throws Exception {
    String response="<?xml version=\"1.0\" encoding=\"utf-8\"?><MVRReports ExternalReference=\"Batch.xml\"><MVRReport Version=\"2\" Name=\"MVR\" AbstractDate=\"2017-07-25\" ReportID=\"4339\"><Client><ClientID>90009</ClientID><ClientName>Union Pacific Railroad</ClientName><DivisionName>Employee Quality Management System</DivisionName><DivisionTag>EQMS</DivisionTag></Client><Driver><DriverReferenceNumber>0218964</DriverReferenceNumber><FirstName>ALLEN JR</FirstName><LastName>VARGOT</LastName><BirthDate>1981-02-22</BirthDate><Gender>M</Gender><EyeColor>BROWN</EyeColor><Height>511</Height><Weight>185</Weight></Driver><License><LicenseNumber>B8304605</LicenseNumber><LicenseState>CA</LicenseState><ClientRiskPoints>0</ClientRiskPoints><ClientRiskScore>0</ClientRiskScore></License><Classes><Class><Code>A</Code><Description>A</Description><IssueDate>2013-02-19</IssueDate><ExpirationDate>2018-02-22</ExpirationDate><Restrictions/><Endorsements><Endorsement><Text>DOUBLES/TRIPLESENDORSEMENT</Text></Endorsement><Endorsement><Text>HAZARDOUS MATERIALS ENDORSEMENT</Text></Endorsement></Endorsements></Class></Classes><LicenseComments><LicenseComment><Text>TSA CLEARANCE APPROVED HAZARDOUS MATERIALS</Text></LicenseComment><LicenseComment><Text>ENDORSEMENT EXPIRES: 01-16-16</Text></LicenseComment><LicenseComment><Text>QB: 1047-782085</Text></LicenseComment><LicenseComment><Text>SUBJECT ISSUED ID CARD 06/06/97 EXPIRES 02/25/03</Text></LicenseComment></LicenseComments><AdditionalAlerts><AdditionalAlert><Date>2017-07-25</Date><Description>MVR Received</Description><AcknowledgementStatus>Unacknowledged</AcknowledgementStatus><RiskPoints>0</RiskPoints><Attributes/></AdditionalAlert><AdditionalAlert><Date>2017-07-25</Date><Description>Medical Certificate Expiration Date Is Expired</Description><AcknowledgementStatus>Unacknowledged</AcknowledgementStatus><RiskPoints>0</RiskPoints><Attributes/></AdditionalAlert></AdditionalAlerts><MedicalCertificates><MedicalCertificate><ExpirationDate>2016-12-29</ExpirationDate><Status>C</Status><SelfCertificate>NI</SelfCertificate><Description>MEDICALCERTIFICATE</Description><IssueDate>2015-01-20</IssueDate><MedicalCertificateSourceID>MVR</MedicalCertificateSourceID><ExaminerFirstName>W</ExaminerFirstName><ExaminerLastName>DOWNS</ExaminerLastName><ExaminerMDLicenseNo>CAG39617</ExaminerMDLicenseNo><ExaminerSpeciality>MDMEDEXAMINER</ExaminerSpeciality><ExaminerPhoneNo>9093902799</ExaminerPhoneNo></MedicalCertificate></MedicalCertificates><EmbeddedReport><Type>PDF</Type><Data>{08C14708-C463-4929-A9F0-594FBCD4D1A1}</Data></EmbeddedReport></MVRReport></MVRReports>";
    Map<String, SysParamBean> sysParmaMap = sysParamDao.getAllSystemParameter();
    new MvrRestrictionMessageConvertor().parseMessage(response, sysParmaMap);
  }

}
