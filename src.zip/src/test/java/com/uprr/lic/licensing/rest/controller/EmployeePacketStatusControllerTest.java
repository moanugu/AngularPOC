package com.uprr.lic.licensing.rest.controller;

import static org.hamcrest.Matchers.is;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.hamcrest.core.IsNull;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.uprr.lic.config.spring.MainConfig;
import com.uprr.lic.dataaccess.Licensing.model.License;
import com.uprr.lic.exception.EqmDaoException;
import com.uprr.lic.licensing.rest.model.EmpPacketStatusResponse;
import com.uprr.lic.licensing.rest.model.LicensingRequest;
import com.uprr.lic.licensing.rest.service.IEmployeePacketStatusService;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes={MainConfig.class})
@WebAppConfiguration
@Ignore
public class EmployeePacketStatusControllerTest {

	private static final String LDAP_SYSTEM_ADMIN = "EQM-SYSTEM-ADMIN";
	private static final String LDAP_MANAGER = "EQM_Manager";

	private MockMvc mockMvc;

	@Autowired
	private WebApplicationContext applicationContext;

	@Mock
	private LicensingRequest licensingRequest;

	@Mock
	private IEmployeePacketStatusService employeePacketStatusService;

	@Autowired
	@InjectMocks
	private EmployeePacketStatusController controller;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		System.setProperty("uprr.implementation.environment", "local");
		System.setProperty("jbs.name", "localhost");
	}

	@Before
	public void setUp() throws Exception {
		this.mockMvc = MockMvcBuilders.webAppContextSetup(applicationContext).build();
		MockitoAnnotations.initMocks(this);
	}


	@Test
	public void testGetEmpPackStatusListForEmpl_case_1() throws Exception {

		List<EmpPacketStatusResponse> list = new ArrayList<EmpPacketStatusResponse>();
		EmpPacketStatusResponse employee = new EmpPacketStatusResponse();
		employee.setResult("Pass");
		employee.setResultDate("03/20/2017");
		employee.setRecordType("MVR");
		employee.setResnId(122);
		License license = new License();
		license.setLicenseClass("Class 3-Student Engineer");
		employee.setLicense(license);
		employee.setRecordType("MVR");
		employee.setEmployeeName("Lawrence, Bryan G");
		employee.setEmployeeID("0298376");
		employee.setServiceUnit("NORTH LITTLE ROCK");
		employee.setSvcUnitNbr(6);
		list.add(employee);
		when(employeePacketStatusService.getEmpPackStatusListForEmpl(any(String.class), any(Integer.class))).thenReturn(list);

		this.mockMvc.perform(get("/licensing/getEmpPackStatusListForEmpl/0298376/1")
				.contentType(MediaType.APPLICATION_JSON_VALUE)
				.header("emplId", "9000018").header("ldapRoleList", LDAP_SYSTEM_ADMIN + "," + LDAP_MANAGER))
		.andExpect(status().isOk())
		.andExpect(jsonPath("$[0].result", is("Pass")))
		.andExpect(jsonPath("$[0].resultDate", is("03/20/2017")))
		.andExpect(jsonPath("$[0].recordType", is("MVR")))
		.andExpect(jsonPath("$[0].resnId", is(122)))
		.andExpect(jsonPath("$[0].license.licenseClass", is("Class 3-Student Engineer")))
		.andExpect(jsonPath("$[0].license.state", is(IsNull.nullValue())))
		.andExpect(jsonPath("$[0].license.reason", is(IsNull.nullValue())))
		.andExpect(jsonPath("$[0].license.assignedManager", is(IsNull.nullValue())))
		.andExpect(jsonPath("$[0].license.skillRideConductedBy", is(IsNull.nullValue())))
		.andExpect(jsonPath("$[0].license.bulletinLocation", is(IsNull.nullValue())))
		.andExpect(jsonPath("$[0].license.licenseClassDescription", is(IsNull.nullValue())))
		.andExpect(jsonPath("$[0].license.licenseType", is(IsNull.nullValue())))
		.andExpect(jsonPath("$[0].license.licenseClassAll", is(IsNull.nullValue())))
		.andExpect(jsonPath("$[0].license.startDate", is(IsNull.nullValue())))
		.andExpect(jsonPath("$[0].license.expireDate", is(IsNull.nullValue())))
		.andExpect(jsonPath("$[0].license.city", is(IsNull.nullValue())))
		.andExpect(jsonPath("$[0].license.classNumber", is(IsNull.nullValue())))
		.andExpect(jsonPath("$[0].license.issueDate", is(IsNull.nullValue())))
		.andExpect(jsonPath("$[0].license.lastSkillRide", is(IsNull.nullValue())))
		.andExpect(jsonPath("$[0].license.effectiveDate", is(IsNull.nullValue())))
		.andExpect(jsonPath("$[0].license.issuedBy", is(IsNull.nullValue())))
		.andExpect(jsonPath("$[0].svcUnitNbr", is(6)))
		.andExpect(jsonPath("$[0].employeeName", is("Lawrence, Bryan G")))
		.andExpect(jsonPath("$[0].employeeID", is("0298376")))

		.andExpect(jsonPath("$[0].serviceUnit", is("NORTH LITTLE ROCK")))
		.andExpect(jsonPath("$[0].actionTakenBy", is(IsNull.nullValue())))
		.andReturn();
	}

	@Test
	public void testGetEmpPackStatusListForEmpl_case_2() throws Exception {
		List<EmpPacketStatusResponse> list = new ArrayList<EmpPacketStatusResponse>();

		EmpPacketStatusResponse employee = new EmpPacketStatusResponse();
		employee.setResult("Pass");
		employee.setResultDate("01/17/2017");
		employee.setRecordType("NDR");
		employee.setResnId(124);
		License license = new License();
		license.setLicenseClass("Class 3-Student Engineer");
		employee.setLicense(license);
		employee.setEmployeeName("Lawrence, Bryan G");
		employee.setEmployeeID("0298376");
		employee.setServiceUnit("NORTH LITTLE ROCK");
		employee.setSvcUnitNbr(6);
		list.add(employee);
		when(employeePacketStatusService.getEmpPackStatusListForEmpl(any(String.class), any(Integer.class))).thenReturn(list);
		this.mockMvc.perform(get("/licensing/getEmpPackStatusListForEmpl/0298376/2")
				.contentType(MediaType.APPLICATION_JSON_VALUE)
				.header("emplId", "9000018").header("ldapRoleList", LDAP_SYSTEM_ADMIN + "," + LDAP_MANAGER))
		.andExpect(status().isOk()).andExpect(jsonPath("$[0].result", is("Pass")))
		.andExpect(jsonPath("$[0].resultDate", is("01/17/2017")))
		.andExpect(jsonPath("$[0].recordType", is("NDR")))
		.andExpect(jsonPath("$[0].resnId", is(124)))
		.andExpect(jsonPath("$[0].license.licenseClass", is("Class 3-Student Engineer")))
		.andExpect(jsonPath("$[0].license.state", is(IsNull.nullValue())))
		.andExpect(jsonPath("$[0].license.reason", is(IsNull.nullValue())))
		.andExpect(jsonPath("$[0].license.assignedManager", is(IsNull.nullValue())))
		.andExpect(jsonPath("$[0].license.skillRideConductedBy", is(IsNull.nullValue())))
		.andExpect(jsonPath("$[0].license.bulletinLocation", is(IsNull.nullValue())))
		.andExpect(jsonPath("$[0].license.licenseClassDescription", is(IsNull.nullValue())))
		.andExpect(jsonPath("$[0].license.licenseType", is(IsNull.nullValue())))
		.andExpect(jsonPath("$[0].license.licenseClassAll", is(IsNull.nullValue())))
		.andExpect(jsonPath("$[0].license.startDate", is(IsNull.nullValue())))
		.andExpect(jsonPath("$[0].license.expireDate", is(IsNull.nullValue())))
		.andExpect(jsonPath("$[0].license.city", is(IsNull.nullValue())))
		.andExpect(jsonPath("$[0].license.classNumber", is(IsNull.nullValue())))
		.andExpect(jsonPath("$[0].license.issueDate", is(IsNull.nullValue())))
		.andExpect(jsonPath("$[0].license.lastSkillRide", is(IsNull.nullValue())))
		.andExpect(jsonPath("$[0].license.effectiveDate", is(IsNull.nullValue())))
		.andExpect(jsonPath("$[0].license.issuedBy", is(IsNull.nullValue())))
		.andExpect(jsonPath("$[0].svcUnitNbr", is(6)))
		.andExpect(jsonPath("$[0].employeeName", is("Lawrence, Bryan G")))
		.andExpect(jsonPath("$[0].employeeID", is("0298376")))

		.andExpect(jsonPath("$[0].serviceUnit", is("NORTH LITTLE ROCK")))
		.andExpect(jsonPath("$[0].actionTakenBy", is(IsNull.nullValue())))
		.andReturn();
	}

	@Test
	public void testGetEmpPackStatusListForEmpl_case_3() throws Exception {

		List<EmpPacketStatusResponse> list = new ArrayList<EmpPacketStatusResponse>();
		EmpPacketStatusResponse employee = new EmpPacketStatusResponse();
		employee.setResult("-");
		employee.setResultDate("-");
		employee.setRecordType("Employee Authorization");
		License license = new License();
		license.setLicenseClass("Class 3-Student Engineer");
		employee.setLicense(license);
		employee.setEmployeeName("Lawrence, Bryan G");
		employee.setEmployeeID("0298376");
		employee.setServiceUnit("NORTH LITTLE ROCK");
		employee.setSvcUnitNbr(6);
		list.add(employee);
		
		when(employeePacketStatusService.getEmpPackStatusListForEmpl(any(String.class), any(Integer.class))).thenReturn(list);

		this.mockMvc.perform(get("/licensing/getEmpPackStatusListForEmpl/0298376/3")
				.contentType(MediaType.APPLICATION_JSON_VALUE)
				.header("emplId", "9000018").header("ldapRoleList", LDAP_SYSTEM_ADMIN + "," + LDAP_MANAGER))
		.andExpect(status().isOk()).andExpect(jsonPath("$[0].result", is("-")))
		.andExpect(jsonPath("$[0].resultDate", is("-")))
		.andExpect(jsonPath("$[0].recordType", is("Employee Authorization")))
		.andExpect(jsonPath("$[0].resnId", is(IsNull.nullValue())))

		.andExpect(jsonPath("$[0].svcUnitNbr", is(6)))
		.andExpect(jsonPath("$[0].employeeName", is("Lawrence, Bryan G")))
		.andExpect(jsonPath("$[0].employeeID", is("0298376")))

		.andExpect(jsonPath("$[0].serviceUnit", is("NORTH LITTLE ROCK")))
		.andExpect(jsonPath("$[0].actionTakenBy", is(IsNull.nullValue())))
		.andReturn();
	}

	@Test
	public void testGetEmpPackStatusListForEmpl_case_4() throws Exception {

		List<EmpPacketStatusResponse> list = new ArrayList<EmpPacketStatusResponse>();

		EmpPacketStatusResponse employee = new EmpPacketStatusResponse();
		employee.setResult("Employee Authorization For NDR");
		employee.setResultDate("01/09/2017");
		employee.setRecordType("Employee Authorization");
		employee.setResnId(121);
		License license = new License();
		license.setLicenseClass("Class 3-Student Engineer");
		employee.setLicense(license);
		employee.setEmployeeName("Lawrence, Bryan G");
		employee.setEmployeeID("0298376");
		employee.setServiceUnit("NORTH LITTLE ROCK");
		employee.setSvcUnitNbr(6);
		list.add(employee);
		
		when(employeePacketStatusService.getEmpPackStatusListForEmpl(any(String.class), any(Integer.class))).thenReturn(list);


		this.mockMvc.perform(get("/licensing/getEmpPackStatusListForEmpl/0298376/4")
				.contentType(MediaType.APPLICATION_JSON_VALUE)
				.header("emplId", "9000018").header("ldapRoleList", LDAP_SYSTEM_ADMIN + "," + LDAP_MANAGER))
		.andExpect(status().isOk()).andExpect(jsonPath("$[0].result", is("Employee Authorization For NDR")))
		.andExpect(jsonPath("$[0].resultDate", is("01/09/2017")))
		.andExpect(jsonPath("$[0].recordType", is("Employee Authorization")))
		.andExpect(jsonPath("$[0].resnId", is(121)))
		.andExpect(jsonPath("$[0].license.licenseClass", is("Class 3-Student Engineer")))
		.andExpect(jsonPath("$[0].license.state", is(IsNull.nullValue())))
		.andExpect(jsonPath("$[0].license.reason", is(IsNull.nullValue())))
		.andExpect(jsonPath("$[0].license.assignedManager", is(IsNull.nullValue())))
		.andExpect(jsonPath("$[0].license.skillRideConductedBy", is(IsNull.nullValue())))
		.andExpect(jsonPath("$[0].license.bulletinLocation", is(IsNull.nullValue())))
		.andExpect(jsonPath("$[0].license.licenseClassDescription", is(IsNull.nullValue())))
		.andExpect(jsonPath("$[0].license.licenseType", is(IsNull.nullValue())))
		.andExpect(jsonPath("$[0].license.licenseClassAll", is(IsNull.nullValue())))
		.andExpect(jsonPath("$[0].license.startDate", is(IsNull.nullValue())))
		.andExpect(jsonPath("$[0].license.expireDate", is(IsNull.nullValue())))
		.andExpect(jsonPath("$[0].license.city", is(IsNull.nullValue())))
		.andExpect(jsonPath("$[0].license.classNumber", is(IsNull.nullValue())))
		.andExpect(jsonPath("$[0].license.issueDate", is(IsNull.nullValue())))
		.andExpect(jsonPath("$[0].license.lastSkillRide", is(IsNull.nullValue())))
		.andExpect(jsonPath("$[0].license.effectiveDate", is(IsNull.nullValue())))
		.andExpect(jsonPath("$[0].license.issuedBy", is(IsNull.nullValue())))
		.andExpect(jsonPath("$[0].svcUnitNbr", is(6)))
		.andExpect(jsonPath("$[0].employeeName", is("Lawrence, Bryan G")))
		.andExpect(jsonPath("$[0].employeeID", is("0298376")))

		.andExpect(jsonPath("$[0].serviceUnit", is("NORTH LITTLE ROCK")))
		.andExpect(jsonPath("$[0].actionTakenBy", is(IsNull.nullValue())))
		.andReturn();
	}

	@Test
	public void testGetEmpPackStatusListForEmpl_case_5() throws Exception {
		List<EmpPacketStatusResponse> list = new ArrayList<EmpPacketStatusResponse>();

		EmpPacketStatusResponse employee = new EmpPacketStatusResponse();

		employee.setResult("Received");
		employee.setResultDate("01/09/2017");
		employee.setRecordType("Employee Authorization");
		employee.setResnId(121);
		License license = new License();
		license.setLicenseClass("Class 3-Student Engineer");
		employee.setLicense(license);
		employee.setEmployeeName("Lawrence, Bryan G");
		employee.setEmployeeID("0298376");
		employee.setServiceUnit("NORTH LITTLE ROCK");
		employee.setSvcUnitNbr(6);
		list.add(employee);
		when(employeePacketStatusService.getEmpPackStatusListForEmpl(any(String.class), any(Integer.class))).thenReturn(list);

		this.mockMvc.perform(get("/licensing/getEmpPackStatusListForEmpl/0298376/5")
				.contentType(MediaType.APPLICATION_JSON_VALUE)
				.header("emplId", "9000018").header("ldapRoleList", LDAP_SYSTEM_ADMIN + "," + LDAP_MANAGER))
		.andExpect(status().isOk()).andExpect(jsonPath("$[0].result", is("Received")))
		.andExpect(jsonPath("$[0].resultDate", is("01/09/2017")))
		.andExpect(jsonPath("$[0].recordType", is("Employee Authorization")))
		.andExpect(jsonPath("$[0].resnId", is(121)))
		.andExpect(jsonPath("$[0].license.licenseClass", is("Class 3-Student Engineer")))
		.andExpect(jsonPath("$[0].license.state", is(IsNull.nullValue())))
		.andExpect(jsonPath("$[0].license.reason", is(IsNull.nullValue())))
		.andExpect(jsonPath("$[0].license.assignedManager", is(IsNull.nullValue())))
		.andExpect(jsonPath("$[0].license.skillRideConductedBy", is(IsNull.nullValue())))
		.andExpect(jsonPath("$[0].license.bulletinLocation", is(IsNull.nullValue())))
		.andExpect(jsonPath("$[0].license.licenseClassDescription", is(IsNull.nullValue())))
		.andExpect(jsonPath("$[0].license.licenseType", is(IsNull.nullValue())))
		.andExpect(jsonPath("$[0].license.licenseClassAll", is(IsNull.nullValue())))
		.andExpect(jsonPath("$[0].license.startDate", is(IsNull.nullValue())))
		.andExpect(jsonPath("$[0].license.expireDate", is(IsNull.nullValue())))
		.andExpect(jsonPath("$[0].license.city", is(IsNull.nullValue())))
		.andExpect(jsonPath("$[0].license.classNumber", is(IsNull.nullValue())))
		.andExpect(jsonPath("$[0].license.issueDate", is(IsNull.nullValue())))
		.andExpect(jsonPath("$[0].license.lastSkillRide", is(IsNull.nullValue())))
		.andExpect(jsonPath("$[0].license.effectiveDate", is(IsNull.nullValue())))
		.andExpect(jsonPath("$[0].license.issuedBy", is(IsNull.nullValue())))
		.andExpect(jsonPath("$[0].svcUnitNbr", is(6)))
		.andExpect(jsonPath("$[0].employeeName", is("Lawrence, Bryan G")))
		.andExpect(jsonPath("$[0].employeeID", is("0298376")))

		.andExpect(jsonPath("$[0].serviceUnit", is("NORTH LITTLE ROCK")))
		.andExpect(jsonPath("$[0].actionTakenBy", is(IsNull.nullValue())))
		.andReturn();
	}

	@Test
	public void testGetEmpPackStatusListForEmpl_case_6() throws Exception {

		List<EmpPacketStatusResponse> list = new ArrayList<EmpPacketStatusResponse>();
		EmpPacketStatusResponse employee = new EmpPacketStatusResponse();
		employee.setResult("-");
		employee.setResultDate("-");
		employee.setRecordType("Callback");
		employee.setEmployeeName("Lawrence, Bryan G");
		employee.setEmployeeID("0298376");
		employee.setServiceUnit("NORTH LITTLE ROCK");
		employee.setSvcUnitNbr(6);
		list.add(employee);
		when(employeePacketStatusService.getEmpPackStatusListForEmpl(any(String.class), any(Integer.class))).thenReturn(list);
		this.mockMvc.perform(get("/licensing/getEmpPackStatusListForEmpl/0298376/6")
				.contentType(MediaType.APPLICATION_JSON_VALUE)
				.header("emplId", "9000018").header("ldapRoleList", LDAP_SYSTEM_ADMIN + "," + LDAP_MANAGER))
		.andExpect(status().isOk()).andExpect(jsonPath("$[0].result", is("-")))
		.andExpect(jsonPath("$[0].resultDate", is("-")))
		.andExpect(jsonPath("$[0].recordType", is("Callback")))
		.andExpect(jsonPath("$[0].resnId", is(IsNull.nullValue())))
		.andExpect(jsonPath("$[0].license",is(IsNull.nullValue())))

		.andExpect(jsonPath("$[0].svcUnitNbr", is(6)))
		.andExpect(jsonPath("$[0].employeeName", is("Lawrence, Bryan G")))
		.andExpect(jsonPath("$[0].employeeID", is("0298376")))

		.andExpect(jsonPath("$[0].serviceUnit", is("NORTH LITTLE ROCK")))
		.andExpect(jsonPath("$[0].actionTakenBy", is(IsNull.nullValue())))
		.andReturn();
	}


	@Test
	public void testCancelRevokeRequest() throws Exception {

		String reuest = "{\"workItemID\": 897,\"licOprnID\": 98,\"oprnCode\": \"N\",\"comment\": \"Testing with mock\",\"serviceNumber\": 101,\"emplId\": \"879654\",\"initiatorId\": \"5\",\"studentFlag\": false}";
		doThrow(EqmDaoException.class).when(employeePacketStatusService).cancelRevokeRequest(licensingRequest);
		this.mockMvc.perform(post("/licensing/cancelLicensingRequirement")
				.content(reuest)
				.contentType(MediaType.APPLICATION_JSON_VALUE).header("emplId",
						"9000018") .header("ldapRoleList", LDAP_SYSTEM_ADMIN + "," +
								LDAP_MANAGER))
		.andExpect(status().is(500)).
		andReturn();
	}

	@Test
	public void testSendStatusReport() throws Exception {
		doThrow(EqmDaoException.class).when(employeePacketStatusService).sendStatusReport(null, null, null);
		this.mockMvc.perform(post("/licensing/sendStatusReport")
				.contentType(MediaType.APPLICATION_JSON_VALUE)
				.content("{\"employeeIdList\":[\"0298376\"]}")
				.header("emplId", "9000018").header("ldapRoleList", LDAP_SYSTEM_ADMIN + "," + LDAP_MANAGER))
		.andExpect(status().is(500))
		.andReturn();
	}

}
