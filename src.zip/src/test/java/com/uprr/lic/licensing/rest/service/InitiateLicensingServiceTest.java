package com.uprr.lic.licensing.rest.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.uprr.lic.auth.EQMSUserBean;
import com.uprr.lic.auth.EQMSUserSession;
import com.uprr.lic.config.spring.MainConfig;
import com.uprr.lic.dataaccess.Licensing.model.EmployeeDetailLicInit;
import com.uprr.lic.dataaccess.Licensing.model.InitiateLicensingRequestBean;
import com.uprr.lic.dataaccess.Licensing.model.License;
import com.uprr.lic.dataaccess.common.model.EqmEmplDtls;
import com.uprr.lic.dataaccess.common.model.EqmTestDtls;
import com.uprr.lic.dataaccess.common.model.PersonBean;
import com.uprr.lic.dataaccess.components.licensing.service.LicensingServiceImpl;
import com.uprr.lic.dataaccess.masters.service.SysParamServiceImpl;
import com.uprr.lic.licensing.rest.model.InitiateLicensingRequest;
import com.uprr.lic.util.DDChoice;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { MainConfig.class })
@WebAppConfiguration
public class InitiateLicensingServiceTest {

	private static final String EMP_ID = "9000018";
	
	private MockMvc mockMvc;
	
	@Autowired
	private WebApplicationContext applicationContext;

	@Mock
	private LicensingServiceImpl licenseService;
	
	@Mock
	private PersonBean personBean;
	
	@Mock
	private InitiateLicensingRequestBean initiateLicensingRequestBean;
	
	@Mock
	private InitiateLicensingRequest initiateLicensingRequest;
	
	@Mock
	private EmployeeDetailLicInit employeeDetailLicInit;
	
	@Mock
	private EqmTestDtls eqmTestDtls;
	
	@Mock
	private License license;
	
	@Mock
	private EqmEmplDtls eqmEmplDtls;
	

	@Mock
	private EQMSUserSession eqmsUserSession;

	@Mock
	private SysParamServiceImpl sysParamService;
	
	@Mock
	private EQMSUserBean eQMSUserBean;
	
	@Autowired
	@InjectMocks
	private InitiateLicensingService initiateLicensingService;
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		System.setProperty("uprr.implementation.environment", "local");
		 System.setProperty("jbs.name", "localhost");
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		this.mockMvc = MockMvcBuilders.webAppContextSetup(applicationContext).build();
		MockitoAnnotations.initMocks(this);
		 
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testGetEmployeeDetails() {
		when(personBean.getEmplFirstName()).thenReturn("Ravi");
		when(personBean.getEmplLastName()).thenReturn("Kushwaha");
		when(initiateLicensingService.getEmployeeDetails(EMP_ID)).thenReturn(personBean);
		
		PersonBean result =initiateLicensingService.getEmployeeDetails(EMP_ID);
		assertThat(result.getEmplFirstName()).isEqualTo("Ravi");
		assertThat(result.getEmplLastName()).isEqualTo("Kushwaha");
			
	}

	@Test
	public void testInsertNewEmployee() {
		when(eQMSUserBean.getEmplId()).thenReturn(EMP_ID);
		when(eqmsUserSession.getUser()).thenReturn(eQMSUserBean);
		when(initiateLicensingService.insertNewEmployee(personBean)).thenReturn(true);
		boolean result =licenseService.insertNewEmployee(personBean, EMP_ID);
		assertThat(result).isEqualTo(true);
	}

	@Test
	public void testGetAllLicenseTypeList() {
		List<DDChoice> mockLicenseTypeList = new ArrayList<>();
		DDChoice ddCon = new DDChoice();
		ddCon.setStrKey("CON");
		ddCon.setValue("Conductor");
		mockLicenseTypeList.add(ddCon);
		DDChoice ddEng = new DDChoice();
		ddEng.setStrKey("ENG");
		ddEng.setValue("Engineer");
		mockLicenseTypeList.add(ddEng);
		DDChoice ddRco = new DDChoice();
		ddRco.setStrKey("RCO");
		ddRco.setValue("Remote Control Operator");
		mockLicenseTypeList.add(ddRco);
		DDChoice ddHost = new DDChoice();
		ddHost.setStrKey("HOS");
		ddHost.setValue("Hostler");
		mockLicenseTypeList.add(ddHost);
		
		when(initiateLicensingService.getAllLicenseTypeList(null)).thenReturn(mockLicenseTypeList);
		
		List<DDChoice> result = initiateLicensingService.getAllLicenseTypeList(null);
		assertThat(result.get(0).getStrKey()).isEqualTo(ddCon.getStrKey());
		assertThat(result.get(1).getStrKey()).isEqualTo(ddEng.getStrKey());
		assertThat(result.get(2).getStrKey()).isEqualTo(ddRco.getStrKey());
		assertThat(result.get(3).getStrKey()).isEqualTo(ddHost.getStrKey());
		
	}

	@Test
	public void testInitializeLicensingRequest() {
		List<EmployeeDetailLicInit> finalList= new ArrayList<EmployeeDetailLicInit>();
		when(employeeDetailLicInit.getEmpFirstName()).thenReturn("Ravi");
		when(employeeDetailLicInit.getEmpLastName()).thenReturn("Kushwaha");
		finalList.add(employeeDetailLicInit);
		
		when(initiateLicensingRequestBean.getEmployeeID()).thenReturn(EMP_ID);
		
		HashMap<License,List<EmployeeDetailLicInit>> licenseRequestMap = new HashMap<License,List<EmployeeDetailLicInit>>();
		licenseRequestMap.put(license, finalList);
		
		initiateLicensingRequestBean.setInitiateLicensingRequest(licenseRequestMap);
		when(initiateLicensingService.initializeLicensingRequest(initiateLicensingRequestBean, finalList)).thenReturn(initiateLicensingRequestBean);
		
		InitiateLicensingRequestBean result =  initiateLicensingService.initializeLicensingRequest(initiateLicensingRequestBean, finalList);
		assertThat(result).isNotNull();
		assertThat(result.getEmployeeID()).isEqualTo(EMP_ID);
		assertThat(result.getEmployeeID()).isEqualTo(EMP_ID);
		assertThat(result.getEmployeeID()).isEqualTo(EMP_ID);
		
	}

	@Test
	public void testCreateInitiateLicenseRequest() {
		
	}

	@Test
	public void testIsEmployeeLicensed() {
		
		when(initiateLicensingService.isEmployeeLicensed(EMP_ID, false)).thenReturn(true);
		Boolean result =  initiateLicensingService.isEmployeeLicensed(EMP_ID, false);
		assertThat(result).isNotNull();
		assertThat(result).isEqualTo(true);
	}

	@Test
	public void testCheckForValidTestDetailsAvailability() {
		when(eqmTestDtls.getTestId()).thenReturn(14);
		when(eqmTestDtls.getCrtnEmplId()).thenReturn(EMP_ID);
		when(initiateLicensingService.checkForValidTestDetailsAvailability(EMP_ID, 14)).thenReturn(eqmTestDtls);
		
		EqmTestDtls result = initiateLicensingService.checkForValidTestDetailsAvailability(EMP_ID, 14);
		
		assertThat(result.getCrtnEmplId()).isEqualTo(EMP_ID);
		assertThat(result.getTestId()).isEqualTo(14);
	}

	@Test
	public void testGetEmployeeDetailsForInitiateLicenseRequest() throws Exception{
		when(employeeDetailLicInit.getEmpFirstName()).thenReturn("Ravi");
		when(employeeDetailLicInit.getEmpLastName()).thenReturn("Kushwaha");
		when(initiateLicensingService.getEmployeeDetailsForInitiateLicenseRequest(initiateLicensingRequestBean)).thenReturn(employeeDetailLicInit);
		
		EmployeeDetailLicInit result = initiateLicensingService.getEmployeeDetailsForInitiateLicenseRequest(initiateLicensingRequestBean);
		assertThat(result.getEmpFirstName()).isEqualTo("Ravi");
		assertThat(result.getEmpLastName()).isEqualTo("Kushwaha");
	}

	@Test
	public void testGetEmplDtls() {
		when(eqmEmplDtls.getEmplFirName()).thenReturn("Ravi");
		when(eqmEmplDtls.getEmplLastName()).thenReturn("Kushwaha");
		when(initiateLicensingService.getEmplDtls(EMP_ID)).thenReturn(eqmEmplDtls);
		
		EqmEmplDtls result = initiateLicensingService.getEmplDtls(EMP_ID);
		
		assertThat(result.getEmplFirName()).isEqualTo("Ravi");
		assertThat(result.getEmplLastName()).isEqualTo("Kushwaha");
	}

	@Test
	public void testInitializeAndCreateLicensingRequest() {
		when(eQMSUserBean.getEmplId()).thenReturn(EMP_ID);
		when(eqmsUserSession.getUser()).thenReturn(eQMSUserBean);
		
		when(employeeDetailLicInit.getEmpFirstName()).thenReturn("Ravi");
		when(employeeDetailLicInit.getEmpLastName()).thenReturn("Kushwaha");
		
		List<EmployeeDetailLicInit> employeeDetailLicInitList = Arrays.asList(employeeDetailLicInit);
		
		Map<String, Map<String, EmployeeDetailLicInit>> resultMap= new HashMap<String, Map<String, EmployeeDetailLicInit>>();
		Map<String, EmployeeDetailLicInit> value = new HashMap<String, EmployeeDetailLicInit>();
		value.put(EMP_ID, employeeDetailLicInit);
		resultMap.put("test", value);
		
		when(initiateLicensingService.initializeAndCreateLicensingRequest(initiateLicensingRequestBean, employeeDetailLicInitList)).thenReturn(resultMap);
		
		Map<String, Map<String, EmployeeDetailLicInit>> result = initiateLicensingService.initializeAndCreateLicensingRequest(initiateLicensingRequestBean,employeeDetailLicInitList);
		
		assertThat(result.size()).isGreaterThan(0);
		assertThat(result.get("test")).isNotNull();
		assertThat(result.get("test").size()).isGreaterThan(0);
		assertThat(result.get("test").get(EMP_ID)).isNotNull();
		assertThat(result.get("test").get(EMP_ID).getEmpFirstName()).isNotNull();
		assertThat(result.get("test").get(EMP_ID).getEmpFirstName()).isEqualTo("Ravi");
		assertThat(result.get("test").get(EMP_ID).getEmpLastName()).isNotNull();
		assertThat(result.get("test").get(EMP_ID).getEmpLastName()).isEqualTo("Kushwaha");
	}

}

