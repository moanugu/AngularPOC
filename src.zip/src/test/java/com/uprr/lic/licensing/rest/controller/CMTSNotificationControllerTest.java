package com.uprr.lic.licensing.rest.controller;

import static org.hamcrest.Matchers.is;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.uprr.lic.config.spring.MainConfig;
import com.uprr.lic.dataaccess.Licensing.model.LcnsDtlsObj;
import com.uprr.lic.licensing.rest.model.LicensingRequest;
import com.uprr.lic.licensing.rest.service.ICMTSNotificationRestService;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { MainConfig.class })
@WebAppConfiguration
@Ignore
public class CMTSNotificationControllerTest {

	private static final String LDAP_SYSTEM_ADMIN = "EQM-SYSTEM-ADMIN";
	private static final String LDAP_MANAGER = "EQM_Manager";

	private MockMvc mockMvc;

	@Autowired
	private WebApplicationContext applicationContext;

	@Mock
	private LicensingRequest licensingRequest;
	
	@Mock
	private LcnsDtlsObj lcnsDtlsObj;
	
	@Mock
	private ICMTSNotificationRestService cmIcmtsNotificationRestService;
	
	@Autowired
	@InjectMocks
	private CMTSNotificationController cmtsNotificationController;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		System.setProperty("uprr.implementation.environment", "local");
		System.setProperty("jbs.name", "localhost");
	}

	@Before
	public void setUp() throws Exception {
		this.mockMvc = MockMvcBuilders.webAppContextSetup(applicationContext).build();
		MockitoAnnotations.initMocks(this);
	}


	@Test
	public void testGetLicenseDetailsForEmpl() throws Exception {
		List<LcnsDtlsObj> reponseList = new ArrayList<LcnsDtlsObj>();
		LcnsDtlsObj lcnsDtlsObj = new LcnsDtlsObj();
		lcnsDtlsObj.setEmplId("006019");
		lcnsDtlsObj.setCertFlag("Sampeck, Michael V");
		/*Calendar calendar = Calendar.getInstance();
		calendar.set(2017, 11, 15);
		lcnsDtlsObj.setEffDate(calendar);
		lcnsDtlsObj.setIssueDate(calendar);*/
		lcnsDtlsObj.setLcnsClasCode("License Lost");
		//lcnsDtlsObj.setExpnDate(calendar);
		reponseList.add(lcnsDtlsObj);

		when(cmIcmtsNotificationRestService.getLicenseDetailsForEmpl(any(String.class))).thenReturn(reponseList);
		this.mockMvc
		.perform(post("/licensing/getLicenseDetailsForEmpl?").contentType(MediaType.APPLICATION_JSON_VALUE)
				.param("employeeId", "006019")
				.header("emplId", "9000018").header("ldapRoleList", LDAP_SYSTEM_ADMIN + "," + LDAP_MANAGER))
		.andExpect(status().isOk()).andExpect(content().string("[{\"emplId\":\"006019\",\"lcnsClasCode\":\"License Lost\",\"certFlag\":\"Sampeck, Michael V\",\"effDate\":null,\"issueDate\":null,\"expnDate\":null}]")).andReturn();
	}

	@Test
	public void testSendNtfnToCMTS() throws Exception {
	
		
		when(cmIcmtsNotificationRestService.sendNtfnToCMTS(any(String.class), any(List.class), any(List.class))).thenReturn(true);
		
		this.mockMvc
		.perform(post("/licensing/sendNtfnToCMTS?").contentType(MediaType.APPLICATION_JSON_VALUE)
				.param("employeeId", "006019")
				.content("{\"licenseDetailList\":[{\"emplId\":\"006019\",\"lcnsClasCode\":\"License Lost\",\"certFlag\":\"Sampeck, Michael V\",\"effDate\":null,\"issueDate\":null,\"expnDate\":null}], \"licenseClassList\":[\"Class 1\",\"Class 3\",\"Class 2\",\"Class 5\",\"Class 7\",\"Class 6\",\"Class 9\"]}")
				.header("emplId", "9000018").header("ldapRoleList", LDAP_SYSTEM_ADMIN + "," + LDAP_MANAGER))
		.andExpect(status().isOk()).andExpect(jsonPath("$", is(true))).andReturn();
	}

}
