package com.uprr.lic.licensing.rest.controller;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.uprr.lic.config.spring.MainConfig;
import com.uprr.lic.dataaccess.common.model.EqmEmplDtls;
import com.uprr.lic.dataaccess.twic.model.TwicBean;
import com.uprr.lic.exception.EqmDaoException;
import com.uprr.lic.licensing.rest.model.LicensingRequest;
import com.uprr.lic.licensing.rest.model.TwicDetailResponse;
import com.uprr.lic.licensing.rest.service.ITwicRestService;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { MainConfig.class })
@WebAppConfiguration
@Ignore
public class TwicControllerTest {

	private static final String LDAP_SYSTEM_ADMIN = "EQM-SYSTEM-ADMIN";
	private static final String LDAP_MANAGER = "EQM_Manager";

	private MockMvc mockMvc;

	@Autowired
	private WebApplicationContext applicationContext;

	@Mock
	private ITwicRestService twicRestService;

	@Autowired
	@InjectMocks
	private TwicController twicController;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		System.setProperty("uprr.implementation.environment", "local");
		System.setProperty("jbs.name", "localhost");
	}

	@Before
	public void setUp() throws Exception {
		this.mockMvc = MockMvcBuilders.webAppContextSetup(applicationContext).build();
		MockitoAnnotations.initMocks(this);
	}


	@Test
	public void testGetEmplName() throws Exception {

		String mockedResponseString = "[{\"emplId\":\"0298376\",\"eqmSvcUnit\":{\"svcUnitNbr\":6,\"eqmReg\":null,\"svcUnitName\":null,\"svcUnitCode\":null,\"histRcdFlag\":\"N\",\"crtnDate\":null,\"crtnEmplId\":null,\"lastUptdDate\":null,\"lastUptdEmplId\":null,\"rowVrsnNbr\":0,\"eqmSvcUnitOvrdHistsForOldSvcUnitNbr\":[],\"eqmWunts\":[],\"eqmActnPlanTmpts\":[],\"eqmEvntDtlses\":[],\"eqmEmplDtlsHists\":[],\"eqmEmplRoleAreas\":[],\"eqmSvcUnitOvrdHistsForNewSvcUnitNbr\":[],\"eqmAsgnDtlses\":[],\"eqmEmplDtlses\":[],\"eqmLcnsInits\":[],\"eqmBitEvnt\":[],\"eqmBitEvntDtlsForEvnt\":[],\"eqmBitEvntDtls\":[],\"eqmThrcYardSvcUnitMpng\":[]},\"emplLastName\":\"LAWRENCE\",\"emplFirName\":\"BRYAN\",\"emplMidName\":\"GREGORY\",\"cmtsStatCode\":null,\"emplCrc7\":null,\"actFlag\":\"N\",\"emplBordName\":null,\"histRcdFlag\":\"N\",\"agrmNaInd\":\"Y\",\"birDate\":null,\"crftCode\":null,\"waveFlag\":\"N\",\"ovrdFlag\":\"N\",\"emplHireDate\":null,\"cntrFlag\":\"N\",\"ertCode\":null,\"emplStatCode\":null,\"crtnDate\":null,\"crtnEmplId\":null,\"lastUptdDate\":null,\"lastUptdEmplId\":null,\"rowVrsnNbr\":0,\"ovrdErtDate\":null,\"eqmActnPlanEmplMps\":[],\"ovrdErtFlag\":\"N\",\"jobCode\":null,\"posTitle\":null,\"workCity\":null,\"deptDesc\":null,\"posNbr\":null,\"ovrdErtCode\":null,\"emplTotlScorNbr\":null,\"emplScorCalcDate\":null,\"deptCode\":null,\"eqmDsgnRvkeReqs\":[],\"eqmWuntMgrMpngs\":[],\"eqmDcrtOthEvntDtlses\":[],\"eqmLcnsRqmts\":[],\"eqmEmplCmntDtlsesForActnTakeBy\":[],\"eqmLcnsDtlses\":[],\"eqmPackDtlsesForEmplId\":[],\"eqmSvcUnitOvrdHists\":[],\"eqmTestDtlses\":[],\"eqmEvntCmntDtlses\":[],\"eqmEmplDocs\":[],\"eqmAsgnDtlsesForMgrId\":[],\"eqmDrvRcdHistsForEmplId\":[],\"eqmLcnsOprns\":[],\"eqmEmplDtlsHists\":[],\"eqmRmdlTrngDtlses\":[],\"eqmEmplRoleMpngs\":[],\"eqmDenyDtlses\":[],\"eqmPackDtlsesForActnTakeBy\":[],\"eqmLcnsPrntDtlses\":[],\"eqmDrvRcdHistsForActnTakeBy\":[],\"eqmEmplEvntDtlses\":[],\"eqmEmplCmntDtlsesForEmplId\":[],\"eqmDcrtEmplStats\":[],\"eqmEdrEmplMpngs\":[],\"eqmEmplSleDsgns\":[],\"eqmAsgnDtlsesForEmplId\":[],\"eqmChngClases\":[],\"eqmFaxDtls\":[],\"eqmEmplRestDtlses\":[],\"eqmEmplPndgRuDtlses\":[],\"eqmFtxMgrGrpEmpls\":[],\"eqmFtxEmplPlanMpngs\":[],\"eqmFtxEmplGoalMpngs\":[],\"eqmFtxEmplCatgRules\":[],\"eqmFtxPlanTracs\":[],\"eqmUserMsgsAckm\":[],\"eqmFteUserAccs\":[],\"eqmThrcStatDtls\":[],\"eqmThrcCrewDtls\":[],\"eqmBitEvntEmplDtls\":[]}]";
		
		when(twicRestService.getEmplName(any(String.class))).thenReturn(convertJsonArrayToList());

		this.mockMvc
		.perform(post("/licensing/getEmployeeNameList?").contentType(MediaType.APPLICATION_JSON_VALUE)
				.param("employeeId", "0298376")
				.header("emplId", "9000018").header("ldapRoleList", LDAP_SYSTEM_ADMIN + "," + LDAP_MANAGER))
		.andExpect(status().isOk()).andExpect(content().string(mockedResponseString)).andReturn();
	}

	@Test
	public void testSubmitTwicDetails() throws Exception {

		List<TwicDetailResponse> emplGridList = new ArrayList<TwicDetailResponse>();
		TwicDetailResponse twicDetails = new TwicDetailResponse();
		twicDetails.setUpdateFlag(false);
		twicDetails.setEmployeeID("0298376");

		/*TwicBean bean = twicController.getTwicDtls("0298376");
		if(bean != null& bean.getExpireDate() != null) {
			twicDetails.setExpireDate(bean.getExpireDate());
			twicDetails.setUpdateFlag(true);
		}


		if(bean != null & bean.isRenewCheckbox()) {*/
		twicDetails.setRenewCheckbox(true);
		/*}*/
		emplGridList.add(twicDetails);
		LicensingRequest licensingRequest = new LicensingRequest();
		licensingRequest.setTwicDetailList(emplGridList);

		doThrow(EqmDaoException.class).when(twicRestService).submitTwicDetails(emplGridList, 101);

		this.mockMvc
		.perform(post("/licensing/submitTwicDetails?").contentType(MediaType.APPLICATION_JSON_VALUE)
				.param("serviceUntNbr", "102")
				.content("{\"twicDetailList\":[{\"employeeID\":null,\"empFirstName\":null,\"empMiddleName\":null,\"empLastName\":null,\"expireDate\":null,\"renewCheckbox\":false,\"employeeName\":null,\"updateFlag\":false}]}")
				.header("emplId", "9000018").header("ldapRoleList", LDAP_SYSTEM_ADMIN + "," + LDAP_MANAGER))
		.andExpect(status().isOk()).andReturn();
	}


	@Test
	public void testGetTwicDtls() throws Exception {

		String mockResponseString = "{\"employeeID\":null,\"empFirstName\":null,\"empMiddleName\":null,\"empLastName\":null,\"expireDate\":null,\"renewCheckbox\":false,\"employeeName\":null,\"updateFlag\":false}";
		when(twicRestService.getTwicDtls(any(String.class))).thenReturn((TwicDetailResponse)convertJsonStringToObject(mockResponseString, TwicBean.class));

		this.mockMvc
		.perform(post("/licensing/getTwicDetails?").contentType(MediaType.APPLICATION_JSON_VALUE)
				.param("employeeId", "0298376")
				.header("emplId", "9000018").header("ldapRoleList", LDAP_SYSTEM_ADMIN + "," + LDAP_MANAGER))
		.andExpect(status().isOk()).andExpect(content().string(mockResponseString)).andReturn();
	}

	private Object convertJsonStringToObject(String jsonString, Class<?> className) {

		Object object = null;
		try {
			ObjectMapper mapper = new ObjectMapper();
			object  = mapper.readValue(jsonString, className);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return  object;
	}

	private List<EqmEmplDtls> convertJsonArrayToList() {
		String mockedResponseString = "[{\"emplId\":\"0298376\",\"eqmSvcUnit\":{\"svcUnitNbr\":6,\"eqmReg\":null,\"svcUnitName\":null,\"svcUnitCode\":null,\"histRcdFlag\":\"N\",\"crtnDate\":null,\"crtnEmplId\":null,\"lastUptdDate\":null,\"lastUptdEmplId\":null,\"rowVrsnNbr\":0,\"eqmSvcUnitOvrdHistsForOldSvcUnitNbr\":[],\"eqmWunts\":[],\"eqmActnPlanTmpts\":[],\"eqmEvntDtlses\":[],\"eqmEmplDtlsHists\":[],\"eqmEmplRoleAreas\":[],\"eqmSvcUnitOvrdHistsForNewSvcUnitNbr\":[],\"eqmAsgnDtlses\":[],\"eqmEmplDtlses\":[],\"eqmLcnsInits\":[],\"eqmBitEvnt\":[],\"eqmBitEvntDtlsForEvnt\":[],\"eqmBitEvntDtls\":[],\"eqmThrcYardSvcUnitMpng\":[]},\"emplLastName\":\"LAWRENCE\",\"emplFirName\":\"BRYAN\",\"emplMidName\":\"GREGORY\",\"cmtsStatCode\":null,\"emplCrc7\":null,\"actFlag\":\"N\",\"emplBordName\":null,\"histRcdFlag\":\"N\",\"agrmNaInd\":\"Y\",\"birDate\":null,\"crftCode\":null,\"waveFlag\":\"N\",\"ovrdFlag\":\"N\",\"emplHireDate\":null,\"cntrFlag\":\"N\",\"ertCode\":null,\"emplStatCode\":null,\"crtnDate\":null,\"crtnEmplId\":null,\"lastUptdDate\":null,\"lastUptdEmplId\":null,\"rowVrsnNbr\":0,\"ovrdErtDate\":null,\"eqmActnPlanEmplMps\":[],\"ovrdErtFlag\":\"N\",\"jobCode\":null,\"posTitle\":null,\"workCity\":null,\"deptDesc\":null,\"posNbr\":null,\"ovrdErtCode\":null,\"emplTotlScorNbr\":null,\"emplScorCalcDate\":null,\"deptCode\":null,\"eqmDsgnRvkeReqs\":[],\"eqmWuntMgrMpngs\":[],\"eqmDcrtOthEvntDtlses\":[],\"eqmLcnsRqmts\":[],\"eqmEmplCmntDtlsesForActnTakeBy\":[],\"eqmLcnsDtlses\":[],\"eqmPackDtlsesForEmplId\":[],\"eqmSvcUnitOvrdHists\":[],\"eqmTestDtlses\":[],\"eqmEvntCmntDtlses\":[],\"eqmEmplDocs\":[],\"eqmAsgnDtlsesForMgrId\":[],\"eqmDrvRcdHistsForEmplId\":[],\"eqmLcnsOprns\":[],\"eqmEmplDtlsHists\":[],\"eqmRmdlTrngDtlses\":[],\"eqmEmplRoleMpngs\":[],\"eqmDenyDtlses\":[],\"eqmPackDtlsesForActnTakeBy\":[],\"eqmLcnsPrntDtlses\":[],\"eqmDrvRcdHistsForActnTakeBy\":[],\"eqmEmplEvntDtlses\":[],\"eqmEmplCmntDtlsesForEmplId\":[],\"eqmDcrtEmplStats\":[],\"eqmEdrEmplMpngs\":[],\"eqmEmplSleDsgns\":[],\"eqmAsgnDtlsesForEmplId\":[],\"eqmChngClases\":[],\"eqmFaxDtls\":[],\"eqmEmplRestDtlses\":[],\"eqmEmplPndgRuDtlses\":[],\"eqmFtxMgrGrpEmpls\":[],\"eqmFtxEmplPlanMpngs\":[],\"eqmFtxEmplGoalMpngs\":[],\"eqmFtxEmplCatgRules\":[],\"eqmFtxPlanTracs\":[],\"eqmUserMsgsAckm\":[],\"eqmFteUserAccs\":[],\"eqmThrcStatDtls\":[],\"eqmThrcCrewDtls\":[],\"eqmBitEvntEmplDtls\":[]}]";

		List<EqmEmplDtls> responseList = null;
		try {
			ObjectMapper mapper = new ObjectMapper();
			responseList  = mapper.readValue(mockedResponseString, new TypeReference<List<EqmEmplDtls>>() {});
		} catch (IOException e) {
			e.printStackTrace();
		}
		return  responseList;
	}

}
