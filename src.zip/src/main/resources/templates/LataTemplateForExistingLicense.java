package templates;

import com.uprr.app.eqm.components.licensing.model.CoverLetterForExistingLicenseDetails;

public class LataTemplateForExistingLicense {

	private final String firstMarker = "\t";
	private final String secondMarker = "\t\t";
	private final String thirdMarker = "\t\t\t\t\t\t";
	
	
	public StringBuffer getBufferForLataPrintForExtLicense(final CoverLetterForExistingLicenseDetails m_coverLetterForExistingLicenseDetails){
		
		StringBuffer stringBuffer = new StringBuffer();
		stringBuffer.append(thirdMarker+"April 21,2009");
		stringBuffer.append("\n\n");
		stringBuffer.append(firstMarker+m_coverLetterForExistingLicenseDetails.getEmployeeName());
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+m_coverLetterForExistingLicenseDetails.getAddressLine1());
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+m_coverLetterForExistingLicenseDetails.getAddressLine2());
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+m_coverLetterForExistingLicenseDetails.getCity()+","+m_coverLetterForExistingLicenseDetails.getState()+","+m_coverLetterForExistingLicenseDetails.getCountry());
		stringBuffer.append("\n\n");
		stringBuffer.append(firstMarker+"Dear "+m_coverLetterForExistingLicenseDetails.getEmployeeName()+":");
		stringBuffer.append("\n\n");
		stringBuffer.append(secondMarker);
		stringBuffer.append(firstMarker+"You have been selected as a candidate for engineer training. You have been identified as a");
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+"member of a class "+m_coverLetterForExistingLicenseDetails.getClassNumber() +" tentatively scheduled to begin your classroom field training at ");
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+"or near your work location the week of "+m_coverLetterForExistingLicenseDetails.getStartDate()+".");
		stringBuffer.append("\n\n");
		stringBuffer.append(firstMarker+"Records indicate that you have a current class of service as a Hostler or Remote Control Operator");
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+"or have completed the necessary requirements for certification. Therefore, you will NOT need to complete ");
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+"this examination again nor will you be required to resubmit forms for motor vehicle operator searches.");
		stringBuffer.append("\n\n");
		stringBuffer.append(firstMarker+"Please note:	YOUR EXPIRATION DATE AS A STUDENT ENGINEER WILL BE THE SAME AS YOUR EXPIRATION DATE AS A");
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+"HOSTLER OR REMOTE CONTROL OPERATOR.  You may be required to re-certify prior to promotion as an engineer. ");
		stringBuffer.append("\n\n");
		stringBuffer.append(secondMarker);
		stringBuffer.append(firstMarker+"If you have questions or believe this information to be incorrect, please do not hesitate to ");
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+"contact  the Licensing Department at Company line 8-544-8349/0537 or Bell line 402-544-8349/0537.");
		stringBuffer.append("\n\n");
		stringBuffer.append(secondMarker);
		stringBuffer.append(firstMarker+"As you near your classroom training date, further instructions about the Locomotive Engineer ");
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+"training process will be mailed to you from the Training Center.");
		stringBuffer.append("\n\n");
		stringBuffer.append("\t\t\t\t\t\t\t\t");
		stringBuffer.append("Sincerely,");
		stringBuffer.append("\n\n");
		stringBuffer.append("\t\t\t\t\t\t\t\t");
		stringBuffer.append(m_coverLetterForExistingLicenseDetails.getSysLicDeptManagerName()+",Manager");
		stringBuffer.append("\n");
		stringBuffer.append("\t\t\t\t\t\t\t\t");
		stringBuffer.append(m_coverLetterForExistingLicenseDetails.getSysLicDepartmentName());
		return stringBuffer;
	}

	public static void main(String[] args) {
		LataTemplateForExistingLicense lataTemplateForExistingLicense = new LataTemplateForExistingLicense();

	}
	
	private static CoverLetterForExistingLicenseDetails getTemplateDetails(){
		
		CoverLetterForExistingLicenseDetails coverLetterForExistingLicenseDetails = new CoverLetterForExistingLicenseDetails();
		coverLetterForExistingLicenseDetails.setEmployeeName("Sreekar Vanguru");
		coverLetterForExistingLicenseDetails.setAddressLine1("Satyam Computers,ManikChand Icon");
		coverLetterForExistingLicenseDetails.setAddressLine2("Bund Garden Road");
		coverLetterForExistingLicenseDetails.setCity("Pune");
		coverLetterForExistingLicenseDetails.setState("Maharastra");
		coverLetterForExistingLicenseDetails.setCountry("India");
		coverLetterForExistingLicenseDetails.setClassNumber("Class 2");
		coverLetterForExistingLicenseDetails.setStartDate("May 20,2009");
		coverLetterForExistingLicenseDetails.setSysLicDeptManagerName("L. J. Brennan");
		coverLetterForExistingLicenseDetails.setSysLicDepartmentName("Engineer Certification & Licensing");
		return coverLetterForExistingLicenseDetails;
	}

}
