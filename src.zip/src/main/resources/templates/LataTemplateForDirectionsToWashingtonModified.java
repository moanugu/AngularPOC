/**
 * Classname    : LataTemplateForDirectionsToWashingtonModified
 * Description  : Class is used as a Lata Template for Direction to Washington Employees letter.
 * author   	: Satyam Computer Services Ltd.
 * Date of creation : Jul 20, 2009
 *
 * Change History
 * ------------------------------------------------------------  
 *   Date  Changed By    Description
 * ------------------------------------------------------------  
 *
 *
 * ------------------------------------------------------------  
 *
 * Copyright notice : "Copyright � UPRR 2008"
 */
package templates;

import com.uprr.app.eqm.components.common.logger.EqmsLogger;

public class LataTemplateForDirectionsToWashingtonModified {
	
	EqmsLogger m_logger = EqmsLogger.getLoggerInstance(this.getClass());

	private final String firstMarker = padSpaceTillMaxLength(6);

	/**
	 * Classname / Method Name : LataTemplateForDirectionsToWashingtonModified/getBufferForLataPrintForDirectionsForWashington()
	 * @return : StringBuffer
	 * Description : Method is used to get contents of Direction to Washington state employees letter template.
	 */
	public StringBuffer getBufferForLataPrintForDirectionsForWashington(){

		StringBuffer stringBuffer = new StringBuffer();
		
		stringBuffer.append("\n\n");

		stringBuffer.append(firstMarker+"Note: If you have or previously had a driver's license in the ");
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+"state of Washington, you must complete UP FORM WA20001.");
		stringBuffer.append("\n\n");
		stringBuffer.append(firstMarker+"If you have a license in any other state,");
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+"ONLY use Form 20119 and Form 20999.");
		stringBuffer.append("\n\n\n");
		stringBuffer.append(firstMarker+"If you have any questions please contact");
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+"402-544-CERT (2378) or 8-544-CERT (2378).");
		
		return stringBuffer;
	}

	/**
	 * Classname / Method Name : LataTemplateForDirectionsToWashingtonModified/padSpaceTillMaxLength()
	 * @param maxLength
	 * @return : String
	 * Description : Method is used to add spaces in the template.
	 */
	private String padSpaceTillMaxLength(int maxLength)	{
		StringBuffer sb = new StringBuffer();
		for(int i=0;i<=maxLength;i++){
			sb.append(" ");
		}
		return sb.toString();
	}

	public static void main(String[] args) {
		LataTemplateForDirectionsToWashingtonModified lataTemplateForDirectionsToWashington = 
			new LataTemplateForDirectionsToWashingtonModified();
	}

}
