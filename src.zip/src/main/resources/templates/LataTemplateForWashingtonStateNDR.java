/**
 * Classname    : LataTemplateForWashingtonStateNDR
 * Description  : Class is used as a Lata template for Washington State NDR Form.
 * author   	: Satyam Computer Services Ltd.
 * Date of creation : Jun 16, 2009
 *
 * Change History
 * ------------------------------------------------------------  
 *   Date  Changed By    Description
 * ------------------------------------------------------------  
 *
 *
 * ------------------------------------------------------------  
 *
 * Copyright notice : "Copyright � UPRR 2008"
 */
package templates;

import com.uprr.app.eqm.components.common.logger.EqmsLogger;
import com.uprr.app.eqm.components.licensing.model.WashingtonStateNdrFormTemplateDetails;

public class LataTemplateForWashingtonStateNDR {
	
	EqmsLogger m_logger = EqmsLogger.getLoggerInstance(this.getClass());

	private final String horizontalLinePlain = "___________________________________________________________________________________________________________________";
	private final String horizontalLine = "|__________________________________________________________________________________________________________________|"; 
	private final String horizontalLine1 = "____________________|__________________|__________________________________________________________________________";
	private final String horizontalLine2 = "____________________________________________|____________________________________________|________________________";
	private final String horizontalLineWithMultipleBorder1 = "|________________________________________________________________________________|_________________________________|";
	private final String horizontalLineWithMultipleBorder2 = "|_______________|________|______________|____________|___________|_________________________________________________|";
	private final String horizontalLineWithMultipleBorder3 = "|________________________________________________|______________________|__________________________________________|";
	private final String horizontalLineWithMultipleBorder4 = "|_______________________________________________________________________|__________________________________________|";
	private final String horizontalLineWithMultipleBorder5 = "|__________________________________________|________________|___________|__________________________________________|";

	private final String checkBoxMarker = "|"+"_|";
	private final String leftHorizontalLine = "_______________________________________";
	private final String centerHorizontalLine = "________________________";
	//private final String extraSpaceLine = "_";

	/**
	 * Classname / Method Name : LataTemplateForWashingtonStateNDR/getBufferForWashingtonStateNdr()
	 * @param washingtonStateNdrFormTemplateDetails
	 * @return : StringBuffer
	 * Description : Method is used to get contents of Washington State NDR template.
	 */
	public StringBuffer getBufferForWashingtonStateNdr(WashingtonStateNdrFormTemplateDetails 
			washingtonStateNdrFormTemplateDetails){
		StringBuffer stringBuffer = new StringBuffer();
		stringBuffer.append(padSpaceTillMaxLength(32)+"National Driver Register File Check"+"\n");
		stringBuffer.append(padSpaceTillMaxLength(32)+"and Abstract of Driving Record Request"+"\n");
		stringBuffer.append(padSpaceTillMaxLength(32)+"for current or prospective employee");
		stringBuffer.append(padSpaceTillMaxLength(2)+leftHorizontalLine+"_____"+"\n");
		stringBuffer.append("Please Type or print plainly."+padSpaceTillMaxLength(40)+"|"+"For Validation Only"+padSpaceTillMaxLength(24)+"|");
		stringBuffer.append("\n");
		stringBuffer.append("Inquiries that cannot be read cannot be processed."+padSpaceTillMaxLength(19)+"|"+padSpaceTillMaxLength(43)+"|"+"\n");
		stringBuffer.append(padSpaceTillMaxLength(69)+"|"+padSpaceTillMaxLength(43)+"|"+"\n");
		stringBuffer.append(padSpaceTillMaxLength(69)+"|"+leftHorizontalLine+"_____"+"|"+"\n");
		stringBuffer.append(padSpaceTillMaxLength(70)+"106-060-421-0005");
		stringBuffer.append("\n");
		stringBuffer.append(padSpaceTillMaxLength(64)+"_"+padSpaceTillMaxLength(16)+"_"+padSpaceTillMaxLength(13)+"_");
		stringBuffer.append("\n");
		stringBuffer.append(" Current or Prospective Employer to receive search results");
		stringBuffer.append(padSpaceTillMaxLength(5));
		stringBuffer.append(checkBoxMarker+"Driver Employer"+checkBoxMarker+"Railroad Co."+checkBoxMarker+"Air Carrier");
		stringBuffer.append("\n");
		stringBuffer.append(padSpaceTillMaxLength(1/2)+horizontalLinePlain);
		stringBuffer.append("\n");
		stringBuffer.append("|"+"Employee or agency name"+padSpaceTillMaxLength(90)+"|");
		stringBuffer.append("\n");
		stringBuffer.append("|"+"Union Pacific Railroad"+padSpaceTillMaxLength(91)+"|");	
		stringBuffer.append("\n");
		stringBuffer.append(horizontalLine);
		stringBuffer.append("\n");
		stringBuffer.append("|"+"To the specific attention of"+padSpaceTillMaxLength(42)+"|"+"(Area code)Business telephone number"+padSpaceTillMaxLength(5)+"|");
		stringBuffer.append("\n");
		stringBuffer.append("|"+"Licensing Department"+padSpaceTillMaxLength(50)+"|"+"(402)544-0419 "+padSpaceTillMaxLength(27)+"|");
		stringBuffer.append("\n");
		stringBuffer.append(horizontalLineWithMultipleBorder4);
		stringBuffer.append("\n");
		stringBuffer.append("|"+"Mailing address"+padSpaceTillMaxLength(98)+"|");
		stringBuffer.append("\n");
		stringBuffer.append("|"+"1400 Douglas Street, Mail Stop 1010"+padSpaceTillMaxLength(78)+"|");
		stringBuffer.append("\n");
		stringBuffer.append(horizontalLine);
		stringBuffer.append("\n");
		stringBuffer.append("|"+"City "+padSpaceTillMaxLength(42)+"|"+"State"+padSpaceTillMaxLength(16)+"|"+"ZIP code"+padSpaceTillMaxLength(33)+"|");
		stringBuffer.append("\n");
		stringBuffer.append("|"+"Omaha"+padSpaceTillMaxLength(42)+"|"+"NE"+padSpaceTillMaxLength(19)+"|"+"68179-1010"+padSpaceTillMaxLength(31)+"|");
		stringBuffer.append("\n");
		stringBuffer.append(horizontalLineWithMultipleBorder3);
		stringBuffer.append("\n");
		stringBuffer.append(" "+"Driver Information");
		stringBuffer.append("\n");
		stringBuffer.append(padSpaceTillMaxLength(1/2)+horizontalLinePlain);
		stringBuffer.append("\n");
		stringBuffer.append("|"+"Driver full legal name (First, Middle and Last)"+padSpaceTillMaxLength(66)+"|");
		stringBuffer.append("\n");
		stringBuffer.append("|"+padSpaceTillMaxLengthForDynamicFields(washingtonStateNdrFormTemplateDetails.getDriverEmployeeName(), 113)+"|");
		stringBuffer.append("\n");
		stringBuffer.append(horizontalLine);
		stringBuffer.append("\n");
		stringBuffer.append("|"+"Other names used (Maiden, Prior Name, Nickname, Professional Name, Other)"+padSpaceTillMaxLength(40)+"|");
		stringBuffer.append("\n");
		stringBuffer.append("|"+padSpaceTillMaxLength(113)+"|");
		stringBuffer.append("\n");
		stringBuffer.append(horizontalLine);
		stringBuffer.append("\n");
		stringBuffer.append("|"+"Residance address"+padSpaceTillMaxLength(53)+"|"+"(Area code)Home telephone--Optional"+padSpaceTillMaxLength(6)+"|");
		stringBuffer.append("\n");
		stringBuffer.append("|"+padSpaceTillMaxLengthForDynamicFields(washingtonStateNdrFormTemplateDetails.getResidanceAddress(), 70)+"|"+padSpaceTillMaxLength(41)+"|");
		stringBuffer.append("\n");
		stringBuffer.append(horizontalLineWithMultipleBorder4);
		stringBuffer.append("\n");
		stringBuffer.append("|"+"City"+padSpaceTillMaxLength(37)+"|"+"State"+padSpaceTillMaxLength(10)+"|"+"ZIP code"+padSpaceTillMaxLength(2)+"|"+"(Area code)Home telephone--Optional"+padSpaceTillMaxLength(6)+"|");
		stringBuffer.append("\n");
		stringBuffer.append("|"+padSpaceTillMaxLengthForDynamicFields(washingtonStateNdrFormTemplateDetails.getCity(), 41)+"|"+padSpaceTillMaxLengthForDynamicFields(washingtonStateNdrFormTemplateDetails.getState(), 15)+"|"+padSpaceTillMaxLengthForDynamicFields(washingtonStateNdrFormTemplateDetails.getZipCode(),10)+"|"+padSpaceTillMaxLength(41)+"|");
		stringBuffer.append("\n");
		stringBuffer.append(horizontalLineWithMultipleBorder5);
		stringBuffer.append("\n");
		stringBuffer.append("|"+"Driver license number"+padSpaceTillMaxLength(17)+"|"+"Issuing state"+padSpaceTillMaxLength(10)+"|"+"Social Security number"+padSpaceTillMaxLength(26)+"|");
		stringBuffer.append("\n");
		stringBuffer.append("|"+padSpaceTillMaxLength(38)+"|"+padSpaceTillMaxLength(23)+"|"+padSpaceTillMaxLength(48)+"|"+"\n");
		stringBuffer.append("|"+leftHorizontalLine+"|"+centerHorizontalLine+"|"+padSpaceTillMaxLength(48)+"|");
		stringBuffer.append("\n");
		stringBuffer.append("|"+"Birth date"+padSpaceTillMaxLength(4)+"|"+"Sex"+padSpaceTillMaxLength(4)+"|"+"Eye color"+padSpaceTillMaxLength(4)+"|"+"Height "+padSpaceTillMaxLength(4)+"|"+"Weight "+padSpaceTillMaxLength(3)+"|");
		stringBuffer.append("For commercial drivers-Mandatory for identifica- "+"|");
		stringBuffer.append("\n");
		stringBuffer.append("|"+"(Month, Day,"+padSpaceTillMaxLength(2)+"|"+padSpaceTillMaxLength(7)+"|");
		stringBuffer.append(padSpaceTillMaxLength(13)+"|"+padSpaceTillMaxLength(11)+"|"+padSpaceTillMaxLength(10)+"|");
		stringBuffer.append("tion purposes per 49 CFR 383,153,RCW 46.25.070."+"  |");
		stringBuffer.append("\n");
		stringBuffer.append("|"+"Year)"+padSpaceTillMaxLength(9)+"|"+padSpaceTillMaxLength(7)+"|");
		stringBuffer.append(padSpaceTillMaxLength(13)+"|"+padSpaceTillMaxLength(11)+"|"+padSpaceTillMaxLength(10)+"|");
		stringBuffer.append("For non-commercial drivers-Requested for identi-"+" |");
		stringBuffer.append("\n");
		stringBuffer.append("|"+padSpaceTillMaxLengthForDynamicFields(washingtonStateNdrFormTemplateDetails.getDateOfBirth(), 14)+"|"+padSpaceTillMaxLength(7)+"|");
		stringBuffer.append(padSpaceTillMaxLength(13)+"|"+padSpaceTillMaxLength(11)+"|"+padSpaceTillMaxLength(10)+"|");
		stringBuffer.append("-fication purposes only.Entering SSN is voluntry."+"|");
		stringBuffer.append("\n");
		stringBuffer.append("|"+padSpaceTillMaxLength(14)+"|"+padSpaceTillMaxLength(7)+"|"+padSpaceTillMaxLength(13)+"|"+padSpaceTillMaxLength(11)+"|"+padSpaceTillMaxLength(10)+"|"+"WAC 308-104-014."+padSpaceTillMaxLength(32)+"|");
		stringBuffer.append("\n");
		stringBuffer.append(horizontalLineWithMultipleBorder2);
		stringBuffer.append("\n");
		stringBuffer.append("|"+"Employee Understanding: I understand that this report will result in printed reports whichwill be sent only to the"+"|");
		stringBuffer.append("\n");
		stringBuffer.append("|"+"employer or regulatory agency listed above on this form. The National Driver Register(NDR) report will indicate "+"  |");
		stringBuffer.append("\n");
		stringBuffer.append("|"+"either that (1) the NDR does not contain a record mathing my identification or (2) the NDR has a probable identi-"+" |");
		stringBuffer.append("\n");
		stringBuffer.append("|"+"fication match from one or more states listed on the report. A copy of my Washington driving record will also be "+" |");
		stringBuffer.append("\n");
		stringBuffer.append("|"+"sent to the employer or agency. If there are probable NDR matches from states other than Washington, it is the   "+" |");
		stringBuffer.append("\n");
		stringBuffer.append("|"+"responsibility of the employer to obtain records from those states. Under the privacy act, I have the right to  "+"  |");
		stringBuffer.append("\n");
		stringBuffer.append("|"+"request record(s) pertaining to me from the NDR. I also understand that if convictions, suspensions or revocations"+"|");
		stringBuffer.append("\n");
		stringBuffer.append("|"+"are found which I have not disclosed in applications or interviews, I might not be hired or could lose my job and "+"|");
		stringBuffer.append("\n");
		stringBuffer.append("|"+"Washington state may take action against my license. I hereby authorize the results of a one-time NDR search and a"+"|");
		stringBuffer.append("\n");
		stringBuffer.append("|"+"copy of my Washington driving record e sent to the employer or agency named on this form."+padSpaceTillMaxLength(24)+"|");
		stringBuffer.append("\n");
		stringBuffer.append(horizontalLine);
		stringBuffer.append("\n");
		stringBuffer.append("|"+"Driver's signature (Please read page 2 before signing)"+padSpaceTillMaxLength(25)+"|"+"Date"+padSpaceTillMaxLength(28)+"|");
		stringBuffer.append("\n");
		stringBuffer.append("|"+padSpaceTillMaxLength(79)+"|"+padSpaceTillMaxLength(32)+"|"+"\n");//yet to write the code...
		stringBuffer.append(horizontalLineWithMultipleBorder1);
		stringBuffer.append("\n");
		stringBuffer.append(" Notarization");
		stringBuffer.append("\n");
		stringBuffer.append(padSpaceTillMaxLength(1/2)+horizontalLinePlain+"\n");
		stringBuffer.append("|"+padSpaceTillMaxLength(60)+"State of Washington"+padSpaceTillMaxLength(33)+"|");
		stringBuffer.append("\n");
		stringBuffer.append("|"+padSpaceTillMaxLength(60)+"County of"+leftHorizontalLine+"_____|");
		stringBuffer.append("\n");
		stringBuffer.append("|"+"Signed or attested before me on"+"______________________________"+"by"+leftHorizontalLine+"____________"+"|"+"\n");
		stringBuffer.append("|"+padSpaceTillMaxLength(60)+leftHorizontalLine+"______________|"+"\n");
		stringBuffer.append("|"+padSpaceTillMaxLength(14)+"(Seal or stamp)"+padSpaceTillMaxLength(30)+leftHorizontalLine+"______________|"+"\n");
		stringBuffer.append("|"+padSpaceTillMaxLength(60)+"My appointment expires"+"_______________________________|"+"\n");
		stringBuffer.append(horizontalLine+"\n");
		stringBuffer.append(" OFFICIAL USE ONLY");
		stringBuffer.append("\n"+padSpaceTillMaxLength(1/2)+horizontalLinePlain+"\n");
		stringBuffer.append("|"+"Date received"+padSpaceTillMaxLength(6)+"|"+"Date sent"+padSpaceTillMaxLength(8)+"|"+"Type of identification"+padSpaceTillMaxLength(51)+"|");
		stringBuffer.append("\n|"+horizontalLine1+"|\n");
		stringBuffer.append("|"+padSpaceTillMaxLength(19)+"|"+padSpaceTillMaxLength(17)+"| "+"_"+padSpaceTillMaxLength(27)+"_"+padSpaceTillMaxLength(22)+"_"+padSpaceTillMaxLength(18)+"|");
		stringBuffer.append("\n");
		stringBuffer.append("|"+padSpaceTillMaxLength(19)+"|"+padSpaceTillMaxLength(17)+"|"+checkBoxMarker+"Valid photo driver license");
		stringBuffer.append(checkBoxMarker+"State issued photo ID"+checkBoxMarker+"Birth Certificate |");
		stringBuffer.append("\n");
		stringBuffer.append("|"+padSpaceTillMaxLength(19)+"|"+padSpaceTillMaxLength(17)+"| "+"_"+padSpaceTillMaxLength(15)+"_"+padSpaceTillMaxLength(18)+"_"+padSpaceTillMaxLength(26)+"_"+padSpaceTillMaxLength(5)+" |");
		stringBuffer.append("\n");
		stringBuffer.append("|"+padSpaceTillMaxLength(19)+"|"+padSpaceTillMaxLength(17)+"|"+checkBoxMarker+"Valid Passport"+checkBoxMarker+"Valid Military ID"+checkBoxMarker+"Military discharge papers");
		stringBuffer.append(checkBoxMarker+"Other"+" |");
		stringBuffer.append("\n|"+horizontalLine1+"|\n");
		stringBuffer.append("|"+"Print name of employee verifying applicant  "+"|");
		stringBuffer.append("Signature of employee verifying applicant   "+"|"+"Date  "+padSpaceTillMaxLength(17)+"|"+"\n");
		stringBuffer.append("|"+"identification"+padSpaceTillMaxLength(29)+"|"+"identification"+padSpaceTillMaxLength(29)+"|"+padSpaceTillMaxLength(23)+"|"+"\n");
		stringBuffer.append("|"+padSpaceTillMaxLength(43)+"|"+padSpaceTillMaxLength(43)+"| ");
		stringBuffer.append(padSpaceTillMaxLength(22)+"|");
		stringBuffer.append("\n|"+horizontalLine2+"|\n\n");
//		stringBuffer.append(printNDRDetails());

		return stringBuffer;
	}

	/**
	 * Classname / Method Name : LataTemplateForWashingtonStateNDR/padSpaceTillMaxLength()
	 * @param maxLength
	 * @return : String
	 * Description : Method is used to add spaces in Washington State NDR template
	 */
	private String padSpaceTillMaxLength(int maxLength){
		StringBuffer sb = new StringBuffer();
		for(int i=0;i<=maxLength;i++){
			sb.append(" ");
		}
		return sb.toString();
	}

	/**
	 * Classname / Method Name : LataTemplateForWashingtonStateNDR/padSpaceTillMaxLengthForDynamicFields()
	 * @param str
	 * @param maxLength
	 * @return : String
	 * Description : Method is used to adjust proper spaces for dynamic fields for Washington State 
	 * NDR template.
	 */
	private String padSpaceTillMaxLengthForDynamicFields(String str, int maxLength){
		StringBuffer sb = new StringBuffer(str);
		for(int i=str.length();i<=maxLength;i++){
			sb.append(" ");
		}
		return sb.toString();
	}

	/**
	 * Classname / Method Name : LataTemplateForWashingtonStateNDR/printNDRDetails()
	 * @return : String
	 * Description : Method is used to get NDR details for Washington State NDR template.
	 */
	/*private String printNDRDetails(){
		StringBuffer sb = new StringBuffer();
		sb.append(padSpaceTillMaxLength(31)+"Requests for National Driver Register (NDR) Record Checks");
		sb.append("\n\n");
		sb.append("How to Request an NDR Record Check"+"\n");
		sb.append("This form may be completed by the current or prospective employer or employee. The driver must authorize the request"+"\n");
		sb.append("by their signature (or their mark as witnessed) and have it notarized.");
		sb.append("\n\n");
		sb.append("What NDR Records Contain"+"\n");
		sb.append("NDR results for employers will contain only the identification of the state(s) which have reported information on the "+"\n");
		sb.append("driver to the NDR and only information reported withing the past three years from the date of inquiry. Driver control "+"\n");
		sb.append("actions initiated prior to that time, even if still in effect, will not be included."+"\n");
		sb.append("A copy of the Washington driving record will also be sent to the employer or agency. If there are probable NDR "+"\n");
		sb.append("matches from states other than Washington, it is the responsibility of the employer to obtain the records from "+"\n");
		sb.append("those states.The name and address of the driver licensing official will be provided for each state listed.");
		sb.append("\n\n");
		sb.append("Authorization to Railroad Companies"+"\n");
		sb.append("The employee/prospective employee grants authorization as follows: "+"\"The U.S. Department of Transportation, Federal"+"\n");
		sb.append("Railroad Administration, in accordance with 49 CFR, Part 240.111, requires that i hereby request and auhtorize the "+"\n");
		sb.append("National Highway Traffic Safety Administration(NHTSA) to perform an NDR check of my driving record for a 36 month  "+"\n");
		sb.append("period prior to the date of this request including license withdrawal actions open at the time of file check. I "+"\n");
		sb.append("hereby authorize the NDR to furnish the copy of the results of this NDR check directly to the railroad company "+"\n");
		sb.append("identified on this enquiry form."+"/"+"\n\n");
		sb.append("Authorization to Air Carriers"+"\n");
		sb.append("The employee/prospective employee grants authorization as follows: "+"\"In accordance with Section 502 of Pilot Records"+"\n");
		sb.append("Improvement Act of 1996,Public Law 104-264, I hereby request and authorize the National Highway Traffic Safety "+"\n");
		sb.append("Administration (NHTSA) to perform an NDR check of my driving record for a five-year period prior to the date "+"\n");
		sb.append("of this request, including license withdrawal actions open at the time of the file check. I hereby authorize "+"\n");
		sb.append("the NDR to furnish a copy of the results of this NDR check directly to the air carrier identified on this inquiry form.");
		return sb.toString();
	}*/

	public static void main(String[] args) {
		LataTemplateForWashingtonStateNDR lataTemplateForDriving = 
			new LataTemplateForWashingtonStateNDR();
	}

	private static WashingtonStateNdrFormTemplateDetails getTemplate(){

		WashingtonStateNdrFormTemplateDetails washingtonStateNdrFormTemplateDetails = 
			new WashingtonStateNdrFormTemplateDetails();
		washingtonStateNdrFormTemplateDetails.setDriverEmployeeName("sreekar reddy vanguru");
		washingtonStateNdrFormTemplateDetails.setDriverEmployeeName("ABCDEFGHIJKLWXYZ,ABCDEFGHIJKLMNOPQRSTUVWXYZ ABCDEFGHIJKLMNOPQRSTUVWXYZ ABCDEFGHIJKLMNOPQRSTUVWXYZ ABCDEGHIJKLMNOPQ");
		washingtonStateNdrFormTemplateDetails.setCity("Hyderabad");
		washingtonStateNdrFormTemplateDetails.setResidanceAddress("ABCDEFGHIJKLWXYZ ABCDEssddFGHIJKLWXYZ ABCDEFGHIJKLWXYZ ABCDEFGHIJKLWXYZ");
		washingtonStateNdrFormTemplateDetails.setState("Secunderabaad");
		washingtonStateNdrFormTemplateDetails.setDateOfBirth("10/26/1985");
		washingtonStateNdrFormTemplateDetails.setZipCode("400000115");
		return washingtonStateNdrFormTemplateDetails;
	}
}
