/**
 * Classname    : LataTemplateForMedical
 * Description  : Class is used as a Lata template for Medical Form (LHI Instruction Set).
 * author   	: Satyam Computer Services Ltd.
 * Date of creation : Jun 15, 2009
 *
 * Change History
 * ------------------------------------------------------------  
 *   Date  Changed By    Description
 * ------------------------------------------------------------  
 *
 *
 * ------------------------------------------------------------  
 *
 * Copyright notice : "Copyright � UPRR 2008"
 */
package templates;

import com.uprr.app.eqm.components.common.logger.EqmsLogger;

public class LataTemplateForMedical {
	
	EqmsLogger m_logger = EqmsLogger.getLoggerInstance(this.getClass());
	
	private final String firstMarker = padSpaceTillMaxLength(3);
	private final String secondMarker = padSpaceTillMaxLength(13);
	private final String thirdMarker = padSpaceTillMaxLength(42);
	private final String fourthMarker = padSpaceTillMaxLength(28);
	private final String endMarker = padSpaceTillMaxLength(107);	
	
	private final String horizontalLine = " ____________________________________________________________________________________________________________";
	private final String horizontalLineWithEndBorders = "|____________________________________________________________________________________________________________|";
	private final String horizontalLine5="__";
	private final String horizontalLine6="|__|";
	private final String pdfTitle="UNION PACIFIC RAILROAD";
	private final String medicalTitle="MEDICAL ASSESSMENT INSTRUCTIONS";
	private final String tableRightBorder = padSpaceTillMaxLength(31)+"|";
	private final String tableRightBorder1 = padSpaceTillMaxLength(37);
	private final String rout="Route Code:";
	private final String assign="Assessment Type: Periodic";
	private final String section1="This document is designed to provide you the necessary steps to complete your Medical Assessment for Union";
	private final String section2="Pacific Railroad.Failure to complete the following steps immediately may delay your work time and";
	private final String section3="payroll (if applicable).";
	private final String section4="1. You must contact LHI immediately at 1-866-873-9261 to schedule your Medical Assessment.";
	private final String section5="Please call the LHI Scheduling Center during normal business hours (Monday-Friday 7am-10pm &";
	private final String section6="Saturday 7am-3pm CST).";
	private final String section7="2. Please keep this sheet in front of you when you call to schedule your appointment.";
	private final String section8="3. Take this instruction sheet with you to your appointment. LHI will send your exam forms to the";
	private final String section9="assigned clinic prior to your arrival. If the clinic does not have paperwork when you arrive, please";
	private final String section10="call 1-866-873-9261 to have it faxed to the clinic immediately.";
	private final String section11="4. Medical Clearance to Work - LHI is responsible and accountable to Union Pacific Railroad to";
	private final String section12="issue a medical clearance to work based on the results of your Medical Assessment Testing. It is";
	private final String section13="vitally important, that you cooperate fully in the Medical Assessment process.";
	private final String section14="NOTE:LHI will review the results of your Medical Assessment. Based on this review, FURTHER";
	private final String section15="medical documentation and/or evaluation may be required; your timely response to any further requests";
	private final String section16="for information is greatly appreciated and will help insure a more timely review.";
	private final String section17="LHI can NOT give you information on the clearance status of your exam. Once the final status of your";
	private final String section18="Medical Assessment is determined by LHI, it will immediately be reported to Union Pacific Railroad Health";
	private final String section19="Services Department.";
	private final String section20="Questions about your Medical Assessment please contact LHI at 1-866-873-9261.";
//	private final String section21=padSpaceTillMaxLength(2)+"LHI";
	private final String section22="LOGISTICS  HEALTH";
	private final String section23="INCORPORATED";
	private final String section21=padSpaceTillMaxLength(2)+"LHI"+"  "+section22+"  "+section23;
	
	/**
	 * Classname / Method Name : LataTemplateForMedical/getBufferForLataPrintForMedical()
	 * @return : StringBuffer
	 * Description : Method is used to get contents of the Medical template.
	 */
	public StringBuffer getBufferForLataPrintForMedical(){
		StringBuffer stringBuffer=new StringBuffer();
		stringBuffer.append(firstMarker+horizontalLine);
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+"|"+fourthMarker+secondMarker+padSpaceTillMaxLength(64)+"|");
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+"|"+fourthMarker+firstMarker+section21+padSpaceTillMaxLength(35)+"|");
//		stringBuffer.append(firstMarker+"|"+fourthMarker+secondMarker+padSpaceTillMaxLength(64)+"|");
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+horizontalLineWithEndBorders);
		stringBuffer.append("\n");
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+horizontalLine);
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+"|"+fourthMarker+secondMarker+pdfTitle+thirdMarker+"|");
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+"|"+fourthMarker+firstMarker+"     "+medicalTitle+padSpaceTillMaxLength(38)+"|");
		stringBuffer.append("\n"+firstMarker+"|"+tableRightBorder1+horizontalLine5+padSpaceTillMaxLength(8)+horizontalLine5+padSpaceTillMaxLength(8)+horizontalLine5+padSpaceTillMaxLength(45)+"|");
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+"|"+fourthMarker+firstMarker+"  "+"( "+horizontalLine6+" LEQ"+" / "+horizontalLine6+" RCO"+" / "+horizontalLine6+" SLE"+" /"+" )"+padSpaceTillMaxLength(36)+"|");
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+"|"+rout+padSpaceTillMaxLength(64)+tableRightBorder);
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+"|"+assign+padSpaceTillMaxLength(50)+tableRightBorder);
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+"|"+section1+padSpaceTillMaxLength(1)+"|");
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+"|"+section2+padSpaceTillMaxLength(10)+"|");		
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+"|"+section3+padSpaceTillMaxLength(51)+tableRightBorder);
		stringBuffer.append("\n"+firstMarker+"|"+endMarker+"|");
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+"|"+firstMarker+section4+secondMarker+"|");
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+"|"+firstMarker+"   "+section5+firstMarker+padSpaceTillMaxLength(4)+"|");
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+"|"+firstMarker+"   "+section6+tableRightBorder1+fourthMarker+padSpaceTillMaxLength(11)+"|");
		stringBuffer.append("\n"+firstMarker+"|"+endMarker+"|");
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+"|"+firstMarker+section7+secondMarker+firstMarker+padSpaceTillMaxLength(1/2)+"|");
		stringBuffer.append("\n"+firstMarker+"|"+endMarker+"|");
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+"|"+firstMarker+section8+firstMarker+padSpaceTillMaxLength(2)+"|");
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+"|"+firstMarker+"   "+section9+padSpaceTillMaxLength(1/2)+"|");
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+"|"+firstMarker+"   "+section10+fourthMarker+firstMarker+firstMarker+padSpaceTillMaxLength(1/2)+"|");
		stringBuffer.append("\n"+firstMarker+"|"+endMarker+"|");
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+"|"+firstMarker+section11+firstMarker+firstMarker+padSpaceTillMaxLength(1)+"|");
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+"|"+firstMarker+"   "+section12+firstMarker+padSpaceTillMaxLength(1/2)+"|");
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+"|"+firstMarker+"   "+section13+secondMarker+firstMarker+firstMarker+padSpaceTillMaxLength(1/2)+"|");
		stringBuffer.append("\n"+firstMarker+"|"+endMarker+"|");
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+"|"+section14+secondMarker+firstMarker+"|");		
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+"|"+section15+firstMarker+padSpaceTillMaxLength(2)+"|");
		stringBuffer.append("\n");		
		stringBuffer.append(firstMarker+"|"+section16+secondMarker+firstMarker+firstMarker+padSpaceTillMaxLength(4)+"|");
		stringBuffer.append("\n"+firstMarker+"|"+endMarker+"|");
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+"|"+section17+firstMarker+padSpaceTillMaxLength(3)+"|");
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+"|"+section18+padSpaceTillMaxLength(2)+"|");
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+"|"+section19+tableRightBorder1+secondMarker+firstMarker+tableRightBorder);
		stringBuffer.append("\n"+firstMarker+"|"+endMarker+"|");
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+"|"+section20+fourthMarker+padSpaceTillMaxLength(1)+"|");
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+horizontalLineWithEndBorders);
		
		return stringBuffer;
	}
	
	/**
	 * Classname / Method Name : LataTemplateForMedical/padSpaceTillMaxLength()
	 * @param maxLength
	 * @return : String
	 * Description : Method is used to add spaces wherever necessary.
	 */
	private String padSpaceTillMaxLength(int maxLength)	{
		StringBuffer sb = new StringBuffer();
		for(int i=0;i<=maxLength;i++){
			sb.append(" ");
		}
		return sb.toString();
	}


	public static void main(String[] args) {
		LataTemplateForMedical lataTemplateForMedical =	new LataTemplateForMedical();
	}

}
