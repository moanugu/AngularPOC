/**
 * Class Name	: LataTemplateForMVRReleaseInsForm
 * Description	: Class is used to get Template for MVR Release Instruction  Form 
 * Author		: Techmahindra Ltd.
 * Created On	: Oct 18, 2016
 *
 * Change History
 * ------------------------------------------------------------  
 * Date			Changed By		Description
 * ------------------------------------------------------------  
 *
 *
 * ------------------------------------------------------------  
 *
 * Copyright notice : "Copyright � UPRR 2016"
 */
package templates;

import com.uprr.app.eqm.components.common.logger.EqmsLogger;

public class LataTemplateForMVRReleaseInsForm {
  EqmsLogger m_logger = EqmsLogger.getLoggerInstance(this.getClass());

  /**
   * Method is used to get contents of MVR Release Instruction Form template
   * 
   * @return StringBuffer
   * @author xsat872
   * @since Oct 18, 2016.
   **/
  public StringBuffer getBufferForLataPrintForMVRRelInsForm() {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer
        .append(padSpaceTillMaxLength(20) + "UNION PACIFIC RAILROAD COMPANY" + padSpaceTillMaxLength(20) + "\n");
    stringBuffer.append("\n\n");
    stringBuffer.append("An active employee whose license expires within 150 days or is selected");
    stringBuffer.append("\n");
    stringBuffer.append("for the FIT program should log into the MyUP Portal to complete their");
    stringBuffer.append("\n");
    stringBuffer.append("MVR Release electronically. If the link described below is not present");
    stringBuffer.append("\n");
    stringBuffer.append("the form can be accessed from a company computer by entering go/MVR");
    stringBuffer.append("\n");
    stringBuffer.append("into the address bar.");
    stringBuffer.append("\n\n");
    stringBuffer.append(padSpaceTillMaxLength(4) + "1. Log into your My UP Portal");
    stringBuffer.append("\n");
    stringBuffer.append(padSpaceTillMaxLength(4) + "2. Ensure you are on the TEY Home tab");
    stringBuffer.append("\n");
    stringBuffer.append(padSpaceTillMaxLength(4) + "3. The MVR Release is located in the");
    stringBuffer.append("\n");
    stringBuffer.append(padSpaceTillMaxLength(7) + "Certification section (see below).  Click on the �Update� link");
    stringBuffer.append("\n");
    stringBuffer.append(padSpaceTillMaxLength(7) + "to complete your MVR electronically.Paper forms are no longer");
    stringBuffer.append("\n");
    stringBuffer.append(padSpaceTillMaxLength(7) + "used for this process.");
    stringBuffer.append("\n");
    stringBuffer.append(padSpaceTillMaxLength(4) + "4. WA State Drivers will be automatically");
    stringBuffer.append("\n");
    stringBuffer
        .append(padSpaceTillMaxLength(7) + "redirected to the WA State form after filling out the MVR Release form.");
    stringBuffer.append("\n\n");
    stringBuffer
        .append(padSpaceTillMaxLength(7) + "If your certification has expired, you are still able to complete your");
    stringBuffer.append("\n");
    stringBuffer.append(padSpaceTillMaxLength(7) + "MVR Release electronically.");
    return stringBuffer;
  }

  /**
   * Description : Method is used to add spaces in the template.
   *
   * @param maxLength
   * @return String
   * @author xsat872
   * @since Oct 18, 2016
   */
  private String padSpaceTillMaxLength(int maxLength) {
    StringBuffer sb = new StringBuffer();
    for (int i = 0; i <= maxLength; i++) {
      sb.append(" ");
    }
    return sb.toString();
  }
}