/**
 * Classname    : LataTemplateForCoverLetterOfPrintDocs
 * Description  : Class is used as a Lata Template for Cover Letter Of Print Docs (Employee Letter)
 * author   	: Satyam Computer Services Ltd.
 * Date of creation : Jun 15, 2009
 *
 * Change History
 * ------------------------------------------------------------  
 *   Date  Changed By    Description
 * ------------------------------------------------------------  
 *
 *
 * ------------------------------------------------------------  
 *
 * Copyright notice : "Copyright � UPRR 2008"
 */
package templates;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.uprr.app.eqm.components.common.logger.EqmsLogger;
import com.uprr.app.eqm.components.licensing.delegate.LicensingDelegate;
import com.uprr.app.eqm.components.licensing.model.CoverLetterForPrintDocsTemplate;
import com.uprr.app.eqm.components.licensing.util.LicensingConstant;

public class LataTemplateForCoverLetterOfPrintDocs {
	
	private final Logger m_logger = LoggerFactory.getLogger(this.getClass());

	private final String firstMarker = padSpaceTillMaxLength(63);
	private final String secondMarker = padSpaceTillMaxLength(38);
	private final String thirdMarker = padSpaceTillMaxLength(10);
	private final String fourthMarker = padSpaceTillMaxLength(7);
	private final String centerAlign = secondMarker+padSpaceTillMaxLength(9);
	
	
	LicensingDelegate licensingDelegate;
	


	/**
	 * Classname / Method Name : LataTemplateForCoverLetterOfPrintDocs/getBufferForLataPrintForCoverLetterOfPrintDocs()
	 * @param coverLetterForPrintDocsTemplate
	 * @return
	 * Description : Method is used to get contents of Employee Letter (Cover Letter used in recertification)
	 * template.
	 */
	public StringBuffer getBufferForLataPrintForCoverLetterOfPrintDocs(CoverLetterForPrintDocsTemplate coverLetterForPrintDocsTemplate){
		StringBuffer stringBuffer = new StringBuffer();
		stringBuffer.append(centerAlign+"UNION PACIFIC RAILROAD COMPANY"+"\n");
		stringBuffer.append(padSpaceTillMaxLengthForDynamicFields(coverLetterForPrintDocsTemplate.getEmployeeName(), 100)+"\n");
		String manager="";
		initDelegate(licensingDelegate);
		if (licensingDelegate != null) {
      manager = licensingDelegate.getSysParmValue(LicensingConstant.LICENSING_DEPT_MANAGER_NAME).getParmValu();}
//		stringBuffer.append(padSpaceTillMaxLengthForDynamicFields(coverLetterForPrintDocsTemplate.getAddress1(), 100)+"\n");
//		stringBuffer.append(padSpaceTillMaxLengthForDynamicFields(coverLetterForPrintDocsTemplate.getAddress2(), 100)+"\n");
		//-- Making Address Adjustment
		stringBuffer.append(getAddressAdjustmentForEmployee(coverLetterForPrintDocsTemplate.getAddress1(), coverLetterForPrintDocsTemplate.getAddress2()));
		
		//-- Making adjustment for City, State, Country, Zipcode
//		stringBuffer.append(coverLetterForPrintDocsTemplate.getCity()+","+coverLetterForPrintDocsTemplate.getState()+",");
//		stringBuffer.append(coverLetterForPrintDocsTemplate.getCountry()+"-"+coverLetterForPrintDocsTemplate.getZip()+".");
		stringBuffer.append(getCityStateCountryZipAdjustmentForEmployee(coverLetterForPrintDocsTemplate.getCity(), coverLetterForPrintDocsTemplate.getState(), coverLetterForPrintDocsTemplate.getCountry(), coverLetterForPrintDocsTemplate.getZip()));
		
		//-- remaining template
		stringBuffer.append("\n\n");
		stringBuffer.append(centerAlign+"THIS IS YOUR ONLY NOTICE ");
		stringBuffer.append("\n\n");
		stringBuffer.append("Dear Engineer, RCL Operator or Hostler:");
		stringBuffer.append("\n\n");
		stringBuffer.append("You are a Federally Licensed Operator. Your License expires on your upcoming birthday. Federal law mandates");
		stringBuffer.append("\n");
		stringBuffer.append("specific requirements are satisfied before your license can be renewed. Please be advised that due to processing ");
		stringBuffer.append("\n");
		stringBuffer.append("time, you have thirty (30) days to complete the certification requirements listed below. Failure to comply with ");
		stringBuffer.append("\n");
		stringBuffer.append("Union Pacific Railroad System Special Instructions, Item 7-B, and the instructions contained in this notice, may ");
		stringBuffer.append("\n");
		stringBuffer.append("subject you to discipline under Rule 1.13 of the General Code of Operating Rules.");
		stringBuffer.append("\n\n");
		stringBuffer.append(secondMarker+"WITHIN THE NEXT 30 DAYS YOU NEED TO COMPLETE:");
		stringBuffer.append("\n\n");
		stringBuffer.append("1. Vision and Hearing Acuity Examination:");
		stringBuffer.append("\n");
		stringBuffer.append("a. Note: Do not take the Medical Assessment without your mandatory undisturbed rest. Upon your arrival home from ");
	  stringBuffer.append("\n");
	  stringBuffer.append("the exam, contact CMS as you are required to take an additional 10 hours undisturbed rest.");
	  stringBuffer.append("\n");
    stringBuffer.append("from the exam, contact CMS as you are required to take an additional 10 hours undisturbed rest.");
    stringBuffer.append("\n");
    stringBuffer.append("from the exam, contact CMS as you are required to take an additional 10 hours undisturbed rest.");
    stringBuffer.append("\n");
    stringBuffer.append("from the exam, contact CMS as you are required to take an additional 10 hours undisturbed rest.");
		stringBuffer.append("\n");
		stringBuffer.append("Union Pacific will pay for the testing, but you are responsible for any lost wages, mileage, and/or lodging costs, ");
		stringBuffer.append("\n");
		stringBuffer.append("which may occur. If you have any questions pertaining to the medical examination process, please contact LHI at 1-866-");
		stringBuffer.append("\n");
		stringBuffer.append("873-9261. LHI call center is open Monday - Friday 7:00 a.m. to 10:00 p.m. and Saturday 7:00 a.m. to 3:00 p.m. CST.");
		stringBuffer.append("\n\n");
		stringBuffer.append("2. NDR Review Form 20119: Complete the National Driver Register (NDR) form and return to the Licensing office. Please");
		stringBuffer.append("\n");
		stringBuffer.append("   note your signature, as the requestor must be notarized. Be sure you fill out this form in its entirety before you	");
		stringBuffer.append("\n");
		stringBuffer.append("   have it notarized. Sign the form in the presence of the Notary. ATTENTION EMPLOYEES LICENSED IN THE");
		stringBuffer.append("\n");
		stringBuffer.append("   STATE OF WASHINGTON: Washington State law mandates that State Form DLE-520-316(R/8/07)W");
		stringBuffer.append("\n");
		stringBuffer.append("   (Union Pacific Form WA20001) is utilized for this purpose.");
		stringBuffer.append("\n\n");
		stringBuffer.append("3. State Driving Record Review Form 20999: Complete the State Motor Vehicle Search form and return to the Licensing");
		stringBuffer.append("\n");
		stringBuffer.append("   office. Union Pacific will conduct a search of your state motor vehicle driving record, currently at no cost to you.");
		stringBuffer.append("\n");
		stringBuffer.append("   Please provide your drivers license number(s) and the state(s) where you have obtained a driver's license");
		stringBuffer.append("\n");
		stringBuffer.append("   within the past five years. ATTENTION EMPLOYEES LICENSED IN THE STATE OF WASHINGTON:");
		stringBuffer.append("\n");
		stringBuffer.append("   Washington State law mandates that State Form DLE-520-316(R/8/07)W (Union Pacific Form WA20001) is");
		stringBuffer.append("\n");
		stringBuffer.append("   utilized for this purpose. If your packet does not contain this form immediately call the number(s) listed below.");
		stringBuffer.append("\n\n");
		stringBuffer.append("NOTE: Form(s) referred to in Items 2 and 3 (the NDR Request form and the State Motor Vehicle Search form,");
		stringBuffer.append("\n");
		stringBuffer.append("or for those licensed in Washington State Form DLE-520-316(R/8/07)W, a.k.a. Union Pacific Form WA20001),");
		stringBuffer.append("\n");
		stringBuffer.append("must be mailed to the Certification and Licensing office at 1400 Douglas St., Stop 1010 in Omaha, NE 68179-1010.");
		stringBuffer.append("\n");
		stringBuffer.append("The Licensing office will forward the NDR request form to Washington, D. C. or Washington State as appropriate for");
		stringBuffer.append("\n");
		stringBuffer.append("processing. Results of both record searches will be provided directly to Union Pacific Railroad.");
		stringBuffer.append("\n\n");
		stringBuffer.append("4. Operating Rules Examination: You must successfully pass the General Code of Operating Rules exam");
		stringBuffer.append("\n");
		stringBuffer.append("   within the 365 days preceding your birthday. Contact your manager to be scheduled into a rules class.");
		stringBuffer.append("\n\n");
		stringBuffer.append("5. Performance Skills Evaluation Ride: A designated Supervisor of Locomotive Engineers must accompany you on a");
		stringBuffer.append("\n");
		stringBuffer.append("   train ride and evaluate your performance. It is the responsibility of your Manager of to complete this");
		stringBuffer.append("\n");
		stringBuffer.append("   requirement and he/she will do so prior to the expiration of your current license.");
		stringBuffer.append("\n\n");
		stringBuffer.append("If you have questions other than the medical examination process, please contact Certification and Licensing at");
		stringBuffer.append("\n");
		stringBuffer.append("company lines 402-544-CERT (2378) or 8-544-CERT (2378)");
		stringBuffer.append("\n\n");
		stringBuffer.append("PLEASE NOTE: All certified employees must keep their certificate current in order to avoid a possible");
		stringBuffer.append("\n");
		stringBuffer.append("interruption in service eligibility. It is the individual employee's responsibility to ensure that certification is");
		stringBuffer.append("\n");
		stringBuffer.append("kept current.");
		stringBuffer.append("\n\n");
		stringBuffer.append("Once you have completed all the requirements for recertification, your new license will be mailed directly to your home");
		stringBuffer.append("\n");
		stringBuffer.append("approximately two weeks prior to expiration of your current license. If you have completed all requirements and you");
		stringBuffer.append("\n");
		stringBuffer.append("do not receive your new license prior to expiration, immediately notify the Licensing Department or your Manager.");
		stringBuffer.append("\n\n");
		stringBuffer.append(firstMarker);
		stringBuffer.append("Sincerely,");
		stringBuffer.append("\n\n");
		stringBuffer.append(firstMarker);
		stringBuffer.append(manager);
		stringBuffer.append("\n\n");
		stringBuffer.append(firstMarker);
		stringBuffer.append(manager+",Manager");
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker);
		stringBuffer.append("Certification and Licensing"+"\n\n");
		stringBuffer.append("YOUR PACKET SHOULD INCLUDE:"+"\n");
		stringBuffer.append(fourthMarker+"Instructions for Completing Medical Assessment Form"+"\n");
		stringBuffer.append(fourthMarker+"NDR Request Form 20119"+"\n");
		stringBuffer.append(fourthMarker+"State DMV Information Form 20999"+"\n");
		stringBuffer.append(fourthMarker+"Washington State Form DLE-520-316(R/8/07)W - UP Form WA20001 (if applicable)"+"\n");
		
		return stringBuffer;
	}

	/**
	 * Classname / Method Name : LataTemplateForCoverLetterOfPrintDocs/padSpaceTillMaxLengthForDynamicFields()
	 * @param str
	 * @param maxLength
	 * @return : String
	 * Description : Method is used to make proper space adjustment in template for dynamic data.
	 */
	private String padSpaceTillMaxLengthForDynamicFields(String str, int maxLength)	{
		StringBuffer sb = new StringBuffer(str);
		for(int i=str.length();i<=maxLength;i++){
			sb.append(" ");
		}
		return sb.toString();
	}

	/**
	 * Classname / Method Name : LataTemplateForCoverLetterOfPrintDocs/padSpaceTillMaxLength()
	 * @param maxLength
	 * @return : String
	 * Description : Method is used to add spaces in the template.
	 */
	private String padSpaceTillMaxLength(int maxLength)	{
		StringBuffer sb = new StringBuffer();
		for(int i=0;i<=maxLength;i++){
			sb.append(" ");
		}
		return sb.toString();
	}
	
	/**
	 * Classname / Method Name : LataTemplateForCoverLetterOfPrintDocs/getAddressAdjustmentForEmployee()
	 * @param addressLine1
	 * @param addressLine2
	 * @return : String
	 * Description : Method is used to make adjustment for Address
	 */
	private String getAddressAdjustmentForEmployee(String addressLine1, String addressLine2){
		StringBuffer sb = new StringBuffer();
		if(addressLine1 != null && !addressLine1.equals("") && !addressLine1.equals(" ")){
			sb.append(padSpaceTillMaxLengthForDynamicFields(addressLine1, 100));
			sb.append("\n");
		}
		if(addressLine2 != null && !addressLine2.equals("") && !addressLine2.equals(" ")){
			sb.append(padSpaceTillMaxLengthForDynamicFields(addressLine2, 100));
			sb.append("\n");
		}
		return sb.toString();
	}
	
	/**
	 * Classname / Method Name : LataTemplateForCoverLetterOfPrintDocs/getCityStateCountryZipAdjustmentForEmployee()
	 * @param city
	 * @param state
	 * @param country
	 * @param zipCode
	 * @return : String
	 * Description : Method is used to make adjustment for Coty, State, Country and Zipcode.
	 */
	private String getCityStateCountryZipAdjustmentForEmployee(String city, String state, String country, 
			String zipCode){
		StringBuffer sb = new StringBuffer();
		/*
		 * if city != null && any one of state, country, zipcode != null --> append ',' ahead of city
		 * else --> append only city
		 */
		if((city != null && !city.equals("") && !city.equals(" ")) 
				&& (
						(state != null && !state.equals("") && !state.equals(" "))
						 || (country != null && !country.equals("") && !country.equals(" "))
						 || (zipCode != null && !zipCode.equals("") && !zipCode.equals(" "))
					)){
			sb.append(city+",");
		} else if(city != null && !city.equals("") && !city.equals(" ")){
			sb.append(city);
		}
		
		/*
		 * if state != null && any one of country, zipcode != null --> append ',' ahead of state
		 * else --> append only state
		 */
		if((state != null && !state.equals("") && !state.equals(" "))
				&& (
						(country != null && !country.equals("") && !country.equals(" "))
						|| (zipCode != null && !zipCode.equals("") && !zipCode.equals(" "))
					)){
			sb.append(state+",");
		} else if(state != null && !state.equals("") && !state.equals(" ")){
			sb.append(state);
		}
		
		/*
		 * if country != null && azipcode != null --> append '-' ahead of country
		 * else --> append only country
		 */
		if((country != null && !country.equals("") && !country.equals(" ")) 
				&& (zipCode != null && !zipCode.equals("") && !zipCode.equals(" "))){
			sb.append(country+"-");
		} else if(country != null && !country.equals("") && !country.equals(" ")){
			sb.append(country);
		}
		
		/*
		 * appending zipcode
		 */
		if(zipCode != null && !zipCode.equals("") && !zipCode.equals(" ")){
			sb.append(zipCode);
		}
		
		if(!((city == null || city.equals("") || city.equals(" ")) 
				&& (state == null || state.equals("") || state.equals(" "))
				&& (country == null || country.equals("") || country.equals(" "))
				&& (zipCode == null || zipCode.equals("") || zipCode.equals(" ")))){
			sb.append(".");
		}
		
		return sb.toString();
	}

	public static void main(String[] args) {
		LataTemplateForCoverLetterOfPrintDocs lataTemplateForCoverLetter = 
			new LataTemplateForCoverLetterOfPrintDocs();
	}

	private static CoverLetterForPrintDocsTemplate getTemplate(){
		CoverLetterForPrintDocsTemplate coverLetterForPrintDocsTemplate = 
			new CoverLetterForPrintDocsTemplate();
		coverLetterForPrintDocsTemplate.setEmployeeName("Lenin, Mike R");
		coverLetterForPrintDocsTemplate.setAddress1("Satyam Computers");
		coverLetterForPrintDocsTemplate.setAddress2("Down Street,LA");
		coverLetterForPrintDocsTemplate.setCity("Ohama");
		coverLetterForPrintDocsTemplate.setState("NJ");
		coverLetterForPrintDocsTemplate.setCountry("USA");
		coverLetterForPrintDocsTemplate.setZip("0009123");
		return coverLetterForPrintDocsTemplate;
	}

	private void  initDelegate(LicensingDelegate licensingDelegate){
	  try{
	  ClassPathXmlApplicationContext classPathXmlAppContext = new ClassPathXmlApplicationContext(new String[] { 
	      "classpath:HibernateApplicationContext.xml",
	      "classpath:ConnectionPoolDataSource.xml", 
	      "classpath:ExternalJdbcTemplatesApplicationContext.xml",
	      "classpath:EqmTransactionApplicationContext.xml", 
	      "classpath:BaseRepositoryApplicationContext.xml",
	      "classpath:/junit/LicensingApplicationContextForJunit.xml"});
	  licensingDelegate=(LicensingDelegate) classPathXmlAppContext.getBean("licensingDelegate");
	  }catch(Exception e){
	    
	  }
	}
}
