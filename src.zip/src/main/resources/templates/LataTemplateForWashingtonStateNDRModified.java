package templates;

import com.uprr.app.eqm.components.common.logger.EqmsLogger;
import com.uprr.app.eqm.components.licensing.model.WashingtonStateNdrFormTemplateDetails;

public class LataTemplateForWashingtonStateNDRModified {

	
	EqmsLogger m_logger = EqmsLogger.getLoggerInstance(this.getClass());

	private final static String horizontalLinePlain = "______________________________________________________________________";
	private final String horizontalLine = "|______________________________________________________________________|"; 
	private final String horizontalLine1 = "__________|__________|________________________________________________";
	private final String horizontalLine2 = "________________________________|__________________________|__________";
	private final String horizontalLineWithMultipleBorder1 = "|_______________________________________________________|______________|";
	private final String horizontalLineWithMultipleBorder2 = "|____________|____|_____|_______|______|_______________________________|";
	private final String horizontalLineWithMultipleBorder3 = "|__________________________|__________________|________________________|";
	private final String horizontalLineWithMultipleBorder4 = "|________________________________|_____________________________________|";
	private final String horizontalLineWithMultipleBorder6 = "|____________________________________________|_________________________|";
	private final String horizontalLineWithMultipleBorder5 = "|________________|_________________|_________|_________________________|";

	private final String checkBoxMarker = "|"+"_|";
	private final String leftHorizontalLine = "______________________";
//	private final String centerHorizontalLine = "________________________";
	//private final String extraSpaceLine = "_";

	/**
	 * Classname / Method Name : LataTemplateForWashingtonStateNDRModified/getBufferForWashingtonStateNdr()
	 * @param washingtonStateNdrFormTemplateDetails
	 * @return : StringBuffer
	 * Description : Method is used to get contents of Washington State NDR template.
	 */
	public StringBuffer getBufferForWashingtonStateNdr(WashingtonStateNdrFormTemplateDetails 
			washingtonStateNdrFormTemplateDetails){
		StringBuffer stringBuffer = new StringBuffer();
		stringBuffer.append(padSpaceTillMaxLength(12)+"National Driver Register File Check"+"\n");
		stringBuffer.append(padSpaceTillMaxLength(12)+"and Abstract of Driving Record Request"+"\n");
		stringBuffer.append(padSpaceTillMaxLength(12)+"for current or prospective employee");
		stringBuffer.append(" "+leftHorizontalLine+"\n");
		stringBuffer.append("Please Type or print plainly"+padSpaceTillMaxLength(19)+"|"+"For Validation Only"+padSpaceTillMaxLength(2)+"|");
		stringBuffer.append("\n");
		stringBuffer.append("Inquiries that cannot be read"+padSpaceTillMaxLength(18)+"|"+padSpaceTillMaxLength(21)+"|"+"\n");
		stringBuffer.append("read cannot be processed."+padSpaceTillMaxLength(22)+"|"+padSpaceTillMaxLength(21)+"|"+"\n");
		stringBuffer.append(padSpaceTillMaxLength(47)+"|"+leftHorizontalLine+"|"+"\n");
		stringBuffer.append(padSpaceTillMaxLength(48)+"106-060-421-0005");
		stringBuffer.append("\n");
		stringBuffer.append(" Current or Prospective Employer to receive search results");
		stringBuffer.append("\n");
		stringBuffer.append(padSpaceTillMaxLength(1)+"_"+padSpaceTillMaxLength(16)+"_"+padSpaceTillMaxLength(13)+"_");
		stringBuffer.append("\n");
		stringBuffer.append(" "+checkBoxMarker+"Driver Employer"+checkBoxMarker+"Railroad Co."+checkBoxMarker+"Air Carrier");
		stringBuffer.append("\n");
		stringBuffer.append(" "+horizontalLinePlain);
		stringBuffer.append("\n");
		stringBuffer.append("|"+"Employee or agency name"+padSpaceTillMaxLength(46)+"|");
		stringBuffer.append("\n");
		stringBuffer.append("|"+"Union Pacific Railroad"+padSpaceTillMaxLength(47)+"|");	
		stringBuffer.append("\n");
		stringBuffer.append(horizontalLine);
		stringBuffer.append("\n");
		stringBuffer.append("|"+"To the specific attention of"+padSpaceTillMaxLength(3)+"|"+"(Area code)Business telephone number"+" |");
		stringBuffer.append("\n");
		stringBuffer.append("|"+"Licensing Department"+padSpaceTillMaxLength(11)+"|"+"(402)544-0419 "+padSpaceTillMaxLength(22)+"|");
		stringBuffer.append("\n");
		stringBuffer.append(horizontalLineWithMultipleBorder4);
		stringBuffer.append("\n");
		stringBuffer.append("|"+"Mailing address"+padSpaceTillMaxLength(54)+"|");
		stringBuffer.append("\n");
		stringBuffer.append("|"+"1400 Douglas Street, Mail Stop 1010"+padSpaceTillMaxLength(34)+"|");
		stringBuffer.append("\n");
		stringBuffer.append(horizontalLine);
		stringBuffer.append("\n");
		stringBuffer.append("|"+"City "+padSpaceTillMaxLength(20)+"|"+"State"+padSpaceTillMaxLength(12)+"|"+"ZIP code"+padSpaceTillMaxLength(15)+"|");
		stringBuffer.append("\n");
		stringBuffer.append("|"+"Omaha"+padSpaceTillMaxLength(20)+"|"+"NE"+padSpaceTillMaxLength(15)+"|"+"68179-1010"+padSpaceTillMaxLength(13)+"|");
		stringBuffer.append("\n");
		stringBuffer.append(horizontalLineWithMultipleBorder3);
		stringBuffer.append("\n");
		stringBuffer.append(" "+"Driver Information");
		stringBuffer.append("\n");
		stringBuffer.append(padSpaceTillMaxLength(1/2)+horizontalLinePlain);
		stringBuffer.append("\n");
		stringBuffer.append("|"+"Driver full legal name (First, Middle and Last)"+padSpaceTillMaxLength(22)+"|");
		stringBuffer.append("\n");
		stringBuffer.append("|"+padSpaceTillMaxLengthForDynamicFields(washingtonStateNdrFormTemplateDetails.getDriverEmployeeName(),69)+"|");
		stringBuffer.append("\n");
		stringBuffer.append(horizontalLine);
		stringBuffer.append("\n");
		stringBuffer.append("|"+"Other names used(Maiden,Prior Name,Nickname,Professional Name,Other)"+"  |");
		stringBuffer.append("\n");
		stringBuffer.append("|"+padSpaceTillMaxLength(69)+"|");
		stringBuffer.append("\n");
		stringBuffer.append(horizontalLine);
		stringBuffer.append("\n");
		stringBuffer.append("|"+"Residance address"+padSpaceTillMaxLength(26)+"|"+"(Area code)Home telephone"+"|");
		stringBuffer.append("\n");
		stringBuffer.append("|"+padSpaceTillMaxLengthForDynamicFields(washingtonStateNdrFormTemplateDetails.getResidanceAddress(), 43)+"|"+"--Optional"+padSpaceTillMaxLength(14)+"|");
		stringBuffer.append("\n");
		stringBuffer.append("|"+padSpaceTillMaxLength(43)+"|"+padSpaceTillMaxLength(24)+"|");
		stringBuffer.append("\n");
		stringBuffer.append(horizontalLineWithMultipleBorder6);
		stringBuffer.append("\n");
		stringBuffer.append("|"+"City"+padSpaceTillMaxLength(11)+"|"+"State"+padSpaceTillMaxLength(11)+"|"+"ZIP code"+padSpaceTillMaxLength(1/2)+"|"+"(Area code)Home telephone"+"|");
		stringBuffer.append("\n");
		stringBuffer.append("|"+padSpaceTillMaxLengthForDynamicFields(washingtonStateNdrFormTemplateDetails.getCity(), 15)+"|"+padSpaceTillMaxLengthForDynamicFields(washingtonStateNdrFormTemplateDetails.getState(),16)+"|"+padSpaceTillMaxLengthForDynamicFields(washingtonStateNdrFormTemplateDetails.getZipCode(),8)+"|"+"--Optional"+padSpaceTillMaxLength(14)+"|");
		stringBuffer.append("\n");
		stringBuffer.append("|"+padSpaceTillMaxLength(15)+"|"+padSpaceTillMaxLength(16)+"|"+padSpaceTillMaxLength(8)+"|"+padSpaceTillMaxLength(24)+"|");
		stringBuffer.append("\n");
		stringBuffer.append(horizontalLineWithMultipleBorder5);
		stringBuffer.append("\n");
		stringBuffer.append("|"+"Driver license number"+padSpaceTillMaxLength(1)+"|"+"Issuing state"+padSpaceTillMaxLength(1/2)+"|"+"Social Security number"+padSpaceTillMaxLength(8)+"|");
		stringBuffer.append("\n");
		stringBuffer.append("|"+padSpaceTillMaxLength(22)+"|"+padSpaceTillMaxLength(13)+"|"+padSpaceTillMaxLength(30)+"|"+"\n");
		stringBuffer.append("|"+leftHorizontalLine+"_|"+"______________"+"|"+padSpaceTillMaxLength(30)+"|");
		stringBuffer.append("\n");
		stringBuffer.append("|"+"Birth date"+padSpaceTillMaxLength(1/2)+" |"+"Sex"+padSpaceTillMaxLength(1/2)+"|"+"Eye"+padSpaceTillMaxLength(1)+"|"+"Height"+padSpaceTillMaxLength(1/2)+"|"+"Weight"+"|");
		stringBuffer.append("For commercial drivers-Mandato-"+"|");
		stringBuffer.append("\n");
		stringBuffer.append("|"+"(Month,Day,"+padSpaceTillMaxLength(1/2)+"|"+padSpaceTillMaxLength(3)+"|");
		stringBuffer.append("Color"+"|"+padSpaceTillMaxLength(6)+"|"+padSpaceTillMaxLength(5)+"|");
		stringBuffer.append("ry for identification purposes"+" |");
		stringBuffer.append("\n");
		stringBuffer.append("|"+"Year)"+padSpaceTillMaxLength(6)+"|"+padSpaceTillMaxLength(3)+"|");
		stringBuffer.append(padSpaceTillMaxLength(4)+"|"+padSpaceTillMaxLength(6)+"|"+padSpaceTillMaxLength(5)+"|");
		stringBuffer.append("per 49 CFR 383,153,RCW 46.25.-"+" |");
		stringBuffer.append("\n");
		stringBuffer.append("|"+padSpaceTillMaxLengthForDynamicFields(washingtonStateNdrFormTemplateDetails.getDateOfBirth(), 11)+"|"+padSpaceTillMaxLength(3)+"|");
		stringBuffer.append(padSpaceTillMaxLength(4)+"|"+padSpaceTillMaxLength(6)+"|"+padSpaceTillMaxLength(5)+"|");
		stringBuffer.append("070.For non-commercial drivers-"+"|");
		stringBuffer.append("\n");
		stringBuffer.append("|"+padSpaceTillMaxLength(11)+"|"+padSpaceTillMaxLength(3)+"|"+padSpaceTillMaxLength(4)+"|"+padSpaceTillMaxLength(6)+"|"+padSpaceTillMaxLength(5)+"|"+"Requested for identification-  "+"|");
		stringBuffer.append("\n");
		stringBuffer.append("|"+padSpaceTillMaxLength(11)+"|"+padSpaceTillMaxLength(3)+"|"+padSpaceTillMaxLength(4)+"|"+padSpaceTillMaxLength(6)+"|"+padSpaceTillMaxLength(5)+"|"+"purposes only.Entering SSN is- "+"|");
		stringBuffer.append("\n");
		stringBuffer.append("|"+padSpaceTillMaxLength(11)+"|"+padSpaceTillMaxLength(3)+"|"+padSpaceTillMaxLength(4)+"|"+padSpaceTillMaxLength(6)+"|"+padSpaceTillMaxLength(5)+"|"+"voluntry.WAC 308-104-014.      "+"|");
		stringBuffer.append("\n");
		stringBuffer.append(horizontalLineWithMultipleBorder2);
		stringBuffer.append("\n");
		stringBuffer.append("|"+"Employee Understanding: I understand that this report will result in  "+"|");
		stringBuffer.append("\n");
		stringBuffer.append("|"+"printed reports whichwill be sent only to the employer or regulatory  "+"|");
		stringBuffer.append("\n");
		stringBuffer.append("|"+"agency listed above on this form. The National Driver Register(NDR)   "+"|");
		stringBuffer.append("\n");
		stringBuffer.append("|"+"report will indicate either that (1) the NDR does not contain a record"+"|");
		stringBuffer.append("\n");
		stringBuffer.append("|"+"mathing my identification or (2) the NDR has a probable identification"+"|");
		stringBuffer.append("\n");
		stringBuffer.append("|"+"match from one or more states listed on the report. A copy of my Wash-"+"|");
		stringBuffer.append("\n");
		stringBuffer.append("|"+"ington driving record will also be sent to the employer or agency. If "+"|");
		stringBuffer.append("\n");
		stringBuffer.append("|"+"there are probable NDR matches from states other than Washington, it  "+"|");
		stringBuffer.append("\n");
		stringBuffer.append("|"+"is the responsibility of the employer to obtain records from those st-"+"|");
		stringBuffer.append("\n");
		stringBuffer.append("|"+"ates. Under the privacy act, I have the right to  request record(s)   "+"|");
		stringBuffer.append("\n");
		stringBuffer.append("|"+"pertaining to me from the NDR. I also understand that if convictions, "+"|");
		stringBuffer.append("\n");
		stringBuffer.append("|"+"suspensions or revocations are found which I have not disclosed in    "+"|");
		stringBuffer.append("\n");
		stringBuffer.append("|"+"applications or interviews, I might not be hired or could lose my job "+"|");
		stringBuffer.append("\n");
		stringBuffer.append("|"+"and Washington state may take action against my license. I hereby aut-"+"|");
		stringBuffer.append("\n");
		stringBuffer.append("|"+"horize the results of a one-time NDR search and a copy of my Washingt-"+"|");
		stringBuffer.append("\n");
		stringBuffer.append("|"+"on driving record e sent to the employer or agency named on this form."+"|");
		stringBuffer.append("\n");

		stringBuffer.append(horizontalLine);
		stringBuffer.append("\n");
		stringBuffer.append("|"+"Driver's signature (Please read page 2 before signing)"+padSpaceTillMaxLength(1/2)+"|"+"Date"+padSpaceTillMaxLength(9)+"|");
		stringBuffer.append("\n");
		stringBuffer.append("|"+padSpaceTillMaxLength(54)+"|"+padSpaceTillMaxLength(13)+"|"+"\n");//yet to write the code...
		stringBuffer.append(horizontalLineWithMultipleBorder1);
		stringBuffer.append("\n");
		stringBuffer.append(" Notarization");
		stringBuffer.append("\n");
		stringBuffer.append(padSpaceTillMaxLength(1/2)+horizontalLinePlain+"\n");
		stringBuffer.append("|"+padSpaceTillMaxLength(25)+"State of Washington"+padSpaceTillMaxLength(24)+"|");
		stringBuffer.append("\n");
		stringBuffer.append("|"+padSpaceTillMaxLength(25)+"County of"+leftHorizontalLine+"_____________|");
		stringBuffer.append("\n");
		stringBuffer.append("|"+"Signed or attested before me on"+"________________"+"by"+"_____________________"+"|"+"\n");
		stringBuffer.append("|"+padSpaceTillMaxLength(47)+"______________________"+"|"+"\n");
		stringBuffer.append("|"+padSpaceTillMaxLength(5)+"(Seal or stamp)"+padSpaceTillMaxLength(17)+"_______________________________"+"|"+"\n");
		stringBuffer.append("|"+padSpaceTillMaxLength(20)+"My appointment expires"+"___________________________|"+"\n");
		stringBuffer.append(horizontalLine+"\n");
		stringBuffer.append(" OFFICIAL USE ONLY");
		stringBuffer.append("\n"+padSpaceTillMaxLength(1/2)+horizontalLinePlain+"\n");
		stringBuffer.append("|"+"Date"+padSpaceTillMaxLength(5)+"|"+"Date sent"+padSpaceTillMaxLength(1/2)+"|"+"Type of identification"+padSpaceTillMaxLength(25)+"|");
		stringBuffer.append("\n|"+"Received"+padSpaceTillMaxLength(1)+"|"+padSpaceTillMaxLength(9)+"|"+padSpaceTillMaxLength(47)+"|");
		stringBuffer.append("\n|"+horizontalLine1+"|\n");
		stringBuffer.append("|"+padSpaceTillMaxLength(9)+"|"+padSpaceTillMaxLength(9)+"| "+"_"+padSpaceTillMaxLength(15)+"_"+padSpaceTillMaxLength(14)+"_"+padSpaceTillMaxLength(12)+"|");
		stringBuffer.append("\n");
		stringBuffer.append("|"+padSpaceTillMaxLength(9)+"|"+padSpaceTillMaxLength(9)+"|"+checkBoxMarker+"Valid photo"+padSpaceTillMaxLength(2));
		stringBuffer.append(checkBoxMarker+"State issued "+checkBoxMarker+"Birth"+padSpaceTillMaxLength(6)+"|");
		stringBuffer.append("\n");
		stringBuffer.append("|"+padSpaceTillMaxLength(9)+"|"+padSpaceTillMaxLength(9)+"| "+" "+" driver license"+padSpaceTillMaxLength(2)+"photo ID"+padSpaceTillMaxLength(7)+"Certificate"+" |");
		stringBuffer.append("\n");
		stringBuffer.append("|"+padSpaceTillMaxLength(9)+"|"+padSpaceTillMaxLength(9)+"| "+"_"+padSpaceTillMaxLength(15)+"_"+padSpaceTillMaxLength(14)+"_"+padSpaceTillMaxLength(12)+"|");
		stringBuffer.append("\n");
		stringBuffer.append("|"+padSpaceTillMaxLength(9)+"|"+padSpaceTillMaxLength(9)+"|"+checkBoxMarker+"Valid passport");
		stringBuffer.append(checkBoxMarker+"Valid"+padSpaceTillMaxLength(7)+checkBoxMarker+"Military"+padSpaceTillMaxLength(3)+"|");
		stringBuffer.append("\n");
		
		
		stringBuffer.append("|"+padSpaceTillMaxLength(9)+"|"+padSpaceTillMaxLength(9)+"|"+padSpaceTillMaxLength(19)+"Military ID"+padSpaceTillMaxLength(4)+"discharge"+padSpaceTillMaxLength(2)+"|");
		stringBuffer.append("\n");
		stringBuffer.append("|"+padSpaceTillMaxLength(9)+"|"+padSpaceTillMaxLength(9)+"| "+"_"+padSpaceTillMaxLength(33)+"papers"+padSpaceTillMaxLength(5)+"|");
		stringBuffer.append("\n");
		stringBuffer.append("|"+padSpaceTillMaxLength(9)+"|"+padSpaceTillMaxLength(9)+"|"+checkBoxMarker+"Others"+padSpaceTillMaxLength(38)+"|");
		stringBuffer.append("\n|"+horizontalLine1+"|\n");
		stringBuffer.append("|"+"Print name of employee verifying"+"|");
		stringBuffer.append("Signature of employee     "+"|"+"Date"+padSpaceTillMaxLength(5)+"|"+"\n");
		stringBuffer.append("|"+"applicant identification"+padSpaceTillMaxLength(7)+"|"+"verifying applicant"+padSpaceTillMaxLength(6)+"|"+padSpaceTillMaxLength(9)+"|"+"\n");
		stringBuffer.append("|"+padSpaceTillMaxLength(31)+"|"+"identification"+padSpaceTillMaxLength(11)+"| ");
		stringBuffer.append(padSpaceTillMaxLength(8)+"|");
		stringBuffer.append("\n");
		stringBuffer.append("|"+padSpaceTillMaxLength(31)+"|"+padSpaceTillMaxLength(25)+"| ");
		stringBuffer.append(padSpaceTillMaxLength(8)+"|");
		stringBuffer.append("\n");
		stringBuffer.append("|"+padSpaceTillMaxLength(31)+"|"+padSpaceTillMaxLength(25)+"| ");
		stringBuffer.append(padSpaceTillMaxLength(8)+"|");
		stringBuffer.append("\n|"+horizontalLine2+"|\n\n");
//		stringBuffer.append(printNDRDetails());

		return stringBuffer;
	}

	/**
	 * Classname / Method Name : LataTemplateForWashingtonStateNDRModified/padSpaceTillMaxLength()
	 * @param maxLength
	 * @return : String
	 * Description : Method is used to add spaces in Washington State NDR template
	 */
	private  String padSpaceTillMaxLength(int maxLength){
		StringBuffer sb = new StringBuffer();
		for(int i=0;i<=maxLength;i++){
			sb.append(" ");
		}
		return sb.toString();
	}

	/**
	 * Classname / Method Name : LataTemplateForWashingtonStateNDRModified/padSpaceTillMaxLengthForDynamicFields()
	 * @param str
	 * @param maxLength
	 * @return : String
	 * Description : Method is used to adjust proper spaces for dynamic fields for Washington State 
	 * NDR template.
	 */
	private String padSpaceTillMaxLengthForDynamicFields(String str, int maxLength){
		StringBuffer sb = new StringBuffer(str);
		for(int i=str.length();i<=maxLength;i++){
			sb.append(" ");
		}
		return sb.toString();
	}

	/**
	 * Classname / Method Name : LataTemplateForWashingtonStateNDRModified/printNDRDetails()
	 * @return : String
	 * Description : Method is used to get NDR details for Washington State NDR template.
	 */
	/*private String printNDRDetails(){
		StringBuffer sb = new StringBuffer();
		sb.append(padSpaceTillMaxLength(31)+"Requests for National Driver Register (NDR) Record Checks");
		sb.append("\n\n");
		sb.append("How to Request an NDR Record Check"+"\n");
		sb.append("This form may be completed by the current or prospective employer or employee. The driver must authorize the request"+"\n");
		sb.append("by their signature (or their mark as witnessed) and have it notarized.");
		sb.append("\n\n");
		sb.append("What NDR Records Contain"+"\n");
		sb.append("NDR results for employers will contain only the identification of the state(s) which have reported information on the "+"\n");
		sb.append("driver to the NDR and only information reported withing the past three years from the date of inquiry. Driver control "+"\n");
		sb.append("actions initiated prior to that time, even if still in effect, will not be included."+"\n");
		sb.append("A copy of the Washington driving record will also be sent to the employer or agency. If there are probable NDR "+"\n");
		sb.append("matches from states other than Washington, it is the responsibility of the employer to obtain the records from "+"\n");
		sb.append("those states.The name and address of the driver licensing official will be provided for each state listed.");
		sb.append("\n\n");
		sb.append("Authorization to Railroad Companies"+"\n");
		sb.append("The employee/prospective employee grants authorization as follows: "+"\"The U.S. Department of Transportation, Federal"+"\n");
		sb.append("Railroad Administration, in accordance with 49 CFR, Part 240.111, requires that i hereby request and auhtorize the "+"\n");
		sb.append("National Highway Traffic Safety Administration(NHTSA) to perform an NDR check of my driving record for a 36 month  "+"\n");
		sb.append("period prior to the date of this request including license withdrawal actions open at the time of file check. I "+"\n");
		sb.append("hereby authorize the NDR to furnish the copy of the results of this NDR check directly to the railroad company "+"\n");
		sb.append("identified on this enquiry form."+"/"+"\n\n");
		sb.append("Authorization to Air Carriers"+"\n");
		sb.append("The employee/prospective employee grants authorization as follows: "+"\"In accordance with Section 502 of Pilot Records"+"\n");
		sb.append("Improvement Act of 1996,Public Law 104-264, I hereby request and authorize the National Highway Traffic Safety "+"\n");
		sb.append("Administration (NHTSA) to perform an NDR check of my driving record for a five-year period prior to the date "+"\n");
		sb.append("of this request, including license withdrawal actions open at the time of the file check. I hereby authorize "+"\n");
		sb.append("the NDR to furnish a copy of the results of this NDR check directly to the air carrier identified on this inquiry form.");
		return sb.toString();
	}*/

	public static void main(String[] args) {
		LataTemplateForWashingtonStateNDRModified lataTemplateForDriving = 
			new LataTemplateForWashingtonStateNDRModified();

	}

	private static WashingtonStateNdrFormTemplateDetails getTemplate(){

		WashingtonStateNdrFormTemplateDetails washingtonStateNdrFormTemplateDetails = 
			new WashingtonStateNdrFormTemplateDetails();
		washingtonStateNdrFormTemplateDetails.setDriverEmployeeName("sreekar reddy vanguru");
		washingtonStateNdrFormTemplateDetails.setDriverEmployeeName("ABCDEFGHIJKLWXYZ,ABCDEFGHIJKLMNOPQRSTUVWXYZ ABCDEFGHIJKLMNOPQRSTUVWXYZ");
		washingtonStateNdrFormTemplateDetails.setCity("Hyderabad");
		washingtonStateNdrFormTemplateDetails.setResidanceAddress("ABCDEFGHIJKLWXYZ ABCDEssddFGHIJK");
		washingtonStateNdrFormTemplateDetails.setState("Secunderabaad");
		washingtonStateNdrFormTemplateDetails.setDateOfBirth("10/26/1985");
		washingtonStateNdrFormTemplateDetails.setZipCode("400000115");
		return washingtonStateNdrFormTemplateDetails;
	}


}
