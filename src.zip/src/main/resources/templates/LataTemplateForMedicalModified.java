/**
 * Classname    : LataTemplateForMedicalModified
 * Description  : Class is used as a Lata template for Medical Form (LHI Instruction Set).
 * author     : Techmahindra Ltd.
 * Date of creation : Jul 20, 2009
 *
 * Change History
 * ------------------------------------------------------------  
 *   Date  Changed By    Description
 * ------------------------------------------------------------  
 *  04/12/2016    xsat671       Modified for SS_QC#5503.
 *  30/06/2016    xsat872       Modified for SS_QC#6452.
 *  21/04/2017    xsat872       Modified for SS_QC#8579.
 * ------------------------------------------------------------  
 *
 * Copyright notice : "Copyright UPRR 2008"
 */
package templates;

import com.uprr.app.eqm.components.common.logger.EqmsLogger;

public class LataTemplateForMedicalModified {

  EqmsLogger m_logger = EqmsLogger.getLoggerInstance(this.getClass());

  //-- markers
  private final String firstMarker = padSpaceTillMaxLength(2);
  private final String singleSpace = padSpaceTillMaxLength(1);
  private final String tripleSpace = padSpaceTillMaxLength(3);  

  private final String verticalLine = "|";

  private final String endMarkersWithSpace = firstMarker+verticalLine+padSpaceTillMaxLength(66)+verticalLine;

  //-- lines
  private final String toplLine = "___________________________________________________________________";
  private final String bottomlLineWithEndBorders = "|___________________________________________________________________|";

  //-- data
  //Modified for SS_QC#8579:Start
  private final String heading="Instructions for Scheduling Hearing & Vision Exam";
  private final String secondHeading="Please read the instructions carefully as this ";
  private final String thirdHeading=" process has changed as of January 2015. ";

  // SS_QC#5503 changes start
  private final String section3 = "This document lists the steps necessary to complete your Medical ";

  private final String section4 = "Assessment for Union Pacific Railroad. Failure to promptly complete";

  private final String section5 = "your assessment can impact your eligibility to work.";

  private final String section34 = "Your medical exam can be taken through LHI or your ";

  private final String section35 = "Occupational Health Nurse (OHN). You must first take action";

  private final String section36 = "in eHealthSafe (eHS) before calling to schedule the exam. ";

  private final String section37 = "Please note that HR Services is unable to make this determination";

  private final String section38 = "for you.";

  // SS_QC#5503 changes end
  private final String section7="1. From the UP homepage, click on ePayroll, eHealthSafe.";
  private final String section8="2. Click 'Messages / Attachments'.";
  private final String section9="3. On the ToDo List tab, look for the exam in your list.";
  private final String section10="   Exams are created approximately 150 days before";
  private final String section11="   the expiration date. ";
  private final String section12="   The Description will say:\"Exam Required-Select Provider.\"";
  private final String section13="4  Click on the row so it is highlighted.";
  private final String section14="To schedule your exam with LHI:.";
  private final String section15="a. With the exam row highlighted, click the \"Reject\" button.";
  private final String section16="b. Allow one hour for LHI to receive your orders and then";
  private final String section17="call them to schedule the exam.";
  private final String section18="c. LHI's phone number is 1-866-873-9261.";
  private final String section19="To schedule your exam with your Occupational Health Nurse:";
  private final String section20="a. With the exam row highlighted, click the \"Approve\" button. ";
  private final String section21="b. Call your local nurse to schedule your exam.";
  private final String section22="* Please note that the items in your To Do List may not be in";
  private final String section23="order, so review carefully.";
  private final String section24="* If your exam is not showing up on your To Do List, ";
  private final String section25=" please contact Health & Medical at 877-275-8747.";
  private final String section26="Note: You are responsible for ensuring you have sufficient";
  private final String section27="time under the Hours of Service or have completed federal";
  private final String section28="rest when taking the Medical Assessment.";
  private final String section29="Upon completion of the exam, contact CMS";
  private final String section30="to update your records as required by law for federal";
  private final String section31="rest purposes.";
  
  // SS_QC#6452 Changes start
  private final String section32 = "1. LHI's Scheduling Center is available during normal";
  private final String section33 = "business hours (Monday-Friday 7am-10pm & Saturday 7am-3pm CST).";
  // SS_QC#6452 Changes end
  

  private final String section39 = "2. Please keep this sheet in front of you when you call";
  private final String section40 = "to schedule your appointment.";
  private final String section41 = "3. Take this instruction sheet with you to your appointment.";
  private final String section42 = "LHI will send your exam forms to the assigned clinic prior";
  private final String section43 = "to your arrival. If the clinic does not have paperwork";
  private final String section44 = "when you arrive, please call LHI at 1-866-873-9261";
  private final String section45 = " to have it faxed to the clinic immediately.";
  private final String section46 = "4. Medical Clearance to Work - LHI is responsible";
  private final String section47 = " and accountable to Union Pacific Railroad to issue a medical";
  private final String section48 = "to work based on the results of your Medical Assessment Testing.";
  private final String section49 = "It is vitally important, that you cooperate fully in the ";
  private final String section50 = "Medical Assessment process.";  
  private final String section51 = "NOTE: LHI will review the results of your Medical Assessment.";
  private final String section52 = "Based on this review, FURTHER medical documentation";
  private final String section53 = "and/or evaluation may be required;";
  private final String section54 = "your timely response to any further requests for";
  private final String section55 = "information is greatly appreciated and will help ensure ";
  private final String section56 = "a more timely review."; 
  private final String section57 = "LHI cannot give you information on the clearance";
  private final String section58 = "status of your exam. Once the final status of your";
  private final String section59 = "Medical Assessment is determined by LHI, ";
  private final String section60 = "it will immediately be reported to Union Pacific Railroad Health";
  private final String section61 = "Services Department."; 
  //Modified for SS_QC#8579:End
  
  
  //Commented For SS_QC#8579:Start
  /*// SS_QC#5503 changes start
  //SS_QC#6452 Changes start
  private final String headingInstruction1 = "**The instructions below are for scheduling your exam through LHI. ";
  private final String headingInstruction2 = "If you selected 'approve' in eHealthSafe (eHS) to receive your";
  private final String headingInstruction3 = "exam through your Occupational Health Nurse (OHN), their contact";
  private final String headingInstruction4 = "information will appear in your 'To Do List' in eHS.";
  private final String headingInstruction5 = "Please contact them to schedule your appointment.";
  // SS_QC#5503 changes end
  //SS_QC#6452 Changes end
  */  
  //Commented For SS_QC#8579:End
  
  
  /**
   * Method is used to get contents of the Medical template.
   *
   * @return
   * @author xsat671
   * @since Apr 12, 2016. Modified for SS_QC#5503.
   * Modified for SS_QC#6452
   * Modified for SS_QC#8579
   */
  public StringBuffer getBufferForLataPrintForMedical(){
    StringBuffer stringBuffer=new StringBuffer();
    stringBuffer.append(tripleSpace+toplLine);
    stringBuffer.append("\n");
    stringBuffer.append(endMarkersWithSpace);
    stringBuffer.append("\n");
    stringBuffer.append(firstMarker+verticalLine+padSpaceTillMaxLengthAlignCenter(heading, 66)+verticalLine);
    stringBuffer.append("\n");
    stringBuffer.append(endMarkersWithSpace);
    //Commented for SS_QC#8579:Start
    /*
    // SS_QC#5503 changes start       
    // SS_QC#6452 Changes Start
    stringBuffer.append(firstMarker + verticalLine + headingInstruction1 + verticalLine);
    stringBuffer.append("\n");
    stringBuffer.append(firstMarker + verticalLine + headingInstruction2 + padSpaceTillMaxLength(4) + verticalLine);
    stringBuffer.append("\n");
    stringBuffer.append(firstMarker + verticalLine + headingInstruction3 + padSpaceTillMaxLength(2) + verticalLine);
    stringBuffer.append("\n");
    stringBuffer.append(firstMarker + verticalLine + headingInstruction4 + padSpaceTillMaxLength(14) + verticalLine);
    stringBuffer.append("\n");
    stringBuffer.append(firstMarker + verticalLine + headingInstruction5 + padSpaceTillMaxLength(17) + verticalLine);
    stringBuffer.append("\n");
    // SS_QC#6452 Changes Start   
    // SS_QC#5503 changes end
    stringBuffer.append(firstMarker+bottomlLineWithEndBorders);
    stringBuffer.append("\n");
    stringBuffer.append(tripleSpace+toplLine);
    //Commented for SS_QC#8579:End
    */
    //Modified for SS_QC#8579:Start
    stringBuffer.append("\n");
    stringBuffer.append(firstMarker+verticalLine+padSpaceTillMaxLengthAlignCenter(secondHeading, 66)+verticalLine);
    stringBuffer.append("\n");
    stringBuffer.append(firstMarker+verticalLine+padSpaceTillMaxLengthAlignCenter(thirdHeading, 66)+verticalLine);
    stringBuffer.append("\n");
    // SS_QC#5503 changes start
    stringBuffer.append(endMarkersWithSpace);
    stringBuffer.append("\n");
    stringBuffer.append(firstMarker + verticalLine + section3 + padSpaceTillMaxLength(1) + verticalLine);
    stringBuffer.append("\n");
    stringBuffer.append(firstMarker + verticalLine + section4 + verticalLine);
    stringBuffer.append("\n");
    stringBuffer.append(firstMarker + verticalLine + section5 + padSpaceTillMaxLength(14) + verticalLine);
    stringBuffer.append("\n" + endMarkersWithSpace + "\n");
    stringBuffer.append(firstMarker + verticalLine + section34 + padSpaceTillMaxLength(15) + verticalLine);
    stringBuffer.append("\n");
    stringBuffer.append(firstMarker + verticalLine + section35 + padSpaceTillMaxLength(7) + verticalLine);
    stringBuffer.append("\n");
    stringBuffer.append(firstMarker + verticalLine + section36 +padSpaceTillMaxLength(8) + verticalLine);
    stringBuffer.append("\n");
    stringBuffer.append(firstMarker + verticalLine + section37 + padSpaceTillMaxLength(1) + verticalLine);
    stringBuffer.append("\n");
    stringBuffer.append(firstMarker + verticalLine + section38 + padSpaceTillMaxLength(58) + verticalLine);
    // SS_QC#5503 changes end
    stringBuffer.append("\n"+endMarkersWithSpace+"\n");
    stringBuffer.append(firstMarker+verticalLine+singleSpace+section7+padSpaceTillMaxLength(8)+verticalLine);
    stringBuffer.append("\n");
    stringBuffer.append(firstMarker+verticalLine+singleSpace+section8+padSpaceTillMaxLength(30)+verticalLine);
    stringBuffer.append("\n");
    stringBuffer.append(firstMarker+verticalLine+singleSpace+section9+padSpaceTillMaxLength(8)+verticalLine);
    stringBuffer.append("\n");
    stringBuffer.append(firstMarker+verticalLine+singleSpace+section10+padSpaceTillMaxLength(14)+verticalLine);
    stringBuffer.append("\n");
    stringBuffer.append(firstMarker+verticalLine+singleSpace+section11+padSpaceTillMaxLength(40)+verticalLine);
    stringBuffer.append("\n");   
    stringBuffer.append(firstMarker+verticalLine+singleSpace+section12+padSpaceTillMaxLength(4)+verticalLine);
    stringBuffer.append("\n");
    // SS_QC#6452 Changes Start
    stringBuffer.append(firstMarker+verticalLine+singleSpace+section13+padSpaceTillMaxLength(23)+verticalLine);   
    stringBuffer.append("\n"+endMarkersWithSpace+"\n");
    stringBuffer.append(firstMarker+verticalLine+singleSpace+section14+padSpaceTillMaxLength(32)+verticalLine);
    stringBuffer.append("\n");
    stringBuffer.append(firstMarker+verticalLine+padSpaceTillMaxLength(4)+section15+padSpaceTillMaxLength(1)+verticalLine);
    stringBuffer.append("\n");
    stringBuffer.append(firstMarker+verticalLine+padSpaceTillMaxLength(4)+section16+padSpaceTillMaxLength(4)+verticalLine);
    stringBuffer.append("\n");
    stringBuffer.append(firstMarker+verticalLine+padSpaceTillMaxLength(4)+section17+padSpaceTillMaxLength(30)+verticalLine);
    // SS_QC#6452 Changes End 
    stringBuffer.append("\n");   
    stringBuffer.append(firstMarker+verticalLine+padSpaceTillMaxLength(4)+section18+padSpaceTillMaxLength(21)+verticalLine);    
   stringBuffer.append("\n"+endMarkersWithSpace+"\n");
    stringBuffer.append(firstMarker+verticalLine+singleSpace+section19+padSpaceTillMaxLength(6)+verticalLine);
    stringBuffer.append("\n");
    stringBuffer.append(firstMarker+verticalLine+padSpaceTillMaxLength(4)+section20+verticalLine);
    stringBuffer.append("\n");
    stringBuffer.append(firstMarker+verticalLine+padSpaceTillMaxLength(4)+section21+padSpaceTillMaxLength(14)+verticalLine);
    stringBuffer.append("\n"+endMarkersWithSpace+"\n");
    stringBuffer.append(firstMarker+verticalLine+section22+padSpaceTillMaxLength(5)+verticalLine);
    stringBuffer.append("\n");
    stringBuffer.append(firstMarker+verticalLine+section23+padSpaceTillMaxLength(39)+verticalLine);
    stringBuffer.append("\n");
    stringBuffer.append(firstMarker+verticalLine+section24+padSpaceTillMaxLength(13)+verticalLine);
    stringBuffer.append("\n");
    stringBuffer.append(firstMarker+verticalLine+section25+padSpaceTillMaxLength(17)+verticalLine);
    stringBuffer.append("\n");
    stringBuffer.append(firstMarker+verticalLine+section26+padSpaceTillMaxLength(8)+verticalLine);
    stringBuffer.append("\n");
    stringBuffer.append(firstMarker+verticalLine+section27+padSpaceTillMaxLength(9)+verticalLine);
    stringBuffer.append("\n");
    stringBuffer.append(firstMarker+verticalLine+section28+padSpaceTillMaxLength(26)+verticalLine);
    stringBuffer.append("\n");
    stringBuffer.append(firstMarker+verticalLine+section29+padSpaceTillMaxLength(26)+verticalLine);
    stringBuffer.append("\n");
    stringBuffer.append(firstMarker+verticalLine+section30+padSpaceTillMaxLength(13)+verticalLine);
    stringBuffer.append("\n");
    stringBuffer.append(firstMarker+verticalLine+section31+padSpaceTillMaxLength(52)+verticalLine);
    stringBuffer.append("\n");    
    // SS_QC#6452 Changes start
    stringBuffer.append(firstMarker + verticalLine + section32 + padSpaceTillMaxLength(13) + verticalLine);
    stringBuffer.append("\n");
    stringBuffer.append(firstMarker + verticalLine + section33 + padSpaceTillMaxLength(3) + verticalLine);
    // SS_QC#6452 Changes end
    stringBuffer.append("\n");
    stringBuffer.append(firstMarker + verticalLine + section39 + padSpaceTillMaxLength(11) + verticalLine);
    stringBuffer.append("\n");
    stringBuffer.append(firstMarker + verticalLine + section40 + padSpaceTillMaxLength(37) + verticalLine);
    stringBuffer.append("\n");
    stringBuffer.append(firstMarker + verticalLine + section41 + padSpaceTillMaxLength(6) + verticalLine);
    stringBuffer.append("\n");
    stringBuffer.append(firstMarker + verticalLine + section42 + padSpaceTillMaxLength(8) + verticalLine);
    stringBuffer.append("\n");
    stringBuffer.append(firstMarker + verticalLine + section43 + padSpaceTillMaxLength(12) + verticalLine);
    stringBuffer.append("\n");
    stringBuffer.append(firstMarker + verticalLine + section44 + padSpaceTillMaxLength(16) + verticalLine);
    stringBuffer.append("\n");
    stringBuffer.append(firstMarker + verticalLine + section45 + padSpaceTillMaxLength(22) + verticalLine);
    stringBuffer.append("\n");
    stringBuffer.append(firstMarker + verticalLine + section46 + padSpaceTillMaxLength(17) + verticalLine);
    stringBuffer.append("\n");
    stringBuffer.append(firstMarker + verticalLine + section47 + padSpaceTillMaxLength(5) + verticalLine);
    stringBuffer.append("\n");
    stringBuffer.append(firstMarker + verticalLine + section48 + padSpaceTillMaxLength(2) + verticalLine);
    stringBuffer.append("\n");
    stringBuffer.append(firstMarker + verticalLine + section49 + padSpaceTillMaxLength(9) + verticalLine);
    stringBuffer.append("\n");
    stringBuffer.append(firstMarker + verticalLine + section50 + padSpaceTillMaxLength(39) + verticalLine);
    stringBuffer.append("\n");
    stringBuffer.append(firstMarker + verticalLine + section51 + padSpaceTillMaxLength(5) + verticalLine);
    stringBuffer.append("\n");
    stringBuffer.append(firstMarker + verticalLine + section52 + padSpaceTillMaxLength(15) + verticalLine);
    stringBuffer.append("\n");
    stringBuffer.append(firstMarker + verticalLine + section53 + padSpaceTillMaxLength(32) + verticalLine);
    stringBuffer.append("\n");
    stringBuffer.append(firstMarker + verticalLine + section54 + padSpaceTillMaxLength(18) + verticalLine);
    stringBuffer.append("\n");
    stringBuffer.append(firstMarker + verticalLine + section55+ padSpaceTillMaxLength(10) + verticalLine);
    stringBuffer.append("\n");
    stringBuffer.append(firstMarker + verticalLine + section56 + padSpaceTillMaxLength(45) + verticalLine);
    stringBuffer.append("\n");
    stringBuffer.append(firstMarker + verticalLine + section57 + padSpaceTillMaxLength(18) + verticalLine);
    stringBuffer.append("\n");
    stringBuffer.append(firstMarker + verticalLine + section58 + padSpaceTillMaxLength(16) + verticalLine);
    stringBuffer.append("\n");
    stringBuffer.append(firstMarker + verticalLine + section59 + padSpaceTillMaxLength(25) + verticalLine);
    stringBuffer.append("\n");
    stringBuffer.append(firstMarker + verticalLine + section60 + padSpaceTillMaxLength(2) + verticalLine);
    stringBuffer.append("\n");
    stringBuffer.append(firstMarker + verticalLine + section61 + padSpaceTillMaxLength(46) + verticalLine);  
    stringBuffer.append("\n");  
    stringBuffer.append(firstMarker+bottomlLineWithEndBorders);
    stringBuffer.append("\n");
    //Modified for SS_QC#8579:End
   
    return stringBuffer;
  }

  /**
   * Classname / Method Name : LataTemplateForMedicalModified/padSpaceTillMaxLength()
   * @param maxLength
   * @return : String
   * Description : Method is used to add spaces wherever necessary.
   */
  private String padSpaceTillMaxLength(int maxLength) {
    StringBuffer sb = new StringBuffer();
    for(int i=0;i<=maxLength;i++){
      sb.append(" ");
    }
    return sb.toString();
  }

  /**
   * Classname / Method Name : LataTemplateForMedicalModified/padSpaceTillMaxLengthForDynamicData()
   * @param str
   * @param maxLength
   * @return : String
   * Description : Method is used to add adjustable spaces for dynamic data.
   */
  private String padSpaceTillMaxLengthForDynamicData(String str, int maxLength) {
    StringBuffer sb = new StringBuffer(str);
    for(int i=str.length();i<=maxLength;i++){
      sb.append(" ");
    }
    return sb.toString();
  }

  /**
   * Classname / Method Name : LataTemplateForMedicalModified/padSpaceTillMaxLengthAlignCenter()
   * @param str
   * @param maxLength
   * @return : String
   * Description : Method is used to center align the content.
   */
  private String padSpaceTillMaxLengthAlignCenter(String str, int maxLength){
    int initLength = str.length();
    StringBuffer sb = new StringBuffer();
    if(initLength<maxLength)
    {
      for(int i=0;i<(maxLength-initLength)/2;i++)
      {
        sb.append(" ");
      }
      sb.append(str);
      final int len = sb.length();
      for(int i=len;i<=maxLength;i++)
      {
        sb.append(" ");
      }
    }   
    return sb.toString();
  }


  public static void main(String[] args) {
    LataTemplateForMedicalModified lataTemplateForMedical = new LataTemplateForMedicalModified();
  }

}
