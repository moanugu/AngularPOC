package com.uprr.lic.licensing.rest.service;

import java.util.List;

import com.uprr.lic.dataaccess.Licensing.model.PrintTemporaryLicenseGrid;
import com.uprr.lic.exception.EqmDaoException;
import com.uprr.lic.licensing.rest.model.LicensingRequest;
import com.uprr.lic.licensing.rest.model.PendingActionDetail;
import com.uprr.lic.licensing.rest.model.PendingActionRequest;

/**
 * 
 * @author xsat956
 *
 */
public interface IPendingActionService {
	//This code is oriented to licensing and started by xsat956(Girish)
	List<PendingActionDetail> getPendingActionDataList(PendingActionRequest pendingActionRequest);
	
	void removeWorkItemEntry(List<LicensingRequest> licensingRequestList) throws EqmDaoException;
	
	  //End By Girish
	
	//Started By Abhishek
	
	 /**
	   * To remove Photo Identification work item
	   *
	   * @param emplId
	   * @param loggedInUser
	   * @param packResn
	   * @param workItemFlagList
	   * @param comments
	   * @author xsat976
	   * @since Feb 27, 2017
	   * Added for SS_QC#8231
	   */
	public void removeRecordForPhotoID(final String emplId, final String crtnEmplId, final List<Integer> packResn,
	    final List<String> workItemFlagList, final String comments);
	

	public boolean printLataForTempLicense(List<PrintTemporaryLicenseGrid> pendingActionDetail, String printId);
	
	//Ended by Abhishek
	
	
}
