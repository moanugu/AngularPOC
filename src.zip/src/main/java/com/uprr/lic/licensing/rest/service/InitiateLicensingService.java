package com.uprr.lic.licensing.rest.service;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uprr.lic.auth.EQMSUserSession;
import com.uprr.lic.dataaccess.Licensing.model.EmployeeDetailLicInit;
import com.uprr.lic.dataaccess.Licensing.model.InitiateLicensingRequestBean;
import com.uprr.lic.dataaccess.common.model.EqmEmplDtls;
import com.uprr.lic.dataaccess.common.model.EqmTestDtls;
import com.uprr.lic.dataaccess.common.model.PersonBean;
import com.uprr.lic.dataaccess.components.licensing.service.ILicensingService;
import com.uprr.lic.exception.EqmException;
import com.uprr.lic.util.DDChoice;
import com.uprr.lic.util.LicensingConstant;
import com.uprr.lic.util.SysParamBean;

/**
 * 
 * @author xsat004
 *
 */
@Service("initiateLicensingService")
public class InitiateLicensingService implements IInitiateLicensingService {

	private static final String CLASSNAME = InitiateLicensingService.class.getCanonicalName();
	private static final Logger logger = LoggerFactory.getLogger(InitiateLicensingService.class);
	@Autowired
	private ILicensingService licensingService;
	
	@Autowired
	private EQMSUserSession eqmsUserSession; 
	
	@Override
	public PersonBean getEmployeeDetails(final String emplId){
		return licensingService.getEmployeeDetails(emplId);
	}
	@Override
	public boolean insertNewEmployee(PersonBean personBean) {
		return licensingService.insertNewEmployee(personBean,eqmsUserSession.getUser().getEmplId());
	}
	@Override
	public List<DDChoice> getAllLicenseTypeList(String licenseType) {
		return licensingService.getAllLicenseTypeList(licenseType);
	}
	@Override
	public InitiateLicensingRequestBean initializeLicensingRequest(InitiateLicensingRequestBean licenseRequest,
			List<EmployeeDetailLicInit> finalList) {
		return licensingService.initializeLicensingRequest(licenseRequest,finalList);	
	}
	@Override
	public Map<String, Map<String, EmployeeDetailLicInit>> createInitiateLicenseRequest(
			InitiateLicensingRequestBean licenseRequest) {
		return licensingService.createInitiateLicenseRequest(licenseRequest,eqmsUserSession.getUser().getEmplId());
	}
	
	@Override
	public boolean isEmployeeLicensed(String employeeID,final Boolean flagHist){
		return licensingService.isEmployeeLicensed(employeeID,flagHist);
	}
	@Override
	public EqmTestDtls checkForValidTestDetailsAvailability(String employeeId, Integer selection) {
		return licensingService.checkForValidTestDetailsAvailability(employeeId,selection);		
	}
	@Override
	public EmployeeDetailLicInit getEmployeeDetailsForInitiateLicenseRequest(
			InitiateLicensingRequestBean licenseRequest) throws EqmException, ParseException {
		return licensingService.getEmployeeDetailsForInitiateLicenseRequest(licenseRequest);		
	}
	@Override
	public EqmEmplDtls getEmplDtls(String employeeId) {
		return licensingService.getEmplDtls(employeeId);
	}
	@Override
	public Map<String, Map<String, EmployeeDetailLicInit>> initializeAndCreateLicensingRequest(InitiateLicensingRequestBean licenseRequest,
			List<EmployeeDetailLicInit> finalList) {
		InitiateLicensingRequestBean  initiateLicensingRequestBean =licensingService.initializeLicensingRequest(licenseRequest,finalList);	
		return licensingService.createInitiateLicenseRequest(initiateLicensingRequestBean,eqmsUserSession.getUser().getEmplId());
	}
	
	/**
	   * Classname / Method Name : InitiateLicensingRequestPage/getEmployeeTestDetails()
	   * @param employeebean
	   * @return : EmployeeDetailLicInit
	   * Description : Method is used to get Test Details of an employee required while initiating license request.
	   * The Test Details are obtained from EQM_TEST_DTLS.
	   */
	  public List<EmployeeDetailLicInit> getEmployeeTestDetails(List<EmployeeDetailLicInit> employeebeans) {
	    //-- check whether valid Medical is present in Test details table
	    Map<String, SysParamBean> sysparm=licensingService.getSysParmMap();
	    List<EmployeeDetailLicInit> finalList = new ArrayList<EmployeeDetailLicInit>();
	    for(EmployeeDetailLicInit employeebean : employeebeans){
	    
	    employeebean.setEqmTestDtlsByMedId(checkForValidTestDetailsAvailability(employeebean
	        .getEmployeeID(), Integer.valueOf(LicensingConstant.QLFN_CODE_MED)));

	    //-- check whether valid Rules is present in Test details table for Agreement and Non-Agreement Employee(QC 1293)
	    String emplId=employeebean.getEmployeeID();
	    EqmEmplDtls eqmEmplDtlsObj=getEmplDtls(emplId);
	    
	    EqmTestDtls eqmTestRuleDtls=null;
	    //code for REQ 97
	    //check if this is employees first license ever or he is already licensed with any parent class
	    Boolean isEmpFirstLic=isEmployeeLicensed(employeebean.getEmployeeID(), Boolean.FALSE);
	    
	    //end
//	    if(null!=eqmEmplDtlsObj){
//	      agreementInd = eqmEmplDtlsObj.getAgrmNaInd();
	      eqmTestRuleDtls = setRulesDetails(employeebean, sysparm);
	      employeebean.setEqmTestDtlsByRulesId(eqmTestRuleDtls);
//	    }
	//end vor REQ 97
	    //-- check whether valid Exam is present in Test details table
	    employeebean.setEqmTestDtlsByExamId(checkForValidTestDetailsAvailability(employeebean
	        .getEmployeeID(), Integer.valueOf(LicensingConstant.QLFN_CODE_OR6A)));

	    // Added For REQ#159 & 174.
	    employeebean.setEqmTestDtlsForOPCCCode(checkForValidTestDetailsAvailability(
	        employeebean.getEmployeeID(), LicensingConstant.OPCC_RULE_CODE_ID));
	    // REQ#159 & 174 changes Ends.
	    
	    // Added For Req 495
	    employeebean.setEqmTestDtlsbyConEPCOPins(checkForValidTestDetailsAvailability(
	        employeebean.getEmployeeID(), LicensingConstant.EPCO_CODE_ID));
	    // Req 495 changes Ends.
	    
	    // Added for REQ# 194.
	    employeebean.setEqmTestDtlsForOPTERCode(checkForValidTestDetailsAvailability(employeebean
	        .getEmployeeID(), Integer.valueOf(LicensingConstant.RULE_CODE_OPTER_EXAM)));
	    
	    employeebean.setEqmTestDtlsForRXTECode(checkForValidTestDetailsAvailability(employeebean
	        .getEmployeeID(), Integer.valueOf(LicensingConstant.RULE_CODE_RXTE_EXAM)));
	    // End.
	    //start:Added for Req#400
	    EqmTestDtls eqmTstDtlsFTXEvent = checkForValidTestDetailsAvailability(employeebean
	        .getEmployeeID(), Integer.valueOf(LicensingConstant.QLFN_CODE_FTX_EVNT_CON));
	    
	    EqmTestDtls eqmTstDtlsOPPCAT = checkForValidTestDetailsAvailability(employeebean
	        .getEmployeeID(), Integer.valueOf(LicensingConstant.QLFN_CODE_ATE_CON));
	    
	    
	    if(null == eqmTstDtlsFTXEvent && null == eqmTstDtlsOPPCAT){ // both are null
	      employeebean.setEqmTestDtlsByFTXEvntId(null);
	    }else if(null != eqmTstDtlsFTXEvent && null == eqmTstDtlsOPPCAT){ //OPPCAT is null
	      employeebean.setEqmTestDtlsByFTXEvntId(eqmTstDtlsFTXEvent);
	    }else if(null == eqmTstDtlsFTXEvent && null != eqmTstDtlsOPPCAT){ //FTX event is null
	      employeebean.setEqmTestDtlsByFTXEvntId(eqmTstDtlsOPPCAT);
	    }else if(null != eqmTstDtlsFTXEvent && null != eqmTstDtlsOPPCAT){ //both are not null
	      if(eqmTstDtlsFTXEvent.getExamDate().after(eqmTstDtlsOPPCAT.getExamDate())){
	        employeebean.setEqmTestDtlsByFTXEvntId(eqmTstDtlsFTXEvent);
	      }else if (eqmTstDtlsOPPCAT.getExamDate().after(eqmTstDtlsFTXEvent.getExamDate()) && 
	          eqmTstDtlsOPPCAT.getRsltFlag().equalsIgnoreCase(LicensingConstant.RESULT_PASS)){ //OPPCAT is latest
	        employeebean.setEqmTestDtlsByFTXEvntId(eqmTstDtlsOPPCAT);
	      } else if (eqmTstDtlsOPPCAT.getExamDate().after(eqmTstDtlsFTXEvent.getExamDate()) && 
	          eqmTstDtlsOPPCAT.getRsltFlag().equalsIgnoreCase(LicensingConstant.RESULT_FAIL)){ //OPPCAT is fail
	        employeebean.setEqmTestDtlsByFTXEvntId(eqmTstDtlsFTXEvent);
	      } else{
	        employeebean.setEqmTestDtlsByFTXEvntId(eqmTstDtlsFTXEvent);
	      }
	    }
	    finalList.add(employeebean);
	    }
	    //end:Added for Req#400
	    return finalList;
	  }
	  
	  
	  private EqmTestDtls setRulesDetails(EmployeeDetailLicInit employeebean,  Map<String, SysParamBean> sysparm) {
		    EqmTestDtls eqmTestRuleDtls=null;
		    
		    eqmTestRuleDtls = setRulesDtlsAccoToLicense(employeebean.getEmployeeID(), sysparm.get("ENG_RUL_AGR_INI").getParmValu());
		    
		  
		    return eqmTestRuleDtls;
	 }
	  
	  /**
	   * Classname / Method Name : InitiateLicensingRequestPage/setRulesDtlsAccoToLicense()
	   * @param sysparm
	   * @param employeebean
	   * @return
	   * Description :  This method is used to Set the Rules details according to the license that is being Initiated .REQ 97 Implementation.
	   */
	  //code for REQ 97
	  private EqmTestDtls setRulesDtlsAccoToLicense(String emplId,String licQualCode) 
	  {
	    EqmTestDtls eqmTestRuleDtls=null;
	    StringTokenizer qualCodeTkn= new StringTokenizer(licQualCode,",");
	    final String qualCode = (qualCodeTkn.hasMoreElements()) ? (String) qualCodeTkn.nextElement()
	        : LicensingConstant.BLANK_STRING;
	    final String qualCode2 = (qualCodeTkn.hasMoreElements()) ? (String) qualCodeTkn.nextElement()
	        : LicensingConstant.BLANK_STRING;
	    if(qualCode!=LicensingConstant.BLANK_STRING){
	      eqmTestRuleDtls=checkForValidTestDetailsAvailability(emplId,Integer.parseInt(qualCode));
	      if(eqmTestRuleDtls==null && qualCode2!=LicensingConstant.BLANK_STRING)
	      {
	          eqmTestRuleDtls=checkForValidTestDetailsAvailability(emplId,Integer.parseInt(qualCode2));
	      }
	    }
	    return eqmTestRuleDtls;
	  }

}

