package com.uprr.lic.licensing.rest.model;

import java.util.List;

public class PhotoIDRequestBean {
	
	 private String emplId;
	 public String getEmplId() {
		return emplId;
	}
	public void setEmplId(String emplId) {
		this.emplId = emplId;
	}
	public List<Integer> getPackResn() {
		return packResn;
	}
	public void setPackResn(List<Integer> packResn) {
		this.packResn = packResn;
	}
	public List<String> getWorkItemFlagList() {
		return workItemFlagList;
	}
	public void setWorkItemFlagList(List<String> workItemFlagList) {
		this.workItemFlagList = workItemFlagList;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	private List<Integer> packResn;
	 private List<String> workItemFlagList;
	 private  String comments;
    

}
