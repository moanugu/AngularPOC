package com.uprr.lic.licensing.rest.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uprr.lic.auth.EQMSUserSession;
import com.uprr.lic.dataaccess.Licensing.model.LcnsDtlsObj;
import com.uprr.lic.dataaccess.components.licensing.service.ILicensingService;

/**
 * 
 * @author xsat956
 *
 */
@Service("CMTSNotificationRestService")
public class CMTSNotificationRestService implements ICMTSNotificationRestService {

	@Autowired
	private ILicensingService licensingService;
	
	@Autowired
	private EQMSUserSession eqmsUserSession;


	@Override
	public boolean sendNtfnToCMTS(String emplId, List<String> lstlcnsClass, List<LcnsDtlsObj> lsLcnsDtlsObj) {
		return licensingService.sendNtfnToCMTS(emplId, lstlcnsClass, lsLcnsDtlsObj, eqmsUserSession.getUser().getEmplId())
				;
	}

	@Override
	public List<LcnsDtlsObj> getLicenseDetailsForEmpl(String employeeId) {
		return licensingService.getLcnsDtlsForEmpl(employeeId);
	}

	

}
