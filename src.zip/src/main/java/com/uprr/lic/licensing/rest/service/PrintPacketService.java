package com.uprr.lic.licensing.rest.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uprr.lic.auth.EQMSUserSession;
import com.uprr.lic.dataaccess.Licensing.model.CoverLetterForPrintDocsTemplate;
import com.uprr.lic.dataaccess.Licensing.model.NdrTemplatePageDetail;
import com.uprr.lic.dataaccess.common.model.EqmLcnsRqmt;
import com.uprr.lic.dataaccess.components.licensing.service.ILicensingService;
import com.uprr.lic.exception.EqmDaoException;
import com.uprr.lic.externalservice.xmf.service.PrintXmfILataService;
import com.uprr.lic.licensing.rest.model.NdrTemplateDetail;
import com.uprr.lic.util.LicensingConstant;

import templates.LataTemplateForCoverLetterOfPrintDocsModified;
import templates.LataTemplateForMVRReleaseInsForm;
import templates.LataTemplateForMedicalModified;
import templates.LataTemplateForNDRModified;

/**
 * 
 * @author xsat956
 *
 */
@Service("printPacketService")
public class PrintPacketService implements IPrintPacketService {

	private final Logger logger = LoggerFactory.getLogger(PrintPacketService.class);

	private String m_className = PrintPacketService.class.getSimpleName();
	
	private final String LATA_PRINTING_SERVICE_PROBLEM = "Due to problem in ILata Service following packets cannot be printed: ";
	private  final String LATA_PRINTING_SUCCESSFUL = "ILata printing is successful for the packets: ";

	@Autowired
	private ILicensingService licensingService;

	
	
	@Autowired
	private PrintXmfILataService printXmfLataService;


	@Autowired
	private EQMSUserSession eqmsUserSession;

	private Boolean iLataSentSuccessfullyFlag = null;
	private String lataPacketsNotSentDueToOffshoreServiceInfunctionality = "";
	private String lataPacketsSentSuccessfully = "";
	private String lataPacketsNotSentDueToProblemInService = "";
	private boolean lataSuccessForEmployeeLetter = false;
	private boolean lataSuccessForMedical = false;
	private boolean lataSuccessForNdr = false;
	private boolean lataSuccessForDirectionToWashington = false;
	private boolean lataSuccessForWashingtonStateNdr = false;

	

	@Override
	public boolean isStudentLicense(String emplId) {
		return licensingService.isStudentLicense(emplId);
	}

	@Override
	public CoverLetterForPrintDocsTemplate getAddressInfoForEmplCoverLetterFromTeradata(String employeeId,
			String sysParamName) {
		String mgrName = licensingService.getSysParmValue(sysParamName).getParmValu();
		return licensingService.getAddressInfoForEmplCoverLetterFromTeradata(employeeId, mgrName);
	}

	@Override
	public NdrTemplateDetail getEmployeeDetailsForNDRTemplate(String employeeID) {
		return createEmployeeDetailsForNDRTemplate(licensingService.getEmployeeDetailsForNDRTemplate(employeeID));
	}

	private NdrTemplateDetail createEmployeeDetailsForNDRTemplate(NdrTemplatePageDetail objNdrTemplatePageDetail) {
		if(objNdrTemplatePageDetail == null) {
			return null;
		}
		
		
		NdrTemplateDetail objResponse = new NdrTemplateDetail();
		objResponse.setEmployeeName( objNdrTemplatePageDetail.getEmployeeName(  )  ) ; 
		objResponse.setEmployeeID( objNdrTemplatePageDetail.getEmployeeID(  )  ) ; 
		objResponse.setNickName( objNdrTemplatePageDetail.getNickName(  )  ) ; 
		objResponse.setDateOfBirth( objNdrTemplatePageDetail.getDateOfBirth(  )  ) ; 
		objResponse.setWeight( objNdrTemplatePageDetail.getWeight(  )  ) ; 
		objResponse.setLicenseNumber( objNdrTemplatePageDetail.getLicenseNumber(  )  ) ; 
		objResponse.setState( objNdrTemplatePageDetail.getState(  )  ) ; 
		objResponse.setSsn( objNdrTemplatePageDetail.getSsn(  )  ) ; 
		objResponse.setHeightFt( objNdrTemplatePageDetail.getHeightFt(  )  ) ; 
		objResponse.setHeightInches( objNdrTemplatePageDetail.getHeightInches(  )  ) ; 
		objResponse.setAddress( objNdrTemplatePageDetail.getAddress(  )  ) ; 
		objResponse.setAddressCity( objNdrTemplatePageDetail.getAddressCity(  )  ) ; 
		objResponse.setAddressState( objNdrTemplatePageDetail.getAddressState(  )  ) ; 
		objResponse.setAddressZip( objNdrTemplatePageDetail.getAddressZip(  )  ) ; 
		return objResponse;
	}

	@Override
	public List<EqmLcnsRqmt> getRecertificationInitiatedDetailsForEmployee(String employeeId, String licenseClassCode) {
		return licensingService.getRecertificationInitiatedDetailsForEmployee(employeeId, licenseClassCode);
	}
	
	/**
	 * Print packet for Cover letter, Medical, NDR, MVR Release Instruction From
	 * Modified Method for  SS_QC#10235
	 */
	public Map<String, String> printLataPacket(String iLataNumber,String userId) throws EqmDaoException { // Added  Parameter For SS_QC#10235

		Map<String, String> messageMap = new HashMap<>();
		//-- string to store data of all the Templates to be sent through Lata service
		/*String finalMessage;
			String packetMessage = null;
			String washingtonMessage = null;
			Boolean iLataSentSuccessfullyFlag = null;*/
		iLataSentSuccessfullyFlag = null;
		lataPacketsNotSentDueToOffshoreServiceInfunctionality = "";
		lataPacketsSentSuccessfully = "";
		lataPacketsNotSentDueToProblemInService = "";
		//-- Employee Letter(Cover Letter for Print Docs)
		CoverLetterForPrintDocsTemplate employeeLetterTemplateDetails = getAddressInfoForEmplCoverLetterFromTeradata(userId,LicensingConstant.LICENSING_DEPT_MANAGER_NAME);//modified for vtl changes
		// initializing Employee Letter template in LATA format


		//-- NDR Template
		NdrTemplatePageDetail ndrTemplateDetails = licensingService.getEmployeeDetailsForNDRTemplate(userId);

		//initializing NDR template in LATA format
		LataTemplateForNDRModified ndrTemplate = getLataTemplateForNDRInitiation();
		LataTemplateForMVRReleaseInsForm mvrReleaseInsFormTemplate = getLataTemplateForMvrRelInsFormInitiation();
		LataTemplateForCoverLetterOfPrintDocsModified employeeLetterTemplate = 
				getLataTemplateForCoverLetterOfPrintDocsInitiation();

		//-- Medical Template(LHI Instruction Form)
		//initializing Medical Template in LATA format
		LataTemplateForMedicalModified medicalTemplate = getLataTemplateForMedicalInitiation();


		//-- 1. Lata call for Employee Letter(Cover Letter for print docs) 
		iLataSentSuccessfullyFlag = null;
		iLataSentSuccessfullyFlag = printXmfLataService.getIlataPrint(userId, 
				iLataNumber, employeeLetterTemplate
				.getBufferForLataPrintForCoverLetterOfPrintDocs(employeeLetterTemplateDetails, licensingService)
				.toString());
		if(iLataSentSuccessfullyFlag != null && iLataSentSuccessfullyFlag){
			lataSuccessForEmployeeLetter = true;
		}
		decidingFeedbackPanelMessage(iLataSentSuccessfullyFlag, "Employee Cover Letter");

		//-- 2. Lata call for Medical Form (LHI Instruction Form)
		iLataSentSuccessfullyFlag = null;
		iLataSentSuccessfullyFlag = printXmfLataService.getIlataPrint( userId, 
				iLataNumber, medicalTemplate
				.getBufferForLataPrintForMedical().toString());
		if(iLataSentSuccessfullyFlag != null && iLataSentSuccessfullyFlag){
			lataSuccessForMedical = true;
		}
		decidingFeedbackPanelMessage(iLataSentSuccessfullyFlag, "Medical Form");

		//-- 3. Lata call for NDR Form
		iLataSentSuccessfullyFlag = null;
		iLataSentSuccessfullyFlag =printXmfLataService.getIlataPrint(userId, 
				iLataNumber, ndrTemplate.getBufferForLataPrintForNDR(ndrTemplateDetails).toString());
		if(iLataSentSuccessfullyFlag != null && iLataSentSuccessfullyFlag){
			lataSuccessForNdr = true;
		}
		decidingFeedbackPanelMessage(iLataSentSuccessfullyFlag, "NDR Form");

		//Changes For SS_QC#5427:Start	
		//-- 4. Lata call for MVR Release Instruction Form 
		iLataSentSuccessfullyFlag = null;
		iLataSentSuccessfullyFlag = printXmfLataService.getIlataPrint(userId, 
				iLataNumber, mvrReleaseInsFormTemplate.getBufferForLataPrintForMVRRelInsForm().toString());
		/*if(null != iLataSentSuccessfullyFlag   && iLataSentSuccessfullyFlag){
			lataSuccessForMVRRelInsFrom = true;
		}*/
		decidingFeedbackPanelMessage(iLataSentSuccessfullyFlag, "MVR Release Instruction Form");

		decideWeatherToMakeEntryInPacketDetailsForPrintpacket();

		if(!lataPacketsNotSentDueToOffshoreServiceInfunctionality.equalsIgnoreCase("")){
			messageMap.put("Failure", LATA_PRINTING_SERVICE_PROBLEM 
					+ lataPacketsNotSentDueToOffshoreServiceInfunctionality + ".");
			//-- at offshore service will return null
			/*m_feedbackPanel.warn(FeedbackMessageConstant.LATA_PRINTING_SERVICE_PROBLEM 
						+ lataPacketsNotSentDueToOffshoreServiceInfunctionality + ".");*/
			lataPacketsNotSentDueToOffshoreServiceInfunctionality = new String();
		} 
		if(!lataPacketsSentSuccessfully.equalsIgnoreCase("")){
			
			messageMap.put("Success", LATA_PRINTING_SUCCESSFUL 
					+ lataPacketsSentSuccessfully + ".");
			lataPacketsSentSuccessfully = new String();
		}
		
		if(!lataPacketsNotSentDueToProblemInService.equalsIgnoreCase("")){
			
			messageMap.put("Failure", LATA_PRINTING_SERVICE_PROBLEM 
					+ lataPacketsNotSentDueToProblemInService + ".");
			lataPacketsNotSentDueToProblemInService = new String();
		}


		/*target.addComponent(m_feedbackPanel);
		Ricola.refresh(target, m_feedbackPanel);*/
		
		return messageMap;

	}


	/**
	 * Classname / Method Name : PrintPacketForTEYPortalModified/decidingFeedbackPanelMessage()
	 * @param iLataSentSuccessfullyFlag
	 * @param packetName
	 * Description : Method is used to decide the feed messages for On Line ILata printing functionality.
	 */
	private void decidingFeedbackPanelMessage(Boolean iLataSentSuccessfullyFlag, String packetName){
		if(iLataSentSuccessfullyFlag == null) {
			//-- at offshore service will return null
			lataPacketsNotSentDueToOffshoreServiceInfunctionality = 
					lataPacketsNotSentDueToOffshoreServiceInfunctionality.equalsIgnoreCase("") ? 
							lataPacketsNotSentDueToOffshoreServiceInfunctionality + packetName :
								lataPacketsNotSentDueToOffshoreServiceInfunctionality + ", " + packetName;
		} else if(iLataSentSuccessfullyFlag) {
			//-- if service work successfully
			lataPacketsSentSuccessfully = 
					lataPacketsSentSuccessfully.equalsIgnoreCase("") ? 
							lataPacketsSentSuccessfully + packetName :
								lataPacketsSentSuccessfully + ", " + packetName;
		} else {
			//-- if there is some problem in service
			lataPacketsNotSentDueToProblemInService = 
					lataPacketsNotSentDueToProblemInService.equalsIgnoreCase("") ? 
							lataPacketsNotSentDueToProblemInService + packetName :
								lataPacketsNotSentDueToProblemInService + ", " + packetName;
		}
	}


	/**
	 * Classname / Method Name : PrintPacketForTEYPortalModified/decideWeatherToMakeEntryInPacketDetailsForPrintpacket()
	 * Description : Method is used to decide weather to make entry in Packet Details fro Print Packet once
	 * Lata Print link is been clicked.
	 */
	private void decideWeatherToMakeEntryInPacketDetailsForPrintpacket() throws EqmDaoException{
		/*if(isPrintPacket
				&& Boolean.parseBoolean(m_washingtonStateCheckbox.getValue())){*/

		//-- CHECKING WEATHER ALL LATA PACKETS(IF BOTH CHECKBOXES ARE SELECTED) SENT SUCCESSFULLY OR NOT
		if(lataSuccessForEmployeeLetter && lataSuccessForMedical && lataSuccessForNdr /*&& lataSuccessForMvr*/ 
				&& lataSuccessForDirectionToWashington && lataSuccessForWashingtonStateNdr){
			makeEntryForPacketPrinted();
		}
		/*} *//*else if(Boolean.parseBoolean(m_packetCheckbox.getValue())) {

			//-- CHECKING WEATHER LATA PACKETS FOR '1ST CHECKBOX(IF SELECTED)' SENT SUCCESSFULLY OR NOT
			if(lataSuccessForEmployeeLetter && lataSuccessForMedical && lataSuccessForNdr && lataSuccessForMvr) {
				makeEntryForPacketPrinted();
			}
		} */else if(lataSuccessForDirectionToWashington && lataSuccessForWashingtonStateNdr) {

			//-- CHECKING WEATHER LATA PACKETS FOR '2ND CHECKBOX(IF SELECTED)' SENT SUCCESSFULLY OR NOT
			makeEntryForPacketPrinted();
		}
	}

	/**
	 * To get all active recertification requests and make entry in packet details for 'Print Packet' against each one of
	 * them.
	 * 
	 * @author xsat737
	 * @since Sep 13, 2016
	 * Modified for SS_QC#5696(MVR&NDR)
	 */
	private void makeEntryForPacketPrinted() throws EqmDaoException{
		
		String comments = "All Forms Printed"; 
		try{
			licensingService.insertPacketPrintingDetailsWithValidation(
					/*printPacketForTEYPortalBean.getEmployeeId()*/eqmsUserSession.getUser().getEmplId(),  eqmsUserSession.getUser().getEmplId(), comments);//Modified for SS_QC#5696(MVR&NDR)
		} catch(Exception e) {
			logger.error(LicensingConstant.LOGGER_EQMEXCEPTION + "makeEntryForPacketPrinted() :: " + e.getMessage(), e);
			throw new EqmDaoException(e.getMessage());
		}

		lataSuccessForEmployeeLetter = false;
		lataSuccessForMedical = false;
		lataSuccessForNdr = false;
		//			lataSuccessForMvr = false;s
		lataSuccessForDirectionToWashington = false;
		lataSuccessForWashingtonStateNdr = false;
	}

	
	
	/**
	 * Classname / Method Name : PrintPacketForTEYPortalModified/getLataTemplateForCoverLetterOfPrintDocsInitiation()
	 * @return : LataTemplateForCoverLetterOfPrintDocs
	 * Description : Method is used to get 'Employee Letter' template for Lata printing.
	 */
	private LataTemplateForCoverLetterOfPrintDocsModified getLataTemplateForCoverLetterOfPrintDocsInitiation(){
		return new LataTemplateForCoverLetterOfPrintDocsModified();
	}

	/**
	 * Classname / Method Name : PrintPacketForTEYPortalModified/getLataTemplateForMedicalInitiation()
	 * @return : LataTemplateForMedical
	 * Description : Method is used to get 'Medical Template' for Lata printing.
	 */
	private LataTemplateForMedicalModified getLataTemplateForMedicalInitiation() {
		return new LataTemplateForMedicalModified();
	}

	/**
	 * Classname / Method Name : PrintPacketForTEYPortalModified/getLataTemplateForNDRInitiation()
	 * @return : LataTemplateForNDR
	 * Description : Method is used to get 'NDR Template' for Lata printing.
	 */
	private LataTemplateForNDRModified getLataTemplateForNDRInitiation() {
		return new LataTemplateForNDRModified();
	}

	/**
	 * 
	 * To Get 'MVR Release Instruction Form Template' for Lata printing.
	 *
	 * @return
	 * @author xsat872
	 * @since Oct 26, 2016
	 * Added For SS_QC#5427
	 */
  private LataTemplateForMVRReleaseInsForm getLataTemplateForMvrRelInsFormInitiation() {
    return new LataTemplateForMVRReleaseInsForm();
  }
  
  /**
   * 
   * Classname / Method Name : EqmsDelegate/getAOTRoleSet()
   * @param emplId
   * @return aotRoleSet 
   * Description :  This method is used toobtain Employee's roles in AOT.
   */
  public Set<Integer> getAOTRoleSet(){
    final Set<Integer> aotRoleSet = licensingService.getAOTRoleSet(eqmsUserSession.getUser().getEmplId());
    return aotRoleSet;
  }
}
