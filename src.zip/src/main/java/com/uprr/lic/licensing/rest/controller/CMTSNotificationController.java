package com.uprr.lic.licensing.rest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.uprr.lic.dataaccess.Licensing.model.LcnsDtlsObj;
import com.uprr.lic.licensing.rest.model.LicensingRequest;
import com.uprr.lic.licensing.rest.service.ICMTSNotificationRestService;

/**
 * This Controller is using for CMTSNotificationController
 * @author xsat956
 *
 */
@Controller
public class CMTSNotificationController {
	
	@Autowired
	private ICMTSNotificationRestService cmIcmtsNotificationRestService;
		
	@RequestMapping(value = "/licensing/getLicenseDetailsForEmpl", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public List<LcnsDtlsObj> getLicenseDetailsForEmpl(@RequestParam(value="employeeId", required=true) String employeeID) {
		return cmIcmtsNotificationRestService.getLicenseDetailsForEmpl(employeeID);
	}


	@RequestMapping(value = "/licensing/sendNtfnToCMTS", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public boolean sendNtfnToCMTS(@RequestParam(value="employeeId", required=true) String employeeID,@RequestBody LicensingRequest licensingRequest) {
		return cmIcmtsNotificationRestService.sendNtfnToCMTS(employeeID, licensingRequest.getLicenseClassList(), licensingRequest.getLicenseDetailList())
				;
	}
	
}
