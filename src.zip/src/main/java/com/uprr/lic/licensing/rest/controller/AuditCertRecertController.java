/**
 * 
 */
package com.uprr.lic.licensing.rest.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.uprr.lic.auth.EQMSUserBean;
import com.uprr.lic.auth.EQMSUserSession;
import com.uprr.lic.dataaccess.common.model.EqmAudDtls;
import com.uprr.lic.dataaccess.common.model.EqmAudRcdDtls;
import com.uprr.lic.licensing.rest.model.AuditCertRecertRequest;
import com.uprr.lic.licensing.rest.model.CategoryInformationDetailResponse;
import com.uprr.lic.licensing.rest.model.CertRideSummaryResponse;
import com.uprr.lic.licensing.rest.model.EmplLicHistoryDetails;
import com.uprr.lic.licensing.rest.model.FTXExamSummaryDetailsResponse;
import com.uprr.lic.licensing.rest.service.IAuditCertRecertRestService;
import com.uprr.lic.licensing.rest.service.ICertRideSummaryService;
import com.uprr.lic.licensing.rest.service.ILicPendingRequirementService;

/**
 * 
 * @author xsat976
 *
 */
@Controller
public class AuditCertRecertController {

	@Autowired
	private IAuditCertRecertRestService auditCertRecertRestService;

	@Autowired
	private ICertRideSummaryService certRideSummaryService;

	@Autowired
	private ILicPendingRequirementService licPendingRequirementService;

	@Autowired
	private EQMSUserSession session;

	@RequestMapping(method = RequestMethod.POST, value = "/licensingAudit/searchInitiateAudit")
	@ResponseBody
	public List<EqmAudRcdDtls> searchInitiateAuditRecords(@RequestBody AuditCertRecertRequest auditCertRecertRequest) {

		EQMSUserBean eqmsUsrBean = session.getUser();
		if (null != eqmsUsrBean && null != eqmsUsrBean.getEmplId()) {
			auditCertRecertRequest.setLoggedEmpId(eqmsUsrBean.getEmplId());
		} else {
			return null;
		}
		return auditCertRecertRestService.searchInitiateAuditRecords(auditCertRecertRequest);
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "/licensingAudit/searchAuditRecord")
	@ResponseBody
	public List<EqmAudDtls> searchAuditRecord(@RequestBody AuditCertRecertRequest auditCertRecertRequest) {
		return auditCertRecertRestService.searchAuditRecord(auditCertRecertRequest);
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "/licensingAudit/insertInitiateAudit")
	@ResponseBody
	public EqmAudDtls insertAuditRecords(@RequestBody AuditCertRecertRequest auditCertRecertRequest) {

		EQMSUserBean eqmsUsrBean = session.getUser();
		if (null != eqmsUsrBean && null != eqmsUsrBean.getEmplId()) {
			auditCertRecertRequest.setLoggedEmpId(eqmsUsrBean.getEmplId());
		} else {
			return null;
		}
		return auditCertRecertRestService.insertAuditRecords(auditCertRecertRequest);
	}
	
	@RequestMapping(value = "/licensingAudit/getAuditRecordsById/{audDtlsId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public List<EqmAudRcdDtls> getAuditRecordsById(@PathVariable("audDtlsId") Integer audDtlsId) {
		return auditCertRecertRestService.getAuditRecordsById(audDtlsId);
	}

	@SuppressWarnings({ "null" })
	@RequestMapping(value = "/licensingAudit/exportToExcelAuditRecord/{audDtlsId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public void exportToExcelAuditRecord(@PathVariable("audDtlsId") Integer audDtlsId, HttpServletRequest request,
			HttpServletResponse httpServletResponse) {

		byte[] byteOutput = auditCertRecertRestService.exportToExcelAuditRecord(audDtlsId);
		String nameOfWorkBook = "AuditRecordDetails";
		httpServletResponse.setContentType("application/Document");
		httpServletResponse.setHeader("Content-Disposition", "attachment;filename= " + nameOfWorkBook + ".xlsx");
		ServletOutputStream responseOutputStream = null;
		if (null != byteOutput) {
			try {
				responseOutputStream = httpServletResponse.getOutputStream();
				responseOutputStream.write(byteOutput);
			} catch (IOException e) {
				e.printStackTrace();
			}
		} else {
			try {
				responseOutputStream.write("Error While getting Document, Please Try after some time".getBytes());
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

	}

	@RequestMapping(method = RequestMethod.POST, value = "/licensingAudit/markAuditStatus")
	@ResponseBody
	public boolean markAuditStatus(@RequestBody AuditCertRecertRequest auditCertRecertRequest) {

		EQMSUserBean eqmsUsrBean = session.getUser();
		if (null != eqmsUsrBean && null != eqmsUsrBean.getEmplId()) {
			auditCertRecertRequest.setLoggedEmpId(eqmsUsrBean.getEmplId());
		} else {
			return false;
		}
		return auditCertRecertRestService.markAuditStatus(auditCertRecertRequest);
	}

	@RequestMapping(value = "/licensingAudit/getAuditRideSummaryDetail/{employeeId}/{sequenceNumber}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public CertRideSummaryResponse getAuditRideSummaryDetail(@PathVariable("employeeId") String employeeId,
			@PathVariable("sequenceNumber") Integer sequenceNumber) {
		return certRideSummaryService.getAuditRideSummaryDetail(employeeId, sequenceNumber);
	}

	@RequestMapping(value = "/licensingAudit/getAuditRideCheckList/{employeeId}/{sequenceNumber}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public List<CategoryInformationDetailResponse> getAuditRideCheckList(@PathVariable("employeeId") String employeeId,
			@PathVariable("sequenceNumber") Integer sequenceNumber) {
		return certRideSummaryService.getAuditRideCheckList(employeeId, sequenceNumber);
	}

	@RequestMapping(value = "/licensingAudit/getAuditEvaluationDetails/{employeeId}/{sequenceNumber}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public FTXExamSummaryDetailsResponse getAuditEvaluationDetails(@PathVariable("employeeId") String employeeId,
			@PathVariable("sequenceNumber") Integer sequenceNumber) {
		return licPendingRequirementService.getAuditEvaluationDetails(employeeId, sequenceNumber);
	}

	@RequestMapping(value = "/licensingAudit/getEmployeeLicenseHistory/{employeeId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public EmplLicHistoryDetails getEmployeeLicenseHistory(@PathVariable("employeeId") String employeeId) {
		return licPendingRequirementService.getEmployeeLicHistoryDetails(employeeId);
	}

}
