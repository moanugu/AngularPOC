package com.uprr.lic.licensing.rest.model;

import java.util.Date;

import com.uprr.lic.dataaccess.Licensing.model.License;

public class EmpPacketStatusResponse {

	protected Date packetDate;

	protected String reply;

	protected String resultPassOrFail;

	protected String result;

	protected String status;

	protected String resultEmpAuth;

	protected String actionTakenBy;

	protected String employeeID;

	protected String employeeName;

	protected String serviceUnit;

	protected License license;

	protected String resultDate;

	protected Integer svcUnitNbr;  

	protected String recordType;

	protected Integer resnId;

	private String packStatCmnt;

	private String callBackCmnt;

	private String documentTypeRadioGrp;

	private String histRcdFlag; 

	private String viewMVR;

	private String entrMVRAuth; 

	private Date rcvdDate;
	
	private String employeeAction;

	public Date getPacketDate() {
		return packetDate;
	}

	public void setPacketDate(Date packetDate) {
		this.packetDate = packetDate;
	}

	public String getReply() {
		return reply;
	}

	public void setReply(String reply) {
		this.reply = reply;
	}

	public String getResultPassOrFail() {
		return resultPassOrFail;
	}

	public void setResultPassOrFail(String resultPassOrFail) {
		this.resultPassOrFail = resultPassOrFail;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getResultEmpAuth() {
		return resultEmpAuth;
	}

	public void setResultEmpAuth(String resultEmpAuth) {
		this.resultEmpAuth = resultEmpAuth;
	}

	public String getActionTakenBy() {
		return actionTakenBy;
	}

	public void setActionTakenBy(String actionTakenBy) {
		this.actionTakenBy = actionTakenBy;
	}

	public String getEmployeeID() {
		return employeeID;
	}

	public void setEmployeeID(String employeeID) {
		this.employeeID = employeeID;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public String getServiceUnit() {
		return serviceUnit;
	}

	public void setServiceUnit(String serviceUnit) {
		this.serviceUnit = serviceUnit;
	}

	public License getLicense() {
		return license;
	}

	public void setLicense(License license) {
		this.license = license;
	}

	public String getResultDate() {
		return resultDate;
	}

	public void setResultDate(String resultDate) {
		this.resultDate = resultDate;
	}

	public Integer getSvcUnitNbr() {
		return svcUnitNbr;
	}

	public void setSvcUnitNbr(Integer svcUnitNbr) {
		this.svcUnitNbr = svcUnitNbr;
	}

	public String getRecordType() {
		return recordType;
	}

	public void setRecordType(String recordType) {
		this.recordType = recordType;
	}

	public Integer getResnId() {
		return resnId;
	}

	public void setResnId(Integer resnId) {
		this.resnId = resnId;
	}

	public String getPackStatCmnt() {
		return packStatCmnt;
	}

	public void setPackStatCmnt(String packStatCmnt) {
		this.packStatCmnt = packStatCmnt;
	}

	public String getCallBackCmnt() {
		return callBackCmnt;
	}

	public void setCallBackCmnt(String callBackCmnt) {
		this.callBackCmnt = callBackCmnt;
	}

	public String getDocumentTypeRadioGrp() {
		return documentTypeRadioGrp;
	}

	public void setDocumentTypeRadioGrp(String documentTypeRadioGrp) {
		this.documentTypeRadioGrp = documentTypeRadioGrp;
	}

	public String getHistRcdFlag() {
		return histRcdFlag;
	}

	public void setHistRcdFlag(String histRcdFlag) {
		this.histRcdFlag = histRcdFlag;
	}

	public String getViewMVR() {
		return viewMVR;
	}

	public void setViewMVR(String viewMVR) {
		this.viewMVR = viewMVR;
	}

	public String getEntrMVRAuth() {
		return entrMVRAuth;
	}

	public void setEntrMVRAuth(String entrMVRAuth) {
		this.entrMVRAuth = entrMVRAuth;
	}

	public Date getRcvdDate() {
		return rcvdDate;
	}

	public void setRcvdDate(Date rcvdDate) {
		this.rcvdDate = rcvdDate;
	}

	public String getEmployeeAction() {
		return employeeAction;
	}
	
	public void setEmployeeAction(String employeeAction) {
		this.employeeAction = employeeAction;
	}
	
	 //Added for SS_QC#6703:start
	  private String riskScore;
	    
	  public String getRiskScore() {
		return riskScore;
	}

	public void setRiskScore(String riskScore) {
		this.riskScore = riskScore;
	}
	//Added for SS_QC#6703:end
}
