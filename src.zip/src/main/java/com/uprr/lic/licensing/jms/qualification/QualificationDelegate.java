package com.uprr.lic.licensing.jms.qualification;

import java.text.ParseException;
import java.util.Arrays;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.uprr.lic.dataaccess.Licensing.model.HumanFactorCodesBean;
import com.uprr.lic.dataaccess.Licensing.model.PeopleSoftDisciplineBean;
import com.uprr.lic.dataaccess.Licensing.model.PeopleSoftMiscellaneousBean;
import com.uprr.lic.dataaccess.Licensing.model.PeopleSoftQualificationBean;
import com.uprr.lic.dataaccess.common.model.EqmEmplDtls;
import com.uprr.lic.dataaccess.common.model.PsftMapsMsgBean;
import com.uprr.lic.dataaccess.components.licensing.hibernate.dao.DisciplineDao;
import com.uprr.lic.dataaccess.components.licensing.hibernate.dao.NotificationDAO;
import com.uprr.lic.dataaccess.decertification.dao.DecertificationDao;
import com.uprr.lic.dataaccess.transactions.EqmsTransactions;
import com.uprr.lic.exception.EqmDaoException;
import com.uprr.lic.externalservice.xmf.service.EmailNotificationService;
import com.uprr.lic.util.EqmsUtil;
import com.uprr.lic.util.ScoreConstants;

public class QualificationDelegate {

	@Autowired
	private NotificationDAO notificationDAO;

	@Autowired
	private DisciplineDao disciplineDao;

	@Autowired
	private EmailNotificationService m_serviceManager;


	private final String LOGGER_GENERIC_EXCEPTION = "Exception :: ";
	private final String LOGGER_PARSE_EXCEPTION = "ParseException :: ";
	
	private static final String appEnvironment = System.getProperty("uprr.implementation.environment").toUpperCase();


	private static final Logger m_logger = LoggerFactory.getLogger(QualificationDelegate.class);


	/**
	 * To process all Qualification related services
	 *
	 * @param peopleSoftQualificationBean
	 * @author xsat243
	 * @since Oct 14, 2014
	 * Modified for SS_QC#8447
	 */
	@EqmsTransactions
	public void processQualification(
			PeopleSoftQualificationBean peopleSoftQualificationBean) {
		m_logger
		.info("Entered :: Execution starts :: processQualification() :  method :"
				);
		//Added by xsat244
		final String[] recipientEmailAddressess = EqmsUtil.getEqmsSupportEmailIds().split(",");
		//Modified for SS_QC#8447 -- Start
		if(peopleSoftQualificationBean != null){
			final EqmEmplDtls emplDetails = disciplineDao.getEmplDtls(peopleSoftQualificationBean.getEmployeeId());
			final String empName = emplDetails.getEmplLastName() + " " + emplDetails.getEmplFirName() + " " + emplDetails.getEmplMidName() ;
			final String mailSubject =  "Rules service error for employee ["+ empName +"(" + peopleSoftQualificationBean.getEmployeeId() +")]";
			final boolean successFlag = disciplineDao.isEmployeePresentInEqms(peopleSoftQualificationBean);
			if(successFlag){
				try {
					if(peopleSoftQualificationBean.getEventAction()!= null && peopleSoftQualificationBean.getEventAction().equalsIgnoreCase(ScoreConstants.INSERT)){
						notificationDAO
						.processQualificationNotification(peopleSoftQualificationBean);
					}
				} catch (ParseException parseException) {

					String content = LOGGER_GENERIC_EXCEPTION
							+ "processQualificationNotification() ::"
							+ parseException.getMessage();
							m_serviceManager.sendEmailNotification(Arrays.asList(recipientEmailAddressess), null, 
									null, mailSubject, content, DecertificationDao.EQMS_EMAIL_DESCRIPTION);
	
					m_logger
					.error(
							" Inside processQualificationNotification method :: parseException :: Message is  : "
									+ parseException.getMessage()
									+ ScoreConstants.DOUBLE_COLON ,
									parseException);
				} catch (EqmDaoException eqmDaoException) {
					String content = LOGGER_GENERIC_EXCEPTION
							+ "processQualificationNotification() ::"
							+ eqmDaoException.getMessage();
							m_serviceManager.sendEmailNotification(Arrays.asList(recipientEmailAddressess), null, 
									null, mailSubject +"--IN SCORE", content, DecertificationDao.EQMS_EMAIL_DESCRIPTION);
					
					m_logger
					.error(
							" Inside processQualificationNotification method :: EqmDaoException :: Message is  : "
									+ eqmDaoException.getMessage()
									+ ScoreConstants.DOUBLE_COLON ,
									eqmDaoException);

				} catch (Exception exception) {
					String content = LOGGER_GENERIC_EXCEPTION
							+ "processQualificationNotification() ::"
							+ exception.getMessage();
							m_serviceManager.sendEmailNotification(Arrays.asList(recipientEmailAddressess), null, 
									null, mailSubject +"--IN SCORE", content, DecertificationDao.EQMS_EMAIL_DESCRIPTION);
					
					m_logger
					.error(
							" Inside processQualificationNotification method :: Exception :: Message is  : "
									+ exception.getMessage()
									+ ScoreConstants.DOUBLE_COLON ,
									exception);


				}
				try {
					disciplineDao
					.processQualificationForPendingRulesDetail(peopleSoftQualificationBean);
				} 
				catch (RuntimeException runExcep) {

					if(runExcep.getMessage().contains("ConstraintViolationException") || 
							runExcep.getMessage().contains("StaleObjectStateException")){
						try {
							disciplineDao
							.processQualificationForPendingRulesDetail(peopleSoftQualificationBean);
						} catch (ParseException parseException) {
							m_logger.error(LOGGER_PARSE_EXCEPTION
									+ "processQualificationForPendingRulesDetail() ::"
									+ parseException.getMessage(), parseException);


							String content = LOGGER_GENERIC_EXCEPTION
							+ "processQualificationForPendingRulesDetail() :: Second Time  ::"
							+ parseException.getMessage();
							m_serviceManager.sendEmailNotification(Arrays.asList(recipientEmailAddressess), null, null, mailSubject +"--IN Licensing", content, DecertificationDao.EQMS_EMAIL_DESCRIPTION);
						} catch (Exception exception) {
							
							String content = LOGGER_GENERIC_EXCEPTION
									+ "processQualificationForPendingRulesDetail() :: Second Time  ::"
									+ exception.getMessage();
									m_serviceManager.sendEmailNotification(Arrays.asList(recipientEmailAddressess), null, 
											null, mailSubject +"--IN Licensing", content, DecertificationDao.EQMS_EMAIL_DESCRIPTION);
					
							m_logger.error(LOGGER_GENERIC_EXCEPTION
									+ "processQualificationForPendingRulesDetail() :: Second Time :: "
									+exception.getMessage(),exception);

						}
					}
				}catch (ParseException e) {
					m_logger.error("processQualificationForPendingRulesDetail() ::"+ e.getMessage(), e);

				
					String content = LOGGER_GENERIC_EXCEPTION
							+ "processQualificationForPendingRulesDetail() ::"
							+ e.getMessage();
							m_serviceManager.sendEmailNotification(Arrays.asList(recipientEmailAddressess), null,
									null, mailSubject +"--IN Licensing", content, DecertificationDao.EQMS_EMAIL_DESCRIPTION);
				} catch (Exception e) {
					String content = LOGGER_GENERIC_EXCEPTION
							+ "processQualificationForPendingRulesDetail() ::"
							+ e.getMessage();
							m_serviceManager.sendEmailNotification(Arrays.asList(recipientEmailAddressess), null,
									null, mailSubject +"--IN Licensing", content, DecertificationDao.EQMS_EMAIL_DESCRIPTION);
				
					m_logger.error(LOGGER_GENERIC_EXCEPTION
							+ "processQualificationForPendingRulesDetail() ::"
							+ e.getMessage(), e);
				}
			}else{
				String content = LOGGER_GENERIC_EXCEPTION
				          + "processQualification() :: Employee " +peopleSoftQualificationBean.getEmployeeId()+" not present in EQMS System, so processing of "+ peopleSoftQualificationBean.getExamCode() +" ignored";
						m_serviceManager.sendEmailNotification(Arrays.asList(recipientEmailAddressess), null,
								null, "Employee not present in EQMS System "+ peopleSoftQualificationBean.getEmployeeId(), content, DecertificationDao.EQMS_EMAIL_DESCRIPTION);
		
 
			}
		}//Modified for SS_QC#8447 -- End
		m_logger
		.info("Exit :: Execution ends :: processQualification() :  method :"
				);

	}

	/**
	 * Classname / Method Name : ServiceDelegate/processDiscipline()
	 * 
	 * @param peopleSoftDisciplineBean
	 *            Description : This method is used to process all Discipline
	 *            related services.
	 */
	public void processDiscipline(
			PeopleSoftDisciplineBean peopleSoftDisciplineBean) {
		m_logger
		.info("Entered :: Execution starts :: processDiscipline() :  method :"
				);
		if(peopleSoftDisciplineBean.getEventAction().equalsIgnoreCase(ScoreConstants.INSERT)){
			try {
				notificationDAO
				.processDisciplineNotification(peopleSoftDisciplineBean);
			} catch (ParseException parseException) {
				m_logger
				.error(
						" Inside processDisciplineNotification method :: parseException :: Message is  : "
								+ parseException.getMessage()
								+ ScoreConstants.DOUBLE_COLON ,
								parseException);

			} catch (Exception exception) {
				m_logger.error(
						" Inside processDisciplineNotification method :: Exception :: Message is  : "
								+ exception.getMessage()
								+ ScoreConstants.DOUBLE_COLON ,
								exception);
			
			}

			try {
				disciplineDao.processDisciplineForDcrtOthr(peopleSoftDisciplineBean);
			} catch (Exception e) {
				m_logger.error(LOGGER_GENERIC_EXCEPTION
						+ "processDisciplineForDcrtOthr() ::" + e.getMessage(), e);
				
			}
		}
		else
		{
			//Added by xsat244
			final String[] recipientEmailAddressess = EqmsUtil.getEqmsSupportEmailIds().split(",");
			
			String subject = appEnvironment+": The event action was "+peopleSoftDisciplineBean.getEventAction()+
					" for Employee ID ::"+peopleSoftDisciplineBean.getEmployeeId()+" with Date ::"+ peopleSoftDisciplineBean.getEventDateTime();
			String content = LOGGER_GENERIC_EXCEPTION
					+ "::Discipline() :: Employee ID"
					+ peopleSoftDisciplineBean.getEmployeeId()+" :: Action ::"+peopleSoftDisciplineBean.getEventAction();
					m_serviceManager.sendEmailNotification(Arrays.asList(recipientEmailAddressess), null,
							null, subject, content, DecertificationDao.EQMS_EMAIL_DESCRIPTION);
		}
		m_logger
		.info("Exit :: Execution ends :: processDiscipline() :  method :"
				);

	}
	/**
	 * This method is used to save all Miscellaneous related service
	 */
	public void processMiscellaneous(
			PeopleSoftMiscellaneousBean peopleSoftMiscellaneousBean) {
		m_logger
		.debug(" Inside processMiscellaneousNotification method :: Start :: "
				);
		try {
			notificationDAO
			.processMiscellaneousNotification(peopleSoftMiscellaneousBean);
		} catch (ParseException parseException) {
			m_logger
			.error(" Inside processMiscellaneousNotification method :: parseException :: Message is  : "
					+ parseException.getMessage()
					+ ScoreConstants.DOUBLE_COLON , parseException);

		} catch (EqmDaoException eqmDaoException) {
			m_logger
			.error(" Inside processMiscellaneousNotification method :: EqmDaoException :: Message is  : "
					+ eqmDaoException.getMessage()
					+ ScoreConstants.DOUBLE_COLON , eqmDaoException);

		}

		catch (Exception exception) {
			m_logger
			.error(" Inside processMiscellaneousNotification method :: Exception :: Message is  : "
					+ exception.getMessage()
					+ ScoreConstants.DOUBLE_COLON , exception);

		}
	}

	public void processDerailment(HumanFactorCodesBean humanFactorCodesBean){
		m_logger.debug("Inside processDerailmentNotification method :: Start ::" );

		try {
			notificationDAO.processDerailmentNotification(humanFactorCodesBean);
		} catch (EqmDaoException eqmDaoException) {

			m_logger
			.error(" Inside processDerailmentNotification method :: EqmDaoException :: Message is  : "
					+ eqmDaoException.getMessage()
					+ ScoreConstants.DOUBLE_COLON , eqmDaoException);
		} catch (ParseException parseException) {

			m_logger
			.error(" Inside processDerailmentNotification method :: parseException :: Message is  : "
					+ parseException.getMessage()
					+ ScoreConstants.DOUBLE_COLON , parseException);
		}
		catch (Exception exception) {
			m_logger
			.error(" Inside processDerailmentNotification method :: Exception :: Message is  : "
					+ exception.getMessage()
					+ ScoreConstants.DOUBLE_COLON , exception);

		}
	}

	/**
	 * 
	 * This method is used to process messages of MAPS Service.
	 *
	 * @param psftMapsMsgBean
	 * @author xsat568
	 * @since Jun 22, 2015
	 * Added for REQ#687.
	 */
	public void processMapsNotification(final PsftMapsMsgBean psftMapsMsgBean) {
		m_logger.info("Entered :: Execution starts :: processMapsNotification() :  method :" );
		try {
			notificationDAO.processMapsNotification(psftMapsMsgBean);
		} catch (final ParseException parseException) {
			m_logger.error("processMapsNotification method :: parseException :: Message is  : " + parseException.getMessage()
			+ ScoreConstants.DOUBLE_COLON , parseException);
		} catch (final EqmDaoException eqmDaoException) {
			m_logger.error(
					"processMapsNotification method :: EqmDaoException :: Message is  : " + eqmDaoException.getMessage()
					+ ScoreConstants.DOUBLE_COLON , eqmDaoException);
		} catch (final Exception exception) {
			m_logger.error("processMapsNotification method :: Exception :: Message is  : " + exception.getMessage()
			+ ScoreConstants.DOUBLE_COLON , exception);
		}
		m_logger.info("Exit :: Execution ends :: processMapsNotification() :  method :" );
	}

}
