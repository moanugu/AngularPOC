package com.uprr.lic.licensing.rest.model;

import java.util.List;

public class EmployeeAuthorizationDetailsRequest {

	private List<EmpPacketStatusResponse> empPacketStatusDetails;
	private Integer number;
	private String mvrNdrCode;
	private String comments;
	private Boolean fromSupervision;
	
	
	
	public List<EmpPacketStatusResponse> getEmpPacketStatusDetails() {
		return empPacketStatusDetails;
	}

	public void setEmpPacketStatusDetails(List<EmpPacketStatusResponse> empPacketStatusDetails) {
		this.empPacketStatusDetails = empPacketStatusDetails;
	}

	public Integer getNumber() {
		return number;
	}
	
	public void setNumber(Integer number) {
		this.number = number;
	}
	
	public String getMvrNdrCode() {
		return mvrNdrCode;
	}
	
	public void setMvrNdrCode(String mvrNdrCode) {
		this.mvrNdrCode = mvrNdrCode;
	}
	
	public String getComments() {
		return comments;
	}
	
	public void setComments(String comments) {
		this.comments = comments;
	}
	
	public Boolean getFromSupervision() {
		return fromSupervision;
	}
	
	public void setFromSupervision(Boolean fromSupervision) {
		this.fromSupervision = fromSupervision;
	}
}
