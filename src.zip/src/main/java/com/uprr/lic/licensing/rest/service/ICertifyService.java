package com.uprr.lic.licensing.rest.service;

import java.util.List;

import com.uprr.lic.dataaccess.Licensing.model.EmployeeDetail;
import com.uprr.lic.dataaccess.Licensing.model.IssueStudentLicBean;
import com.uprr.lic.dataaccess.Licensing.model.PendingActionListGridDetail;
import com.uprr.lic.dataaccess.common.model.EqmEmplDtls;
import com.uprr.lic.dataaccess.common.model.EqmWorkItem;
import com.uprr.lic.dataaccess.common.model.Medical;
import com.uprr.lic.dataaccess.decertification.model.CertRideSummaryDetails;
import com.uprr.lic.licensing.rest.model.IssueStudentLicBeanDetail;

/**
 * 
 * @author xsat030
 *
 */
public interface ICertifyService {
	//This code is oriented to licensing and started by Abhishek
	public IssueStudentLicBeanDetail getEmployeeDetailsForIssueStudentLic(final EmployeeDetail employeeDetailBean, final String paramName) ;
	/**
	   * Classname / Method Name : ILicensingService/getStudentLcnsClass() 
	   * @param :  Integer
	   * @return : String
	   * @exception :
	   * Description : Method is used to call the actual method from LicensingDao
	   */
	  public String getStudentLcnsClass(Integer oprnId);
	  
	  /**
	   * To get valid work item
	   *
	   * @param workItemId
	   * @param b
	   * @return
	   * @author xsat874
	   * @since Sep 17, 2016
	   * Added for SS_QC#4759
	   */
	 public EqmWorkItem getValidWorkItem(final int workItemId,final boolean histFlag);
	 
	 /**
	   * @param studentLicBean
	   * @param emplId
	   * @param employeeDetailBean
	   * @return
	   */
	  IssueStudentLicBean validateCertifyStudentLicRequest(IssueStudentLicBean studentLicBean,
	      EmployeeDetail employeeDetailBean,boolean pendCertFlag);
	  
	  IssueStudentLicBean issueLicense(IssueStudentLicBean studentLicBean, EmployeeDetail employeeDetailBean,
		      String reason,   boolean pendCertRide); //Req#417
	  /**
	   * Classname / Method Name : ILicensingService/doesEmployeehasRequiredLicense()
	   * @param : employeeId
	   * @return : Boolean
	   * Description : Method is used to check wheather employee has 
	   * valid RCO(class 7 or class 6) or valid Hostler(class 5 or class 2) license and 
	   * employee is currently applying for Student Engineer license (class 3).
	   */
	  public Boolean doesEmployeehasRequiredLicense(final String employeeId,final String licClass);

	  EqmEmplDtls getEmployee(String emplId) ;
	  
	  public List<Medical> getRestrictionCodesList(String employeeID);
	  
	  /**
	   * Classname / Method Name : DecertificationDelegate/getSummaryDetail()
	   * @param employeeID,testID
	   * @return CertRideSummaryDetails Description : This method is used to get cert ride information
	   */
	  public CertRideSummaryDetails getSummaryDetail(final String employeeID, final Integer testId);
	  
	  
	  /**
	   * @param studentLicBean
	   * @param emplId
	   * @param employeeDetailBean
	   * @return
	   */
	  IssueStudentLicBean validateCertifyLicRequest(IssueStudentLicBean studentLicBean,
	      EmployeeDetail employeeDetailBean,String reason);
	  
	  /**
	   * @param detailList
	   * @param manager 
	   * @param application 
	   * @throws Exception 
	   */
	  //Req#417
	  List<IssueStudentLicBean> certifyLicense(List<PendingActionListGridDetail> detailList, final String paramName);
	  
	  //End By Abhishek
}
