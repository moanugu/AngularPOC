package com.uprr.lic.licensing.rest.service;

import java.util.List;
import java.util.Set;

import com.uprr.lic.exception.EqmDaoException;
import com.uprr.lic.licensing.rest.model.EmpPacketStatusResponse;
import com.uprr.lic.licensing.rest.model.LicensingRequest;

/**
 * 
 * @author xsat956
 *
 */
public interface IEmployeePacketStatusService {
	//This code is oriented to licensing and started by xsat956(Girish)
	
	  
	 List<EmpPacketStatusResponse> getEmpPackStatusListForEmpl(String employeeId, Integer number);
	 
	 /**
	   * @param workItemID
	   * @param licOprnID
	   * @param oprnCode
	   * @param comment
	   * @param svcNbr
	   * @param emplId
	   * @param initiatorId
	   * @throws Exception
	   */
	  void cancelRevokeRequest(LicensingRequest licensingRequest) throws EqmDaoException;
	  
	 void sendStatusReport(final List<String> employeeIdList, final Set<Integer> resnList, String mvrOrNdrValue) throws EqmDaoException;
	  //End By Girish
}
