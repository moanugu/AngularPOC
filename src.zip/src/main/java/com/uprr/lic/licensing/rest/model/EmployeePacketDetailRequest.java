package com.uprr.lic.licensing.rest.model;

import java.util.List;

/**
 * @author xsat956
 *
 */
public class EmployeePacketDetailRequest {
	
	private  String employeeId;
	private List<Integer> regionIdList;
	public String getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	public List<Integer> getRegionIdList() {
		return regionIdList;
	}
	public void setRegionIdList(List<Integer> regionIdList) {
		this.regionIdList = regionIdList;
	}
	
}
