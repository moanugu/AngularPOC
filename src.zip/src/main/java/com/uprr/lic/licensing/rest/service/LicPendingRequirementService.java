package com.uprr.lic.licensing.rest.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uprr.lic.auth.EQMSUserSession;
import com.uprr.lic.dataaccess.Licensing.model.FTXEventSummaryBean;
import com.uprr.lic.dataaccess.Licensing.model.FTXExamSummaryBean;
import com.uprr.lic.dataaccess.Licensing.model.MedicalPopup;
import com.uprr.lic.dataaccess.Licensing.model.PendingRequirement;
import com.uprr.lic.dataaccess.Licensing.model.PendingRequirementResult;
import com.uprr.lic.dataaccess.Licensing.model.RulesExamCodeDetails;
import com.uprr.lic.dataaccess.Licensing.model.SLERevokeDesignation;
import com.uprr.lic.dataaccess.components.licensing.service.ILicensingService;
import com.uprr.lic.dataaccess.decertification.util.LicensingUtil;
import com.uprr.lic.dataaccess.masters.service.ISysParamService;
import com.uprr.lic.decert.rest.model.DropdownChoice;
import com.uprr.lic.licensing.rest.model.EmplLicHistoryDetails;
import com.uprr.lic.licensing.rest.model.FTXExamSummaryDetailsResponse;
import com.uprr.lic.licensing.rest.model.MedicalDetailResponse;
import com.uprr.lic.licensing.rest.model.PendingRequirementRequest;
import com.uprr.lic.licensing.rest.model.PendingRequirementResponse;
import com.uprr.lic.util.DDChoice;
import com.uprr.lic.util.EqmsUtil;

@Service("licPendingRequirementService")
public class LicPendingRequirementService implements ILicPendingRequirementService {

	@Autowired
	private ILicensingService licenseService;

	@Autowired
	private EQMSUserSession eqmsUserSession;

	//Added by xsat956
	@Autowired
	private ISysParamService sysParamService;

	@Override
	public List<String> getLicenseClassList() {
		return licenseService.getLicenseClassList();
	}

	@Override
	public List<String> getPendingRequirementsList() {
		return LicensingUtil.getPendingRequirementsList();
	}

	@Override
	public List<DropdownChoice> getServiceUnitListByRegion(Integer regNum) {

		return createDropDownChoiceListResponse(licenseService.getServiceUnitListByRegion(regNum));
	}


	private List<DropdownChoice> createDropDownChoiceListResponse(List<DDChoice> dropDownChoiceList) {
		List<DropdownChoice> dropdownChoiceResponseList = new ArrayList<>();
		if (dropDownChoiceList != null) {
			for (DDChoice objDropdownChoice : dropDownChoiceList) {
				DropdownChoice dropdownChoiceResponse = new DropdownChoice();
				dropdownChoiceResponse.setIntKey(objDropdownChoice.getIntKey());
				dropdownChoiceResponse.setStrKey(objDropdownChoice.getStrKey());
				dropdownChoiceResponse.setValue(objDropdownChoice.getValue());
				dropdownChoiceResponseList.add(dropdownChoiceResponse);
			}
		}
		return dropdownChoiceResponseList;
	}

	@Override
	public Boolean isExistingEmployee(String employeeId) {
		return licenseService.isEmployeeExistInDatabase(employeeId);
	}

	@Override
	public List<PendingRequirementResponse> getPendingRequirementsEmpDetailsList(PendingRequirementRequest objPendingRequirement) {
		List<PendingRequirementResult> pendingRequirementResultList = licenseService.getPendingRequirementsEmpDetailsList(createRequestForPendingRequirment(objPendingRequirement));
		return createResponseListForPendingRequirementResult(pendingRequirementResultList);
	}

	/**
	 * Convert PendingRequirement OBJ to PendingRequirementRequest object
	 * @param objPendingRequirement
	 * @return
	 */
	private PendingRequirement createRequestForPendingRequirment(PendingRequirementRequest objPendingRequirement) {
		if(objPendingRequirement == null) {
			return null;
		}
		PendingRequirement objRequest = new PendingRequirement();
		objRequest.setFromDate( objPendingRequirement.getFromDate(  )  ) ; 
		objRequest.setToDate( objPendingRequirement.getToDate(  )  ) ; 
		objRequest.setRegion( objPendingRequirement.getRegion(  )  ) ; 
		objRequest.setServiceUnit( objPendingRequirement.getServiceUnit(  )  ) ; 
		objRequest.setLicenseClass( objPendingRequirement.getLicenseClass(  )  ) ; 
		objRequest.setEmployeeID( objPendingRequirement.getEmployeeID(  )  ) ; 
		objRequest.setRequirement( objPendingRequirement.getRequirement(  )  ) ; 
		return objRequest;
	}

	/**
	 * 
	 * @param pendingRequirementResultList
	 * @return
	 */
	private List<PendingRequirementResponse> createResponseListForPendingRequirementResult(List<PendingRequirementResult> pendingRequirementResultList) {

		List<PendingRequirementResponse> pendingRequirementResponseList = new ArrayList<>();
		if(pendingRequirementResultList == null) {
			return pendingRequirementResponseList;
		}
		for(PendingRequirementResult objPendingRequirementResult:pendingRequirementResultList) {
			PendingRequirementResponse objResponse = new PendingRequirementResponse();
			objResponse.setEmployeeID( objPendingRequirementResult.getEmployeeID(  )  ) ; 
			objResponse.setEmployeeName( objPendingRequirementResult.getEmployeeName(  )  ) ; 
			objResponse.setServiceUnit( objPendingRequirementResult.getServiceUnit(  )  ) ; 
			objResponse.setServiceUnitNbr( objPendingRequirementResult.getServiceUnitNbr(  )  ) ; 
			objResponse.setLicenseClass( objPendingRequirementResult.getLicenseClass(  )  ) ; 
			objResponse.setMedicalResult( objPendingRequirementResult.getMedicalResult(  )  ) ; 
			objResponse.setRulesResult( objPendingRequirementResult.getRulesResult(  )  ) ; 
			objResponse.setCertRideResult( objPendingRequirementResult.getCertRideResult(  )  ) ; 
			objResponse.setMvrResult( objPendingRequirementResult.getMvrResult(  )  ) ; 
			objResponse.setNdrResult( objPendingRequirementResult.getNdrResult(  )  ) ; 
			objResponse.setRules( objPendingRequirementResult.getRules(  )  ) ; 
			objResponse.setLcnsRqmtId( objPendingRequirementResult.getLcnsRqmtId(  )  ) ; 
			objResponse.setLicenseClassDesc( objPendingRequirementResult.getLicenseClassDesc(  )  ) ; 
			objResponse.setCheckWorkItemForMvrOrNdr( objPendingRequirementResult.isCheckWorkItemForMvrOrNdr(  )  ) ; 
			objResponse.setCheckWorkItemForPeaMvr( objPendingRequirementResult.isCheckWorkItemForPeaMvr(  )  ) ; 
			objResponse.setCheckWorkItemForPeaNdr( objPendingRequirementResult.isCheckWorkItemForPeaNdr(  )  ) ; 
			objResponse.setEmployeeAlreadyLicensedFlag( objPendingRequirementResult.isEmployeeAlreadyLicensedFlag(  )  ) ; 
			objResponse.setJobTypeCode( objPendingRequirementResult.getJobTypeCode(  )  ) ; 
			objResponse.setTestId( objPendingRequirementResult.getTestId(  )  ) ; 
			objResponse.setFtxEventResult( objPendingRequirementResult.getFtxEventResult(  )  ) ; 
			objResponse.setConExamFlag( objPendingRequirementResult.getConExamFlag(  )  ) ; 
			objResponse.setCondLicType( objPendingRequirementResult.getCondLicType(  )  ) ; 
			objResponse.setFtxEvntTestId( objPendingRequirementResult.getFtxEvntTestId(  )  ) ; 
			objResponse.setFtxEvntQlfnCodeId( objPendingRequirementResult.getFtxEvntQlfnCodeId(  )  ) ; 
			objResponse.setFtxEventDate( objPendingRequirementResult.getFtxEventDate(  )  ) ; 
			objResponse.setOr6aExamResult( objPendingRequirementResult.getOr6aExamResult(  )  ) ; 
			objResponse.setOr6aExamDate( objPendingRequirementResult.getOr6aExamDate(  )  ) ; 
			objResponse.setDescription( objPendingRequirementResult.getDescription(  )  ) ; 
			objResponse.setKnlgExamResult( objPendingRequirementResult.getKnlgExamResult(  )  ) ; 
			objResponse.setKnlgExamDate( objPendingRequirementResult.getKnlgExamDate(  )  ) ; 
			objResponse.setKnlgExamType( objPendingRequirementResult.getKnlgExamType(  )  ) ; 
			objResponse.setErtCode( objPendingRequirementResult.getErtCode(  )  ) ; 
			objResponse.setAgrmntFlag( objPendingRequirementResult.getAgrmntFlag(  )  ) ; 
			objResponse.setReCertFlag( objPendingRequirementResult.getReCertFlag(  )  ) ; 
			objResponse.setOpccValue( objPendingRequirementResult.getOpccValue(  )  ) ; 
			objResponse.setOprcValue( objPendingRequirementResult.getOprcValue(  )  ) ; 
			objResponse.setOpecValue( objPendingRequirementResult.getOpecValue(  )  ) ; 
			objResponse.setRcnmCode( objPendingRequirementResult.getRcnmCode(  )  ) ; 
			//Added for SS_QC#6703
			objResponse.setRiskScore(objPendingRequirementResult.getRiskScore());
			objResponse.setFtxEventID(objPendingRequirementResult.getFtxEventID()); // Added for SS_QC#10202(9049)
			pendingRequirementResponseList.add(objResponse);
		}
		return pendingRequirementResponseList;
	}

	@Override
	public EmplLicHistoryDetails getEmployeeLicHistoryDetails(String employeeId) {
		return createEmplLicHistoryDetails(licenseService.getEmployeeLicHistoryDetails(employeeId), employeeId);
	}


	private EmplLicHistoryDetails createEmplLicHistoryDetails(SLERevokeDesignation objSLERevokeDesignation, String employeeId) {
		if(objSLERevokeDesignation == null) {
			return null;
		}

		EmplLicHistoryDetails emplLicHistoryDetails = new EmplLicHistoryDetails();
		emplLicHistoryDetails.setManagerId( objSLERevokeDesignation.getManagerId(  )  ) ; 
		emplLicHistoryDetails.setEmployeeId( objSLERevokeDesignation.getEmployeeId(  )  ) ; 
		emplLicHistoryDetails.setEmployeeName( objSLERevokeDesignation.getEmployeeName(  )  ) ; 
		emplLicHistoryDetails.setServiceUnit( objSLERevokeDesignation.getServiceUnit(  )  ) ; 
		emplLicHistoryDetails.setComments( objSLERevokeDesignation.getComments(  )  ) ; 
		emplLicHistoryDetails.setSleDesignationResultList( objSLERevokeDesignation.getSleDesignationResultList(  )  ) ; 
		emplLicHistoryDetails.setLicenseList( objSLERevokeDesignation.getLicenseList(  )  ) ; 
		emplLicHistoryDetails.setManagerPopupList( objSLERevokeDesignation.getManagerPopupList(  )  ) ; 
		emplLicHistoryDetails.setInitiatorName( objSLERevokeDesignation.getInitiatorName(  )  ) ; 
		emplLicHistoryDetails.setInitiatorId( objSLERevokeDesignation.getInitiatorId(  )  ) ; 
		emplLicHistoryDetails.setRevoke( objSLERevokeDesignation.getRevoke(  )  ) ; 
		emplLicHistoryDetails.setDateOfBirth( objSLERevokeDesignation.getDateOfBirth(  )  ) ; 
		emplLicHistoryDetails.setIssueDate( objSLERevokeDesignation.getIssueDate(  )  ) ;
		emplLicHistoryDetails.setCmtsViewLink(EqmsUtil.viewCMTSLink(sysParamService.getAllSystemParameter()));
		emplLicHistoryDetails.setDisciplineHistoryLink(EqmsUtil.viewDisciplineHistoryLink(objSLERevokeDesignation.getManagerId(  ), sysParamService.getAllSystemParameter()));
		emplLicHistoryDetails.setLicenseHistoryLink(EqmsUtil.viewEmpLicenseHist(sysParamService.getAllSystemParameter(), employeeId));
		return emplLicHistoryDetails;
	}

	@Override
	public List<RulesExamCodeDetails> getRulesExamCodes(String emplId) {
		return licenseService.getRulesExamCodes(emplId);
	}

	@Override
	public MedicalDetailResponse getMedicalResult(Integer rqmtId) {
		return createResponseForMedicalPoppup(licenseService.getMedicalResult(rqmtId));
	}

	@Override
	public MedicalDetailResponse getMedicalResult(String employeeId, String licenseClassCode) {
		return createResponseForMedicalPoppup(licenseService.getMedicalResult(employeeId, licenseClassCode));
	}

	/**
	 * Convert MedicalDetailResponse OBJ to MedicalPoppup object
	 * @param objPendingRequirement
	 * @return
	 */
	private MedicalDetailResponse createResponseForMedicalPoppup(MedicalPopup medicalPopup) {
		if(medicalPopup == null) {
			return null;
		}
		MedicalDetailResponse objResponse = new MedicalDetailResponse();
		objResponse.setMedical( medicalPopup.getMedical(  )  ) ; 
		objResponse.setEmpId( medicalPopup.getEmpId(  )  ) ; 
		return objResponse;
	}

	@Override
	public FTXExamSummaryDetailsResponse getEvaluationDetailsForConductor(String employeeId, Integer testId, Integer ftxEventId) {
		return createResponseForFTXExamSummaryDetailsResponse(licenseService.getEvaluationDetailsForConductor(employeeId, testId, ftxEventId));
	}
	@Override
	public FTXExamSummaryDetailsResponse getAuditEvaluationDetails(final String employeeId,
			final Integer sequenceNumber) {
		return createResponseForFTXExamSummaryDetailsResponse(
				licenseService.getAuditEvaluationDetails(employeeId, sequenceNumber));
	}
	@Override
	public String getPinsForConductorLicense(PendingRequirementResult pendingRequirementResult) {
		return licenseService.getPinsForConductorLicense(pendingRequirementResult, eqmsUserSession.getUser().getEmplId());
	}



	/**
	 * Convert MedicalDetailResponse OBJ to MedicalPoppup object
	 * @param objPendingRequirement
	 * @return
	 */
	private FTXExamSummaryDetailsResponse createResponseForFTXExamSummaryDetailsResponse(FTXEventSummaryBean objFTXEventSummaryBean) {

		FTXExamSummaryDetailsResponse objResponse = new FTXExamSummaryDetailsResponse();

		if(objFTXEventSummaryBean == null) {
			return null;
		}

		objResponse.setManagerName( objFTXEventSummaryBean.getManagerName(  )  ) ; 
		objResponse.setFtxEventDate( objFTXEventSummaryBean.getFtxEventDate(  )  ) ; 
		objResponse.setFtxEventType( objFTXEventSummaryBean.getFtxEventType(  )  ) ; 
		objResponse.setManagerServiceUnit( objFTXEventSummaryBean.getManagerServiceUnit(  )  ) ; 
		objResponse.setSubDivision( objFTXEventSummaryBean.getSubDivision(  )  ) ; 
		objResponse.setMilePost( objFTXEventSummaryBean.getMilePost(  )  ) ; 
		objResponse.setWeather( objFTXEventSummaryBean.getWeather(  )  ) ; 
		objResponse.setVisibility( objFTXEventSummaryBean.getVisibility(  )  ) ; 
		objResponse.setTrainID( objFTXEventSummaryBean.getTrainID(  )  ) ; 
		objResponse.setLocomotiveNum( objFTXEventSummaryBean.getLocomotiveNum(  )  ) ; 
		objResponse.setCrewCallCirc7( objFTXEventSummaryBean.getCrewCallCirc7(  )  ) ; 
		objResponse.setCrewCallTime( objFTXEventSummaryBean.getCrewCallTime(  )  ) ; 
		objResponse.setDistPowerUnit( objFTXEventSummaryBean.getDistPowerUnit(  )  ) ; 
		objResponse.setRemoteControl( objFTXEventSummaryBean.getRemoteControl(  )  ) ; 
		objResponse.setAssistMgr( objFTXEventSummaryBean.getAssistMgr(  )  ) ; 
		objResponse.setSecAssistMgr( objFTXEventSummaryBean.getSecAssistMgr(  )  ) ; 
		objResponse.setThirdAssistMgr( objFTXEventSummaryBean.getThirdAssistMgr(  )  ) ; 
		objResponse.setFtxExamSummaryGridDetails( objFTXEventSummaryBean.getFtxExamSummaryGridDetails(  )  ) ; 
		objResponse.setManagerComments( objFTXEventSummaryBean.getManagerComments(  )  ) ; 
		objResponse.setCrewMember( objFTXEventSummaryBean.getCrewMember(  )  ) ; 
		objResponse.setReason( objFTXEventSummaryBean.getReason(  )  ) ; 
		objResponse.setCrewPosition( objFTXEventSummaryBean.getCrewPosition(  )  ) ; 
		objResponse.setOverallScore( objFTXEventSummaryBean.getOverallScore(  )  ) ; 
		return objResponse;
	}

	@Override
	public boolean cancelLicensingRequirement(List<PendingRequirementResult> rqmtList, String comments) {
		return licenseService.cancelLicensingRequirement(rqmtList, eqmsUserSession.getUser().getEmplId(), comments);
	}



}
