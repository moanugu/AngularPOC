package com.uprr.lic.licensing.rest.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uprr.lic.dataaccess.decertification.model.CategoryInformationDetail;
import com.uprr.lic.dataaccess.decertification.model.CertRideSummaryDetails;
import com.uprr.lic.dataaccess.decertification.services.interfaces.IDecertificationService;
import com.uprr.lic.licensing.rest.model.CategoryInformationDetailResponse;
import com.uprr.lic.licensing.rest.model.CertRideSummaryResponse;

/**
 * 
 * @author xsat956
 *
 */
@Service("certRideSummaryService")
public class CertRideSummaryService implements ICertRideSummaryService {

	@Autowired
	private IDecertificationService decertificationService;

	@Override
	public CertRideSummaryResponse getSummaryDetail(String employeeId, Integer testId) {
		return createCertSummaryDetailResponse(decertificationService.getSummaryDetail(employeeId, testId));
	}
	@Override
	public CertRideSummaryResponse getAuditRideSummaryDetail(String employeeId, Integer sequenceNumber) {
		return createCertSummaryDetailResponse(
				decertificationService.getAuditRideSummaryDetail(employeeId, sequenceNumber));
	}
	@Override
	public List<CategoryInformationDetailResponse> getCategoryInformationList(String employeeID, Integer testId) {
		return createCategoryInformationDetailResponse(decertificationService.getCategoryInformationList(employeeID, testId));
	}
	@Override
	public List<CategoryInformationDetailResponse> getAuditRideCheckList(String employeeID, Integer sequenceNumber) {
		return createCategoryInformationDetailResponse(
				decertificationService.getAuditRideCheckList(employeeID, sequenceNumber));
	}

	private CertRideSummaryResponse createCertSummaryDetailResponse(CertRideSummaryDetails objCertRideSummaryDetails) {
		
		if(objCertRideSummaryDetails == null) {
			return null;
		}

		CertRideSummaryResponse  certRideSummaryResponse = new CertRideSummaryResponse();
		certRideSummaryResponse.setManager( objCertRideSummaryDetails.getManager(  )  ) ; 
		certRideSummaryResponse.setEvaluationDate( objCertRideSummaryDetails.getEvaluationDate(  )  ) ; 
		certRideSummaryResponse.setServiceUnit( objCertRideSummaryDetails.getServiceUnit(  )  ) ; 
		certRideSummaryResponse.setTrainID( objCertRideSummaryDetails.getTrainID(  )  ) ; 
		certRideSummaryResponse.setTotalLoads( objCertRideSummaryDetails.getTotalLoads(  )  ) ; 
		certRideSummaryResponse.setCrewOnDutyCirc7( objCertRideSummaryDetails.getCrewOnDutyCirc7(  )  ) ; 
		certRideSummaryResponse.setServiceType( objCertRideSummaryDetails.getServiceType(  )  ) ; 
		certRideSummaryResponse.setLength( objCertRideSummaryDetails.getLength(  )  ) ; 
		certRideSummaryResponse.setSimulator( objCertRideSummaryDetails.getSimulator(  )  ) ; 
		certRideSummaryResponse.setdPU(objCertRideSummaryDetails.getDPU(  ) ) ; 
		certRideSummaryResponse.setForignInitial( objCertRideSummaryDetails.getForignInitial(  )  ) ; 
		certRideSummaryResponse.setWeight( objCertRideSummaryDetails.getWeight(  )  ) ; 
		certRideSummaryResponse.setTotalEmpties( objCertRideSummaryDetails.getTotalEmpties(  )  ) ; 
		certRideSummaryResponse.setRemoteControl(objCertRideSummaryDetails.getRemoteControl(  )  ) ; 
		certRideSummaryResponse.setHelper( objCertRideSummaryDetails.getHelper(  )  ) ; 
		certRideSummaryResponse.setCrewMember( objCertRideSummaryDetails.getCrewMember(  )  ) ; 
		certRideSummaryResponse.setPosition( objCertRideSummaryDetails.getPosition(  )  ) ; 
		certRideSummaryResponse.setStudent( objCertRideSummaryDetails.getStudent(  )  ) ; 
		certRideSummaryResponse.setReason( objCertRideSummaryDetails.getReason(  )  ) ; 
		certRideSummaryResponse.setTotalMiles( objCertRideSummaryDetails.getTotalMiles(  )  ) ; 
		certRideSummaryResponse.setStartDate( objCertRideSummaryDetails.getStartDate(  )  ) ; 
		certRideSummaryResponse.setStopDate( objCertRideSummaryDetails.getStopDate(  )  ) ; 
		certRideSummaryResponse.setOriginCirc7( objCertRideSummaryDetails.getOriginCirc7(  )  ) ; 
		certRideSummaryResponse.setDestCirc7( objCertRideSummaryDetails.getDestCirc7(  )  ) ; 
		certRideSummaryResponse.setOverAllScore( objCertRideSummaryDetails.getOverAllScore(  )  ) ; 
		certRideSummaryResponse.setTrainHandlingScore( objCertRideSummaryDetails.getTrainHandlingScore(  )  ) ; 
		certRideSummaryResponse.setMngrComments( objCertRideSummaryDetails.getMngrComments(  )  ) ;

		return certRideSummaryResponse;
	}

	private List<CategoryInformationDetailResponse> createCategoryInformationDetailResponse(List<CategoryInformationDetail> objCertRideSummaryDetailList) {

		List<CategoryInformationDetailResponse> categoryInformationDetailResponseList = new ArrayList<>();
		if(objCertRideSummaryDetailList == null) {
			return categoryInformationDetailResponseList;
		}
		
		for( CategoryInformationDetail categoryInformationDetail: objCertRideSummaryDetailList) {
			CategoryInformationDetailResponse categoryInformationDetailResponse = new CategoryInformationDetailResponse();
			categoryInformationDetailResponse.setCategoryFirst( categoryInformationDetail.getCategory1(  )  ) ; 
			categoryInformationDetailResponse.setActionFirst( categoryInformationDetail.getAction1(  )  ) ; 
			categoryInformationDetailResponse.setCategorySecond( categoryInformationDetail.getCategory2(  )  ) ; 
			categoryInformationDetailResponse.setActionSecond( categoryInformationDetail.getAction2(  )  ) ;
			categoryInformationDetailResponseList.add(categoryInformationDetailResponse);
		}
		return categoryInformationDetailResponseList;
	}

}
