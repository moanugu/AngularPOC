package com.uprr.lic.licensing.rest.model;

import java.util.List;

public class FeedbackMsgRequest {

	private List<String> lstNotAuthEmpl;
	private List<String> emplAuthlst;
	private List<String> emplNTValidlst;
	private String validate;
	private boolean fromErrWrkItm;
	private boolean fromSendRequest;
	
	public List<String> getLstNotAuthEmpl() {
		return lstNotAuthEmpl;
	}
	public void setLstNotAuthEmpl(List<String> lstNotAuthEmpl) {
		this.lstNotAuthEmpl = lstNotAuthEmpl;
	}
	public List<String> getEmplAuthlst() {
		return emplAuthlst;
	}
	public void setEmplAuthlst(List<String> emplAuthlst) {
		this.emplAuthlst = emplAuthlst;
	}
	public List<String> getEmplNTValidlst() {
		return emplNTValidlst;
	}
	public void setEmplNTValidlst(List<String> emplNTValidlst) {
		this.emplNTValidlst = emplNTValidlst;
	}
	public String getValidate() {
		return validate;
	}
	public void setValidate(String validate) {
		this.validate = validate;
	}
	public boolean isFromErrWrkItm() {
		return fromErrWrkItm;
	}
	public void setFromErrWrkItm(boolean fromErrWrkItm) {
		this.fromErrWrkItm = fromErrWrkItm;
	}
	public boolean isFromSendRequest() {
		return fromSendRequest;
	}
	public void setFromSendRequest(boolean fromSendRequest) {
		this.fromSendRequest = fromSendRequest;
	}
	
}
