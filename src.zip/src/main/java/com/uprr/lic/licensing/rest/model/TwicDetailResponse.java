package com.uprr.lic.licensing.rest.model;

public class TwicDetailResponse {

	  private String employeeID;
	  
	  private String empFirstName;

	  private String empMiddleName;

	  private String empLastName;
	  
	  private String expireDate;
	   
	  private boolean renewCheckbox; 
	  
	  private String employeeName;
	  
	  private boolean isUpdateFlag;


	  /**
	   * @return the employeeID
	   */
	  public String getEmployeeID() {
	    return employeeID;
	  }

	  /**
	   * @param employeeID the employeeID to set
	   */
	  public void setEmployeeID(String employeeID) {
	    this.employeeID = employeeID;
	  }

	  /**
	   * @return the empFirstName
	   */
	  public String getEmpFirstName() {
	    return empFirstName;
	  }

	  /**
	   * @param empFirstName the empFirstName to set
	   */
	  public void setEmpFirstName(String empFirstName) {
	    this.empFirstName = empFirstName;
	  }

	  /**
	   * @return the empMiddleName
	   */
	  public String getEmpMiddleName() {
	    return empMiddleName;
	  }

	  /**
	   * @param empMiddleName the empMiddleName to set
	   */
	  public void setEmpMiddleName(String empMiddleName) {
	    this.empMiddleName = empMiddleName;
	  }

	  /**
	   * @return the empLastName
	   */
	  public String getEmpLastName() {
	    return empLastName;
	  }

	  /**
	   * @param empLastName the empLastName to set
	   */
	  public void setEmpLastName(String empLastName) {
	    this.empLastName = empLastName;
	  }

	  /**
	   * @return the expireDate
	   */
	  public String getExpireDate() {
	    return expireDate;
	  }

	  /**
	   * @param expireDate the expireDate to set
	   */
	  public void setExpireDate(String expireDate) {
	    this.expireDate = expireDate;
	  }

	  /**
	   * @return the renewCheckbox
	   */
	  public boolean isRenewCheckbox() {
	    return renewCheckbox;
	  }

	  /**
	   * @param renewCheckbox the renewCheckbox to set
	   */
	  public void setRenewCheckbox(boolean renewCheckbox) {
	    this.renewCheckbox = renewCheckbox;
	  }

	  /**
	   * @return the employeeName
	   */
	  public String getEmployeeName() {
	    return employeeName;
	  }

	  /**
	   * @param employeeName the employeeName to set
	   */
	  public void setEmployeeName(String employeeName) {
	    this.employeeName = employeeName;
	  }

	  /**
	   * @return the isUpdateFlag
	   */
	  public boolean isUpdateFlag() {
	    return isUpdateFlag;
	  }

	  /**
	   * @param isUpdateFlag the isUpdateFlag to set
	   */
	  public void setUpdateFlag(boolean isUpdateFlag) {
	    this.isUpdateFlag = isUpdateFlag;
	  }
}
