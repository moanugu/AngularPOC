package com.uprr.lic.licensing.rest.model;

import com.uprr.lic.dataaccess.Licensing.model.EmployeeDetail;
import com.uprr.lic.dataaccess.Licensing.model.IssueStudentLicBean;

/**
 * @author xsat956
 *
 */
public class StudentLicenseControllerBean  {
	
	IssueStudentLicBean studentLicBean;
    EmployeeDetail employeeDetailBean;
    boolean pendCertFlag;
    String reason;
	
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
	public IssueStudentLicBean getStudentLicBean() {
		return studentLicBean;
	}
	public StudentLicenseControllerBean() {
		super();
	}
	public void setStudentLicBean(IssueStudentLicBean studentLicBean) {
		this.studentLicBean = studentLicBean;
	}
	public EmployeeDetail getEmployeeDetailBean() {
		return employeeDetailBean;
	}
	public void setEmployeeDetailBean(EmployeeDetail employeeDetailBean) {
		this.employeeDetailBean = employeeDetailBean;
	}
	public boolean isPendCertFlag() {
		return pendCertFlag;
	}
	public void setPendCertFlag(boolean pendCertFlag) {
		this.pendCertFlag = pendCertFlag;
	}
	
}
