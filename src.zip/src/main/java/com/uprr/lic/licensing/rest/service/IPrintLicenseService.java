package com.uprr.lic.licensing.rest.service;

import java.util.List;
import java.util.Map;

import com.uprr.lic.dataaccess.Licensing.model.PendingActionListGridDetail;
import com.uprr.lic.dataaccess.Licensing.model.PrintTemporaryLicense;
import com.uprr.lic.dataaccess.Licensing.model.PrintTemporaryLicenseGrid;

/**
 * 
 * @author xsat004
 *
 */
public interface IPrintLicenseService {

	Boolean isExpnDateSameForAllLcns(String employeeId);

	PrintTemporaryLicense getPrintLicenseService(PrintTemporaryLicense employeeDetails, Integer choice, String employeeId, String printFlag);

	Map<String, List<String>> updateLicenseMailedStatus(List<PrintTemporaryLicenseGrid> printTemporaryLicenseGrids);

	void removeWorkItemForPrintWorkItem(List<String> emplId, String printFlag, Integer modId);

	Boolean updatePendingActionPrintLicense(List<PendingActionListGridDetail> detailList);
	
	Boolean getPrintStatusforGrndEmplWQ(final String employeeId);
}
