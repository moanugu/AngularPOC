package com.uprr.lic.licensing.rest.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uprr.lic.auth.EQMSUserSession;
import com.uprr.lic.dataaccess.Licensing.model.EmpPacketStatusDetails;
import com.uprr.lic.dataaccess.components.licensing.service.ILicensingService;
import com.uprr.lic.dataaccess.decertification.dao.DecertificationDao;
import com.uprr.lic.dataaccess.masters.service.ISysParamService;
import com.uprr.lic.exception.EqmDaoException;
import com.uprr.lic.externalservice.xmf.service.EmailNotificationService;
import com.uprr.lic.licensing.rest.model.EmpPacketStatusResponse;
import com.uprr.lic.licensing.rest.model.LicensingRequest;
import com.uprr.lic.util.LicensingConstant;
import com.uprr.lic.util.SysParamBean;

/**
 * 
 * @author xsat956
 *
 */
@Service("employeePacketStatusService")
public class EmployeePacketStatusService implements IEmployeePacketStatusService {

	@Autowired
	private ILicensingService licensingService;

	@Autowired
	private EQMSUserSession eqmsUserSession;

	//Added by xsat956
	@Autowired
	private ISysParamService sysParamService;

	@Autowired
	private EmailNotificationService emailNotificationService;



	@Override
	public List<EmpPacketStatusResponse> getEmpPackStatusListForEmpl(String employeeId, Integer number) {
		return createEmployeePacketStatusResponse(licensingService.getEmpPackStatusListForEmpl(employeeId, number));
	}

	private List<EmpPacketStatusResponse> createEmployeePacketStatusResponse(List<EmpPacketStatusDetails> employeePacketStatusList) {

		List<EmpPacketStatusResponse> employeeStatusResponseList = new ArrayList<EmpPacketStatusResponse>();
		
		if(employeePacketStatusList == null) {
			return employeeStatusResponseList;
		}
		
		for( EmpPacketStatusDetails  objEmpPacketStatusDetails : employeePacketStatusList) {
			EmpPacketStatusResponse objResponse = new EmpPacketStatusResponse();
			objResponse.setPacketDate( objEmpPacketStatusDetails.getPacketDate(  )  ) ; 
			objResponse.setReply( objEmpPacketStatusDetails.getReply(  )  ) ; 
			objResponse.setResultPassOrFail( objEmpPacketStatusDetails.getResultPassOrFail(  )  ) ; 
			objResponse.setResult( objEmpPacketStatusDetails.getResult(  )  ) ; 
			objResponse.setStatus( objEmpPacketStatusDetails.getStatus(  )  ) ; 
			objResponse.setResultEmpAuth( objEmpPacketStatusDetails.getResultEmpAuth(  )  ) ; 
			objResponse.setActionTakenBy( objEmpPacketStatusDetails.getActionTakenBy(  )  ) ; 
			objResponse.setEmployeeID( objEmpPacketStatusDetails.getEmployeeID(  )  ) ; 
			objResponse.setEmployeeName( objEmpPacketStatusDetails.getEmployeeName(  )  ) ; 
			objResponse.setServiceUnit( objEmpPacketStatusDetails.getServiceUnit(  )  ) ; 
			objResponse.setLicense( objEmpPacketStatusDetails.getLicense(  )  ) ; 
			objResponse.setResultDate( objEmpPacketStatusDetails.getResultDate(  )  ) ; 
			objResponse.setSvcUnitNbr( objEmpPacketStatusDetails.getSvcUnitNbr(  )  ) ; 
			objResponse.setRecordType( objEmpPacketStatusDetails.getRecordType(  )  ) ; 
			objResponse.setResnId( objEmpPacketStatusDetails.getResnId(  )  ) ; 
			objResponse.setPackStatCmnt( objEmpPacketStatusDetails.getPackStatCmnt(  )  ) ; 
			objResponse.setCallBackCmnt( objEmpPacketStatusDetails.getCallBackCmnt(  )  ) ; 
			objResponse.setDocumentTypeRadioGrp( objEmpPacketStatusDetails.getDocumentTypeRadioGrp(  )  ) ; 
			objResponse.setHistRcdFlag( objEmpPacketStatusDetails.getHistRcdFlag(  )  ) ; 
			objResponse.setViewMVR( objEmpPacketStatusDetails.getViewMVR(  )  ) ; 
			objResponse.setEntrMVRAuth( objEmpPacketStatusDetails.getEntrMVRAuth(  )  ) ; 
			objResponse.setRcvdDate( objEmpPacketStatusDetails.getRcvdDate(  )  ) ; 

			List<String> employeeList = new ArrayList<>();
			employeeList.add(objEmpPacketStatusDetails.getEmployeeID());
			List<Map<String, Object>> mvrList = licensingService.getMVRReportDetails(employeeList);

			if(mvrList != null && !mvrList.isEmpty()) {
				objResponse.setEmployeeAction("Update MVR Authorization");
			} else {
				objResponse.setEmployeeAction("Enter MVR Authorization");
			}
			
			//Added for SS_QC#6703
			objResponse.setRiskScore(objEmpPacketStatusDetails.getRiskScore());
			employeeStatusResponseList.add(objResponse);
		}
		return employeeStatusResponseList;

	}


	@Override
	public void cancelRevokeRequest(LicensingRequest licensingRequest) throws EqmDaoException{
		try {
			licensingService.cancelRevokeRequest(licensingRequest.getWorkItemID(), licensingRequest.getLicOprnID(),
					licensingRequest.getOprnCode(), licensingRequest.getComment(), licensingRequest.getServiceNumber(), 
					licensingRequest.getEmplId(), licensingRequest.getInitiatorId(), licensingRequest.isStudentFlag(), eqmsUserSession.getUser().getEmplId());

		} catch (Exception e){
			throw new EqmDaoException(e.getMessage()) ;
		}
	}




	/**
	 * To send the packet receiving status report to the DEV team (Delete when no monitoring required).
	 * 
	 * @author xsat244
	 * @param emplpacketDtlsList
	 * @param resnList
	 */
	@Override
	public void sendStatusReport(final List<String> employeeIdList, final Set<Integer> resnList, String mvrOrNdrValue) throws EqmDaoException{

		try {
			boolean mvrFlag = false;
			boolean ndrFlag = false;
			final StringBuilder emailBodyContent = new StringBuilder();
			final StringBuilder updatedEmplsContent = new StringBuilder();
			final StringBuilder errorContent = new StringBuilder();
			final Map<String, SysParamBean> sysParmMap = sysParamService.getAllSystemParameter();
			final SysParamBean monitorFlagSysParam = sysParmMap.get("MONITOR_MVR_NDR");//Modifiesd for SS_QC#6732
			final SysParamBean supportEmailSysParam = sysParmMap.get("EQMS_SUPPORT_EMAIL");//Modifiesd for SS_QC#6732

			if (null != monitorFlagSysParam && LicensingConstant.FLAG_Y.equalsIgnoreCase(monitorFlagSysParam.getParmValu())) {
				final Set<String> emplIdList = new HashSet(employeeIdList);//new HashSet<String>();
				if("BOTH".equalsIgnoreCase(mvrOrNdrValue)){
					emailBodyContent.append("MVR and NDR ");
				} else {
					emailBodyContent.append(mvrOrNdrValue);
				}
				emailBodyContent.append("<b> received by ");
				emailBodyContent.append(eqmsUserSession.getUser().getEmplId());
				emailBodyContent.append(" received for </b><BR>");
			/*	for (EmpPacketStatusDetails empPacketStatusDetails : emplpacketDtlsList) {
					emplIdList.add(empPacketStatusDetails.getEmployeeID());
				}*/
				emailBodyContent.append(emplIdList);
				emailBodyContent.append("<BR><b>"+mvrOrNdrValue+" updated into system</b><BR>");

				final Map<String, List<EmpPacketStatusDetails>> emplPacktDtlsMap = licensingService.getPackDtlsList(emplIdList, resnList);
				for(Map.Entry<String, List<EmpPacketStatusDetails>> packEntry:emplPacktDtlsMap.entrySet()){
					mvrFlag = false;
					ndrFlag = false;
					List<EmpPacketStatusDetails> packList = packEntry.getValue();
					for (EmpPacketStatusDetails emplPack : packList) {
						if (resnList.contains(emplPack.getResnId())) {
							if (emplPack.getResnId().intValue() == 120) {
								mvrFlag = true;
							} else if (emplPack.getResnId().intValue() == 121) {
								ndrFlag = true;
							}
						}
					}
					if("BOTH".equalsIgnoreCase(mvrOrNdrValue)){
						updatedEmplsContent.append(packEntry.getKey()+" MVR:"+mvrFlag+" NDR:"+ndrFlag);
						if(!mvrFlag || !ndrFlag){
							errorContent.append(packEntry.getKey()+" MVR:"+mvrFlag+" NDR:"+ndrFlag);
						}
					} else if("MVR".equalsIgnoreCase(mvrOrNdrValue)){
						updatedEmplsContent.append(packEntry.getKey()+" MVR:"+mvrFlag);
						if(!mvrFlag){
							errorContent.append(packEntry.getKey()+" MVR:"+mvrFlag);
						}
					} else if("NDR".equalsIgnoreCase(mvrOrNdrValue)){
						updatedEmplsContent.append(packEntry.getKey()+" NDR:"+ndrFlag);
						if(!mvrFlag){
							errorContent.append(packEntry.getKey()+" NDR:"+ndrFlag);
						}
					}
				}
				emailBodyContent.append(updatedEmplsContent);
				emailBodyContent.append("<BR><b>List of employees not updated (if any) into system</b><BR>");
				if(errorContent.length()>0){
					emailBodyContent.append(errorContent);
				} else {
					emailBodyContent.append("None");
				}
				final String supportEmailId = (null != supportEmailSysParam)?supportEmailSysParam.getParmValu():"EQMSTechSupport@up.com";
				emailNotificationService.sendEmailNotification(Arrays.asList(new String[]{supportEmailId}), null, null, "Employee Packet Report", emailBodyContent.toString(), DecertificationDao.EQMS_EMAIL_DESCRIPTION);
			}

		} catch(Exception e) {
			throw new EqmDaoException(e.getMessage());
		}
	}
}
