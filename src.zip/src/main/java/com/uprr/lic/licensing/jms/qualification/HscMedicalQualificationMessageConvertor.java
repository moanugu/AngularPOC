package com.uprr.lic.licensing.jms.qualification;

import java.io.StringReader;
import java.util.Arrays;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.apache.commons.lang.StringEscapeUtils;
import org.apache.xmlbeans.XmlException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.support.converter.MessageConversionException;
import org.springframework.jms.support.converter.MessageConverter;

import com.uprr.lic.dataaccess.Licensing.model.PeopleSoftQualificationBean;
import com.uprr.lic.dataaccess.components.licensing.service.IPsftService;
import com.uprr.lic.externalservice.xmf.service.EmailNotificationService;
import com.uprr.lic.util.EQMSConstant;
import com.uprr.lic.util.EqmsUtil;
import com.uprr.lic.util.ScoreConstants;
import com.uprr.netcontrol.shared.xml_bindings.jaxb2.hsc.medical_qualifications.HSCMedicalExamDetails;
import com.uprr.netcontrol.shared.xml_bindings.jaxb2.hsc.medical_qualifications.HSCMedicalQualificationDetails;
import com.uprr.netcontrol.shared.xml_bindings.jaxb2.hsc.medical_qualifications.ObjectFactory;

public class HscMedicalQualificationMessageConvertor implements MessageConverter{

	private static Logger logger = LoggerFactory.getLogger(HscMedicalQualificationMessageConvertor.class);


	private static final String className = HscMedicalQualificationMessageConvertor.class.getName();

	@Autowired
	private IPsftService psftDelegate; //Req#503

	@Autowired
	private EmailNotificationService emailNotificationService;

	private static final String mailSubject = "Rules service error - The XML not parse Successfully.";

	private static final String FLAG_YES = "Y";

	private static final String FLAG_NO = "N";


	/**
	 * To (TODO some description about method)
	 *
	 * @param message
	 * @return
	 * @throws JMSException
	 * @throws MessageConversionException
	 * @author xsat976
	 * @since Jun 30, 2017
	 */
	@Override
	public Object fromMessage(Message message) throws JMSException, MessageConversionException {

		PeopleSoftQualificationBean peopleSoftQualificationObject = null;
		final String[] recipientEmailAddressess = EqmsUtil.getEqmsSupportEmailIds().split(",");
		TextMessage textMessage = (TextMessage) message;
		String xmlMessage = "";
		try {
			StringBuffer subStringMessage = new StringBuffer();
			if (null != textMessage.getText()) {
				subStringMessage.append(textMessage.getText().split("<wsnb:Message>")[1].split("</wsnb:Message>")[0]);
				xmlMessage = subStringMessage.toString();
			}
			Integer primaryKey = psftDelegate.insertMessageInPsftNtfnDtl(textMessage.getText(),EQMSConstant.QUALIFICATION_QUEUE, null);

			logger.debug(" Inside fromMessage method :: Start :: Message  Obtained  is  : " + xmlMessage
					+ ScoreConstants.DOUBLE_COLON + className);
			logger.debug(" Inside fromMessage method :: Start :: Message  Obtained  is  : "
					+ xmlMessage + ScoreConstants.DOUBLE_COLON + className);

			peopleSoftQualificationObject = parseMessage(xmlMessage, primaryKey);

		} catch (XmlException xmlException) {
			String mailContent = "The XML not parse Successfully. <br><hr><br>" + StringEscapeUtils.escapeXml(xmlMessage);
			emailNotificationService.sendEmailNotification(Arrays.asList(recipientEmailAddressess), null, null,  mailSubject, mailContent, EmailNotificationService.EQMS_EMAIL_DESCRIPTION);

			logger.error(" Inside fromMessage method :: XmlException :: The XML is ::  : " + xmlException.getMessage()
			+ " :: was not parse Successfull :: " + className);
			logger.error(" Inside fromMessage method :: XmlException :: The XML is ::  : "
					+ xmlException.getMessage() + " :: was not parse Successfull :: " + className);

		} catch (Exception exception) {

			String mailContent = "The XML not parse Successfully. <br><hr><br>" + StringEscapeUtils.escapeXml(xmlMessage);
			emailNotificationService.sendEmailNotification(Arrays.asList(recipientEmailAddressess), null, null,  mailSubject, mailContent, EmailNotificationService.EQMS_EMAIL_DESCRIPTION);

			logger.error(" Inside fromMessage method :: Exception : The XML is :: " + exception.getMessage()
			+ " :: was not parse Successfully :: " + className);
			logger.error(" Inside fromMessage method :: Exception : The XML is :: " + exception.getMessage()
			+ " :: was not parse Successfully :: " + className);
		}
		logger.debug(" Inside fromMessage method :: Ends :: " + className);
		return peopleSoftQualificationObject;
	}

	/**
	 * To (TODO some description about method)
	 *
	 * @param arg0
	 * @param arg1
	 * @return
	 * @throws JMSException
	 * @throws MessageConversionException
	 * @author xsat976
	 * @since Jun 30, 2017
	 */
	@Override
	public Message toMessage(Object arg0, Session arg1) throws JMSException, MessageConversionException {
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * This method is used to set the parsed xml value to
	 * peopleSoftQualificationBean bean.
	 * 
	 * @param response
	 * @return
	 * @throws XmlException
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	private PeopleSoftQualificationBean parseMessage(String response, final Integer psftNtfnDtlId) throws XmlException {

		PeopleSoftQualificationBean peopleSoftQualificationBean = null;

		logger.debug(" Inside parseMessage method :: Start :: Message  Obtained  is  : " + response
				+ ScoreConstants.DOUBLE_COLON + className);
		logger.debug(" Inside parseMessage Starts  :: " + className);

		HSCMedicalQualificationDetails medicalQualificationDetails =null;


		JAXBContext jaxbContext = null;
		try {
			jaxbContext = JAXBContext.newInstance(ObjectFactory.class);

			Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
			StringReader reader = new StringReader(response);
			medicalQualificationDetails = ((JAXBElement<HSCMedicalQualificationDetails>)jaxbUnmarshaller.unmarshal(reader)).getValue();

		} catch (JAXBException e1) {
			logger.error("Unable to create jaxbContext ", e1);
		} catch( Exception e ) {
			logger.error("Unable to create jaxbContext ", e);
		}


		if (medicalQualificationDetails != null) {

			HSCMedicalExamDetails medicalExamDetails = medicalQualificationDetails.getMedicalExamDetails();

			if (medicalExamDetails == null) {
				return null;
			} else {
				peopleSoftQualificationBean = new PeopleSoftQualificationBean();
				peopleSoftQualificationBean.setEventAction(ScoreConstants.INSERT); // set default insert action because of we use this action everywhere in existing code.

				if (medicalExamDetails.getPerson().getEmployeeId() != null && !medicalExamDetails.getPerson().getEmployeeId().equals(ScoreConstants.BLANK_VALUE)) {
					peopleSoftQualificationBean.setEmployeeId(medicalExamDetails.getPerson().getEmployeeId());
				}
				if (medicalExamDetails.getExamCode() != null && !medicalExamDetails.getExamCode().equals(ScoreConstants.BLANK_VALUE)) {
					peopleSoftQualificationBean.setExamCode(medicalExamDetails.getExamCode());
				}
				if (medicalExamDetails.isPassed()) {
					peopleSoftQualificationBean.setExamResult(FLAG_YES);
				} else {
					peopleSoftQualificationBean.setExamResult(FLAG_NO);
				}
				peopleSoftQualificationBean.setExamScore(0.0);

				if (medicalExamDetails.getDateTaken() != null) {
					peopleSoftQualificationBean.setEventDateTime(medicalExamDetails.getDateTaken().toGregorianCalendar());
				}
				peopleSoftQualificationBean.setPsftNtfnDtlId(psftNtfnDtlId);
			}
		} else {
			throw new XmlException(response);
		}

		logger.debug(" Inside parseMessage method Ends :: " + className);
		return peopleSoftQualificationBean;
	}


}
