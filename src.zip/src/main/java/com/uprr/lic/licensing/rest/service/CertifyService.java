package com.uprr.lic.licensing.rest.service;

import java.text.ParseException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uprr.lic.auth.EQMSUserBean;
import com.uprr.lic.auth.EQMSUserSession;
import com.uprr.lic.dataaccess.Licensing.model.EmployeeDetail;
import com.uprr.lic.dataaccess.Licensing.model.IssueStudentLicBean;
import com.uprr.lic.dataaccess.Licensing.model.PendingActionListGridDetail;
import com.uprr.lic.dataaccess.common.model.EqmEmplDtls;
import com.uprr.lic.dataaccess.common.model.EqmWorkItem;
import com.uprr.lic.dataaccess.common.model.Medical;
import com.uprr.lic.dataaccess.components.licensing.service.ILicensingService;
import com.uprr.lic.dataaccess.decertification.model.CertRideSummaryDetails;
import com.uprr.lic.exception.EqmDaoException;
import com.uprr.lic.exception.EqmException;
import com.uprr.lic.licensing.rest.model.IssueStudentLicBeanDetail;

/**
 * 
 * @author xsat956
 *
 */
@Service("certifyService")
public class CertifyService implements ICertifyService {

	@Autowired
	private ILicensingService licensingService;
	
	@Autowired
	EQMSUserSession eqmsUserSession;


	@Override
	public IssueStudentLicBeanDetail getEmployeeDetailsForIssueStudentLic(final EmployeeDetail employeeDetailBean, final String paramName) {
		
		IssueStudentLicBean  issueStuLicBean = licensingService.getEmployeeDetailsForIssueStudentLic(employeeDetailBean,employeeDetailBean.getLcnsOprnId(),employeeDetailBean.getStudReason(),paramName);
		return createStudentLicBeanDetailsResponse(issueStuLicBean)	;
	}


	private IssueStudentLicBeanDetail createStudentLicBeanDetailsResponse(IssueStudentLicBean objIssueStudentLicBean) {
		if(objIssueStudentLicBean == null) {
			return null;
		}
		IssueStudentLicBeanDetail licBeanDetail=new IssueStudentLicBeanDetail();
		licBeanDetail.setEmployeeName( objIssueStudentLicBean.getEmployeeName(  )  ) ; 
		licBeanDetail.setServiceUnit( objIssueStudentLicBean.getServiceUnit(  )  ) ; 
		licBeanDetail.setDateOfBirth( objIssueStudentLicBean.getDateOfBirth(  )  ) ; 
		licBeanDetail.setEffectiveDate( objIssueStudentLicBean.getEffectiveDate(  )  ) ; 
		licBeanDetail.setExpireDate( objIssueStudentLicBean.getExpireDate(  )  ) ; 
		licBeanDetail.setExistingLicDetails( objIssueStudentLicBean.getExistingLicDetails(  )  ) ; 
		licBeanDetail.setTestDetails( objIssueStudentLicBean.getTestDetails(  )  ) ; 
		licBeanDetail.setManagerName( objIssueStudentLicBean.getManagerName(  )  ) ; 
		licBeanDetail.setStartDate( objIssueStudentLicBean.getStartDate(  )  ) ; 
		licBeanDetail.setState( objIssueStudentLicBean.getState(  )  ) ; 
		licBeanDetail.setCity( objIssueStudentLicBean.getCity(  )  ) ; 
		licBeanDetail.setBulletinLocation( objIssueStudentLicBean.getBulletinLocation(  )  ) ; 
		licBeanDetail.setClassNumber( objIssueStudentLicBean.getClassNumber(  )  ) ; 
		licBeanDetail.setLicenseClassDescription( objIssueStudentLicBean.getLicenseClassDescription(  )  ) ; 
		licBeanDetail.setComment( objIssueStudentLicBean.getComment(  )  ) ; 
		licBeanDetail.setManagerTrainee( objIssueStudentLicBean.isManagerTrainee(  )  ) ; 
		licBeanDetail.setTeyExperience( objIssueStudentLicBean.isTeyExperience(  )) ; 
		licBeanDetail.setLblTeyExperience( objIssueStudentLicBean.getLblTeyExperience(  )  ) ; 
		licBeanDetail.setPinCodesforManagerTrainee( objIssueStudentLicBean.getPinCodesforManagerTrainee(  )  ) ; 
		licBeanDetail.setWorkItemId( objIssueStudentLicBean.getWorkItemId(  )  ) ; 
		licBeanDetail.setJobTypeCode( objIssueStudentLicBean.getJobTypeCode(  )  ) ; 
		licBeanDetail.setStudentLicenseFlag( objIssueStudentLicBean.isStudentLicenseFlag() ) ; 
		licBeanDetail.setTestId( objIssueStudentLicBean.getTestId(  )  ) ; 
		licBeanDetail.setLcnsRqmtId( objIssueStudentLicBean.getLcnsRqmtId(  )  ) ; 
		licBeanDetail.setSvcUnitId( objIssueStudentLicBean.getSvcUnitId(  )  ) ; 
		licBeanDetail.setQlfnCode( objIssueStudentLicBean.getQlfnCode(  )  ) ; 
		licBeanDetail.setValidClass1Lcns( objIssueStudentLicBean.getValidClass1Lcns(  )  ) ; 
		licBeanDetail.setFtxEvntTestId( objIssueStudentLicBean.getFtxEvntTestId(  )  ) ; 
		licBeanDetail.setErtCode( objIssueStudentLicBean.getErtCode(  )  ) ; 
		licBeanDetail.setAgrmntFlag( objIssueStudentLicBean.getAgrmntFlag(  )  ) ; 
		licBeanDetail.setEmployeeId( objIssueStudentLicBean.getEmployeeId(  )  ) ; 
		licBeanDetail.setLstUptdEmplId( objIssueStudentLicBean.getLstUptdEmplId(  )  ) ; 
		licBeanDetail.setLstUptdDate( objIssueStudentLicBean.getLstUptdDate(  )  ) ; 
		return licBeanDetail;
	}

	/**
	   * Classname / Method Name : LicensingServiceImpl/getStudentLcnsClass()
	   * 
	   * @param :
	   *          String
	   * @return : Integer
	   * @exception :
	   *              Description : Method is used to call the actual method from LicensingDao
	   */
	
	@Override
	public String getStudentLcnsClass(Integer oprnId) {
	    return licensingService.getStudentLcnsClass(oprnId);
	  }
	
	/**
	  * 
	  * To get valid work item
	  *
	  * @param workItemId
	  * @param histFlag
	  * @return
	  * @author xsat874
	  * @since Sep 18, 2016
	  * Added for SS_QC#4759
	  */
	@Override
	  public EqmWorkItem getValidWorkItem(final int workItemId, final boolean histFlag) {
	    return licensingService.getValidWorkItem(workItemId, histFlag);
	  }
	
	  /**
	   * @param studentLicBean
	   * @param emplId
	   * @param employeeDetailBean
	   * @return
	   */
	@Override
	 public IssueStudentLicBean validateCertifyStudentLicRequest(IssueStudentLicBean studentLicBean,
	      EmployeeDetail employeeDetailBean,boolean pendCertFlag){
		EQMSUserBean eqmsUserBean = eqmsUserSession.getUser();
		  return licensingService.validateCertifyStudentLicRequest(studentLicBean,eqmsUserBean.getEmplId(), employeeDetailBean, pendCertFlag);
	}
	
	/**
	   * @param studentLicBean
	   * @param employeeDetailBean
	   * @param crtnEmplId 
	   * @param crtnEmplId2 
	   * @return
	   * @throws Exception 
	   */
	  public IssueStudentLicBean issueLicense(IssueStudentLicBean studentLicBean, EmployeeDetail employeeDetailBean,
	      String reason,   boolean pendCertRide) { //Req#417
		  EQMSUserBean eqmsUserBean = eqmsUserSession.getUser();
	    return licensingService.issueLicense(studentLicBean, employeeDetailBean, reason, eqmsUserBean.getEmplId(),
	        pendCertRide); //Req#417
	  }
	  /**
	   * Classname / Method Name : LicensingServiceImpl/doesEmployeehasRequiredLicense()
	   * @param : employeeId
	   * @return : Boolean
	   * Description : Method is used to check wheather employee has 
	   * valid RCO(class 7 or class 6) or valid Hostler(class 5 or class 2) license and 
	   * employee is currently applying for Student Engineer license (class 3).
	   */
	  public Boolean doesEmployeehasRequiredLicense(final String employeeId,final String licClass) {
	    return licensingService.doesEmployeehasRequiredLicense(employeeId,licClass);
	  }
	  
	  /**
		 * Method to get an employee detail
		 * 
		 * @param aEmplId
		 * @return Object for an Employee
		 */
		public EqmEmplDtls getEmployee(final String aEmplId) throws EqmDaoException, EqmException
		{
			EqmEmplDtls eqmEmplDtls = null;
				eqmEmplDtls = licensingService.getEmplDtls(aEmplId);
			return eqmEmplDtls;
		}


	@Override
	public List<Medical> getRestrictionCodesList(String employeeID) {
		return licensingService.getRestrictionCodesList(employeeID);
	}


	@Override
	public CertRideSummaryDetails getSummaryDetail(String employeeId, Integer testId) {
		final CertRideSummaryDetails certRideSummaryDetails = licensingService.getSummaryDetail(employeeId, testId);
		return certRideSummaryDetails;
	}


	@Override
	public IssueStudentLicBean validateCertifyLicRequest(IssueStudentLicBean studentLicBean,
			EmployeeDetail employeeDetailBean, String reason) {
		// TODO Auto-generated method stub
		return licensingService.validateCertifyLicRequest(studentLicBean, employeeDetailBean, reason);
	}


	@Override
	public List<IssueStudentLicBean> certifyLicense(List<PendingActionListGridDetail> detailList, String paramName) {
		 EQMSUserBean eqmsUserBean = eqmsUserSession.getUser();
		try {
			return licensingService.certifyLicense(detailList,paramName,eqmsUserBean.getEmplId());
		} catch (ParseException e) {
			e.printStackTrace();
			return null;
			
		}
		
	}
	  
}
