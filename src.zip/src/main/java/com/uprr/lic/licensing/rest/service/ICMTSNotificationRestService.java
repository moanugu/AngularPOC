package com.uprr.lic.licensing.rest.service;

import java.util.List;

import com.uprr.lic.dataaccess.Licensing.model.LcnsDtlsObj;

/**
 * 
 * @author xsat956
 *
 */
public interface ICMTSNotificationRestService {
	//This code is oriented to licensing and started by xsat956(Girish)
	 
	  
	  /**
	   * 
	   * Classname / Method Name : ILicensingService/sendNtfnToCMTS()
	   * @param emplId
	   * @param lstlcnsClass
	   * Description :  This method is used to req398.
	   */
	  boolean sendNtfnToCMTS(final String emplId, final List<String> lstlcnsClass,final List<LcnsDtlsObj> lsLcnsDtlsObj);
	  
	  List<LcnsDtlsObj> getLicenseDetailsForEmpl(final String emplId);
	  //End By Girish
}
