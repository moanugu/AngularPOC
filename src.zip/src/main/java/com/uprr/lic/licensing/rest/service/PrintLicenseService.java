package com.uprr.lic.licensing.rest.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uprr.lic.auth.EQMSUserSession;
import com.uprr.lic.dataaccess.Licensing.model.PendingActionListGridDetail;
import com.uprr.lic.dataaccess.Licensing.model.PrintTemporaryLicense;
import com.uprr.lic.dataaccess.Licensing.model.PrintTemporaryLicenseGrid;
import com.uprr.lic.dataaccess.components.licensing.service.ILicensingService;
import com.uprr.lic.exception.EqmDaoException;
import com.uprr.lic.util.LicensingConstant;
import com.uprr.lic.util.SysParamBean;

/**
 * 
 * @author xsat004
 *
 */
@Service
public class PrintLicenseService implements IPrintLicenseService {

	@Autowired
	private ILicensingService licensingService;
	
	@Autowired
	private EQMSUserSession eqmsUserSession; 
		
	private static final String CLASSNAME = PrintLicenseService.class.getCanonicalName();
	private static final Logger logger = LoggerFactory.getLogger(PrintLicenseService.class);
	
	@Override
	public Boolean isExpnDateSameForAllLcns(String employeeId) {
		return licensingService.isExpnDateSameForAllLcns(employeeId);
	}

	@Override
	public PrintTemporaryLicense getPrintLicenseService(PrintTemporaryLicense employeeDetails, Integer choice,
			String employeeId, String printFlag) {
		return licensingService.getPrintLicenseService(employeeDetails,choice, employeeId, printFlag, eqmsUserSession.getUser().getEmplId());
	}

	@Override
	public Map<String, List<String>> updateLicenseMailedStatus(List<PrintTemporaryLicenseGrid> printTemporaryLicenseGrids) {
		Map<String, List<String>> successFailureMap = new HashMap<String, List<String>>();
		successFailureMap.put(LicensingConstant.SUCCESS_KEY, new ArrayList<String>());
		successFailureMap.put(LicensingConstant.FAILURE_KEY, new ArrayList<String>());
		// List is used to get the values from the grid
		Integer status = null;
		Iterator<PrintTemporaryLicenseGrid> iterator = printTemporaryLicenseGrids.iterator();
		// List is used to get employee Id's from the gridList
		
		Map<String, SysParamBean> map = licensingService.getSysParmMap();
		SysParamBean crewSysParamBean = map.get(LicensingConstant.CREW_SERVICE_MAILID);
		SysParamBean sernioritySysParamBean = map.get(LicensingConstant.SENIORITY_MAILID);
		String emailId[] = new String[2];
		
		if(null != crewSysParamBean && null != sernioritySysParamBean){
			emailId[0] = new String(crewSysParamBean.getParmValu());
			emailId[1] = new String(sernioritySysParamBean.getParmValu());
			
			while (iterator.hasNext()) {
				PrintTemporaryLicenseGrid printTemporaryLicenseGrid = iterator.next();
				try {					
					status = licensingService.updateLicenseMailedStatus(printTemporaryLicenseGrid, emailId,  eqmsUserSession.getUser().getEmplId());
				} catch (EqmDaoException e) {
					logger.error(CLASSNAME + LicensingConstant.LOGGER_EQMDAOEXCEP + " getLicenseMailedButton :: " + e.getMessage(), e);					
				} catch (Exception e) {
					logger.error(CLASSNAME + LicensingConstant.LOGGER_EQMEXCEPTION + " getLicenseMailedButton :: " + e.getMessage(), e);					
				}
				if (status == null) {
					List<String> employeeIdList = successFailureMap.get(LicensingConstant.FAILURE_KEY);
					employeeIdList.add(printTemporaryLicenseGrid.getEmployeeID());
					successFailureMap.put(LicensingConstant.FAILURE_KEY, employeeIdList);
	
				} else {
					List<String> employeeIdList = successFailureMap.get(LicensingConstant.SUCCESS_KEY);
					employeeIdList.add(printTemporaryLicenseGrid.getEmployeeID());
					successFailureMap.put(LicensingConstant.SUCCESS_KEY, employeeIdList);
				}				
			}
		}	
		
		return successFailureMap;
	}

	@Override
	public void removeWorkItemForPrintWorkItem(List<String> emplId, String printFlag, Integer modId) {
		licensingService.removeWorkItemForPrintWorkItem(emplId, printFlag, modId,eqmsUserSession.getUser().getEmplId() );
		
	}

	@Override
	public Boolean updatePendingActionPrintLicense(List<PendingActionListGridDetail> detailList) {
		return licensingService.updatePendingActionPrintLicense(detailList,eqmsUserSession.getUser().getEmplId());
	}

	@Override
	public Boolean getPrintStatusforGrndEmplWQ(String employeeId) {
		return licensingService.getPrintStatusforGrndEmplWQ(employeeId);
	}

		
}