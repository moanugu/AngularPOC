package com.uprr.lic.licensing.rest.service;

import java.util.List;

import com.uprr.lic.licensing.rest.model.CategoryInformationDetailResponse;
import com.uprr.lic.licensing.rest.model.CertRideSummaryResponse;

/**
 * 
 * @author xsat956
 *
 */
public interface ICertRideSummaryService {
	//This code is oriented to licensing and started by xsat956(Girish)
	CertRideSummaryResponse getSummaryDetail(String employeeId, Integer testId);
	
	CertRideSummaryResponse getAuditRideSummaryDetail(String employeeId, Integer sequenceNumber);
	
	List<CategoryInformationDetailResponse> getAuditRideCheckList(String employeeId, Integer sequenceNumber);
	  
	List<CategoryInformationDetailResponse> getCategoryInformationList(String employeeID, Integer testId);
	  //End By Girish
}
