package com.uprr.lic.licensing.rest.service;

import java.util.List;

import com.uprr.lic.dataaccess.common.model.EqmEmplDtls;
import com.uprr.lic.licensing.rest.model.TwicDetailResponse;

/**
 * 
 * @author xsat956
 *
 */
public interface ITwicRestService {
	//This code is oriented to licensing and started by xsat956(Girish)
	/**
	   * 
	   * Classname / Method Name : ITwicService/getEmplName()
	   * @param employeeID
	   * @return
	   * Description :  This method is used to employee details.
	   */
	  List<EqmEmplDtls> getEmplName(String employeeID);
	  /**
	   * 
	   * Classname / Method Name : ITwicService/submitTwicDetails()
	   * @param employeeGridList
	   * @param crtnEmplId
	   * @param serviceUntNbr
	   * Description :  This method is used to submit twic details
	   */
	  void submitTwicDetails(List<TwicDetailResponse> employeeGridList, Integer serviceUntNbr);
	  /**
	   * 
	   * Classname / Method Name : ITwicService/getTwicDtls()
	   * @param employeeID
	   * @return
	   * Description :  This method is used to get Twic details based on employee ID.
	   */
	   TwicDetailResponse getTwicDtls(String employeeID);
	  //End By Girish
}
