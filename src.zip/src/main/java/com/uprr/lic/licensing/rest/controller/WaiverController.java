package com.uprr.lic.licensing.rest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.uprr.lic.dataaccess.Licensing.model.WaiverDetails;
import com.uprr.lic.dataaccess.Licensing.model.WaiverGrid;
import com.uprr.lic.licensing.rest.model.LicensingRequest;
import com.uprr.lic.licensing.rest.service.IWaiverService;

@Controller
public class WaiverController {

	
	@Autowired
	private IWaiverService waiverService;
	
	@RequestMapping(value = "/licensing/getWaiverDetail", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public WaiverDetails getWaiverDetail(@RequestParam(value="employeeId", required=true) String employeeId) {
	    return waiverService.getWaiverDetail(employeeId);
	}
	
	@RequestMapping(value = "/licensing/unWaiveEmployeesLicense", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public List<WaiverGrid> unWaiveEmployeesLicense(@RequestBody LicensingRequest licensingRequest) {
	    return waiverService.unwaiveEmployeesLicense(licensingRequest.getWaiverItemList());
	}
	
	@RequestMapping(value = "/licensing/hasLicenseWaivedSuccessfully", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public List<WaiverGrid> hasLicenseWaivedSuccessfully(@RequestBody LicensingRequest licensingRequest) {
	    return waiverService.hasLicenseWaivedSuccessfully(licensingRequest.getWaiverItemList());
	}
	
}
