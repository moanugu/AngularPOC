package com.uprr.lic.licensing.rest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.uprr.lic.exception.EqmDaoException;
import com.uprr.lic.licensing.rest.model.EmpPacketStatusResponse;
import com.uprr.lic.licensing.rest.model.LicensingRequest;
import com.uprr.lic.licensing.rest.service.IEmployeePacketStatusService;

/**
 * This Controller is using for NDRReplyController
 * @author xsat956
 *
 */
@Controller
public class EmployeePacketStatusController {
	
	@Autowired
	private IEmployeePacketStatusService employeePacketStatusService;
	
	
	
	@RequestMapping(value = "/licensing/getEmpPackStatusListForEmpl/{employeeId}/{switchCase}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public List<EmpPacketStatusResponse> getEmpPackStatusListForEmpl(@PathVariable("employeeId") String employeeId, @PathVariable("switchCase") Integer switchCase){
	     return employeePacketStatusService.getEmpPackStatusListForEmpl(employeeId, switchCase);
	}
	
	
	@RequestMapping(value = "/licensing/cancelRevokeRequest", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public void cancelRevokeRequest(@RequestBody LicensingRequest licensingRequest) throws EqmDaoException{
	    employeePacketStatusService.cancelRevokeRequest(licensingRequest);
	}
	
	@RequestMapping(value = "/licensing/sendStatusReport", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public void sendStatusReport(@RequestBody LicensingRequest licensingRequest) throws EqmDaoException{
	    employeePacketStatusService.sendStatusReport(licensingRequest.getEmployeeIdList(), licensingRequest.getResnList(), licensingRequest.getMvrOrNdrValue());
	}
	
}
