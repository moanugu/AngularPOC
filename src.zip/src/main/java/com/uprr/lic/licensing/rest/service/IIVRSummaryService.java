package com.uprr.lic.licensing.rest.service;

import java.util.List;

import com.uprr.lic.dataaccess.common.model.IVRSummaryDetails;
import com.uprr.lic.licensing.rest.model.IVRSummary;

public interface IIVRSummaryService {
	
	String insertIVRSummary(IVRSummary ivrSummary);
	
	List<IVRSummaryDetails> searchIVRSummaryHistory(String emplId, String fromDate, String toDate);

}
