package com.uprr.lic.licensing.rest.service;

import java.util.List;

import com.uprr.lic.dataaccess.Licensing.model.Restriction;

/**
 * 
 * @author xsat956
 *
 */
public interface IRestrictionService {
	//This code is oriented to licensing and started by xsat956(Girish)
	  Restriction getEmployeeDetailsForRestriction(String employeeId);

	  Boolean insertEmpRestrictionData(Restriction restriction);

	  List<String> getRailRoadList();
	  //End By Girish
}
