package com.uprr.lic.licensing.rest.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uprr.lic.auth.EQMSUserBean;
import com.uprr.lic.auth.EQMSUserSession;
import com.uprr.lic.dataaccess.common.model.EqmLcnsInit;
import com.uprr.lic.dataaccess.components.licensing.service.ILicensingService;

/**
 * 
 * @author xsat956
 *
 */
@Service("printDocsService")
public class PrintDocsService implements IPrintDocsService {

	@Autowired
	private ILicensingService licensingService;
	
	@Autowired
	private EQMSUserSession eqmsUserSession;
	

	/**
	 * Modified Method at 12/13/2017 for SS_QC#10235
	 */
	@Override
	public List<String> insertPacketPrintingDetailsWithValidation(final String employeeId, final String comments) {
		
		String loggedInUser;
    if (eqmsUserSession!=null && eqmsUserSession.getUser()!=null) { // Added  Condition For SS_QC#10235
      EQMSUserBean eqmsUserBean = eqmsUserSession.getUser();
      loggedInUser = eqmsUserBean.getEmplId();
    }
    else{ // Added  Condition For SS_QC#10235
      loggedInUser=employeeId;
    }
    List<String> insertMsgList = licensingService.insertPacketPrintingDetailsWithValidation(employeeId, loggedInUser,comments);
		return insertMsgList;
	}


	@Override
	public String getEmployeesLicenseInitiationDetails(final Integer lcnsOprnId) {
		
		String startDate = licensingService.getEmployeesLicenseInitiationDetails(lcnsOprnId);
		return startDate;
	}

	@Override
	public String updatePendingActionMarkAsPacketSent(final String employeeID, final String licenseClass, final Integer reasonID,
		      final Integer workItemID, final Integer oprnId) {
		EQMSUserBean eqmsUserBean = eqmsUserSession.getUser();
		String successFlag = licensingService.updatePendingActionMarkAsPacketSent(employeeID, licenseClass, reasonID, workItemID,
		        oprnId, eqmsUserBean.getEmplId());
		return successFlag;
	}


	@Override
	public EqmLcnsInit getInitDtlsByOprnId(Integer lcnsOprnId) {
		return licensingService.getInitDtlsByOprnId(lcnsOprnId);
	}


	@Override
	public Map<Boolean, Integer> getOprnIdforExistingLicense(String emplId) {
		return licensingService.getOprnIdforExistingLicense(emplId);
	}


	@Override
	public Boolean isRecertificationInitiatedForEmployee(String employeeId, String licenseClassCode,
			Integer selection) {
		return licensingService.isRecertificationInitiatedForEmployee(employeeId, licenseClassCode, selection);
	}
	
}
