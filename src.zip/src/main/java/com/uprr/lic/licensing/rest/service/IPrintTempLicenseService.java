package com.uprr.lic.licensing.rest.service;

import com.uprr.lic.dataaccess.Licensing.model.TempLicenseTemplate;

/**
 * 
 * @author xsat004
 *
 */
public interface IPrintTempLicenseService {

	TempLicenseTemplate getTemporaryLicenseTemplateForPortal(String employeeId);

	Boolean getIlataPrint(String iLataNumber, String message);

}
