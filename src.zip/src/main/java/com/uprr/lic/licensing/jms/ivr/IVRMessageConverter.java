package com.uprr.lic.licensing.jms.ivr;

import java.io.StringReader;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.apache.xmlbeans.XmlException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jms.support.converter.MessageConversionException;
import org.springframework.jms.support.converter.MessageConverter;

import com.uprr.lic.dataaccess.components.licensing.hibernate.ivr.model.IVRRequestBean;
import com.uprr.lic.shared.xml_bindings.jaxb2.ivr.request.IvrRequest;

/**
 * To convert message in to corresponding java POJO.
 * 
 * @author xsat244
 * @since 27-Aug-2012
 * @see MessageConverter
 */
public class IVRMessageConverter implements MessageConverter {
	private static final Logger LOGGER = LoggerFactory.getLogger(IVRMessageConverter.class);

	@Override
	public Object fromMessage(Message message) throws JMSException, MessageConversionException {
		TextMessage textMessage = (TextMessage) message;
		IVRRequestBean ivrRequestBean;
		try {
			ivrRequestBean = getIvrRequestBean(textMessage.getText());
			ivrRequestBean.setCorrelationId(textMessage.getJMSCorrelationID());
		} catch (Exception ex) {
			ivrRequestBean = new IVRRequestBean();
		}
		return ivrRequestBean;
	}

	@Override
	public Message toMessage(Object objec, Session session) throws JMSException, MessageConversionException {
		return null;
	}

	/**
	 * To convert message into request bean.
	 *
	 * @param megAsText
	 *            text message received from JMS server.
	 * @return ivrRequestBean
	 * @throws XmlException
	 */
	private final IVRRequestBean getIvrRequestBean(final String megAsText) throws XmlException {
		
		IVRRequestBean ivrRequestBean = new IVRRequestBean();
		JAXBContext jaxbContext = null;
		try {
			jaxbContext = JAXBContext.newInstance(IvrRequest.class);

			Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
			StringReader reader = new StringReader(megAsText);
			IvrRequest ivrReply = (IvrRequest) jaxbUnmarshaller.unmarshal(reader);
			ivrRequestBean.setEmplId(ivrReply.getEmplId());
			ivrRequestBean.setRequestType(ivrReply.getRequestType());
		} catch (JAXBException e1) {
			LOGGER.error("Unable to create jaxbContext ", e1);
		}
		return ivrRequestBean;
	}
}