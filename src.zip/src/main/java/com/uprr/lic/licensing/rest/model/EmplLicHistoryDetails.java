package com.uprr.lic.licensing.rest.model;

import java.util.List;

import com.uprr.lic.dataaccess.Licensing.model.License;
import com.uprr.lic.dataaccess.Licensing.model.ManagerList;
import com.uprr.lic.dataaccess.Licensing.model.SleDesignationResult;

public class EmplLicHistoryDetails{

	private String managerId;

	private String employeeId;

	private String employeeName;

	private String serviceUnit;

	private String comments;

	private List<SleDesignationResult> sleDesignationResultList;

	private List<License> licenseList;

	private List<ManagerList> managerPopupList;

	private String initiatorName;

	private String initiatorId;

	private String revoke;

	private String dateOfBirth;

	private String issueDate;
	
	private String cmtsViewLink;

	private String disciplineHistoryLink;
	
	private String licenseHistoryLink;

	public String getLicenseHistoryLink() {
		return licenseHistoryLink;
	}

	public void setLicenseHistoryLink(String licenseHistoryLink) {
		this.licenseHistoryLink = licenseHistoryLink;
	}

	public String getManagerId() {
		return managerId;
	}

	public void setManagerId(String managerId) {
		this.managerId = managerId;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public String getServiceUnit() {
		return serviceUnit;
	}

	public void setServiceUnit(String serviceUnit) {
		this.serviceUnit = serviceUnit;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public List<SleDesignationResult> getSleDesignationResultList() {
		return sleDesignationResultList;
	}

	public void setSleDesignationResultList(List<SleDesignationResult> sleDesignationResultList) {
		this.sleDesignationResultList = sleDesignationResultList;
	}

	public List<License> getLicenseList() {
		return licenseList;
	}

	public void setLicenseList(List<License> licenseList) {
		this.licenseList = licenseList;
	}

	public List<ManagerList> getManagerPopupList() {
		return managerPopupList;
	}

	public void setManagerPopupList(List<ManagerList> managerPopupList) {
		this.managerPopupList = managerPopupList;
	}

	public String getInitiatorName() {
		return initiatorName;
	}

	public void setInitiatorName(String initiatorName) {
		this.initiatorName = initiatorName;
	}

	public String getInitiatorId() {
		return initiatorId;
	}

	public void setInitiatorId(String initiatorId) {
		this.initiatorId = initiatorId;
	}

	public String getRevoke() {
		return revoke;
	}

	public void setRevoke(String revoke) {
		this.revoke = revoke;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getIssueDate() {
		return issueDate;
	}

	public void setIssueDate(String issueDate) {
		this.issueDate = issueDate;
	}

	public String getCmtsViewLink() {
		return cmtsViewLink;
	}

	public void setCmtsViewLink(String cmtsViewLink) {
		this.cmtsViewLink = cmtsViewLink;
	}

	public String getDisciplineHistoryLink() {
		return disciplineHistoryLink;
	}

	public void setDisciplineHistoryLink(String disciplineHistoryLink) {
		this.disciplineHistoryLink = disciplineHistoryLink;
	}
	
	
}
