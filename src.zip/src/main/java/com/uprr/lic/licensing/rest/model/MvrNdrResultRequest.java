package com.uprr.lic.licensing.rest.model;

import com.uprr.lic.dataaccess.Licensing.model.MvrNdrReplyPopupDetail;

public class MvrNdrResultRequest {

	private  MvrNdrReplyPopupDetail mvrNdrPopupDtls;
	private String codeStr;
	private  Integer rqmtId;
	private  Integer serviceUnitNumber;
	
	public MvrNdrReplyPopupDetail getMvrNdrPopupDtls() {
		return mvrNdrPopupDtls;
	}
	
	public void setMvrNdrPopupDtls(MvrNdrReplyPopupDetail mvrNdrPopupDtls) {
		this.mvrNdrPopupDtls = mvrNdrPopupDtls;
	}
	
	public String getCodeStr() {
		return codeStr;
	}
	
	public void setCodeStr(String codeStr) {
		this.codeStr = codeStr;
	}
	
	
	public Integer getRqmtId() {
		return rqmtId;
	}
	
	public void setServiceUnitNumber(int serviceUnitNumber) {
		this.serviceUnitNumber = serviceUnitNumber;
	}
	
	public Integer getServiceUnitNumber() {
		return serviceUnitNumber;
	}
	
}
