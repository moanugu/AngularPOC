package com.uprr.lic.licensing.rest.service;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uprr.lic.auth.EQMSUserSession;
import com.uprr.lic.dataaccess.Licensing.model.InitiateReplaceLicenseBean;
import com.uprr.lic.dataaccess.components.licensing.service.ILicensingService;

/**
 * 
 * @author xsat956
 *
 */
@Service("replaceLicenseService")
public class ReplaceLicenseService implements IReplaceLicenseService {

	@Autowired
	private ILicensingService licensingService;
	
	@Autowired
	private EQMSUserSession eqmsUserSession;

	
	@Override
	public Set<String> isReplaceLicenseRequestInitiated(String employeeid) {
		return licensingService.isReplaceLicenseRequestInitiated(employeeid);
	}

	@Override
	public Integer insertReplaceLicenseWorkItemEntry(String reason,
			List<InitiateReplaceLicenseBean> details) {
		return licensingService.insertReplaceLicenseWorkItemEntry(reason, details, eqmsUserSession.getUser().getEmplId());
	}

	@Override
	public List<InitiateReplaceLicenseBean> getReplaceLicenseEmployeeDetails(
			String employeeId, Set<String> licClass) {
		InitiateReplaceLicenseBean replacePendingActionPrintWorkQueue = new InitiateReplaceLicenseBean();
		replacePendingActionPrintWorkQueue.setEmployeeID(employeeId);
		return licensingService.getReplaceLicenseEmployeeDetails(replacePendingActionPrintWorkQueue, licClass);
	}

	@Override
	public boolean isEmployeeLicenseValid(String employeeID) {
		return licensingService.isEmployeeLicenseValid(employeeID);
	}

	

}
