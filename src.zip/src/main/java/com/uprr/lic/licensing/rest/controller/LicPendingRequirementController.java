package com.uprr.lic.licensing.rest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.uprr.lic.dataaccess.Licensing.model.PendingRequirementResult;
import com.uprr.lic.dataaccess.Licensing.model.RulesExamCodeDetails;
import com.uprr.lic.decert.rest.model.DropdownChoice;
import com.uprr.lic.licensing.rest.model.EmplLicHistoryDetails;
import com.uprr.lic.licensing.rest.model.FTXExamSummaryDetailsResponse;
import com.uprr.lic.licensing.rest.model.LicensingRequirementRequest;
import com.uprr.lic.licensing.rest.model.MedicalDetailResponse;
import com.uprr.lic.licensing.rest.model.PendingRequirementRequest;
import com.uprr.lic.licensing.rest.model.PendingRequirementResponse;
import com.uprr.lic.licensing.rest.service.ILicPendingRequirementService;

/**
 * This Controller is using for LicencePendingRequest
 * @author xsat956
 *
 */
@Controller
public class LicPendingRequirementController {
	
	@Autowired
	private ILicPendingRequirementService licPendingRequirementService;
	
	@RequestMapping(value = "/licensing/getLicenseClassList", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public List<String> getLicenseClassList() {
	    return licPendingRequirementService.getLicenseClassList();
	}
	
	@RequestMapping(value = "/licensing/getPendingRequirementsList", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public List<String> getPendingRequirementsList() {
	    return licPendingRequirementService.getPendingRequirementsList();
	}
	
	@RequestMapping(value = "/licensing/getServiceUnitListByRegion/{regionNumber}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public List<DropdownChoice> getServiceUnitListByRegion(@PathVariable("regionNumber") Integer regionNumber) {
	    return licPendingRequirementService.getServiceUnitListByRegion(regionNumber);
	}
	
	@RequestMapping(value = "/licensing/isExistingEmployee/{employeeId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public boolean isExistingEmployee(@PathVariable("employeeId") String employeeId) {
	    return licPendingRequirementService.isExistingEmployee(employeeId);
	}

	@RequestMapping(value = "/licensing/getPendingRequirementsEmpDetailsList", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public List<PendingRequirementResponse> getPendingRequirementsEmpDetailsList(@RequestBody PendingRequirementRequest pendingRequirementRequest) {
	    return licPendingRequirementService.getPendingRequirementsEmpDetailsList(pendingRequirementRequest);
	}
	
	
	/**
	 *API for Employee License History Details PopUp
	 * @param pendingRequirementRequest
	 * @return
	 */
	@RequestMapping(value = "/licensing/getEmployeeLicHistoryDetails/{employeeId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public EmplLicHistoryDetails getEmployeeLicHistoryDetails(@PathVariable("employeeId") String employeeId) {
	    return licPendingRequirementService.getEmployeeLicHistoryDetails(employeeId);
	}
	
	/**
	 *A return medical response for rqmtId and licenseClassCode
	 * @param pendingRequirementRequest
	 * @return
	 */
	@RequestMapping(value = "/licensing/getMedicalResult/{rqmtId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public MedicalDetailResponse getMedicalResult(@PathVariable("rqmtId") Integer rqmtId) {
	    return licPendingRequirementService.getMedicalResult(rqmtId);
	}
	
	/**
	 *Return medical response for employeeId and licenseClassCode
	 * @param pendingRequirementRequest
	 * @return
	 */
	@RequestMapping(value = "/licensing/getMedicalResult/{employeeId}/{licenseClassCode}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public MedicalDetailResponse getMedicalResult(@PathVariable("employeeId") String employeeId, @PathVariable("licenseClassCode") String licenseClassCode) {
	    return licPendingRequirementService.getMedicalResult(employeeId, licenseClassCode);
	}
	
	
	@RequestMapping(value = "/licensing/getPinsForConductorLicense", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public String getPinsForConductorLicense(@RequestBody PendingRequirementResult pendingRequirementResult ) {
	    return licPendingRequirementService.getPinsForConductorLicense(pendingRequirementResult);
	}
	
	@RequestMapping(value = "/licensing/getRulesExamCodes/{employeeId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public List<RulesExamCodeDetails> getRulesExamCodes(@PathVariable("employeeId") String employeeId) {
	    return licPendingRequirementService.getRulesExamCodes(employeeId);
	}
	
	@RequestMapping(value = "/licensing/getEvaluationDetailsForConductor/{employeeId}/{testId}/{ftxEventId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public FTXExamSummaryDetailsResponse getEvaluationDetailsForConductor(@PathVariable("employeeId") String employeeId, @PathVariable("testId") Integer testId, @PathVariable("ftxEventId") Integer ftxEventId) {
	    return licPendingRequirementService.getEvaluationDetailsForConductor(employeeId, testId, ftxEventId);
	}
	
	
	@RequestMapping(value = "/licensing/cancelLicensingRequirement", method = RequestMethod.POST)
	@ResponseBody
	public boolean cancelLicensingRequirement(@RequestBody LicensingRequirementRequest licensingRequirement) {
	   return licPendingRequirementService.cancelLicensingRequirement(licensingRequirement.getPendingRequirementResultList(), licensingRequirement.getComments());
	}
	
	
	
	
}
