package com.uprr.lic.licensing.rest.controller;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.uprr.lic.dataaccess.Licensing.model.InitiateReplaceLicenseBean;
import com.uprr.lic.licensing.rest.model.LicensingRequest;
import com.uprr.lic.licensing.rest.service.IReplaceLicenseService;

/**
 * This Controller is using for ReplaceLicensingController
 * @author xsat956
 *
 */
@Controller
public class ReplaceLicensingController {
	
	@Autowired
	private IReplaceLicenseService replaceLicenseService;
	
	
	@RequestMapping(value = "/licensing/getReplaceLicenseEmployeeDetails", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public List<InitiateReplaceLicenseBean> getReplaceLicenseEmployeeDetails(@RequestParam(value="employeeId" , required=true) String employeeId) {
	    return replaceLicenseService.getReplaceLicenseEmployeeDetails(employeeId, replaceLicenseService.isReplaceLicenseRequestInitiated(employeeId));
	}
	
	
	@RequestMapping(value = "/licensing/isEmployeeLicenseValid", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public boolean isEmployeeLicenseValid(@RequestParam(value="employeeId" , required=true) String employeeId) {
	    return replaceLicenseService.isEmployeeLicenseValid(employeeId);
	}

	@RequestMapping(value = "/licensing/isReplaceLicenseRequestInitiated", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public Set<String> isReplaceLicenseRequestInitiated(@RequestParam(value="employeeId" , required=true) String employeeId){
	     return replaceLicenseService.isReplaceLicenseRequestInitiated(employeeId) ;
	}
	
	
	@RequestMapping(value = "/licensing/insertReplaceLicenseWorkItemEntry", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public Integer insertReplaceLicenseWorkItemEntry(@RequestParam(value="reason") String reason, @RequestBody LicensingRequest licensingRequest){
	     return replaceLicenseService.insertReplaceLicenseWorkItemEntry(reason, licensingRequest.getInitiateReplaceLicenseList());
	}
	
}
