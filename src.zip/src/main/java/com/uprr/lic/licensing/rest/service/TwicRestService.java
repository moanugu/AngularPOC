package com.uprr.lic.licensing.rest.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uprr.lic.auth.EQMSUserSession;
import com.uprr.lic.dataaccess.common.model.EqmEmplDtls;
import com.uprr.lic.dataaccess.twic.model.TwicBean;
import com.uprr.lic.dataaccess.twic.service.ITwicService;
import com.uprr.lic.licensing.rest.model.TwicDetailResponse;
import com.uprr.lic.util.DateUtil;

/**
 * 
 * @author xsat956
 *
 */
@Service("twicRestService")
public class TwicRestService implements ITwicRestService {

	@Autowired
	private ITwicService twicService;
	
	@Autowired
	private EQMSUserSession eqmsUserSession;


	@Override
	public List<EqmEmplDtls> getEmplName(String employeeID) {
		return twicService.getEmplName(employeeID);
	}

	@Override
	public void submitTwicDetails(List<TwicDetailResponse> employeeGridList, Integer serviceUntNbr) {
		twicService.submitTwicDetails(convertTwicDetailResponseListToTwicBeanList(employeeGridList), eqmsUserSession.getUser().getEmplId(), serviceUntNbr);
	}

	@Override
	public TwicDetailResponse getTwicDtls(String employeeID) {
		return convertTwicBeanToTwicDetailResponse(twicService.getTwicDtls(employeeID));
	}

	private TwicDetailResponse convertTwicBeanToTwicDetailResponse(TwicBean twicBean) {
		if(twicBean == null) {
			return null;
		}
		TwicDetailResponse detailResponse = new TwicDetailResponse();
		detailResponse.setEmpFirstName(twicBean.getEmpFirstName());
		detailResponse.setEmpLastName(twicBean.getEmpLastName());
		detailResponse.setEmployeeID(twicBean.getEmployeeID());
		detailResponse.setEmployeeName(twicBean.getEmployeeName());
		detailResponse.setEmpMiddleName(twicBean.getEmpMiddleName());
		detailResponse.setExpireDate(DateUtil.getDateAsString(twicBean.getExpireDate()));
		detailResponse.setRenewCheckbox(twicBean.isRenewCheckbox());
		detailResponse.setUpdateFlag(twicBean.isUpdateFlag());
		return detailResponse;
		
	}
	
	
	private List<TwicBean> convertTwicDetailResponseListToTwicBeanList(List<TwicDetailResponse> twicDetailResponseList) {
		
		List<TwicBean> employeeGridList = new ArrayList<TwicBean>();
		
		if(twicDetailResponseList == null) {
			return employeeGridList;
		}
		
		for(TwicDetailResponse twicDetailResponse: twicDetailResponseList) {
			
			TwicBean twicBean = new TwicBean();
			twicBean.setEmpFirstName(twicDetailResponse.getEmpFirstName());
			twicBean.setEmpLastName(twicDetailResponse.getEmpLastName());
			twicBean.setEmployeeID(twicDetailResponse.getEmployeeID());
			twicBean.setEmployeeName(twicDetailResponse.getEmployeeName());
			twicBean.setEmpMiddleName(twicDetailResponse.getEmpMiddleName());
			twicBean.setExpireDate(DateUtil.getDateFromString(twicDetailResponse.getExpireDate(), "yyyy-MM-dd'T'HH:mm:ss.SSSXXX"));
			twicBean.setRenewCheckbox(twicDetailResponse.isRenewCheckbox());
			twicBean.setUpdateFlag(twicDetailResponse.isUpdateFlag());
			
			
			employeeGridList.add(twicBean);
		}
		return employeeGridList;
	}
}
