package com.uprr.lic.licensing.jms.ivr;

import org.springframework.beans.factory.annotation.Autowired;

import com.uprr.lic.dataaccess.components.licensing.hibernate.ivr.model.IVRRequestBean;

/**
 * To delegate IVR processing request for EQMS.
 * 
 * @author xsat244
 * @since 27-Aug-2012
 */
public class IVRDelegate {
	@Autowired
	private IVRService ivrService;

	/**
	 * To process request received by EQMS in designated queue. A default method
	 * invoked by the JMS listener to process the IVR request.
	 * 
	 * @author xsat244
	 * @param ivrRequestBean
	 *            a request java bean containing all the required information
	 *            needed to process the request.
	 * @since 06-August-2012
	 */
	public void processIvrRequest(final IVRRequestBean ivrRequestBean) {
		ivrService.processIvrRequest(ivrRequestBean);
	}

	/**
	 * @return the ivrService
	 */
	public IVRService getIvrService() {
		return ivrService;
	}

	/**
	 * @param ivrService
	 *            the ivrService to set
	 */
	public void setIvrService(IVRService ivrService) {
		this.ivrService = ivrService;
	}
}
