package com.uprr.lic.licensing.rest.controller;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.velocity.exception.ParseErrorException;
import org.apache.velocity.exception.ResourceNotFoundException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.MethodInvocationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.xml.sax.SAXException;

import com.itextpdf.text.DocumentException;
import com.uprr.lic.dataaccess.Licensing.model.PdfPageSessionDetails;
import com.uprr.lic.dataaccess.Licensing.model.PendingActionListGridDetail;
import com.uprr.lic.dataaccess.Licensing.model.PrintTemporaryLicense;
import com.uprr.lic.dataaccess.Licensing.model.PrintTemporaryLicenseGrid;
import com.uprr.lic.licensing.rest.service.IPrintLicenseService;
import com.uprr.lic.licensing.rest.service.PDFPageService;
import com.uprr.lic.util.LicensingConstant;

@Controller
public class PrintLicenseController {

	private static final Logger logger = LoggerFactory.getLogger(PrintLicenseController.class);
	
	@Autowired
	private IPrintLicenseService printLicenseService;
	
	@Autowired
	private PDFPageService pdfPageService;
	
	
	@RequestMapping(method = RequestMethod.GET, value = "/licensing/isExpnDateSameForAllLcns/{employeeId}", produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public Boolean isExpnDateSameForAllLcns(@PathVariable String employeeId) {
		return printLicenseService.isExpnDateSameForAllLcns(employeeId);
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "/licensing/getPrintLicenseService", produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public PrintTemporaryLicense getPrintLicenseService(@RequestBody PrintTemporaryLicense employeeDetails,@RequestParam Integer choice,
			@RequestParam String employeeID,@RequestParam String printFlag) {
		return printLicenseService.getPrintLicenseService(employeeDetails,choice, employeeID, printFlag);
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "/licensing/updateLicenseMailedStatus", produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	 public Map<String, List<String>> updateLicenseMailedStatus(@RequestBody List<PrintTemporaryLicenseGrid> printTemporaryLicenseGrids) {
		    return printLicenseService.updateLicenseMailedStatus(printTemporaryLicenseGrids);
	}
	
	
	@RequestMapping(method = RequestMethod.POST, value = "/licensing/removeWorkItemForPrintWorkItem", produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	 public void removeWorkItemForPrintWorkItem(@RequestBody List<String> emplId, @RequestParam String printFlag, @RequestParam Integer modId){
		printLicenseService.removeWorkItemForPrintWorkItem(emplId, printFlag, modId);
	 }
	
	
	@SuppressWarnings("unchecked")
	@RequestMapping(method = RequestMethod.POST, value="/licensing/generatePdf")
	public  void  generatePdf(@RequestBody PdfPageSessionDetails pdfPageSessionDetails, HttpServletRequest  request, HttpServletResponse response) {
		logger.warn("print licensing controller");
		if(null != pdfPageSessionDetails){
			try {
				ByteArrayOutputStream baos = pdfPageService.generatePdf(pdfPageSessionDetails);
				String fileName="licensing";
				response.setContentType("application/pdf");
		        response.setHeader("Content-Disposition", "inline;filename="+fileName );
		        ServletOutputStream responseOutputStream = null;
	       	        
	    	    byte[] byteOutput = null;
	    	    if(null != baos){
	    	    	byteOutput = baos.toByteArray();
	    	    	responseOutputStream = response.getOutputStream();
	    	    }
		        if(null!= byteOutput){ 
		        responseOutputStream.write(byteOutput); 
	
		        }else{
		        responseOutputStream.write("Error While getting Document, Please Try after some time".getBytes());
		        }
		        
			} catch (DocumentException de) {
			      logger.error(LicensingConstant.LOGGER_DOCUMENT_EXCEPTION + LicensingConstant.PDFPAGE_LOGGER_COMMENT + de.getMessage(), de);		      
			    } catch (ParserConfigurationException pce) {
			      logger.error(LicensingConstant.LOGGER_PARSERCONFIGURATION_EXCEPTION + LicensingConstant.PDFPAGE_LOGGER_COMMENT + pce.getMessage(), pce);
			    } catch (SAXException saxe) {
			      logger.error(LicensingConstant.LOGGER_SAX_EXCEPTION + LicensingConstant.PDFPAGE_LOGGER_COMMENT + saxe.getMessage(), saxe);
			    } catch (IOException io) {
			      logger.error(LicensingConstant.LOGGER_IO_EXCEPTION + LicensingConstant.PDFPAGE_LOGGER_COMMENT + io.getMessage(), io);
			    } catch (ResourceNotFoundException rnfe) {
			      logger.error(LicensingConstant.LOGGER_RESOURCENOTFOUND_EXCEPTION + LicensingConstant.PDFPAGE_LOGGER_COMMENT + rnfe.getMessage(), rnfe);
			    } catch (ParseErrorException pe) {
			      logger.error(LicensingConstant.LOGGER_PARSEERROR_EXCEPTION + LicensingConstant.PDFPAGE_LOGGER_COMMENT + pe.getMessage(), pe);
			    } catch (MethodInvocationException mie) {
			      logger.error(LicensingConstant.LOGGER_METHODINVOKATION_EXCEPTION + LicensingConstant.PDFPAGE_LOGGER_COMMENT + mie.getMessage(), mie);
			    } catch (Exception e) {
			      e.printStackTrace();
			      logger.error(LicensingConstant.LOGGER_EQMEXCEPTION + LicensingConstant.PDFPAGE_LOGGER_COMMENT + e.getMessage(), e);
		    }
		}
    }
	
	/**
	 * Generate PDF for MyUP POrtal 
	 * @param pdfPageSessionDetails
	 * @param request
	 * @param response
	 * Added for SS_QC#10235
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(method = RequestMethod.POST, value="/licensing/myup/generatePdf")
	public  void  generateMyupPdf(@RequestBody PdfPageSessionDetails pdfPageSessionDetails, HttpServletRequest  request, HttpServletResponse response) { // Added  Method For SS_QC#10235
	  this.generatePdf(pdfPageSessionDetails, request, response);
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "/licensing/updatePendingActionPrintLicense", produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public Boolean updatePendingActionPrintLicense(@RequestBody List<PendingActionListGridDetail> detailList){
		return printLicenseService.updatePendingActionPrintLicense(detailList);
	 }
	
	@RequestMapping(method = RequestMethod.GET, value = "/licensing/getPrintStatusforGrndEmplWQ/{employeeId}", produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public Boolean getPrintStatusforGrndEmplWQ(@PathVariable String employeeId) {
		return printLicenseService.getPrintStatusforGrndEmplWQ(employeeId);
	}
	
	@SuppressWarnings("unchecked")
	@RequestMapping(method = RequestMethod.POST, value="/licensing/generatePdfWQ")
	@ResponseBody
	public  byte[]  generatePdf(@RequestBody PdfPageSessionDetails pdfPageSessionDetails) {
		logger.warn("print licensing controller");
		byte[] byteOutput = null;
		if(null != pdfPageSessionDetails){
			try {
				if(pdfPageSessionDetails.getEmplIdList() != null && pdfPageSessionDetails.getEmplIdList().size() == 0){
				pdfPageSessionDetails.getEmplIdList().add("");
				} 
				ByteArrayOutputStream baos = pdfPageService.generatePdf(pdfPageSessionDetails);
	    	    if(null != baos){
	    	    	byteOutput = baos.toByteArray();
	    	    }
		         return byteOutput;

			} catch (DocumentException de) {
			      logger.error(LicensingConstant.LOGGER_DOCUMENT_EXCEPTION + LicensingConstant.PDFPAGE_LOGGER_COMMENT + de.getMessage(), de);		      
			    } catch (ParserConfigurationException pce) {
			      logger.error(LicensingConstant.LOGGER_PARSERCONFIGURATION_EXCEPTION + LicensingConstant.PDFPAGE_LOGGER_COMMENT + pce.getMessage(), pce);
			    } catch (SAXException saxe) {
			      logger.error(LicensingConstant.LOGGER_SAX_EXCEPTION + LicensingConstant.PDFPAGE_LOGGER_COMMENT + saxe.getMessage(), saxe);
			    } catch (IOException io) {
			      logger.error(LicensingConstant.LOGGER_IO_EXCEPTION + LicensingConstant.PDFPAGE_LOGGER_COMMENT + io.getMessage(), io);
			    } catch (ResourceNotFoundException rnfe) {
			      logger.error(LicensingConstant.LOGGER_RESOURCENOTFOUND_EXCEPTION + LicensingConstant.PDFPAGE_LOGGER_COMMENT + rnfe.getMessage(), rnfe);
			    } catch (ParseErrorException pe) {
			      logger.error(LicensingConstant.LOGGER_PARSEERROR_EXCEPTION + LicensingConstant.PDFPAGE_LOGGER_COMMENT + pe.getMessage(), pe);
			    } catch (MethodInvocationException mie) {
			      logger.error(LicensingConstant.LOGGER_METHODINVOKATION_EXCEPTION + LicensingConstant.PDFPAGE_LOGGER_COMMENT + mie.getMessage(), mie);
			    } catch (Exception e) {
			      e.printStackTrace();
			      logger.error(LicensingConstant.LOGGER_EQMEXCEPTION + LicensingConstant.PDFPAGE_LOGGER_COMMENT + e.getMessage(), e);
		    }
		}
		return byteOutput;
    } 
}
