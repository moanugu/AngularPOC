/**
 * 
 */
package com.uprr.lic.licensing.rest.service;

import java.util.List;

import com.uprr.lic.dataaccess.common.model.EqmAudDtls;
import com.uprr.lic.dataaccess.common.model.EqmAudRcdDtls;
import com.uprr.lic.licensing.rest.model.AuditCertRecertRequest;

/**
 * @author xsat976
 *
 */
public interface IAuditCertRecertRestService {

	List<EqmAudRcdDtls> searchInitiateAuditRecords(AuditCertRecertRequest auditCertRecertRequest);

	List<EqmAudDtls> searchAuditRecord(AuditCertRecertRequest auditCertRecertRequest);

	List<EqmAudRcdDtls> getAuditRecordsById(final Integer audDtlsId);

	EqmAudDtls insertAuditRecords(AuditCertRecertRequest auditCertRecertRequest);

	boolean markAuditStatus(AuditCertRecertRequest auditCertRecertRequest);
	
	byte[] exportToExcelAuditRecord(final Integer audDtlsId);
}
