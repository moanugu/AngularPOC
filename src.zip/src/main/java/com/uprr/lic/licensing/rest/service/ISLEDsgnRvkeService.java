package com.uprr.lic.licensing.rest.service;

import java.text.ParseException;
import java.util.Calendar;
import java.util.List;

import com.uprr.lic.dataaccess.Licensing.model.Designate;
import com.uprr.lic.dataaccess.Licensing.model.DesignationRequirement;
import com.uprr.lic.dataaccess.Licensing.model.License;
import com.uprr.lic.dataaccess.Licensing.model.ManagerList;
import com.uprr.lic.dataaccess.Licensing.model.SLERevokeDesignation;
import com.uprr.lic.dataaccess.Licensing.model.SleDesignateInitReq;
import com.uprr.lic.dataaccess.Licensing.model.SleDesignationRequest;
import com.uprr.lic.dataaccess.Licensing.model.SleDesignationResult;
import com.uprr.lic.dataaccess.common.model.EqmEmplSleDsgn;
import com.uprr.lic.dataaccess.common.model.EqmLcnsOprn;
import com.uprr.lic.dataaccess.workflow.impl.EqmsWorkItemBean;
import com.uprr.lic.decert.rest.model.DesignateResponse;
import com.uprr.lic.exception.EqmDaoException;
import com.uprr.lic.util.DDChoice;

public interface ISLEDsgnRvkeService {
	
	  /**
	   * Classname / Method Name : LicensingDelegate/getDesignationRequirement()
	   * @param 		: designate
	   * @return 		: List<DesignationRequirement>
	   * @throws 		: HibernateException, SQLException
	   * Description 	: Method is used to get Designation requirements.
	   */
	  public List<DesignationRequirement> getDesignationRequirement(Designate designate) ;
	  
	  /**
	   * Classname / Method Name : ILicensingService/getDesignateEmployeeLicenseDtls()
	   * @param 		: designate
	   * @return 		: List<License>
	   * Description 	: Method is used to get Existing License Details
	   */
	  List<License> getDesignateEmployeeLicenseDtls(Designate designate);

	  /**
	   * Classname / Method Name : ILicensingService/getDesignationInitiatorDetails()
	   * @param 		: designate
	   * @return 		: List<Designate>
	   * Description 	: Method is used to get Initiator Details
	   */
	  List<Designate> getDesignationInitiatorDetails(Designate designate);
	  /**
	   * @return
	   * @throws EqmDaoException
	   * @throws Exception
	   */
	  List<DDChoice> getAllServiceUnitList();
	  
	  /**
	   * Classname / Method Name : ILicensingService/getManagers()
	   * @param svcNbr
	   * @param lcnsClass
	   * @return : List<DDChoice>
	   * Description : Method is used to get the Manager for given service unit and license class
	   */
	  List<DDChoice> getManagers(int svcNbr, String lcnsClass);
	  
	  /**
	   * @param managerId
	   * @return
	   */
	  String getDSCount(String managerId);

	  /**
	   * Classname / Method Name : ILicensingService/designateEmployee()
	   * @param 		: designate, creationEmplId
	   * @return 		: Object
	   * @throws 		: HibernateException, SQLException, Exception
	   * Description 	: Method is used to designate employee
	   */
	  Object designateEmployee(Designate designate);
	  
	  /**
	   * Classname / Method Name : ILicensingService / getEmployeeDetailsForRevokeInitiation()
	   * @param   		: employeeId
	   * @return    	: SLERevokeDesignationPageBean
	   * Description  	: Method is used to get call actual method from LicensingDao
	   */
	  SLERevokeDesignation getEmployeeDetailsForRevokeInitiation(String employeeId);

	  /**
	   * Classname / Method Name : ILicensingService / getDesignationDetailsForRevokeInitiation()
	   * @param   		: employeeId, status
	   * @return    	: List<SleDesignationResult>  
	   * Description  	: Method is used to call actual method in LicensingDao
	   */
	  List<SleDesignationResult> getDesignationDetailsForRevokeInitiation(String employeeId, String status);

	  /**
	   * Classname / Method Name : ILicensingService / getWorkItemForRevoke()
	   * @param   : workItemId
	   * @return    : EqmsWorkItemBean  
	   * @exception : Exception
	   * Description  : Method is used to call actual method in LicensingDao
	   */
	  EqmsWorkItemBean getWorkItemForRevoke(Integer workItemId);

	  /**
	   * Classname / Method Name : ILicensingService / getInitiaterDetailsForRevoke()
	   * @param   		: revokeDesignationPageBean, workItemId
	   * @return    	: revokeDesignationPageBean 
	   * @exception 	: Exception
	   * Description  	: Method is used to get actual method from LicensingDao
	   */
	  SLERevokeDesignation getInitiatorDetailsForRevoke(SLERevokeDesignation revokeDesignationPageBean, Integer workItemId);

	  /**
	   * Classname / Method Name : ILicensingService / getComment() 
	   * @param     : licOprnId
	   * @return    : comment
	   * @exception   :
	   * @description : Method used to call actual database interaction method from LicensingDao
	   */
	  String getComment(final int licOprnId) ;

	  /**
	   * Classname / Method Name : ILicensingService / getDesignationDetailsListForRevokePage()
	   * @param     	: eqmsWorkItemBean
	   * @return    	: List<SleDesignationResult>
	   * @description 	: Method is used call the database interaction method in LicensingDao
	   */
	  List<SleDesignationResult> getDesignationDetailsListForRevokePage(String employeeId, String licClass);

	  /**
	   * Classname / Method Name : ILicensingService / insertForRevoke  
	   * @param     : workItemId, eqmsWorkItemBean, initiatorId, crtnId
	   * @return    : Boolean
	   * @exception   : Exception
	   * @description : Method used to get database interaction method from LicensingDao
	   */
	  DesignateResponse insertForRevoke(EqmsWorkItemBean eqmsWorkItemBean, String initiatorId);
	  
	  /**
	   * Classname / Method Name : ILicensingService / insertSleRevokeInitiationRequest()
	   * @param   		: arrayList, employeeId, comments, crtnId, workItemId
	   * @return    	: Boolean 
	   * @exception 	: Exception
	   * Description  	: Method is used to call actual method in LicensingDao
	   */
	  Boolean insertSleRevokeInitiationRequest(List<SleDesignationResult> arrayList, String employeeId, String comments);
	  
	  /**
	   * Classname / Method Name : ILicensingService/isRevokeInitiated() 
	   * @param     	: employeeId
	   * @return    	: String
	   * Description  	: Method is used to call database validation method from LiceningDao
	   */
	  String isRevokeInitiatedForEmployee(String employeeId);
	  
	  /**
	   * This method is to check whether minimum requirements met for DSLE/DSRCo.
	   *
	   * @param employeeId
	   * @param isDsleChecked
	   * @param isDsrcoChecked
	   * @return List<String>
	   * @author xsat671
	   * @since Mar 4, 2016 Modified for REQ#578.
	   */
	  List<String> isEmployeeMeetMinimumDesignationRequirement(String employeeId, final boolean isDsleChecked,
	      final boolean isDsrcoChecked);

	  /**
	   * Classname / Method Name : ILicensingService/getDesignateRequestInitiationDetails()
	   * @param         : sleDesignateInitReqBean
	   * @return        : List<EqmLcnsOprn>
	   * Description	: Method used to call Database validation method from dao
	   */
	  List<EqmLcnsOprn> getDesignateRequestInitiationDetails(String employeeId);

	  /**
	   * To get employee already Designated details. Changes just to add proper method level comment. Did along with
	   * REQ#578. No else modification has been done.
	   *
	   * @param employeeDetailsBean
	   * @return List<EqmEmplSleDsgn>
	   * @author xsat671
	   * @since Mar 4, 2016.
	   */
	  List<EqmEmplSleDsgn> getAlreadyDesignatedEmployeeDetails(String employeeId);

	  /**
	   * Classname / Method Name: ILicensingService/getSLEDesignationInitiateEmpDetails() 
	   * @param     	: sleDesignateInitReqBean
	   * @return    	: SleDesignateInitReq
	   * Description  	: Method used to call the actual method from LicensingDao
	   */
	  SleDesignateInitReq getSLEDesignationInitiateEmpDetails(String employeeId);

	  /**
	   * Classname / Method Name : ILicensingService/getDesignationRequirementsForInitiation()
	   * @param 		: sleDesignateInitReqBean, webApplication
	   * @return 		: List<SleDesignationRequest>
	   * Description 	: Method is used to call a method in LicensingDao for getting Designation requirements
	   */
	  List<SleDesignationRequest> getDesignationRequirementsForInitiation(SleDesignateInitReq sleDesignateInitReqBean, Calendar rxmlTrainingDate);

	 
	  /**
	   * Method used to call actual method in LicensingDao
	   *
	   * @param DSLE
	   * @param DSRCO
	   * @param employeeId
	   * @param crtnEmplId
	   * @param resultList
	   * @return Boolean
	   * @throws ParseException
	   * @author xsat671
	   * @since Jun 16, 2016. Modified for SS_QC#6108: Changed the parameter type and removed existing PMD issue by changing
	   * the name of DSLE and DSRCO in lower case.
	   */
	  Boolean insertSLEDesignateInitiateRequest(String dsle, String dsrco, String employeeId,
	      List<SleDesignationRequest> designationDtlList) throws ParseException;
	  
	  /**
	   * Classname / Method Name : ILicensingService/isEmployeeSelectedFromAutoCompleteListForRevokeInitiation()
	   * @param : employeeId
	   * @return : Boolean
	   * Description : Method is used to check verify the conditions for being added in AutoComplete List
	   */
	  public Boolean isEmployeeSelectedFromAutoCompleteListForRevokeInitiation(String employeeId);

	  /**
	   * Classname / Method Name : ILicensingService/isRevokeDesignationInitiatedForEmployee()
	   * @param : employeeId
	   * @return : String
	   * Description : Method is used to check weather the revoke request for an employee already intiated 
	   * and if yes for which designation i.e. DSLE/DSRCO
	   */
	  public String isRevokeDesignationInitiatedForEmployee(final String employeeId);
	  
	  /**
	   * Classname / Method Name : ILicensindService / getDesignatedEmployeeDetailsListForRevokeInitiation()
	   * @param   		: employeeId
	   * @return    	: List<ManagerPopupBean> 
	   * Description  	: Method is used to call the actual method from LicensingDao
	   */
	  List<ManagerList> getDesignatedEmployeeDetailsListForRevokeInitiation(String employeeId);
	  
	  /**
	   * Classname / Method Name : ILicensingService/isDsleOrDsrco()
	   * @param     	: employeeId
	   * @return    	: Boolean
	   * Description  	: Method is used to call database validation method from LicensingDao
	   */
	  Boolean isDsleOrDsrco(String employeeId);
	  
	  String viewDisciplineHistoryLink(String employeeId);
	  
	  /**
	    * 
	    * Classname / Method Name : EqmsUtil/viewEmpLicenseHist()
	    * @param employeeID
	    * @return
	    * Description :  This method is used for QC#800
	    */
	   public  String viewEmpLicenseHist(String employeeID);
	   
	   public  String viewCMTSLink();
	   
	   public  Calendar getRXMLTrainingDateFromService(String employeeID);
}
