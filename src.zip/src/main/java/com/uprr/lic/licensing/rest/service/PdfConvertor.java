/**
 * Classname	  : PdfConvertor
 * Description  : Class is used to convert Template into the PDF format
 * author       : Satyam Computers Private Ltd.
 * Date of creation	:
 * Change History
 * ------------------------------------------------------------	
 *  Date          Changed By  	   Description
 * ------------------------------------------------------------	
 *  29-Feb-2012   xsat244          Req#193
 *  14-June-2013  xsat508          Req#439
 *  09/02/2015    xsat030          QC 1641
 * ------------------------------------------------------------ 
 *
 * Copyright notice : "Copyright � UPRR 2008"
 */
package com.uprr.lic.licensing.rest.service;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.StringWriter;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.xml.sax.SAXException;

import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Element;
import com.lowagie.text.Image;
import com.lowagie.text.PageSize;
import com.lowagie.text.Rectangle;
import com.lowagie.text.pdf.PdfCopy;
import com.lowagie.text.pdf.PdfReader;
import com.lowagie.text.pdf.PdfWriter;
import com.lowagie.text.xml.TagMap;
import com.uprr.lic.decert.handler.CustomTagHandler;
import com.uprr.lic.exception.EqmDaoException;

@Service
public class PdfConvertor {

  private static final Logger m_logger = LoggerFactory.getLogger(PdfConvertor.class);

  private static final String m_className = PdfConvertor.class.getCanonicalName();

  private TagMap customMap = null;

  public PdfConvertor() {
    if (customMap == null) {
      customMap = new TagMap(getClass().getClassLoader().getResourceAsStream("tagmap.xml"));
    }
  }

  /**
   * Classname / Method Name : PdfConvertor / getPdf()
   * 
   * @param :
   *          stringWriter
   * @return : ByteArrayOutputStream
   * @exception :
   *              DocumentException, ParserConfigurationException, SAXException, IOException Description : Method is
   *              used to convert Template into the PDF document
   */
  public ByteArrayOutputStream getPdf(StringWriter stringWriter) throws DocumentException, ParserConfigurationException, SAXException, IOException {
    ByteArrayOutputStream baos = new ByteArrayOutputStream();
    /** *************************************************************************************** */
    Document doc = new Document(PageSize.A4);
    // step 2: create a writer that listens to the document
    PdfWriter writer = PdfWriter.getInstance(doc, baos);
    doc.open();
    // step 3: we create a parser and set the document handler
    SAXParser parser = SAXParserFactory.newInstance().newSAXParser();
    CustomTagHandler cth = new CustomTagHandler(doc, writer, customMap);
    ByteArrayInputStream bais = new ByteArrayInputStream(stringWriter.toString().getBytes());
    // step 4: we parse the document
    parser.parse(bais, cth);
    writer.flush();
    doc.close();
    return baos;
  }

  /**
   * Classname / Method Name : PdfConvertor / getPdf()
   * 
   * @param :
   *          stringWriter, image
   * @return : ByteArrayOutputStream
   * @exception :
   *              DocumentException, ParserConfigurationException, SAXException, IOException Description : Method is
   *              used to write Template data and image into the PDF document for License Template
   */
  public ByteArrayOutputStream getPdf(StringWriter stringWriter, byte[] image) throws DocumentException, ParserConfigurationException, SAXException, IOException {
    ByteArrayOutputStream baos = new ByteArrayOutputStream();
    if (stringWriter != null) {
      /** *************************************************************************************** */
      Document doc = new Document(new Rectangle(250, 160), 10, 10, 10.8f, 10);// (new
//      Document doc = new Document(new Rectangle(PageSize.A4), 10, 10, 10, 10);
      // Rectangle(230,120),1,1,1,1)
      // step 2: create a writer that listens to the document
      PdfWriter writer = PdfWriter.getInstance(doc, baos);
      doc.open();
      // step 3: we create a parser and set the document handler
      SAXParser parser = SAXParserFactory.newInstance().newSAXParser();
      CustomTagHandler cth = new CustomTagHandler(doc, writer, customMap);
      ByteArrayInputStream bais = new ByteArrayInputStream(stringWriter.toString().getBytes());
      // step 4: we parse the document
      parser.parse(bais, cth);
      if (image != null && image.length > 0) {
        Image headerImage = Image.getInstance(image); /* NOI18N */
        headerImage.scaleAbsolute(62, 95);
        headerImage.setAbsolutePosition(175, 38);
      
     
        doc.add((Element) headerImage);
      } else {
        /*
         * FileInputStream fis = new
         * FileInputStream("D:\\Eqms_Project\\UPRR_Projects\\24_11_08\\src\\java\\templates/pers.jpg"); int l =
         * fis.available(); byte[] byteArray = new byte[l]; fis.read(byteArray); Image headerImage =
         * Image.getInstance(byteArray); headerImage.scaleAbsolute(70, 91); headerImage.setAbsolutePosition(182, 38);
         * doc.add((Element) headerImage);
         */
      }
      writer.flush();
      doc.close();
    }
    return baos;
  }

  /**
   * Classname / Method Name : PdfConvertor / merge()
   * 
   * @param :
   *          pdfWriter, reader, document
   * @exception :
   *              DocumentException, IOException Description : Method is used to write Template data into the PDF
   *              document
   */
  public void merge(PdfCopy pdfWriter, PdfReader reader, Document document) throws DocumentException, IOException {
    int count = 0;
    int number = 0;
    number = reader.getNumberOfPages();
    // we retrieve the size of the first page
    while (count < number) {
      document.newPage();
      count++;
      pdfWriter.addPage(pdfWriter.getImportedPage(reader, count));
    }
  }

  /**
   * Classname / Method Name : PdfConvertor / getImagePdf()
   * 
   * @param : stringWriter
   * @param : imageBytes
   * @return : ByteArrayOutputStream
   * @exception :DocumentException
   * @exception :IOException 
   * Description : To write image into the PDF document. Added by xsat244 for Req#193.
   */
  public ByteArrayOutputStream getImagePdf(final StringWriter stringWriter, final byte[] imageBytes) 
    throws DocumentException, IOException{
    final ByteArrayOutputStream baos = new ByteArrayOutputStream();
    if (null != stringWriter) {
      final Document doc = new Document(new Rectangle(100, 45), 10, 10, 10.8f, 10);
      final PdfWriter writer = PdfWriter.getInstance(doc, baos);
      final double[] maxExpectedSize = new double[]{90, 40};
      doc.open();
      if (null != imageBytes && imageBytes.length > 0) {
        final Image signatureImage = Image.getInstance(imageBytes);
        final double[] xyValue = new double[]{signatureImage.plainWidth(), signatureImage.plainHeight()};
        final int[] scalledSize = getImageSize(maxExpectedSize, xyValue);
        signatureImage.scaleAbsolute(scalledSize[0], scalledSize[1]);
        doc.add((Element) signatureImage);
      } else {
        m_logger.warn("Image bytes array is empty or null.");
      }
      writer.flush();
      doc.close();
    }
    return baos;
  }
  
  /**
   * 
   * Classname / Method Name : PdfConvertor/addImagesToLicencePdf()
   * @param stringWriter
   * @param emplImageBytes
   * @param signImageBytes
   * @throws EqmDaoException
   * @throws DocumentException
   * @throws IOException
   * @throws Exception
   * Description :  To write image into the PDF, Added for Req#193 by xsat244.
   */
  public ByteArrayOutputStream addImagesToLicencePdf(final StringWriter stringWriter, final byte[] emplImageBytes, final byte[] signImageBytes) 
    throws EqmDaoException, DocumentException, IOException, SAXException, ParserConfigurationException{
    ByteArrayOutputStream baos = new ByteArrayOutputStream();
    if (stringWriter != null) {
      final Document doc = new Document(new Rectangle(250, 160), 10, 10, 10.8f, 10);
      final SAXParser parser = SAXParserFactory.newInstance().newSAXParser();
      final PdfWriter writer = PdfWriter.getInstance(doc, baos);
      
      doc.open();
      CustomTagHandler cth = new CustomTagHandler(doc, writer, customMap);
      ByteArrayInputStream bais = new ByteArrayInputStream(stringWriter.toString().getBytes());
      parser.parse(bais, cth);
      /* Adding employee image to PDF */
      if (emplImageBytes != null && emplImageBytes.length > 0) {
        Image employeeImage = Image.getInstance(emplImageBytes);
        employeeImage.scaleAbsolute(62, 95);
        employeeImage.setAbsolutePosition(175, 38);     
        doc.add((Element) employeeImage);
      } else {
        m_logger.warn("IMAGE FOR THE EMPLOYEE DOES NOT EXIST");
      }
      /* Adding signature image to PDF */
      if (signImageBytes != null && signImageBytes.length > 0) {        
        final Image signatureImage = Image.getInstance(signImageBytes);
        final double[] maxExpectedSize = new double[]{75, 38};
        double[] xyValue = new double[]{signatureImage.plainWidth(), signatureImage.plainHeight()};
        final int[] scalledSize = getImageSize(maxExpectedSize, xyValue);
        signatureImage.scaleAbsolute(scalledSize[0], scalledSize[1]);
        signatureImage.setAbsolutePosition(97, 45);
        doc.add((Element) signatureImage);
      }
      writer.flush();
      doc.close();
    }
    return baos;
  }
  
  public final int[] getImageSize(final double[] expectedXY, final double[] xyValue){
    int[] finalXY = new int[]{65, 32};
    if ((null != expectedXY && (expectedXY[0] > 0 && expectedXY[1] > 0))
        && (null != xyValue && (xyValue[0] > 0 && xyValue[1] > 0))) {
      double zoomPer = (expectedXY[0] / xyValue[0]) * 100;
      if ((zoomPer * xyValue[1]) / 100 > expectedXY[1]) {
        zoomPer = (expectedXY[1] / xyValue[1]) * 100;
      }
      finalXY = new int[] { (int) ((xyValue[0] * zoomPer) / 100), (int) ((xyValue[1] * zoomPer) / 100) };
    }
    return finalXY;
  }

  /**
   * To ad signature to the Pdf document.
   *
   * @param stringWriter
   * @param signImgByteData
   * @return
   * @throws EqmDaoException
   * @throws DocumentException
   * @throws IOException
   * @throws SAXException
   * @throws ParserConfigurationException
   * @author xsat508
   * @since Jun 14, 2013
   */
  public ByteArrayOutputStream addImagesToWashingtonPdf(StringWriter stringWriter, byte[] signImgByteData) //Added for Req#439
      throws EqmDaoException, DocumentException, IOException, SAXException, ParserConfigurationException {
    ByteArrayOutputStream baos = new ByteArrayOutputStream();
    if (stringWriter != null) {
      final Document doc = new Document(PageSize.A4);
      final SAXParser parser = SAXParserFactory.newInstance().newSAXParser();
      final PdfWriter writer = PdfWriter.getInstance(doc, baos);      
      doc.open();
      CustomTagHandler cth = new CustomTagHandler(doc, writer, customMap);
      ByteArrayInputStream bais = new ByteArrayInputStream(stringWriter.toString().getBytes());
      parser.parse(bais, cth);
      /* Adding signature image to PDF */
      if (signImgByteData != null && signImgByteData.length > 0) {        
        final Image signatureImage = Image.getInstance(signImgByteData);
        final double[] maxExpectedSize = new double[]{100, 60};
        double[] xyValue = new double[]{signatureImage.plainWidth(), signatureImage.plainHeight()};
        final int[] scalledSize = getImageSize(maxExpectedSize, xyValue);
        signatureImage.scaleAbsolute(scalledSize[0], scalledSize[1]);
        signatureImage.setAbsolutePosition(350,140);//QC 1641
        doc.add((Element) signatureImage);
      }
      writer.flush();
      doc.close();
    }
    return baos;
  }
  
}