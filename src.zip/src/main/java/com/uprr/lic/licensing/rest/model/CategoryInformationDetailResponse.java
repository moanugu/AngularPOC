package com.uprr.lic.licensing.rest.model;

public class CategoryInformationDetailResponse {

	 private String categoryFirst;

	  private String actionFirst;

	  private String categorySecond;

	  private String actionSecond;

	public String getCategoryFirst() {
		return categoryFirst;
	}

	public void setCategoryFirst(String categoryFirst) {
		this.categoryFirst = categoryFirst;
	}

	public String getActionFirst() {
		return actionFirst;
	}

	public void setActionFirst(String actionFirst) {
		this.actionFirst = actionFirst;
	}

	public String getCategorySecond() {
		return categorySecond;
	}

	public void setCategorySecond(String categorySecond) {
		this.categorySecond = categorySecond;
	}

	public String getActionSecond() {
		return actionSecond;
	}

	public void setActionSecond(String actionSecond) {
		this.actionSecond = actionSecond;
	}
	  
	  
}
