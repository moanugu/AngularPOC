package com.uprr.lic.licensing.rest.service;

import java.util.List;
import java.util.Map;
import java.util.Set;

import com.uprr.lic.dataaccess.Licensing.model.CoverLetterForPrintDocsTemplate;
import com.uprr.lic.dataaccess.common.model.EqmLcnsRqmt;
import com.uprr.lic.licensing.rest.model.NdrTemplateDetail;

/**
 * 
 * @author xsat956
 *
 */
public interface IPrintPacketService {
	
	//Started by Girish
	
	 boolean isStudentLicense( String emplId);
	  
	  CoverLetterForPrintDocsTemplate getAddressInfoForEmplCoverLetterFromTeradata(String employeeId, String sysParamName);
	  NdrTemplateDetail getEmployeeDetailsForNDRTemplate(String employeeID);
	  
	  List<EqmLcnsRqmt> getRecertificationInitiatedDetailsForEmployee(String employeeId, String licenseClassCode);
	
	   Map<String, String> printLataPacket(String iLataNumber,String employeeId); // Added  Parameter For SS_QC#10235
	   Set<Integer> getAOTRoleSet();
	// End by Girish
}
