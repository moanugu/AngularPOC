package com.uprr.lic.licensing.rest.controller;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.uprr.lic.dataaccess.Licensing.model.EmployeeDetail;
import com.uprr.lic.dataaccess.Licensing.model.IssueStudentLicBean;
import com.uprr.lic.dataaccess.Licensing.model.PendingActionListGridDetail;
import com.uprr.lic.dataaccess.common.model.EqmEmplDtls;
import com.uprr.lic.dataaccess.common.model.EqmWorkItem;
import com.uprr.lic.dataaccess.common.model.Medical;
import com.uprr.lic.dataaccess.decertification.model.CertRideSummaryDetails;
import com.uprr.lic.licensing.rest.model.IssueStudentLicBeanDetail;
import com.uprr.lic.licensing.rest.model.StudentLicenseControllerBean;
import com.uprr.lic.licensing.rest.service.ICertifyService;

@Controller
public class CertifyController{
	
	@Autowired
	private ICertifyService certifyService;

	@RequestMapping(value = "/licensing/getEmpDetForStudLic", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IssueStudentLicBeanDetail getEmployeeDetailsForIssueStudentLic(@RequestBody EmployeeDetail employeeDetailBean
			,@RequestParam(value = "paramName", required = true) String paramName){
	     return certifyService.getEmployeeDetailsForIssueStudentLic(employeeDetailBean, paramName);
	}
	
	
	@RequestMapping(value = "/licensing/getStudLcnsClass", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public String getStudentLcnsClass(@RequestParam(value = "oprnId", required = true) Integer oprnId){
	     return certifyService.getStudentLcnsClass(oprnId);
	}
	
	@RequestMapping(value = "/licensing/getValidWorkItem", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public EqmWorkItem getValidWorkItem(@RequestParam(value = "workItemId", required = true) int workItemId,@RequestParam(value = "histFlag", required = true) boolean histFlag){
	     return certifyService.getValidWorkItem(workItemId,histFlag);
	}
	
	@RequestMapping(value = "/licensing/validateCertifyStudentLicRequest", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IssueStudentLicBean validateCertifyStudentLicRequest(@RequestBody StudentLicenseControllerBean issueStudentLicBean){
	     return certifyService.validateCertifyStudentLicRequest(issueStudentLicBean.getStudentLicBean(),issueStudentLicBean.getEmployeeDetailBean(),issueStudentLicBean.isPendCertFlag());
	}
	
	@RequestMapping(value = "/licensing/issueLicense", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IssueStudentLicBean issueLicense(@RequestBody StudentLicenseControllerBean issueStudentLicBean){
	     return certifyService.issueLicense(issueStudentLicBean.getStudentLicBean(),issueStudentLicBean.getEmployeeDetailBean(),issueStudentLicBean.getReason(),issueStudentLicBean.isPendCertFlag());
	}
	
	
	@RequestMapping(value = "/licensing/doesEmplHasReqLic", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public Boolean doesEmployeehasRequiredLicense(@RequestParam(value = "employeeId", required = true) String employeeId,@RequestParam(value = "licClass", required = true) String licClass){
	     return certifyService.doesEmployeehasRequiredLicense(employeeId,licClass);
	}
	
	@RequestMapping(value = "/licensing/getEmployee", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public EqmEmplDtls getEmployee(@RequestParam(value = "employeeId", required = true) String employeeId){
	     return certifyService.getEmployee(employeeId);
	}
	
	
	@RequestMapping(value = "/licensing/getRestrictionCodesList", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public List<Medical> getRestrictionCodesList(@RequestParam(value = "employeeId", required = true) String employeeId){
	     return certifyService.getRestrictionCodesList(employeeId);
	}
	
	@RequestMapping(value = "/licensing/getSummaryDetail", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public CertRideSummaryDetails getSummaryDetail(@RequestParam(value = "employeeId", required = true) String employeeId,
			@RequestParam(value = "testId", required = true) Integer testId){
	     return certifyService.getSummaryDetail(employeeId,testId);
	}
//	
	
	@RequestMapping(value = "/licensing/validateCertifyLicRequest", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IssueStudentLicBean validateCertifyLicRequest(@RequestBody StudentLicenseControllerBean issueStudentLicBean){
	     return certifyService.validateCertifyLicRequest(issueStudentLicBean.getStudentLicBean(),issueStudentLicBean.getEmployeeDetailBean(),issueStudentLicBean.getReason());
	}
	
	@RequestMapping(value = "/licensing/certifyLicense", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public List<IssueStudentLicBean> certifyLicense(@RequestBody List<PendingActionListGridDetail> detailList,@RequestParam(value = "paramName", required = true) String paramName){
	     return certifyService.certifyLicense(detailList,paramName);
	}
	

	
	
}