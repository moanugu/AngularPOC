package com.uprr.lic.licensing.rest.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.uprr.lic.dataaccess.Licensing.model.FTXExamSummaryGridDetails;

public class FTXExamSummaryDetailsResponse implements Serializable{

	  /**
	   * 
	   */
	  private static final long serialVersionUID = 1L;

	  private String managerName;

	  private String ftxEventDate;

	  private String ftxEventType;

	  private String managerServiceUnit;

	  private String subDivision;

	  private String milePost;

	  private String weather;

	  private String visibility;

	  private String trainID;

	  private String locomotiveNum;

	  private String crewCallCirc7;

	  private String crewCallTime;

	  private String distPowerUnit;

	  private String remoteControl;

	  private String reviewTestCon;

	  private String reviewRulesCovered;

	  private String discOfTestObserved;

	  private String discOfCorrectiveAction;

	  private String explOfFtxGuidelines;

	  private String structured;

	  private String assistMgr;

	  private String secAssistMgr;

	  private String thirdAssistMgr;

	  private List<FTXExamSummaryGridDetails> ftxExamSummaryGridDetails = new ArrayList<FTXExamSummaryGridDetails>();

	  private String managerComments;

	  private String crewMember;

	  private String reason;

	  private String crewPosition;

	  private String overallScore;

	  private String twentyMinObservation;


	  /**
	   * @return the managerName
	   */
	  public String getManagerName() {
	    return managerName;
	  }
	  /**
	   * @param managerName the managerName to set
	   */
	  public void setManagerName(String managerName) {
	    this.managerName = managerName;
	  }
	  /**
	   * @return the ftxEventDate
	   */
	  public String getFtxEventDate() {
	    return ftxEventDate;
	  }
	  /**
	   * @param ftxEventDate the ftxEventDate to set
	   */
	  public void setFtxEventDate(String ftxEventDate) {
	    this.ftxEventDate = ftxEventDate;
	  }
	  /**
	   * @return the ftxEventType
	   */
	  public String getFtxEventType() {
	    return ftxEventType;
	  }
	  /**
	   * @param ftxEventType the ftxEventType to set
	   */
	  public void setFtxEventType(String ftxEventType) {
	    this.ftxEventType = ftxEventType;
	  }
	  /**
	   * @return the managerServiceUnit
	   */
	  public String getManagerServiceUnit() {
	    return managerServiceUnit;
	  }
	  /**
	   * @param managerServiceUnit the managerServiceUnit to set
	   */
	  public void setManagerServiceUnit(String managerServiceUnit) {
	    this.managerServiceUnit = managerServiceUnit;
	  }
	  /**
	   * @return the subDivision
	   */
	  public String getSubDivision() {
	    return subDivision;
	  }
	  /**
	   * @param subDivision the subDivision to set
	   */
	  public void setSubDivision(String subDivision) {
	    this.subDivision = subDivision;
	  }
	  /**
	   * @return the milePost
	   */
	  public String getMilePost() {
	    return milePost;
	  }
	  /**
	   * @param milePost the milePost to set
	   */
	  public void setMilePost(String milePost) {
	    this.milePost = milePost;
	  }
	  /**
	   * @return the weather
	   */
	  public String getWeather() {
	    return weather;
	  }
	  /**
	   * @param weather the weather to set
	   */
	  public void setWeather(String weather) {
	    this.weather = weather;
	  }
	  /**
	   * @return the visibility
	   */
	  public String getVisibility() {
	    return visibility;
	  }
	  /**
	   * @param visibility the visibility to set
	   */
	  public void setVisibility(String visibility) {
	    this.visibility = visibility;
	  }
	  /**
	   * @return the trainID
	   */
	  public String getTrainID() {
	    return trainID;
	  }
	  /**
	   * @param trainID the trainID to set
	   */
	  public void setTrainID(String trainID) {
	    this.trainID = trainID;
	  }
	  /**
	   * @return the locomotiveNum
	   */
	  public String getLocomotiveNum() {
	    return locomotiveNum;
	  }
	  /**
	   * @param locomotiveNum the locomotiveNum to set
	   */
	  public void setLocomotiveNum(String locomotiveNum) {
	    this.locomotiveNum = locomotiveNum;
	  }
	  /**
	   * @return the crewCallCirc7
	   */
	  public String getCrewCallCirc7() {
	    return crewCallCirc7;
	  }
	  /**
	   * @param crewCallCirc7 the crewCallCirc7 to set
	   */
	  public void setCrewCallCirc7(String crewCallCirc7) {
	    this.crewCallCirc7 = crewCallCirc7;
	  }
	  /**
	   * @return the crewCallTime
	   */
	  public String getCrewCallTime() {
	    return crewCallTime;
	  }
	  /**
	   * @param crewCallTime the crewCallTime to set
	   */
	  public void setCrewCallTime(String crewCallTime) {
	    this.crewCallTime = crewCallTime;
	  }
	  /**
	   * @return the distPowerUnit
	   */
	  public String getDistPowerUnit() {
	    return distPowerUnit;
	  }
	  /**
	   * @param distPowerUnit the distPowerUnit to set
	   */
	  public void setDistPowerUnit(String distPowerUnit) {
	    this.distPowerUnit = distPowerUnit;
	  }
	  /**
	   * @return the remoteControl
	   */
	  public String getRemoteControl() {
	    return remoteControl;
	  }
	  /**
	   * @param remoteControl the remoteControl to set
	   */
	  public void setRemoteControl(String remoteControl) {
	    this.remoteControl = remoteControl;
	  }
	  /**
	   * @return the reviewTestCon
	   */
	  public String getReviewTestCon() {
	    return reviewTestCon;
	  }
	  /**
	   * @param reviewTestCon the reviewTestCon to set
	   */
	  public void setReviewTestCon(String reviewTestCon) {
	    this.reviewTestCon = reviewTestCon;
	  }
	  /**
	   * @return the reviewRulesCovered
	   */
	  public String getReviewRulesCovered() {
	    return reviewRulesCovered;
	  }
	  /**
	   * @param reviewRulesCovered the reviewRulesCovered to set
	   */
	  public void setReviewRulesCovered(String reviewRulesCovered) {
	    this.reviewRulesCovered = reviewRulesCovered;
	  }
	  /**
	   * @return the discOfTestObserved
	   */
	  public String getDiscOfTestObserved() {
	    return discOfTestObserved;
	  }
	  /**
	   * @param discOfTestObserved the discOfTestObserved to set
	   */
	  public void setDiscOfTestObserved(String discOfTestObserved) {
	    this.discOfTestObserved = discOfTestObserved;
	  }
	  /**
	   * @return the discOfCorrectiveAction
	   */
	  public String getDiscOfCorrectiveAction() {
	    return discOfCorrectiveAction;
	  }
	  /**
	   * @param discOfCorrectiveAction the discOfCorrectiveAction to set
	   */
	  public void setDiscOfCorrectiveAction(String discOfCorrectiveAction) {
	    this.discOfCorrectiveAction = discOfCorrectiveAction;
	  }
	  /**
	   * @return the explOfFtxGuidelines
	   */
	  public String getExplOfFtxGuidelines() {
	    return explOfFtxGuidelines;
	  }
	  /**
	   * @param explOfFtxGuidelines the explOfFtxGuidelines to set
	   */
	  public void setExplOfFtxGuidelines(String explOfFtxGuidelines) {
	    this.explOfFtxGuidelines = explOfFtxGuidelines;
	  }
	  /**
	   * @return the structured
	   */
	  public String getStructured() {
	    return structured;
	  }
	  /**
	   * @param structured the structured to set
	   */
	  public void setStructured(String structured) {
	    this.structured = structured;
	  }
	  /**
	   * @return the assistMgr
	   */
	  public String getAssistMgr() {
	    return assistMgr;
	  }
	  /**
	   * @param assistMgr the assistMgr to set
	   */
	  public void setAssistMgr(String assistMgr) {
	    this.assistMgr = assistMgr;
	  }
	  /**
	   * @return the secAssistMgr
	   */
	  public String getSecAssistMgr() {
	    return secAssistMgr;
	  }
	  /**
	   * @param secAssistMgr the secAssistMgr to set
	   */
	  public void setSecAssistMgr(String secAssistMgr) {
	    this.secAssistMgr = secAssistMgr;
	  }
	  /**
	   * @return the thirdAssistMgr
	   */
	  public String getThirdAssistMgr() {
	    return thirdAssistMgr;
	  }
	  /**
	   * @param thirdAssistMgr the thirdAssistMgr to set
	   */
	  public void setThirdAssistMgr(String thirdAssistMgr) {
	    this.thirdAssistMgr = thirdAssistMgr;
	  }
	  /**
	   * @return the ftxExamSummaryGridDetails
	   */
	  public List<FTXExamSummaryGridDetails> getFtxExamSummaryGridDetails() {
	    return ftxExamSummaryGridDetails;
	  }
	  /**
	   * @param ftxExamSummaryGridDetails the ftxExamSummaryGridDetails to set
	   */
	  public void setFtxExamSummaryGridDetails(
	      List<FTXExamSummaryGridDetails> ftxExamSummaryGridDetails) {
	    this.ftxExamSummaryGridDetails = ftxExamSummaryGridDetails;
	  }
	  /**
	   * @return the managerComments
	   */
	  public String getManagerComments() {
	    return managerComments;
	  }
	  /**
	   * @param managerComments the managerComments to set
	   */
	  public void setManagerComments(String managerComments) {
	    this.managerComments = managerComments;
	  }
	  /**
	   * @return the crewMember
	   */
	  public String getCrewMember() {
	    return crewMember;
	  }
	  /**
	   * @param crewMember the crewMember to set
	   */
	  public void setCrewMember(String crewMember) {
	    this.crewMember = crewMember;
	  }
	  /**
	   * @return the reason
	   */
	  public String getReason() {
	    return reason;
	  }
	  /**
	   * @param reason the reason to set
	   */
	  public void setReason(String reason) {
	    this.reason = reason;
	  }
	  /**
	   * @return the crewPosition
	   */
	  public String getCrewPosition() {
	    return crewPosition;
	  }
	  /**
	   * @param crewPosition the crewPosition to set
	   */
	  public void setCrewPosition(String crewPosition) {
	    this.crewPosition = crewPosition;
	  }
	  /**
	   * @return the overallScore
	   */
	  public String getOverallScore() {
	    return overallScore;
	  }
	  /**
	   * @param overallScore the overallScore to set
	   */
	  public void setOverallScore(String overallScore) {
	    this.overallScore = overallScore;
	  }
	  /**
	   * @return the twentyMinObservation
	   */
	  public String getTwentyMinObservation() {
	    return twentyMinObservation;
	  }
	  /**
	   * @param twentyMinObservation the twentyMinObservation to set
	   */
	  public void setTwentyMinObservation(String twentyMinObservation) {
	    this.twentyMinObservation = twentyMinObservation;
	  }

	}