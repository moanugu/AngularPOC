package com.uprr.lic.licensing.rest.service;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.gson.JsonObject;
import com.uprr.lic.auth.EQMSUserSession;
import com.uprr.lic.dataaccess.Licensing.model.Designate;
import com.uprr.lic.dataaccess.Licensing.model.DesignationRequirement;
import com.uprr.lic.dataaccess.Licensing.model.License;
import com.uprr.lic.dataaccess.Licensing.model.ManagerList;
import com.uprr.lic.dataaccess.Licensing.model.SLERevokeDesignation;
import com.uprr.lic.dataaccess.Licensing.model.SleDesignateInitReq;
import com.uprr.lic.dataaccess.Licensing.model.SleDesignationRequest;
import com.uprr.lic.dataaccess.Licensing.model.SleDesignationResult;
import com.uprr.lic.dataaccess.common.model.EqmEmplSleDsgn;
import com.uprr.lic.dataaccess.common.model.EqmLcnsOprn;
import com.uprr.lic.dataaccess.components.licensing.service.ILicensingService;
import com.uprr.lic.dataaccess.workflow.impl.EqmsWorkItemBean;
import com.uprr.lic.decert.rest.model.DesignateResponse;
import com.uprr.lic.util.DDChoice;

/**
 * 
 * @author xsat956
 *
 */
@Service("sleDsgnRvkeService")
public class SLEDsgnRvkeService implements ISLEDsgnRvkeService {

	@Autowired
	private ILicensingService licensingService;
	
	@Autowired
	EQMSUserSession eqmsUserSession;

	@Override
	public List<DesignationRequirement> getDesignationRequirement(Designate designate) {
		 List<DesignationRequirement> list = licensingService.getDesignationRequirement(designate);
		return list;
	}

	@Override
	public List<License> getDesignateEmployeeLicenseDtls(Designate designate) {
		 List<License> list = licensingService.getDesignateEmployeeLicenseDtls(designate);
		return list;
	}

	@Override
	public List<Designate> getDesignationInitiatorDetails(Designate designate) {
		List<Designate> list = licensingService.getDesignationInitiatorDetails(designate);
		return list;
	}

	@Override
	public List<DDChoice> getAllServiceUnitList() {
		List<DDChoice> list = licensingService.getAllServiceUnitList();
		return list;
	}

	@Override
	public List<DDChoice> getManagers(int svcNbr, String lcnsClass) {
	    List<DDChoice> list = licensingService.getManagers(svcNbr, lcnsClass);
	    return list;
	  }

	@Override
	public String getDSCount(String managerId) {
	return licensingService.getDSCount(managerId);
	}

	@Override
	public Object designateEmployee(Designate designate) {
		Object object = licensingService.designateEmployee(designate,  eqmsUserSession.getUser().getEmplId());
		DesignateResponse jsonObject = new DesignateResponse();
		if(object != null) {
			jsonObject.setDesignateSuccess(true);
		} else {
			jsonObject.setDesignateSuccess(false);
		}
		jsonObject.setManagerNotAssigned(designate.isManagerNotAssigned());
		
		return jsonObject;
	}

	@Override
	public SLERevokeDesignation getEmployeeDetailsForRevokeInitiation(String employeeId) {
		SLERevokeDesignation revokeDesignationPageBean1 = new SLERevokeDesignation();
	    revokeDesignationPageBean1 = licensingService.getEmployeeDetailsForRevokeInitiation(employeeId);
		return revokeDesignationPageBean1;
	}

	@Override
	public List<SleDesignationResult> getDesignationDetailsForRevokeInitiation(String employeeId, String status) {
		 List<SleDesignationResult> designationRequirementsList = new ArrayList<SleDesignationResult>();
	    designationRequirementsList = licensingService.getDesignationDetailsForRevokeInitiation(employeeId, status);
		return designationRequirementsList;
	}

	@Override
	public EqmsWorkItemBean getWorkItemForRevoke(Integer workItemId) {
		return licensingService.getWorkItemForRevoke(workItemId);
	}

	@Override
	public SLERevokeDesignation getInitiatorDetailsForRevoke(SLERevokeDesignation revokeDesignationPageBean,
			Integer workItemId) {
		 return licensingService.getInitiatorDetailsForRevoke(revokeDesignationPageBean, workItemId);
	}

	@Override
	public String getComment(int licOprnId) {
		 return licensingService.getComment(licOprnId);
	}

	@Override
	public List<SleDesignationResult> getDesignationDetailsListForRevokePage(String employeeId, String licClass) {
		  return licensingService.getDesignationDetailsListForRevokePage( employeeId,  licClass);
	}

	@Override
	public DesignateResponse insertForRevoke(EqmsWorkItemBean eqmsWorkItemBean, String initiatorId) {
		
		boolean revokeConfirmedFlag = licensingService.insertForRevoke(eqmsWorkItemBean, initiatorId, eqmsUserSession.getUser().getEmplId());
		
		DesignateResponse designateResponse = new DesignateResponse();
		
		designateResponse.setDesignateSuccess(revokeConfirmedFlag);
	
		designateResponse.setManagerNotAssigned(eqmsWorkItemBean.isManagerNotAssigned());
		
		return designateResponse;
	}

	@Override
	public Boolean insertSleRevokeInitiationRequest(List<SleDesignationResult> arrayList, String employeeId,
			String comments) {
		 boolean workItemCreatedFlag = licensingService.insertSleRevokeInitiationRequest(arrayList, employeeId, comments, eqmsUserSession.getUser().getEmplId());
		return workItemCreatedFlag;
	}

	@Override
	public String isRevokeInitiatedForEmployee(String employeeId) {
		 return licensingService.isRevokeInitiatedForEmployee(employeeId);
	}

	@Override
	public List<String> isEmployeeMeetMinimumDesignationRequirement(String employeeId, boolean isDsleChecked,
			boolean isDsrcoChecked) {
		  List<String> eqmlcnsList = licensingService.isEmployeeMeetMinimumDesignationRequirement(employeeId, isDsleChecked,
			        isDsrcoChecked);
		return eqmlcnsList;
	}

	@Override
	public List<EqmLcnsOprn> getDesignateRequestInitiationDetails(String employeeId) {
		return licensingService.getDesignateRequestInitiationDetails( employeeId);
	}



	@Override
	public SleDesignateInitReq getSLEDesignationInitiateEmpDetails(String employeeId) {
		 SleDesignateInitReq sleDesignateInitReq = new SleDesignateInitReq();
		    sleDesignateInitReq = licensingService.getSLEDesignationInitiateEmpDetails(employeeId);
		    return sleDesignateInitReq;
	}

	@Override
	public List<SleDesignationRequest> getDesignationRequirementsForInitiation(
			SleDesignateInitReq sleDesignateInitReqBean, Calendar rxmlTrainingDate) {
		  return licensingService.getDesignationRequirementsForInitiation(sleDesignateInitReqBean, rxmlTrainingDate);
	}

	@Override
	public Boolean insertSLEDesignateInitiateRequest(String dsle, String dsrco, String employeeId,
			List<SleDesignationRequest> designationDtlList) throws ParseException {
		 boolean workItemCreatedFlag = (boolean) licensingService.insertSLEDesignateInitiateRequest(dsle, dsrco, employeeId,eqmsUserSession.getUser().getEmplId(), designationDtlList);
			    return workItemCreatedFlag;
	}

	@Override
	public Boolean isEmployeeSelectedFromAutoCompleteListForRevokeInitiation(String employeeId) {
		return licensingService.isEmployeeSelectedFromAutoCompleteListForRevokeInitiation(employeeId);
	}

	@Override
	public String isRevokeDesignationInitiatedForEmployee(String employeeId) {
		return licensingService.isRevokeDesignationInitiatedForEmployee(employeeId);
	}

	@Override
	public List<ManagerList> getDesignatedEmployeeDetailsListForRevokeInitiation(String employeeId) {
		 List<ManagerList> empList = new ArrayList<ManagerList>();
		    empList = licensingService.getDesignatedEmployeeDetailsListForRevokeInitiation(employeeId);
		    return empList;
	}

	@Override
	public Boolean isDsleOrDsrco(String employeeId) {
		return licensingService.isDsleOrDsrco(employeeId);
	}

	@Override
	public String viewDisciplineHistoryLink(String employeeId) {
	 	
		  return licensingService.viewDisciplineHistoryLink(employeeId);
}

	@Override
	public String viewEmpLicenseHist(String employeeID) {
		 return licensingService.viewEmpLicenseHist(employeeID);
	}

	@Override
	public String viewCMTSLink() {
		return licensingService.viewCMTSLink();
	}

	@Override
	public List<EqmEmplSleDsgn> getAlreadyDesignatedEmployeeDetails(String employeeId) {
		return licensingService.getAlreadyDesignatedEmployeeDetails(employeeId);
		}

	@Override
	public Calendar getRXMLTrainingDateFromService(String employeeID) {
		return licensingService.getRXMLTrainingDateFromService( employeeID);
	}

	
		  
}
