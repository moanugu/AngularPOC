package com.uprr.lic.licensing.rest.service;

import java.util.List;

import com.uprr.lic.dataaccess.common.model.EqmEmplDtls;
import com.uprr.lic.dataaccess.common.model.EqmSysParm;

public interface ILicensingCommonRestService {
	
	EqmSysParm getSysParmValue(String parmName);

	String getCFMUrlForMVRFromECL( String employeeId);
	List<EqmEmplDtls> getEmplDtlsLsit(final List<String> emplIdList);
}
