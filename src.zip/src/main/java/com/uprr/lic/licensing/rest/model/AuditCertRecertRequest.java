/**
 * 
 */

package com.uprr.lic.licensing.rest.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.uprr.lic.dataaccess.common.model.EqmAudRcdDtls;

/**
 * 
 * @author xsat976
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class AuditCertRecertRequest {
	
	private String fromDate;
	
	private String toDate;
	
	private String xPercentage;
	
	private List<String> licenseClass;
	
	private String typeOfCerfication;
	
	private String auditStatus;
	
	private String loggedEmpId;
	
	private List<EqmAudRcdDtls> eqmAudRcdDtlsList;
	
	private Integer audDtlsId;
	
	private String failureReason;
	
	private String comments;

	/**
	 * @return the fromDate
	 */
	public String getFromDate() {
		return fromDate;
	}

	/**
	 * @param fromDate the fromDate to set
	 */
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}

	/**
	 * @return the toDate
	 */
	public String getToDate() {
		return toDate;
	}

	/**
	 * @param toDate the toDate to set
	 */
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}

	/**
	 * @return the xPercentage
	 */
	public String getxPercentage() {
		return xPercentage;
	}

	/**
	 * @param xPercentage the xPercentage to set
	 */
	public void setxPercentage(String xPercentage) {
		this.xPercentage = xPercentage;
	}

	/**
	 * @return the licenseClass
	 */
	public List<String> getLicenseClass() {
		return licenseClass;
	}

	/**
	 * @param licenseClass the licenseClass to set
	 */
	public void setLicenseClass(List<String> licenseClass) {
		this.licenseClass = licenseClass;
	}

	/**
	 * @return the typeOfCerfication
	 */
	public String getTypeOfCerfication() {
		return typeOfCerfication;
	}

	/**
	 * @param typeOfCerfication the typeOfCerfication to set
	 */
	public void setTypeOfCerfication(String typeOfCerfication) {
		this.typeOfCerfication = typeOfCerfication;
	}

	/**
	 * @return the auditStatus
	 */
	public String getAuditStatus() {
		return auditStatus;
	}

	/**
	 * @param auditStatus the auditStatus to set
	 */
	public void setAuditStatus(String auditStatus) {
		this.auditStatus = auditStatus;
	}

	public String getLoggedEmpId() {
		return loggedEmpId;
	}

	public void setLoggedEmpId(String loggedEmpId) {
		this.loggedEmpId = loggedEmpId;
	}

	public List<EqmAudRcdDtls> getEqmAudRcdDtlsList() {
		return eqmAudRcdDtlsList;
	}

	public void setEqmAudRcdDtlsList(List<EqmAudRcdDtls> eqmAudRcdDtlsList) {
		this.eqmAudRcdDtlsList = eqmAudRcdDtlsList;
	}
	
	public Integer getAudDtlsId() {
		return audDtlsId;
	}

	public void setAudDtlsId(Integer audDtlsId) {
		this.audDtlsId = audDtlsId;
	}

	public String getFailureReason() {
		return failureReason;
	}

	public void setFailureReason(String failureReason) {
		this.failureReason = failureReason;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

}
