package com.uprr.lic.licensing.jms.mvr;

import java.io.StringReader;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;

import org.apache.xmlbeans.XmlError;
import org.apache.xmlbeans.XmlException;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.XmlOptions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.support.converter.MessageConversionException;
import org.springframework.jms.support.converter.MessageConverter;

import com.uprr.lic.dataaccess.masters.dao.SysParamDao;
import com.uprr.lic.dataaccess.mvr.MvrConstants;
import com.uprr.lic.dataaccess.mvr.model.DriverBean;
import com.uprr.lic.dataaccess.mvr.model.MVRCommonBean;
import com.uprr.lic.util.SysParamBean;
import com.uprr.netcontrol.shared.xml_bindings.jaxb2.person.get_mvr_report_response_1_0.ClientElement;
import com.uprr.netcontrol.shared.xml_bindings.jaxb2.person.get_mvr_report_response_1_0.DriverElement;
import com.uprr.netcontrol.shared.xml_bindings.jaxb2.person.get_mvr_report_response_1_0.EmbeddedReportElement;
import com.uprr.netcontrol.shared.xml_bindings.jaxb2.person.get_mvr_report_response_1_0.LicenseElement;
import com.uprr.netcontrol.shared.xml_bindings.jaxb2.person.get_mvr_report_response_1_0.MVRElement;
import com.uprr.netcontrol.shared.xml_bindings.jaxb2.person.get_mvr_report_response_1_0.MVRReports;

public class MvrRestrictionMessageConvertor implements MessageConverter {

  private final static Logger logger = LoggerFactory.getLogger(MvrRestrictionMessageConvertor.class);
  private final static Logger JMS_LOG = LoggerFactory.getLogger("JMS");

  private static final String CLASSNAME = MvrRestrictionMessageConvertor.class.getName();

  @Autowired
  public SysParamDao sysParamDao;

  /**
   * Message Converter For MVR
   * 
   * @param message
   * @return
   * @throws JMSException
   * @throws MessageConversionException
   */
  public Object fromMessage(final Message message) throws JMSException, MessageConversionException {
    logger.info("Enters  :: Execution starts : : method: fromMessage " + CLASSNAME);

    TextMessage textMessage = (TextMessage) message;
    MVRCommonBean anMVRCommonBean;
    try {
      Map<String, SysParamBean> sysParmaMap = sysParamDao.getAllSystemParameter();
      JMS_LOG.debug(" textMessage.getText() " ,textMessage.getText());
      anMVRCommonBean = parseMessage(textMessage.getText().toString(), sysParmaMap);
    } catch (Exception e) {
      logger.error(" fromMessage " + CLASSNAME + e.getMessage());
      anMVRCommonBean = new MVRCommonBean();
    }
    logger.info("Exit  :: Execution ends : For :  method :: fromMessage " + CLASSNAME);

    return anMVRCommonBean;
  }

  public Message toMessage(final Object arg0, final Session arg1) throws JMSException, MessageConversionException {
    return null;
  }

  /**
   * Parse Xml message into MVRCommonBean
   * 
   * @param msg
   * @param sysParmMap
   * @return
   * @throws Exception
   */
  public MVRCommonBean parseMessage(String msg, final Map<String, SysParamBean> sysParmMap) throws Exception {// Modified
                                                                                                              // for
                                                                                                              // SS_QC#6707
    logger.info("Enters  :: Execution starts : : method: parseMessage " + CLASSNAME);

    MVRCommonBean anMVRCommonBean = new MVRCommonBean();
    anMVRCommonBean.setResponceOfMVR(msg);
    JAXBContext jaxbContext = null;
    MVRReports anMVRReportsDocument;
    msg = msg.replaceAll("<MVRReports ", "<MVRReports xmlns=\"http://services.www.up.com/person/get-mvr-report-response/1.0\" ");
    try {
      jaxbContext = JAXBContext.newInstance(MVRReports.class);
      Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
      StringReader reader = new StringReader(msg);
      anMVRReportsDocument = (MVRReports) jaxbUnmarshaller.unmarshal(reader);

      if (anMVRReportsDocument != null) {
        List<DriverBean> lstDriverBean = new ArrayList<>();
        for (Iterator<MVRElement> iterator = anMVRReportsDocument.getMVRReport().iterator(); iterator.hasNext();) {
          MVRElement mvrElement = iterator.next();
          // Added for SS_QC#6302 --Start
          DriverBean anDriverBean = new DriverBean();
          if (null != mvrElement.getEmbeddedReport()) {
            EmbeddedReportElement anEmbeddedReportElement = mvrElement.getEmbeddedReport();
            anMVRCommonBean.setGuid(anEmbeddedReportElement.getData());
            anDriverBean.setReportType(anEmbeddedReportElement.getType());
          } // Added for SS_QC#6302 --End
          MVRElement anMVRElement = mvrElement;
          ClientElement anClientType = mvrElement.getClient();

          DriverElement anDriver = mvrElement.getDriver();
          LicenseElement anLicenseElement = mvrElement.getLicense();

          anMVRCommonBean.setClientID(anClientType.getClientID());
          anMVRCommonBean.setClientName(anClientType.getClientName());

          anDriverBean.setEmployeeID(anDriver.getDriverReferenceNumber());
          anDriverBean.setLicenseNumber(anLicenseElement.getLicenseNumber());
          anDriverBean.setLicenseState(anLicenseElement.getLicenseState().toString());
          anDriverBean.setCdlStatus(anLicenseElement.getCDLStatus());
          anDriverBean.setFirstName(anDriver.getFirstName());
          anDriverBean.setMiddleName(anDriver.getMiddleName());
          anDriverBean.setLastName(anDriver.getLastName());

          anDriverBean.setBirthDate(getYyyyMMdd(anDriver.getBirthDate().toString()));

          anDriverBean.setDivisionName(anClientType.getDivisionName());
          anDriverBean.setDivisionTag(anClientType.getDivisionTag());
          anDriverBean.setQuoteBack(anMVRElement.getQuoteback());
          // Added for SS_QC#6302 --Start
          if (null != anMVRElement.getError() && null != anMVRElement.getError().getCode()) {
            anMVRCommonBean.setErrorCode(anMVRElement.getError().getCode());
            // Changes for SS_QC#6707 start
            String mvrErrorMsg = getErrorMsg(sysParmMap.get(MvrConstants.MVR_ERROR_MSG).getParmValu(),
                anMVRElement.getError().getCode());
            anMVRCommonBean.setErrorCodeDesc(mvrErrorMsg);
            // Changes for SS_QC#6707 end
          } // Added for SS_QC#6302 --End
          lstDriverBean.add(anDriverBean);
        }
        anMVRCommonBean.setAnDriverBean(lstDriverBean.toArray(new DriverBean[lstDriverBean.size()]));
      }
    } catch (Exception e) {
      logger.error("Exception parseMessage", e);
      throw new XmlException(e);
    }

    return anMVRCommonBean;
  }

  /**
   * To Get Division Name from MVR Bean
   * 
   * @param anMVRCommonBean
   * @return
   * @author xsat769 Created For QC#4084
   */
  public String getDivNameFromMVR(MVRCommonBean anMVRCommonBean) {

    String appName = null;
    DriverBean[] anDriver = anMVRCommonBean.getAnDriverBean();

    int length = anDriver.length;

    for (int i = 0; i < length; i++) {
      appName = anDriver[i].getDivisionTag();
    }
    return appName;
  }

  /**
   * To Get Date with format
   * 
   * @param calendar
   * @return
   * @author xsat769 Created For QC#4084
   */
  public String getDateMMDDYYYY(Calendar calendar) {
    Date date = calendar.getTime();
    SimpleDateFormat dateformatter = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
    String strDate = dateformatter.format(date);
    return strDate;
  }

  /**
   * To Convert String date To Date
   * 
   * @param anDate
   * @return
   * @author xsat769
   * @since Jan 25, 2016 Created For QC#4084
   */
  public Date getYyyyMMdd(String anDate) {

    String fromDate = anDate.trim().toString();
    DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
    java.util.Date result = null;
    try {
      result = df.parse(fromDate);
    } catch (ParseException e) {
      logger.error("Exception :: For :  method :: getYyyyMMdd " + CLASSNAME, e);
    }
    return result;
  }

  /**
   * This method is used to check the XML is proper or not.
   * 
   * @param xmlObject
   * @author xsat769
   * @since Jul 16, 2015 Created For QC#4084
   */
  @SuppressWarnings("rawtypes")
  private static void getXMLErrors(final XmlObject xmlObject) {
    final ArrayList<?> errors = new ArrayList();
    final XmlOptions validateOptions = new XmlOptions();
    validateOptions.setErrorListener(errors);
    final boolean valid = xmlObject.validate(validateOptions);
    if (!valid) {
      for (final Iterator iterator = errors.iterator(); iterator.hasNext();) {
        final XmlError xmlError = (XmlError) iterator.next();
        logger.error(" XmlException :: XML Error is : " + xmlError.getMessage() + " at "
            + xmlError.getCursorLocation().xmlText() + " Error code " + xmlError.getErrorCode() + ":" + CLASSNAME);
      }
    }
  }

  /**
   * This method is used to get MVR error message.
   * 
   * @param errorMessageMapping,errorCode
   * @author xsat872
   * @since Aug 05,2016 Created For SS_QC#6707
   */
  private static String getErrorMsg(String errorMessageMapping, String errorCode) {
    if (!errorMessageMapping.isEmpty()) {
      Map<String, String> errorMeassgeMap = new HashMap<String, String>();
      String[] errorMsgStrArray = errorMessageMapping.split(",");
      for (String errorMsgStr : errorMsgStrArray) {
        String[] sepErrorMsgArray = errorMsgStr.split("-");
        errorMeassgeMap.put(sepErrorMsgArray[0].trim(), sepErrorMsgArray[1].trim());
      }

      if (null != errorCode && !errorCode.isEmpty()) {
        return errorMeassgeMap.get(errorCode);
      }
    }
    return null;
  }

}
