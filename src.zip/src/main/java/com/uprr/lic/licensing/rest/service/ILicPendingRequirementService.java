package com.uprr.lic.licensing.rest.service;

import java.util.List;

import com.uprr.lic.dataaccess.Licensing.model.PendingRequirementResult;
import com.uprr.lic.dataaccess.Licensing.model.RulesExamCodeDetails;
import com.uprr.lic.decert.rest.model.DropdownChoice;
import com.uprr.lic.licensing.rest.model.EmplLicHistoryDetails;
import com.uprr.lic.licensing.rest.model.FTXExamSummaryDetailsResponse;
import com.uprr.lic.licensing.rest.model.MedicalDetailResponse;
import com.uprr.lic.licensing.rest.model.PendingRequirementRequest;
import com.uprr.lic.licensing.rest.model.PendingRequirementResponse;


public interface ILicPendingRequirementService {
	List<String> getLicenseClassList();
	List<String> getPendingRequirementsList();
	List<DropdownChoice> getServiceUnitListByRegion(Integer regNum);
	Boolean isExistingEmployee(String employeeId);
	
	List<PendingRequirementResponse> getPendingRequirementsEmpDetailsList(PendingRequirementRequest pendingRequirement);

	EmplLicHistoryDetails getEmployeeLicHistoryDetails(String employeeId);

	List<RulesExamCodeDetails> getRulesExamCodes(final String emplId);

	MedicalDetailResponse getMedicalResult(Integer rqmtId);

	MedicalDetailResponse getMedicalResult(String employeeId, String licenseClassCode);

	FTXExamSummaryDetailsResponse getEvaluationDetailsForConductor(final String employeeId, final Integer testId, final Integer ftxEventId);

	FTXExamSummaryDetailsResponse getAuditEvaluationDetails(final String employeeId, final Integer sequenceNumber);

	String getPinsForConductorLicense(final PendingRequirementResult pendingRequirementResult);
	
	boolean cancelLicensingRequirement(List<PendingRequirementResult> rqmtList, String comments);

}
