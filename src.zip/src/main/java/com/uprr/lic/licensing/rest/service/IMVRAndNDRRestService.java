package com.uprr.lic.licensing.rest.service;

import java.util.List;
import java.util.Map;

import com.uprr.lic.dataaccess.Licensing.model.EmployeeDetail;
import com.uprr.lic.dataaccess.Licensing.model.EmployeePacketMvrNdrPopup;
import com.uprr.lic.dataaccess.Licensing.model.MvrNdrDetails;
import com.uprr.lic.dataaccess.Licensing.model.MvrNdrPopupPacketGridDetail;
import com.uprr.lic.dataaccess.Licensing.model.MvrNdrReplyPopupDetail;
import com.uprr.lic.exception.EqmDaoException;
import com.uprr.lic.exception.EqmException;
import com.uprr.lic.licensing.rest.model.EmpPacketStatusResponse;
import com.uprr.lic.licensing.rest.model.EqmLicensingMvrReportDetailsResponse;
import com.uprr.lic.licensing.rest.model.FeedbackMsgRequest;
import com.uprr.lic.licensing.rest.model.LicensingRequest;

public interface IMVRAndNDRRestService {
	Boolean isEmployeeAlreadyLicensed(String employeeId);
	List<Integer> getPackDtlsResn(final String emplId,List<Integer> resnIdList);
	Integer insertEmployeeAuthorizationDetails(final List<EmpPacketStatusResponse> detailsList,
		      final Integer number, final String mvr_ndr_code, final String comments,final Boolean fromSupervision);
	
	boolean setMvrNdrResult(MvrNdrReplyPopupDetail details, String code, Integer rqmtId, Integer svcNbr);
	
	boolean oprnForCallbackOption(String code, String emplId,String comments);
	
	MvrNdrDetails getNdrDetails(int rqmtId, String emplId);
	
	Integer insertEmployeeAuthorizationPacketDetails(List<EmpPacketStatusResponse> detailsList, 
		      Integer number,final String mvr_ndr_code,final String comments,final Boolean fromSupervision);
	  
	  /**
	   * @param rqmtId
	   * @param code
	   * @return
	   * @throws EqmDaoException
	   * @throws EqmException
	   */
	  List<MvrNdrPopupPacketGridDetail> getMvrNDrReplyPacketStatusList(Integer rqmtId, String code, String emplId);
	  
	  /**
	   * @param empID
	   * @param empName
	   * @param serviceUnit
	   * @param licenseClass
	   * @return
	   */
	  EmployeeDetail getEmployeeFaxDetail(String empID);
	  
	  /**
	   * @param workItemID
	   * @param faxNum
	   * @param lcnsOprnID
	   * @param crtnID
	   * @return
	   */
	  Integer updateFaxDetails( String faxNum, Integer lcnsOprnID, String faxContentText);
	  
	  /**
	   * To get MVR Autorization Received Date
	   *
	   * @param emplId
	   */
	  List<MvrNdrPopupPacketGridDetail> getMVRAuthDetailsFromReorpts(final String emplId);
	  
	  /**
	   * @param rqmtId
	   * @return
	   * @throws EqmException
	   * @throws Exception
	   */
	  MvrNdrDetails getMVRDetails(Integer requirmentID,String emplId);
	  
	  /**
	   * To check MVR Authorization and send request.
	   *
	   * @param emplIdLst
	   * @param sysParmMap
	   * @param crtnId
	   * @param fromErrWrkItm
	   */
	  void doAuthAndCreateMVRReq(List<String> emplIdLst,
	      final boolean fromErrWrkItm,final boolean fromSendRequest);
	  
	  /**
	   * 
	   * To Get MVR Report Details
	   *
	   * @param empID
	   * @return
	
	   */
	  EqmLicensingMvrReportDetailsResponse doGetMvrReportDtl(String empID);
	  
	  void removeRecordForRCVDNDRMVR(final String emplId, final List<Integer> packResn,final List<String> workQueueFlagLst,String comments);
	
	  /**	
	   * 
	   * To Get MVR Report Authentication employee Details
	   * @param eqmlcnsMvrLst
	   */
	  List<Map<String, Object>> getMVRReportDetails(List<String> eqmlcnsMvrLst);
	  
	  Boolean insertMvrNdrResultWithDate(LicensingRequest licensingRequest);
	  
	  
	  public List<MvrNdrPopupPacketGridDetail> getPacketHistoryNdrList(EmployeePacketMvrNdrPopup packetStatus);
	  
	  public List<MvrNdrPopupPacketGridDetail> getPacketHistoryMvrList(EmployeePacketMvrNdrPopup packetStatus); 
	  
	  public byte[] downloadFormUsingGuid(String guid);
	  
	  Integer updateMarkAsSentFaxDetails( String faxNum,Integer lcnsOprnID,String faxContentText);
	  
	  String getFeedbackMsgForEmployeePacket(FeedbackMsgRequest feedbackMsgRequest);
}
