package com.uprr.lic.licensing.rest.model;

public class NDROperationalcallbackRequest {
	
	private String workItemCode;
	private String employeeId;
	private String comments;
	
	public String getWorkItemCode() {
		return workItemCode;
	}
	
	public void setWorkItemCode(String workItemCode) {
		this.workItemCode = workItemCode;
	}
	

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public String getComments() {
		return comments;
	}
	
	public void setComments(String comments) {
		this.comments = comments;
	}
	
	
}
