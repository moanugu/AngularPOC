/**
 * 
 */
package com.uprr.lic.licensing.rest.service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.ss.util.RegionUtil;
import org.apache.poi.xssf.streaming.SXSSFSheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uprr.lic.dataaccess.common.model.EqmAudDtls;
import com.uprr.lic.dataaccess.common.model.EqmAudRcdDtls;
import com.uprr.lic.dataaccess.components.licensing.service.IAuditCertRecertService;
import com.uprr.lic.licensing.rest.model.AuditCertRecertRequest;
import com.uprr.lic.util.DateUtil;
import com.uprr.lic.util.LicensingConstant;

/**
 * @author xsat976
 *
 */
@Service("auditCertRecertRestService")
public class AuditCertRecertRestService implements IAuditCertRecertRestService {

	@Autowired
	private IAuditCertRecertService auditCertRecertService;

	@Override
	public List<EqmAudRcdDtls> searchInitiateAuditRecords(AuditCertRecertRequest auditCertRecertRequest) {
		List<String> typeOfCertification = new ArrayList<String>();
		if (null != auditCertRecertRequest.getTypeOfCerfication()
				&& auditCertRecertRequest.getTypeOfCerfication().equalsIgnoreCase("ALL")) {
			typeOfCertification.add(LicensingConstant.FLAG_Y);
			typeOfCertification.add(LicensingConstant.FLAG_R);
		} else {
			typeOfCertification.add(auditCertRecertRequest.getTypeOfCerfication());
		}
		return auditCertRecertService.searchInitiateAuditRecords(auditCertRecertRequest.getFromDate(),
				auditCertRecertRequest.getToDate(), auditCertRecertRequest.getxPercentage(),
				auditCertRecertRequest.getLicenseClass(), typeOfCertification, auditCertRecertRequest.getLoggedEmpId());
	}

	@Override
	public EqmAudDtls insertAuditRecords(AuditCertRecertRequest auditCertRecertRequest) {
		return auditCertRecertService.insertAuditRecords(auditCertRecertRequest.getEqmAudRcdDtlsList(),
				auditCertRecertRequest.getLoggedEmpId());
	}

	@Override
	public List<EqmAudDtls> searchAuditRecord(AuditCertRecertRequest auditCertRecertRequest) {
		return auditCertRecertService.searchAuditRecord(auditCertRecertRequest.getFromDate(),
				auditCertRecertRequest.getToDate(), auditCertRecertRequest.getAuditStatus());
	}

	@Override
	public List<EqmAudRcdDtls> getAuditRecordsById(Integer audDtlsId) {
		return auditCertRecertService.getAuditRecordsById(audDtlsId);
	}

	@Override
	public boolean markAuditStatus(AuditCertRecertRequest auditCertRecertRequest) {
		return auditCertRecertService.markAuditStatus(auditCertRecertRequest.getAudDtlsId(),
				auditCertRecertRequest.getAuditStatus(), auditCertRecertRequest.getFailureReason(),
				auditCertRecertRequest.getComments(), auditCertRecertRequest.getLoggedEmpId());
	}
	
	/**
	 * This method is used to generate excel sheet and write to response.
	 * If any change sequence on gui level we need to change also here. 
	 */
	@Override
	public byte[] exportToExcelAuditRecord(final Integer audDtlsId) {

		List<EqmAudRcdDtls> eqmAudRcdDtlsList = auditCertRecertService.getAuditRecordsById(audDtlsId);

		String[] headerColumns = new String[] { "EMP#", "Name", "License", "Region", "Service Unit", "Cert Flag",
				"Effective Date", "Expiration Date", "Creation EMP", "Action" };

		final SXSSFWorkbook workbook = new SXSSFWorkbook();
		ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
		final SXSSFSheet sheet = workbook.createSheet("Audit Record Details");

		final Font font = workbook.createFont();
		font.setBold(true);
		font.setFontHeightInPoints((short) 11);

		final CellStyle style = getCellStyle(font, workbook);
		style.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());

		final CellStyle emptyRowStyle = getCellStyle(font, workbook);
		emptyRowStyle.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
		emptyRowStyle.setFillPattern(CellStyle.SOLID_FOREGROUND);

		final CellStyle mainHeaderStyle = getCellStyle(font, workbook);
		mainHeaderStyle.setFillForegroundColor(IndexedColors.ORANGE.getIndex());

		final CellStyle subHeaderStyle = getCellStyle(font, workbook);
		subHeaderStyle.setFillForegroundColor(IndexedColors.GOLD.getIndex());

		final CellStyle groupHeaderStyle = getCellStyle(font, workbook);
		groupHeaderStyle.setFillForegroundColor(IndexedColors.LIGHT_CORNFLOWER_BLUE.getIndex());

		int rowNumber = 0;
		final Row mainHeaderRow = sheet.createRow(rowNumber);
		int j = 1;
		for (int i = 0; i < headerColumns.length; i++) {
			if (i != 0) {
				sheet.addMergedRegion(createCellRangeInstance(rowNumber, rowNumber, j, ++j, sheet, workbook));
				mainHeaderRow.createCell((j - 1)).setCellValue(headerColumns[i]);
				mainHeaderRow.getCell((j - 1)).setCellStyle(mainHeaderStyle);
				j++;
			} else {
				mainHeaderRow.createCell(0).setCellValue(headerColumns[i]);
				mainHeaderRow.getCell(0).setCellStyle(mainHeaderStyle);
			}
		}

		Map<String, List<EqmAudRcdDtls>> eqmAudRcdDtlsMap = eqmAudRcdDtlsList.stream()
				.collect(Collectors.groupingBy(EqmAudRcdDtls::getEmplId));
		Set<String> groupKey = eqmAudRcdDtlsMap.keySet();
		List<String> sortedList = new ArrayList<String>(groupKey);
		Collections.sort(sortedList);

		for (String employeeId : sortedList) {

			final Row groupRow = sheet.createRow(++rowNumber);
			sheet.addMergedRegion(createCellRangeInstance(rowNumber, rowNumber, 0, 18, sheet, workbook));
			groupRow.createCell(0).setCellValue(employeeId);
			groupRow.getCell(0).setCellStyle(groupHeaderStyle);

			List<EqmAudRcdDtls> eqmAudRcdGroupList = eqmAudRcdDtlsMap.get(employeeId);

			for (EqmAudRcdDtls eqmAudRcdDtls : eqmAudRcdGroupList) {
				final Row groupDataRow = sheet.createRow(++rowNumber);
				groupDataRow.createCell(0).setCellValue("");// Set first Row as
															// Empty
				sheet.addMergedRegion(createCellRangeInstance(rowNumber, rowNumber, 1, 2, sheet, workbook));
				groupDataRow.createCell(1).setCellValue(eqmAudRcdDtls.getEmplName());
				sheet.addMergedRegion(createCellRangeInstance(rowNumber, rowNumber, 3, 4, sheet, workbook));
				groupDataRow.createCell(3).setCellValue(eqmAudRcdDtls.getLcnsClassCode());
				sheet.addMergedRegion(createCellRangeInstance(rowNumber, rowNumber, 5, 6, sheet, workbook));
				groupDataRow.createCell(5).setCellValue(eqmAudRcdDtls.getRegionName());
				sheet.addMergedRegion(createCellRangeInstance(rowNumber, rowNumber, 7, 8, sheet, workbook));
				groupDataRow.createCell(7).setCellValue(eqmAudRcdDtls.getServiceUnitName());
				sheet.addMergedRegion(createCellRangeInstance(rowNumber, rowNumber, 9, 10, sheet, workbook));
				groupDataRow.createCell(9).setCellValue(eqmAudRcdDtls.getCertFlag());
				sheet.addMergedRegion(createCellRangeInstance(rowNumber, rowNumber, 11, 12, sheet, workbook));
				groupDataRow.createCell(11).setCellValue(DateUtil.getCalendarAsString(eqmAudRcdDtls.getLcnsEffDate()));
				sheet.addMergedRegion(createCellRangeInstance(rowNumber, rowNumber, 13, 14, sheet, workbook));
				groupDataRow.createCell(13).setCellValue(DateUtil.getCalendarAsString(eqmAudRcdDtls.getLcnsExpnDate()));
				sheet.addMergedRegion(createCellRangeInstance(rowNumber, rowNumber, 15, 16, sheet, workbook));
				groupDataRow.createCell(15).setCellValue(DateUtil.getCalendarAsString(eqmAudRcdDtls.getLcnsCrtnDate()));
				sheet.addMergedRegion(createCellRangeInstance(rowNumber, rowNumber, 17, 18, sheet, workbook));
				groupDataRow.createCell(17).setCellValue(eqmAudRcdDtls.getAuditAction());

				final Row testHeaderRow = sheet.createRow(++rowNumber);
				sheet.addMergedRegion(createCellRangeInstance(rowNumber, (rowNumber + 1), 0, 1, sheet, workbook));
				testHeaderRow.createCell(0).setCellValue("Medical");
				testHeaderRow.getCell(0).setCellStyle(style);

				sheet.addMergedRegion(createCellRangeInstance(rowNumber, (rowNumber + 1), 2, 3, sheet, workbook));
				testHeaderRow.createCell(2).setCellValue("Rules");
				testHeaderRow.getCell(2).setCellStyle(style);

				sheet.addMergedRegion(createCellRangeInstance(rowNumber, (rowNumber + 1), 4, 6, sheet, workbook));
				testHeaderRow.createCell(4).setCellValue("Ride");
				testHeaderRow.getCell(4).setCellStyle(style);

				sheet.addMergedRegion(createCellRangeInstance(rowNumber, (rowNumber + 1), 7, 8, sheet, workbook));
				testHeaderRow.createCell(7).setCellValue("FTX Event");
				testHeaderRow.getCell(7).setCellStyle(style);

				sheet.addMergedRegion(createCellRangeInstance(rowNumber, (rowNumber + 1), 9, 10, sheet, workbook));
				testHeaderRow.createCell(9).setCellValue("MVR");
				testHeaderRow.getCell(9).setCellStyle(style);

				sheet.addMergedRegion(createCellRangeInstance(rowNumber, (rowNumber + 1), 11, 12, sheet, workbook));
				testHeaderRow.createCell(11).setCellValue("NDR");
				testHeaderRow.getCell(11).setCellStyle(style);

				sheet.addMergedRegion(createCellRangeInstance(rowNumber, rowNumber, 13, 18, sheet, workbook));
				testHeaderRow.createCell(13).setCellValue("CheckList");
				testHeaderRow.getCell(13).setCellStyle(style);

				final Row checkListSubHeaderRow = sheet.createRow(++rowNumber);
				sheet.addMergedRegion(createCellRangeInstance(rowNumber, rowNumber, 13, 14, sheet, workbook));
				checkListSubHeaderRow.createCell(13).setCellValue("OPEC");
				checkListSubHeaderRow.getCell(13).setCellStyle(subHeaderStyle);

				sheet.addMergedRegion(createCellRangeInstance(rowNumber, rowNumber, 15, 16, sheet, workbook));
				checkListSubHeaderRow.createCell(15).setCellValue("OPRC");
				checkListSubHeaderRow.getCell(15).setCellStyle(subHeaderStyle);

				sheet.addMergedRegion(createCellRangeInstance(rowNumber, rowNumber, 17, 18, sheet, workbook));
				checkListSubHeaderRow.createCell(17).setCellValue("OPCC");
				checkListSubHeaderRow.getCell(17).setCellStyle(subHeaderStyle);
				//
				final Row testSubHeader = sheet.createRow(++rowNumber);
				for (int k = 0; k < 19; k++) {
					testSubHeader.createCell(k).setCellValue("Date");
					testSubHeader.getCell(k).setCellStyle(subHeaderStyle);
					testSubHeader.createCell(++k).setCellValue("Result");
					testSubHeader.getCell(k).setCellStyle(subHeaderStyle);
					if (k == 5) {
						testSubHeader.createCell(++k).setCellValue("Evaluation Position");
						testSubHeader.getCell(k).setCellStyle(subHeaderStyle);
					}
				}

				final Row testDataRow = sheet.createRow(++rowNumber);
				testDataRow.createCell(0).setCellValue(eqmAudRcdDtls.getMedicalDate());
				testDataRow.createCell(1).setCellValue(eqmAudRcdDtls.getMedicalResult());
				testDataRow.createCell(2).setCellValue(eqmAudRcdDtls.getRuleDate());
				testDataRow.createCell(3).setCellValue(eqmAudRcdDtls.getRuleResult());
				testDataRow.createCell(4).setCellValue(eqmAudRcdDtls.getRideDate());
				testDataRow.createCell(5).setCellValue(eqmAudRcdDtls.getRideResult());
				testDataRow.createCell(6).setCellValue(eqmAudRcdDtls.getRideEvalPosition());
				testDataRow.createCell(7).setCellValue(eqmAudRcdDtls.getFtxEventDate());
				testDataRow.createCell(8).setCellValue(eqmAudRcdDtls.getFtxEventResult());
				testDataRow.createCell(9).setCellValue(eqmAudRcdDtls.getMvrDate());
				testDataRow.createCell(10).setCellValue(eqmAudRcdDtls.getMvrResult());
				testDataRow.createCell(11).setCellValue(eqmAudRcdDtls.getNdrDate());
				testDataRow.createCell(12).setCellValue(eqmAudRcdDtls.getNdrResult());
				testDataRow.createCell(13).setCellValue(eqmAudRcdDtls.getOpecDate());
				testDataRow.createCell(14).setCellValue(eqmAudRcdDtls.getOpecResult());
				testDataRow.createCell(15).setCellValue(eqmAudRcdDtls.getOprcDate());
				testDataRow.createCell(16).setCellValue(eqmAudRcdDtls.getOprcResult());
				testDataRow.createCell(17).setCellValue(eqmAudRcdDtls.getOpccDate());
				testDataRow.createCell(18).setCellValue(eqmAudRcdDtls.getOpccResult());

				final Row emptyRow = sheet.createRow(++rowNumber);
				sheet.addMergedRegion(createCellRangeInstance(rowNumber, rowNumber, 0, 18, sheet, workbook));
				emptyRow.createCell(0).setCellValue("");
				emptyRow.getCell(0).setCellStyle(emptyRowStyle);

			}
		}
		sheet.createFreezePane(0, 1);
		byte[] bytes = null;
		try {
			workbook.write(byteArrayOutputStream);
			bytes = byteArrayOutputStream.toByteArray();

		} catch (IOException e) {
			e.printStackTrace();
		}
		return bytes;

	}

	/**
	 * 
	 * @param font
	 * @param workbook
	 * @return
	 */
	private CellStyle getCellStyle(final Font font, SXSSFWorkbook workbook) {
		final CellStyle style = workbook.createCellStyle();
		style.setBorderTop(CellStyle.BORDER_THIN);
		style.setBorderLeft(CellStyle.BORDER_THIN);
		style.setBorderRight(CellStyle.BORDER_THIN);
		style.setBorderBottom(CellStyle.BORDER_THIN);
		style.setFont(font);
		style.setFillPattern(CellStyle.SOLID_FOREGROUND);
		return style;
	}

	/**
	 * 
	 * @param startRow
	 * @param endRow
	 * @param startColumn
	 * @param endColumn
	 * @param sheet
	 * @param workbook
	 * @return
	 */
	private CellRangeAddress createCellRangeInstance(int startRow, int endRow, int startColumn, int endColumn,
			SXSSFSheet sheet, SXSSFWorkbook workbook) {
		CellRangeAddress region = new CellRangeAddress(startRow, endRow, startColumn, endColumn);
		RegionUtil.setBorderTop(CellStyle.BORDER_THIN, region, sheet, workbook);
		RegionUtil.setBorderLeft(CellStyle.BORDER_THIN, region, sheet, workbook);
		RegionUtil.setBorderRight(CellStyle.BORDER_THIN, region, sheet, workbook);
		RegionUtil.setBorderBottom(CellStyle.BORDER_THIN, region, sheet, workbook);
		return region;
	}

}
