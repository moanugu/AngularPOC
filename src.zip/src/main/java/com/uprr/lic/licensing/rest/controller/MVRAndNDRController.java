package com.uprr.lic.licensing.rest.controller;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.velocity.exception.ParseErrorException;
import org.apache.velocity.exception.ResourceNotFoundException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.MethodInvocationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.itextpdf.text.DocumentException;
import com.uprr.lic.dataaccess.Licensing.model.EmployeeDetail;
import com.uprr.lic.dataaccess.Licensing.model.EmployeePacketMvrNdrPopup;
import com.uprr.lic.dataaccess.Licensing.model.MvrNdrDetails;
import com.uprr.lic.dataaccess.Licensing.model.MvrNdrPopupPacketGridDetail;
import com.uprr.lic.exception.EqmException;
import com.uprr.lic.licensing.rest.model.AuthAndCreateMVRRequest;
import com.uprr.lic.licensing.rest.model.EmployeeAuthorizationDetailsRequest;
import com.uprr.lic.licensing.rest.model.EmployeePacketDetailRequest;
import com.uprr.lic.licensing.rest.model.EqmLicensingMvrReportDetailsResponse;
import com.uprr.lic.licensing.rest.model.FeedbackMsgRequest;
import com.uprr.lic.licensing.rest.model.LicensingRequest;
import com.uprr.lic.licensing.rest.model.MvrNdrResultRequest;
import com.uprr.lic.licensing.rest.model.NDROperationalcallbackRequest;
import com.uprr.lic.licensing.rest.model.RemoveRCVDNDRMVRRequest;
import com.uprr.lic.licensing.rest.service.IMVRAndNDRRestService;
import com.uprr.lic.util.LicensingConstant;

/**
 * This Controller is using for NDRReplyController
 * @author xsat956
 *
 */
@Controller
public class MVRAndNDRController {

	@Autowired
	private IMVRAndNDRRestService mvrAndNDRReplyService;

	private static final Logger logger = LoggerFactory.getLogger(MVRAndNDRController.class);


	@RequestMapping(value = "/licensing/isEmployeeAlreadyLicensed/{employeeId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public boolean isEmployeeAlreadyLicensed(@PathVariable("employeeId") String employeeId) {
		return mvrAndNDRReplyService.isEmployeeAlreadyLicensed(employeeId);
	}

	@RequestMapping(value = "/licensing/getPackDtlsResn", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public List<Integer> getPackDtlsResn(@RequestBody EmployeePacketDetailRequest packetDetailRequest){
		return mvrAndNDRReplyService.getPackDtlsResn(packetDetailRequest.getEmployeeId(),packetDetailRequest.getRegionIdList()); 
	}

	@RequestMapping(value = "/licensing/oprnForCallbackOption", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public boolean oprnForCallbackOption(@RequestBody NDROperationalcallbackRequest operationalcallbackRequest){
		return mvrAndNDRReplyService.oprnForCallbackOption(operationalcallbackRequest.getWorkItemCode(), operationalcallbackRequest.getEmployeeId(), 
				operationalcallbackRequest.getComments()); 
	}


	@RequestMapping(value = "/licensing/insertEmployeeAuthorizationDetails", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public Integer insertEmployeeAuthorizationDetails(@RequestBody EmployeeAuthorizationDetailsRequest employeeAuthorizationDetailsRequest){
		return mvrAndNDRReplyService.insertEmployeeAuthorizationDetails(employeeAuthorizationDetailsRequest.getEmpPacketStatusDetails(), 
				employeeAuthorizationDetailsRequest.getNumber(), employeeAuthorizationDetailsRequest.getMvrNdrCode(), 
				employeeAuthorizationDetailsRequest.getComments(), employeeAuthorizationDetailsRequest.getFromSupervision());
	}


	@RequestMapping(value = "/licensing/setMvrNdrResult", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public boolean setMvrNdrResult(@RequestBody MvrNdrResultRequest mvrNdrResultRequest){
		return mvrAndNDRReplyService.setMvrNdrResult(mvrNdrResultRequest.getMvrNdrPopupDtls(), 
				mvrNdrResultRequest.getCodeStr(), mvrNdrResultRequest.getRqmtId(), mvrNdrResultRequest.getServiceUnitNumber());
	}

	@RequestMapping(value = "/licensing/getNdrDetails/{requirmentId}/{employeeId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public MvrNdrDetails getNdrDetails(@PathVariable("requirmentId") Integer requirmentId, @PathVariable("employeeId") String employeeId){
		return mvrAndNDRReplyService.getNdrDetails(requirmentId, employeeId);
	}

	@RequestMapping(value = "/licensing/getEmployeeFaxDetail", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public EmployeeDetail getEmployeeFaxDetail(@RequestParam(value = "employeeId", required = true) String employeeId){
		return mvrAndNDRReplyService.getEmployeeFaxDetail(employeeId);
	}

	@RequestMapping(value = "/licensing/updateFaxDetails", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public Integer updateFaxDetails(@RequestParam(value = "faxNum", required = true) String faxNum,
			@RequestParam(value = "lcnsOprnID", required = true) Integer lcnsOprnID,@RequestParam(value = "faxContentText", required = true) String faxContentText){
		return mvrAndNDRReplyService.updateFaxDetails(faxNum,lcnsOprnID,faxContentText);
	}



	@RequestMapping(value = "/licensing/getMvrReportDetails/{employeeId}", method = RequestMethod.GET)
	@ResponseBody
	public EqmLicensingMvrReportDetailsResponse doGetMvrRptDtl(@PathVariable("employeeId") String employeeId) {
		return mvrAndNDRReplyService.doGetMvrReportDtl(employeeId);
	}


	@RequestMapping(value = "/licensing/getMVRDetails/{requirmentId}/{employeeId}", method = RequestMethod.GET)
	@ResponseBody
	public MvrNdrDetails getMVRDetails(@PathVariable("requirmentId") Integer requirmentId, @PathVariable("employeeId") String employeeId) {
		return mvrAndNDRReplyService.getMVRDetails(requirmentId, employeeId);
	}

	@RequestMapping(value = "/licensing/getMVRAuthDetailsFromReorpts/{employeeId}", method = RequestMethod.GET)
	@ResponseBody
	public List<MvrNdrPopupPacketGridDetail> getMVRAuthDetailsFromReorpts(@PathVariable("employeeId") String employeeId) {
		return mvrAndNDRReplyService.getMVRAuthDetailsFromReorpts(employeeId);
	}

	@RequestMapping(value = "/licensing/doAuthAndCreateMVRReq", method = RequestMethod.POST)
	@ResponseBody
	public void doAuthAndCreateMVRReq(@RequestBody AuthAndCreateMVRRequest authAndCreateMVRRequest) {
		mvrAndNDRReplyService.doAuthAndCreateMVRReq(authAndCreateMVRRequest.getEmplIdLst(), 
				authAndCreateMVRRequest.isFromErrWrkItm(), authAndCreateMVRRequest.isFromSendRequest());
	}


	@RequestMapping(value = "/licensing/removeRecordForRCVDNDRMVR", method = RequestMethod.POST)
	@ResponseBody
	public void removeRecordForRCVDNDRMVR(@RequestBody RemoveRCVDNDRMVRRequest removeRCVDNDRMVRRequest) {
		mvrAndNDRReplyService.removeRecordForRCVDNDRMVR(removeRCVDNDRMVRRequest.getEmployeeID(), removeRCVDNDRMVRRequest.getPacketResnIdList(), 
				removeRCVDNDRMVRRequest.getWorkQueueFlagLst(), removeRCVDNDRMVRRequest.getComments());

	}


	@RequestMapping(value = "/licensing/getMVRReportDetails", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public List<Map<String, Object>> getMVRReportDetails(@RequestBody LicensingRequest licensingRequest) {
		return mvrAndNDRReplyService.getMVRReportDetails(licensingRequest.getEmployeeIdList());
	}

	@RequestMapping(value = "/licensing/insertMvrNdrResultWithDate", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public Boolean insertMvrNdrResultWithDate(@RequestBody LicensingRequest licensingRequest){
		return mvrAndNDRReplyService.insertMvrNdrResultWithDate(licensingRequest);
	}
	@RequestMapping(value = "/licensing/getPacketHistoryNdrList", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public List<MvrNdrPopupPacketGridDetail> getPacketHistoryNdrList(@RequestBody EmployeePacketMvrNdrPopup packetStatus){
		return mvrAndNDRReplyService.getPacketHistoryNdrList(packetStatus);
	}

	@RequestMapping(value = "/licensing/getPacketHistoryMvrList", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public List<MvrNdrPopupPacketGridDetail> getPacketHistoryMvrList(@RequestBody EmployeePacketMvrNdrPopup packetStatus){
		return mvrAndNDRReplyService.getPacketHistoryMvrList(packetStatus);
	}

	@RequestMapping(value = "/licensing/getMvrNDrReplyPacketStatusList", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public List<MvrNdrPopupPacketGridDetail> getMvrNDrReplyPacketStatusList(@RequestParam(value="requirmentId", required=true) Integer rqmtId, @RequestParam(value="code", required=true) String code,  @RequestParam(value="employeeId", required=true) String emplId){
		return mvrAndNDRReplyService.getMvrNDrReplyPacketStatusList(rqmtId, code, emplId);
	}


	@RequestMapping(value = "/licensing/insertEmployeeAuthorizationPacketDetails", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public Integer insertEmployeeAuthorizationPacketDetails(@RequestBody EmployeeAuthorizationDetailsRequest detailsRequest){
		return mvrAndNDRReplyService.insertEmployeeAuthorizationPacketDetails(detailsRequest.getEmpPacketStatusDetails(), detailsRequest.getNumber(), detailsRequest.getMvrNdrCode(), 
				detailsRequest.getComments(), detailsRequest.getFromSupervision());
	}

	//	updateFaxDetails
	@RequestMapping(value = "/licensing/downloadMVRForm", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public void downloadMVRForm(@RequestParam(value="guid", required=true) String guid, HttpServletRequest  request, HttpServletResponse response) throws EqmException {
		if(null != guid){
			try {
				String fileName="licensing";
				response.setContentType("application/pdf");
				response.setHeader("Content-Disposition", "inline;filename="+fileName );
				ServletOutputStream responseOutputStream = null;

				byte[] byteOutput = mvrAndNDRReplyService.downloadFormUsingGuid(guid);
				if(null != byteOutput){
					responseOutputStream = response.getOutputStream();
				}
				if(null!= byteOutput){ 
					responseOutputStream.write(byteOutput); 

				}else{
					responseOutputStream.write("Error While getting Document, Please Try after some time".getBytes());
				}

			} catch (IOException io) {
				logger.error(LicensingConstant.LOGGER_IO_EXCEPTION + LicensingConstant.PDFPAGE_LOGGER_COMMENT + io.getMessage(), io);
			} catch (ResourceNotFoundException rnfe) {
				logger.error(LicensingConstant.LOGGER_RESOURCENOTFOUND_EXCEPTION + LicensingConstant.PDFPAGE_LOGGER_COMMENT + rnfe.getMessage(), rnfe);
			} catch (ParseErrorException pe) {
				logger.error(LicensingConstant.LOGGER_PARSEERROR_EXCEPTION + LicensingConstant.PDFPAGE_LOGGER_COMMENT + pe.getMessage(), pe);
			} catch (MethodInvocationException mie) {
				logger.error(LicensingConstant.LOGGER_METHODINVOKATION_EXCEPTION + LicensingConstant.PDFPAGE_LOGGER_COMMENT + mie.getMessage(), mie);
			} catch (Exception e) {

				e.printStackTrace();
				logger.error(LicensingConstant.LOGGER_EQMEXCEPTION + LicensingConstant.PDFPAGE_LOGGER_COMMENT + e.getMessage(), e);

			}
		}
	}
	
	@RequestMapping(value = "/licensing/downloadMVRFormWQ/{gufnId}",method = RequestMethod.GET)
	  @ResponseBody
	  private byte[] generatePdf(@PathVariable(value = "gufnId") String gufnId) throws DocumentException {
	    
	    try {
	    	byte[] byteOutput = null;
	    	logger.info("======================================================");
	    	logger.info("gufnId"+ gufnId);
	    	byteOutput = mvrAndNDRReplyService.downloadFormUsingGuid("{"+gufnId+"}");
	    	logger.info("byte Code"+ byteOutput.toString());
	        return byteOutput;
	    } catch (ResourceNotFoundException rnfe) {
		      logger.error(LicensingConstant.LOGGER_RESOURCENOTFOUND_EXCEPTION + LicensingConstant.PDFPAGE_LOGGER_COMMENT + rnfe.getMessage(), rnfe);
		    } catch (ParseErrorException pe) {
		      logger.error(LicensingConstant.LOGGER_PARSEERROR_EXCEPTION + LicensingConstant.PDFPAGE_LOGGER_COMMENT + pe.getMessage(), pe);
		    } catch (MethodInvocationException mie) {
		      logger.error(LicensingConstant.LOGGER_METHODINVOKATION_EXCEPTION + LicensingConstant.PDFPAGE_LOGGER_COMMENT + mie.getMessage(), mie);
		    } catch (Exception e) {
		      e.printStackTrace();
		      logger.error(LicensingConstant.LOGGER_EQMEXCEPTION + LicensingConstant.PDFPAGE_LOGGER_COMMENT + e.getMessage(), e);
	    }
		return null;
	  }


	@RequestMapping(value = "/licensing/updateMarkAsSentFaxDetails", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public Integer updateMarkAsSentFaxDetails(@RequestParam(value = "faxNum", required = true) String faxNum,
			@RequestParam(value = "lcnsOprnID", required = true) Integer lcnsOprnID,@RequestParam(value = "faxContentText", required = true) String faxContentText){

		Integer flag = mvrAndNDRReplyService.updateMarkAsSentFaxDetails(faxNum, lcnsOprnID, faxContentText);
		return flag;
	}

	@RequestMapping(value = "/licensing/getFeedbackMsgForEmployeePacket", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public String getFeedbackMsgForEmployeePacket(@RequestBody FeedbackMsgRequest feedbackMsgRequest) {
		return mvrAndNDRReplyService.getFeedbackMsgForEmployeePacket(feedbackMsgRequest);
	}
	
}
