package com.uprr.lic.licensing.rest.model;

import java.util.Date;
import java.util.List;

import com.uprr.lic.dataaccess.Licensing.model.EmployeeDetailLicInit;
import com.uprr.lic.util.DDChoice;
import com.uprr.lic.util.LicensingConstant;
import com.uprr.lic.util.Util;

public class InitiateLicensingRequest {

	 protected DDChoice m_licenseType;

	  protected Date m_startDate;

	  protected String m_classNumber;

	  protected String m_classDescription;

	  protected String m_cityState;	

	  protected String m_bulletinLocation;

	  protected String m_employeeID;

	  protected boolean m_managerTraineeCheckbox;

	  protected boolean conductorTraineeCheckbox;
	  
	  protected String m_hidden;

	  protected String employeeName;
	  protected Date date;
	  protected String licenseClass;
	  
	  protected List<EmployeeDetailLicInit> finalList;
	  
	  // Added for RCO Manager Trainee Pop up (REQ442)
	  protected boolean mgrTraineePopupFlag = false;
	  
	  public boolean isMgrTraineePopupFlag() {
	    return mgrTraineePopupFlag;
	  }
	  public void setMgrTraineePopupFlag(boolean mgrTraineePopupFlag) {
	    this.mgrTraineePopupFlag = mgrTraineePopupFlag;
	  }
	  public String getEmployeeName() {
	    return employeeName;
	  }
	  public void setEmployeeName(String employeeName) {
	    this.employeeName = employeeName;
	  }
	  public Date getDate() {
	    return date;
	  }
	  public void setDate(Date date) {
	    this.date = date;
	  }
	  public String getLicenseClass() {
	    return licenseClass;
	  }
	  public void setLicenseClass(String licenseClass) {
	    this.licenseClass = licenseClass;
	  }
	  public String getReason() {
	    return reason;
	  }
	  public void setReason(String reason) {
	    this.reason = reason;
	  }
	  public String getAction() {
	    return action;
	  }
	  public void setAction(String action) {
	    this.action = action;
	  }
	  protected String reason;
	  protected String action;
	  private static final long serialVersionUID = 1L;

	  /** Getter-Setter Methods */
	  /*public DDChoice getServiceUnit() {
			return m_serviceUnit;
		}

		public void setServiceUnit(DDChoice unit) {
			m_serviceUnit = unit;
		}
	   */
	  public DDChoice getLicenseType() {
	    return m_licenseType;
	  }

	  public void setLicenseType(DDChoice type) {
	    m_licenseType = type;
	  }

	  public Date getStartDate() {
	    return m_startDate;
	  }

	  public void setStartDate(Date date) {
	    m_startDate = date;
	  }

	  public String getClassNumber() {
	    return m_classNumber;
	  }

	  public void setClassNumber(String number) {
	    m_classNumber = number;
	  }

	  public String getClassDescription() {
	    return m_classDescription;
	  }

	  public void setClassDescription(String description) {
	    m_classDescription = description;
	  }

	  public String getCityState() {
	    return m_cityState;
	  }

	  public void setCityState(String cityState) {
	    this.m_cityState = cityState;
	  }

	  public String getBulletinLocation() {
	    return m_bulletinLocation;
	  }

	  public void setBulletinLocation(String location) {
	    m_bulletinLocation = location;
	  }

	  public String getEmployeeID() {
	    if(m_employeeID == null || m_employeeID.equalsIgnoreCase(LicensingConstant.BLANK_STRING)){
	      return null;			
	    }else{
	      return Util.convertLookUpFormatToEmplID(m_employeeID);
	    }
	  }

	  public void setEmployeeID(String employeeid) {
	    if(employeeid == null || employeeid.trim().equalsIgnoreCase(LicensingConstant.BLANK_STRING)){
	      m_employeeID=null;			
	    }else{
	      m_employeeID = Util.convertLookUpFormatToEmplID(employeeid);
	    }
	  }

	  public boolean isManagerTraineeCheckbox() {
	    return m_managerTraineeCheckbox;
	  }

	  public void setManagerTraineeCheckbox(boolean trainee) {
	    m_managerTraineeCheckbox = trainee;
	  }

	  /**
	   * @return the m_hidden
	   */
	  public String getHidden() {
	    return m_hidden;
	  }

	  /**
	   * @param m_hidden the m_hidden to set
	   */
	  public void setHidden(String m_hidden) {
	    this.m_hidden = m_hidden;
	  }

	  public boolean isConductorTraineeCheckbox() {
	    return conductorTraineeCheckbox;
	  }
	  public void setConductorTraineeCheckbox(boolean conductorTraineeCheckbox) {
	    this.conductorTraineeCheckbox = conductorTraineeCheckbox;
	  }
	public List<EmployeeDetailLicInit> getFinalList() {
		return finalList;
	}
	public void setFinalList(List<EmployeeDetailLicInit> finalList) {
		this.finalList = finalList;
	}

}
