package com.uprr.lic.licensing.rest.controller;

import java.text.ParseException;
import java.util.List;
import java.util.Map;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.uprr.lic.dataaccess.Licensing.model.EmployeeDetailLicInit;
import com.uprr.lic.dataaccess.Licensing.model.InitiateLicensingRequestBean;
import com.uprr.lic.dataaccess.common.model.EqmEmplDtls;
import com.uprr.lic.dataaccess.common.model.EqmTestDtls;
import com.uprr.lic.dataaccess.common.model.PersonBean;
import com.uprr.lic.exception.EqmException;
import com.uprr.lic.licensing.rest.model.InitiateLicensingRequest;
import com.uprr.lic.licensing.rest.service.IInitiateLicensingService;
import com.uprr.lic.util.DDChoice;

/**
 * 
 * @author xsat004
 *
 */
@Controller
public class InitiateLicensingController {

	@Autowired
	private IInitiateLicensingService initiateLicensingService;

	@RequestMapping(method = RequestMethod.GET, value = "/licensing/getAllLicenseTypeList", produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public List<DDChoice> getAllLicenseTypeList(
			@RequestParam(value = "licenseType", required = false) String licenseType) {
		return initiateLicensingService.getAllLicenseTypeList(licenseType);
	}

	@RequestMapping(method = RequestMethod.POST, value = "/licensing/insertNewEmployee", produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public boolean insertNewEmployee(@RequestBody PersonBean personBean) {
		return initiateLicensingService.insertNewEmployee(personBean);
	}

	/*@RequestMapping(method = RequestMethod.POST, value = "/licensing/initializeLicensingRequest", produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public InitiateLicensingRequestBean initializeLicensingRequest(
			@RequestBody InitiateLicensingRequest licenseRequest) {
		InitiateLicensingRequestBean bean = new InitiateLicensingRequestBean();
		try {
			if(null != licenseRequest){
			
			BeanUtils.copyProperties(licenseRequest, bean);
			bean =  initiateLicensingService.initializeLicensingRequest(bean, licenseRequest.getFinalList());
			}
		} catch (EqmException e) {
			throw new EqmException(e.getMessage());			
		}
		return bean;
	}

	@RequestMapping(method = RequestMethod.POST, value = "/licensing/createInitiateLicenseRequest", produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public Map<String, Map<String, EmployeeDetailLicInit>> createInitiateLicenseRequest(
			@RequestBody InitiateLicensingRequest licenseRequest) {
		try {
			InitiateLicensingRequestBean bean = new InitiateLicensingRequestBean();
			BeanUtils.copyProperties(licenseRequest, bean);
			return initiateLicensingService.createInitiateLicenseRequest(bean);			
		} catch (EqmException e) {
			throw new EqmException(e.getMessage());			
		}
		
	}*/
	
	/**
	 * InitializeLicensingRequest and CreateInitiateLicenseRequest mearged in single method
	 */
	
	@RequestMapping(method = RequestMethod.POST, value = "/licensing/initializeAndCreateLicensingRequest", produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public Map<String, Map<String, EmployeeDetailLicInit>> initializeAndCreateLicensingRequest(
			@RequestBody InitiateLicensingRequest licenseRequest) {
		if(null != licenseRequest){
		try {		
			InitiateLicensingRequestBean bean = new InitiateLicensingRequestBean();
			BeanUtils.copyProperties(licenseRequest, bean);
			return initiateLicensingService.initializeAndCreateLicensingRequest(bean, licenseRequest.getFinalList());			
		} catch (EqmException e) {
			throw new EqmException(e.getMessage());			
		}
		}
		return null;
	}

	@RequestMapping(method = RequestMethod.GET, value = "/licensing/isEmployeeLicensed", produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public boolean isEmployeeLicensed(@RequestParam(value = "employeeID", required = true) String employeeID,
			@RequestParam(value = "flagHist", required = true)  Boolean flagHist) {
		return initiateLicensingService.isEmployeeLicensed(employeeID, flagHist);
	}

	@RequestMapping(method = RequestMethod.GET, value = "/licensing/checkValidTestAvailability", produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public EqmTestDtls checkForValidTestDetailsAvailability(
			@RequestParam(value = "employeeID", required = true) String employeeID,
			@RequestParam(value = "selection", required = true)  Integer selection) {
		return initiateLicensingService.checkForValidTestDetailsAvailability(employeeID, selection);
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "/licensing/getEmployeeDetailsForInitiateLicenseRequest")
	@ResponseBody
	public EmployeeDetailLicInit getEmployeeDetailsForInitiateLicenseRequest(
			@RequestBody InitiateLicensingRequest licenseRequest) {
		try {
			InitiateLicensingRequestBean bean = new InitiateLicensingRequestBean();
			BeanUtils.copyProperties(licenseRequest, bean);

			return initiateLicensingService.getEmployeeDetailsForInitiateLicenseRequest(bean);
		} catch (EqmException | ParseException  e) {
			throw new EqmException(e.getMessage());			
		}
	}
	/**
	 * This API will call the external service for get person details
	 * @param employeeID
	 * @return
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/licensing/getPersonDetails", produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public PersonBean getEmployeeDetails(@RequestParam(value = "employeeID", required = true) String employeeID){
		return initiateLicensingService.getEmployeeDetails(employeeID);
	}
	
	/**
	 * This API will get the employee details from local
	 * @param employeeID
	 * @return
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/licensing/getEmployeeDetails", produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	 public EqmEmplDtls getEmplDtls(@RequestParam(value = "employeeID", required = true) String employeeID) {
		    return initiateLicensingService.getEmplDtls(employeeID);
		  }
	
	@RequestMapping(method = RequestMethod.POST, value = "/licensing/getEmployeeTestDetails", produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public List<EmployeeDetailLicInit> getEmployeeTestDetails(@RequestBody List<EmployeeDetailLicInit> employeebeans){
		  return initiateLicensingService.getEmployeeTestDetails(employeebeans);
	}
}
