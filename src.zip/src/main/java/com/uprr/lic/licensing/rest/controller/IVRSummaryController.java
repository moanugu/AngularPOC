/**
 * 
 */
package com.uprr.lic.licensing.rest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.uprr.lic.dataaccess.common.model.IVRSummaryDetails;
import com.uprr.lic.licensing.rest.model.IVRSummary;
import com.uprr.lic.licensing.rest.service.IIVRSummaryService;

/**
 * @author xsat976
 *
 */
@Controller
public class IVRSummaryController {
	
	@Autowired
	private IIVRSummaryService ivrSummaryService; 
	
	@RequestMapping(method = RequestMethod.POST , value ="/insertIVRSummary")
	@ResponseBody
	public String insertIVRSummary(@RequestBody IVRSummary ivrSummary){
		return ivrSummaryService.insertIVRSummary(ivrSummary);
	}
	
	@RequestMapping(method = RequestMethod.POST , value ="/searchIVRSummaryHistory")
	@ResponseBody
	public List<IVRSummaryDetails> searchIVRSummaryHistory(@RequestBody IVRSummary ivrSummary){
		return ivrSummaryService.searchIVRSummaryHistory(ivrSummary.getEmployeeID(), ivrSummary.getFromDate(), ivrSummary.getToDate());
	}

}
