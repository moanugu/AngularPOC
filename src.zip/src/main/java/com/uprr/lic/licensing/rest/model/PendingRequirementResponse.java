package com.uprr.lic.licensing.rest.model;


import com.uprr.lic.dataaccess.common.model.Rules;
import com.uprr.lic.util.LicensingConstant;
import com.uprr.lic.util.Util;

public class PendingRequirementResponse {

  private String employeeID;

  private String employeeName;

  private String serviceUnit;

  private Integer serviceUnitNbr;

  private String licenseClass;

  private String medicalResult;

  private String rulesResult;

  private String certRideResult;

  private String mvrResult;

  private String ndrResult;

  private Rules rules;

  private Integer lcnsRqmtId;

  private String licenseClassDesc;

  private boolean checkWorkItemForMvrOrNdr = false;

  private boolean checkWorkItemForPeaMvr = false;

  private boolean checkWorkItemForPeaNdr = false;

  private boolean employeeAlreadyLicensedFlag = false;

  private static final long serialVersionUID = 1L;

  private String jobTypeCode;

  private Integer testId;

  // Added For Conductor Licensing
  private String ftxEventResult;

  private String conExamFlag;

  private String condLicType;

  private Integer ftxEvntTestId;
  
  private Integer ftxEvntQlfnCodeId;
  
  private String ftxEventDate;

  private String or6aExamResult;

  private String or6aExamDate;

  private String description;
  //End
  
  // Added For REQ #194
  private String knlgExamResult;
  
  private String knlgExamDate;
  
  private String knlgExamType;
  
  //added for Req#347
  private String ertCode;
  //added for Req 347
  private String agrmntFlag;
//REQ 581 changes start 
  private String reCertFlag;
//Added for SS_QC#7287:start
  private String opccValue;
  
  private String oprcValue;
  
  private String opecValue;
  
  private Integer ftxEventID; // Added for SS_QC#10202(9049)
  
  /**
   * @return the opccValue
   */
  public String getOpccValue() {
    return opccValue;
  }

  /**
   * @param opccValue the opccValue to set
   */
  public void setOpccValue(String opccValue) {
    this.opccValue = opccValue;
  }

  /**
   * @return the oprcValue
   */
  public String getOprcValue() {
    return oprcValue;
  }

  /**
   * @param oprcValue the oprcValue to set
   */
  public void setOprcValue(String oprcValue) {
    this.oprcValue = oprcValue;
  }

  /**
   * @return the opecValue
   */
  public String getOpecValue() {
    return opecValue;
  }

  /**
   * @param opecValue the opecValue to set
   */
  public void setOpecValue(String opecValue) {
    this.opecValue = opecValue;
  }//Added for ss_QC#7287:end
  private String rcnmCode;
/**
   * @return the reCertFlag
   */
  public String getReCertFlag() {
    return reCertFlag;
  }

  /**
   * @param reCertFlag the reCertFlag to set
   */
  public void setReCertFlag(String reCertFlag) {
    this.reCertFlag = reCertFlag;
  }
  /**
   * @return the rcnmCode
   */
  public String getRcnmCode() {
    return rcnmCode;
  }

  /**
   * @param rcnmCode the rcnmCode to set
   */
  public void setRcnmCode(String rcnmCode) {
    this.rcnmCode = rcnmCode;
  }

//REQ 581 changes end
  
  public Integer getLcnsRqmtId() {
    return lcnsRqmtId;
  }

  public void setLcnsRqmtId(Integer rqmtId) {
    lcnsRqmtId = rqmtId;
  }

  public String getEmployeeID() {
    if(employeeID == null || employeeID.equalsIgnoreCase(LicensingConstant.BLANK_STRING)){
      return null;		   
    }else{
      return Util.removeExtraZeroEmployeeId(employeeID); 
    }
  }

  public void setEmployeeID(String employeeID) {
    if(employeeID == null || employeeID.equalsIgnoreCase(LicensingConstant.BLANK_STRING)){
      this.employeeID=null;  
    }else{
      this.employeeID = Util.removeExtraZeroEmployeeId(employeeID);
    }
  }

  public String getEmployeeName() {
    return employeeName;
  }

  public void setEmployeeName(String employeeName) {
    this.employeeName = employeeName;
  }

  public String getServiceUnit() {
    return serviceUnit;
  }

  public void setServiceUnit(String serviceUnit) {
    this.serviceUnit = serviceUnit;
  }

  public String getLicenseClass() {
    return licenseClass;
  }

  public void setLicenseClass(String licenseClass) {
    this.licenseClass = licenseClass;
  }

  public String getMedicalResult() {
    return medicalResult;
  }

  public void setMedicalResult(String medicalResult) {
    this.medicalResult = medicalResult;
  }

  public String getRulesResult() {
    return rulesResult;
  }

  public void setRulesResult(String rulesResult) {
    this.rulesResult = rulesResult;
  }

  public String getCertRideResult() {
    return certRideResult;
  }

  public void setCertRideResult(String certRideResult) {
    this.certRideResult = certRideResult;
  }

  public String getMvrResult() {
    return mvrResult;
  }

  public void setMvrResult(String mvrResult) {
    this.mvrResult = mvrResult;
  }

  public String getNdrResult() {
    return ndrResult;
  }

  public void setNdrResult(String ndrResult) {
    this.ndrResult = ndrResult;
  }

  public Rules getRules() {
    return rules;
  }

  public void setRules(Rules rules) {
    this.rules = rules;
  }

  public String getLicenseClassDesc()
  {
    return licenseClassDesc;
  }

  public void setLicenseClassDesc(String classDesc)
  {
    licenseClassDesc = classDesc;
  }

  /**
   * @return the m_serviceUnitNbr
   */
  public Integer getServiceUnitNbr()
  {
    return serviceUnitNbr;
  }

  /**
   * @param unitNbr the m_serviceUnitNbr to set
   */
  public void setServiceUnitNbr(Integer unitNbr)
  {
    serviceUnitNbr = unitNbr;
  }

  public boolean isCheckWorkItemForMvrOrNdr() {
    return checkWorkItemForMvrOrNdr;
  }

  public void setCheckWorkItemForMvrOrNdr(boolean workItemForMvr) {
    checkWorkItemForMvrOrNdr = workItemForMvr;
  }

  public boolean isCheckWorkItemForPeaMvr() {
    return checkWorkItemForPeaMvr;
  }

  public void setCheckWorkItemForPeaMvr(boolean workItemForPeaMvr) {
    checkWorkItemForPeaMvr = workItemForPeaMvr;
  }

  public boolean isCheckWorkItemForPeaNdr() {
    return checkWorkItemForPeaNdr;
  }

  public void setCheckWorkItemForPeaNdr(boolean workItemForPeaNdr) {
    checkWorkItemForPeaNdr = workItemForPeaNdr;
  }

  public String getJobTypeCode() {
    return jobTypeCode;
  }

  public void setJobTypeCode(String typeCode) {
    jobTypeCode = typeCode;
  }

  public Integer getTestId() {
    return testId;
  }

  public void setTestId(Integer testid) {
    testId = testid;
  }

  public boolean isEmployeeAlreadyLicensedFlag() {
    return employeeAlreadyLicensedFlag;
  }

  public void setEmployeeAlreadyLicensedFlag(boolean alreadyLicensedFlag) {
    employeeAlreadyLicensedFlag = alreadyLicensedFlag;
  }

  /**
   * @return the ftxEventResult
   */
  public String getFtxEventResult() {
    return ftxEventResult;
  }

  /**
   * @param ftxEventResult the ftxEventResult to set
   */
  public void setFtxEventResult(String ftxEventResult) {
    this.ftxEventResult = ftxEventResult;
  }

  /**
   * @return the conExamFlag
   */
  public String getConExamFlag() {
    return conExamFlag;
  }

  /**
   * @param conExamFlag the conExamFlag to set
   */
  public void setConExamFlag(String conExamFlag) {
    this.conExamFlag = conExamFlag;
  }

  /**
   * @return the ftxEvntTestId
   */
  public Integer getFtxEvntTestId() {
    return ftxEvntTestId;
  }

  /**
   * @param ftxEvntTestId the ftxEvntTestId to set
   */
  public void setFtxEvntTestId(Integer ftxEvntTestId) {
    this.ftxEvntTestId = ftxEvntTestId;
  }

  /**
   * @return the ftxEvntQlfnCodeId
   */
  public Integer getFtxEvntQlfnCodeId() {
    return ftxEvntQlfnCodeId;
  }

  /**
   * @param ftxEvntQlfnCodeId the ftxEvntQlfnCodeId to set
   */
  public void setFtxEvntQlfnCodeId(Integer ftxEvntQlfnCodeId) {
    this.ftxEvntQlfnCodeId = ftxEvntQlfnCodeId;
  }

  /**
   * @return the ftxEventDate
   */
  public String getFtxEventDate() {
    return ftxEventDate;
  }

  /**
   * @param ftxEventDate the ftxEventDate to set
   */
  public void setFtxEventDate(String ftxEventDate) {
    this.ftxEventDate = ftxEventDate;
  }

  /**
   * @return the or6aExamResult
   */
  public String getOr6aExamResult() {
    return or6aExamResult;
  }

  /**
   * @param or6aExamResult the or6aExamResult to set
   */
  public void setOr6aExamResult(String or6aExamResult) {
    this.or6aExamResult = or6aExamResult;
  }

  /**
   * @return the condLicType
   */
  public String getCondLicType() {
    return condLicType;
  }

  /**
   * @param condLicType the condLicType to set
   */
  public void setCondLicType(String condLicType) {
    this.condLicType = condLicType;
  }

  /**
   * @return the or6aExamDate
   */
  public String getOr6aExamDate() {
    return or6aExamDate;
  }

  /**
   * @param or6aExamDate the or6aExamDate to set
   */
  public void setOr6aExamDate(String or6aExamDate) {
    this.or6aExamDate = or6aExamDate;
  }

  /**
   * @return the description
   */
  public String getDescription() {
    return description;
  }

  /**
   * @param description the description to set
   */
  public void setDescription(String description) {
    this.description = description;
  }

  /**
   * @return the knlgExamResult
   */
  public String getKnlgExamResult() {
    return knlgExamResult;
  }

  /**
   * @param knlgExamResult the knlgExamResult to set
   */
  public void setKnlgExamResult(String knlgExamResult) {
    this.knlgExamResult = knlgExamResult;
  }

  /**
   * @return the knlgExamDate
   */
  public String getKnlgExamDate() {
    return knlgExamDate;
  }

  /**
   * @param knlgExamDate the knlgExamDate to set
   */
  public void setKnlgExamDate(String knlgExamDate) {
    this.knlgExamDate = knlgExamDate;
  }

  /**
   * @return the knlgExamType
   */
  public String getKnlgExamType() {
    return knlgExamType;
  }

  /**
   * @param knlgExamType the knlgExamType to set
   */
  public void setKnlgExamType(String knlgExamType) {
    this.knlgExamType = knlgExamType;
  }
  //start: added for Req347
  /**
   * @return the ertCode
   */
  public String getErtCode() {
    return ertCode;
  }
  /**
   * @param ertCode the ertCode to set
   */
  public void setErtCode(String ertCode) {
    this.ertCode = ertCode;
  }
  /**
   * @return the agrmntFlag
   */
  public String getAgrmntFlag() {
    return agrmntFlag;
  }
  /**
   * @param agrmntFlag the agrmntFlag to set
   */
  public void setAgrmntFlag(String agrmntFlag) {
    this.agrmntFlag = agrmntFlag;
  }
  //end: added for req 347
  
  //Added for SS_QC#6703:start
  private String riskScore;
    
  public String getRiskScore() {
	return riskScore;
}

public void setRiskScore(String riskScore) {
	this.riskScore = riskScore;
}
//Added for SS_QC#6703:end

//Added for SS_QC#10202(9049) - Start
public Integer getFtxEventID() {
	return ftxEventID;
}

public void setFtxEventID(Integer ftxEventID) {
	this.ftxEventID = ftxEventID;
}
//Added for SS_QC#10202(9049) - End

}
