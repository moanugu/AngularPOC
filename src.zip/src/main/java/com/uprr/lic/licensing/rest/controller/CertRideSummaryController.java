package com.uprr.lic.licensing.rest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.uprr.lic.licensing.rest.model.CategoryInformationDetailResponse;
import com.uprr.lic.licensing.rest.model.CertRideSummaryResponse;
import com.uprr.lic.licensing.rest.service.ICertRideSummaryService;

/**
 * This Controller is using for NDRReplyController
 * @author xsat956
 *
 */
@Controller
public class CertRideSummaryController {
	
	@Autowired
	private ICertRideSummaryService certRideSummaryService;
	
	
	@RequestMapping(value = "/licensing/getSummaryDetail/{employeeId}/{testId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public CertRideSummaryResponse getSummaryDetail(@PathVariable("employeeId") String employeeId, @PathVariable("testId") Integer testId) {
	    return certRideSummaryService.getSummaryDetail(employeeId, testId);
	}

	@RequestMapping(value = "/licensing/getCategoryInformationList/{employeeId}/{testId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public List<CategoryInformationDetailResponse> getCategoryInformationList(@PathVariable("employeeId") String employeeId, @PathVariable("testId") Integer testId){
	     return certRideSummaryService.getCategoryInformationList(employeeId, testId) ;
	}
	
}
