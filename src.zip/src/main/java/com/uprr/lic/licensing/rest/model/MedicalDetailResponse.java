package com.uprr.lic.licensing.rest.model;

import com.uprr.lic.dataaccess.common.model.Medical;
import com.uprr.lic.util.LicensingConstant;
import com.uprr.lic.util.Util;

public class MedicalDetailResponse  {


	  private Medical medical;

	  private String empId;

	  public Medical getMedical() {
	    return medical;
	  }

	  public void setMedical(Medical medical) {
	    this.medical = medical;
	  }

	  public String getEmpId() {
		  if(empId == null || empId.equalsIgnoreCase(LicensingConstant.BLANK_STRING)){
			  return null;		    
		  }else{
			  return Util.removeExtraZeroEmployeeId(empId);  
		  }
	  }

	  public void setEmpId(String empid) {
		  if(empid == null || empid.equalsIgnoreCase(LicensingConstant.BLANK_STRING)){
			  empId=null;		 
		  }else{
			  empId = Util.removeExtraZeroEmployeeId(empid);
		  }
	  }

	}