package com.uprr.lic.licensing.rest.model;

import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

import com.uprr.lic.dataaccess.Licensing.model.License;
import com.uprr.lic.dataaccess.Licensing.model.TestDetails;

/**
 * @author xsat956
 *
 */
public class IssueStudentLicBeanDetail  {

	  protected String employeeName;

	  protected String serviceUnit;

	  protected String dateOfBirth;

	  protected Date effectiveDate;

	  protected Date expireDate;

	  protected List<License> existingLicDetails;

	  protected List<TestDetails> testDetails;

	  protected String managerName;

	  protected String startDate;

	  protected String state;

	  protected String city;

	  protected String bulletinLocation;

	  protected String classNumber;

	  protected String licenseClassDescription;

	  protected Map<String,List<String>> comment;

	  protected String managerTrainee;

	  protected String teyExperience;

	  protected String lblTeyExperience;

	  protected String pinCodesforManagerTrainee;

	  protected Integer workItemId;

	  protected String jobTypeCode;

	  protected boolean studentLicenseFlag=false;

	  protected Integer testId;

	  protected Integer lcnsRqmtId;

	  protected Integer svcUnitId;

	  protected Integer qlfnCode;

	  protected Boolean validClass1Lcns=false;

	  private Integer ftxEvntTestId;

	  //added for Req#347
	  private String ertCode;
	  //added for Req 347
	  private String agrmntFlag;

	  //Added for SS_QC#4759 : Start
	  private String employeeId;
	  
	  private String lstUptdEmplId;
	  
	  private Calendar lstUptdDate;
	  

	  public String getEmployeeId() {
	    return employeeId;
	  }

	  public void setEmployeeId(final String employeeId) {
	    this.employeeId = employeeId;
	  }
	  
	  public Calendar getLstUptdDate() {
	    return lstUptdDate;
	  }

	  public void setLstUptdDate(final Calendar lstUptdDate) {
	    this.lstUptdDate = lstUptdDate;
	  }
	  
	  public String getLstUptdEmplId() {
	    return lstUptdEmplId;
	  }

	  public void setLstUptdEmplId(final String lstUptdEmplId) {
	    this.lstUptdEmplId = lstUptdEmplId;
	  }//Added for SS_QC#4759 : End


	  public Integer getQlfnCode() {
	    return qlfnCode;
	  }

	  public void setQlfnCode(Integer qlfnCode) {
	    this.qlfnCode = qlfnCode;
	  }

	  public Boolean getValidClass1Lcns() {
	    return validClass1Lcns;
	  }

	  public void setValidClass1Lcns(Boolean validClass1Lcns) {
	    this.validClass1Lcns = validClass1Lcns;
	  }  

	  private static final long serialVersionUID = 1L;

	  public String getEmployeeName() {
	    return employeeName;
	  }

	  public void setEmployeeName(String name) {
	    employeeName = name;
	  }

	  public String getServiceUnit() {
	    return serviceUnit;
	  }

	  public void setServiceUnit(String unit) {
	    serviceUnit = unit;
	  }

	  public String getDateOfBirth() {
	    return dateOfBirth;
	  }

	  public void setDateOfBirth(String ofBirth) {
	    dateOfBirth = ofBirth;
	  }

	  public Date getEffectiveDate() {
	    return effectiveDate;
	  }

	  public void setEffectiveDate(Date date) {
	    effectiveDate = date;
	  }

	  public Date getExpireDate() {
	    return expireDate;
	  }

	  public void setExpireDate(Date date) {
	    expireDate = date;
	  }

	  public List<License> getExistingLicDetails() {
	    return existingLicDetails;
	  }

	  public void setExistingLicDetails(List<License> licDetails) {
	    existingLicDetails = licDetails;
	  }

	  public List<TestDetails> getTestDetails() {
	    return testDetails;
	  }

	  public void setTestDetails(List<TestDetails> details) {
	    testDetails = details;
	  }

	  public String getManagerName() {
	    return managerName;
	  }

	  public void setManagerName(String name) {
	    managerName = name;
	  }

	  public String getStartDate() {
	    return startDate;
	  }

	  public void setStartDate(String date) {
	    startDate = date;
	  }

	  public String getState() {
	    return state;
	  }

	  public void setState(String state) {
	    this.state = state;
	  }

	  public String getCity() {
	    return city;
	  }

	  public void setCity(String city) {
	    this.city = city;
	  }

	  public String getBulletinLocation() {
	    return bulletinLocation;
	  }

	  public void setBulletinLocation(String location) {
	    bulletinLocation = location;
	  }

	  public String getClassNumber() {
	    return classNumber;
	  }

	  public void setClassNumber(String number) {
	    classNumber = number;
	  }

	  public String getLicenseClassDescription() {
	    return licenseClassDescription;
	  }

	  public void setLicenseClassDescription(String classDescription) {
	    licenseClassDescription = classDescription;
	  }

	  public Map<String, List<String>> getComment() {
	    return comment;
	  }

	  public void setComment(Map<String, List<String>> comment) {
	    this.comment = comment;
	  }

	  public String isManagerTrainee() {
	    return managerTrainee;
	  }

	  public void setManagerTrainee(String string) {
	    managerTrainee = string;
	  }

	  public String getPinCodesforManagerTrainee() {
	    return pinCodesforManagerTrainee;
	  }

	  public void setPinCodesforManagerTrainee(String codesforManagerTrainee) {
	    pinCodesforManagerTrainee = codesforManagerTrainee;
	  }

	  public Integer getWorkItemId() {
	    return workItemId;
	  }

	  public void setWorkItemId(Integer itemId) {
	    workItemId = itemId;
	  }

	  public String isTeyExperience() {
	    return teyExperience;
	  }

	  public void setTeyExperience(String experience) {
	    teyExperience = experience;
	  }

	  /**
	   * @return the jobTypeCode
	   */
	  public String getJobTypeCode() {
	    return jobTypeCode;
	  }

	  /**
	   * @param typeCode the jobTypeCode to set
	   */
	  public void setJobTypeCode(String typeCode) {
	    jobTypeCode = typeCode;
	  }

	  /**
	   * @return the m_studentLicenseFlag
	   */
	  public boolean isStudentLicenseFlag() {
	    return studentLicenseFlag;
	  }

	  /**
	   * @param licenseFlag the m_studentLicenseFlag to set
	   */
	  public void setStudentLicenseFlag(boolean licenseFlag) {
	    studentLicenseFlag = licenseFlag;
	  }


	  public String getLblTeyExperience() {
	    return lblTeyExperience;
	  }

	  public void setLblTeyExperience(String teyExperience) {
	    lblTeyExperience = teyExperience;
	  }

	  /**
	   * @return the testId
	   */
	  public Integer getTestId() {
	    return testId;
	  }

	  /**
	   * @param testid the testId to set
	   */
	  public void setTestId(Integer testid) {
	    testId = testid;
	  }

	  public Integer getLcnsRqmtId() {
	    return lcnsRqmtId;
	  }

	  public void setLcnsRqmtId(Integer rqmtId) {
	    lcnsRqmtId = rqmtId;
	  }

	  public Integer getSvcUnitId() {
	    return svcUnitId;
	  }

	  public void setSvcUnitId(Integer unitId) {
	    svcUnitId = unitId;
	  }

	  /**
	   * @return the ftxEvntTestId
	   */
	  public Integer getFtxEvntTestId() {
	    return ftxEvntTestId;
	  }

	  /**
	   * @param ftxEvntTestId the ftxEvntTestId to set
	   */
	  public void setFtxEvntTestId(Integer ftxEvntTestId) {
	    this.ftxEvntTestId = ftxEvntTestId;
	  }
	//start: added for Req347
	  /**
	   * @return the ertCode
	   */
	  public String getErtCode() {
	    return ertCode;
	  }
	  /**
	   * @param ertCode the ertCode to set
	   */
	  public void setErtCode(String ertCode) {
	    this.ertCode = ertCode;
	  }
	  /**
	   * @return the agrmntFlag
	   */
	  public String getAgrmntFlag() {
	    return agrmntFlag;
	  }
	  /**
	   * @param agrmntFlag the agrmntFlag to set
	   */
	  public void setAgrmntFlag(String agrmntFlag) {
	    this.agrmntFlag = agrmntFlag;
	  }
	  //end: added for req 347
}
