/**
 * 
 */
package com.uprr.lic.licensing.rest.service;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uprr.lic.dataaccess.common.model.EqmAsgnDtls;
import com.uprr.lic.dataaccess.common.model.EqmEmplDtls;
import com.uprr.lic.dataaccess.common.model.IVRSummaryDetails;
import com.uprr.lic.dataaccess.components.licensing.service.ILicensingService;
import com.uprr.lic.dataaccess.workflow.impl.EqmsWorkFlowCustombean;
import com.uprr.lic.dataaccess.workflow.impl.EqmsWorkItemBean;
import com.uprr.lic.dataaccess.workflow.impl.WorkItemRoleMgrBean;
import com.uprr.lic.licensing.rest.model.IVRSummary;
import com.uprr.lic.util.EQMSConstant;
import com.uprr.lic.util.EQMSResnConstant;
import com.uprr.lic.util.LicensingConstant;

/**
 * @author xsat976
 *
 */
@Service("ivrSummaryService")
public class IVRSummaryService implements IIVRSummaryService{
	
	@Autowired
	private ILicensingService licensingService;
	
	@Override
	public String insertIVRSummary(IVRSummary ivrSummary) {
		String returnMessage = "";
		EqmEmplDtls eqmEmplDtls = licensingService.getEqmEmployeeDtlsById(ivrSummary.getEmployeeID());
		if(licensingService.insertIVRSummaryWorkItem(createWorkItemBean(ivrSummary , eqmEmplDtls))){
			returnMessage = "IVR Summary Details added successfully..!";
		}else{
			returnMessage = "Error in added IVR Summary Details..!";
		}
		return returnMessage;
	}
	
	@Override
	public List<IVRSummaryDetails> searchIVRSummaryHistory(String emplId, String fromDate, String toDate) {
		try{
			return licensingService.getIVRSummaryDetailsList(emplId, fromDate, toDate);
		}catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		
	}
	
	/**
	 * Create work item from IVR summary details.
	 * @param ivrSummary
	 * @param eqmEmplDtls
	 */
	private EqmsWorkItemBean createWorkItemBean(IVRSummary ivrSummary , EqmEmplDtls eqmEmplDtls){
		if(ivrSummary == null) {
			return null;
		}
		
		  final EqmsWorkItemBean eqmsWorkItem = new EqmsWorkItemBean();
	      eqmsWorkItem.setEmployeeId(ivrSummary.getEmployeeID());
	      eqmsWorkItem.setModuleId(EQMSConstant.LICENSING_MODULE_ID);
	      if(null != eqmEmplDtls){
		      if(null != eqmEmplDtls.getEqmSvcUnit() && null != eqmEmplDtls.getEqmSvcUnit().getSvcUnitNbr()) {
		        eqmsWorkItem.setServiceUnitId(eqmEmplDtls.getEqmSvcUnit().getSvcUnitNbr());
		      }
	      }
	      eqmsWorkItem.setHistoryFlag(LicensingConstant.FLAG_N);
	      eqmsWorkItem.setCreationDate(Calendar.getInstance());
	      eqmsWorkItem.setCreatorId(ivrSummary.getCrtnEmployeeID());
	      eqmsWorkItem.setModifiedDate(Calendar.getInstance());
	      eqmsWorkItem.setModifiedId(ivrSummary.getCrtnEmployeeID());
	      
	      final EqmsWorkFlowCustombean eqmsWorkFlowCustombean = new EqmsWorkFlowCustombean();
	      eqmsWorkFlowCustombean.setCustomField3(LicensingConstant.IVR_SUMMARY);
	      eqmsWorkFlowCustombean.setCustomField4(ivrSummary.getCallBackDays());
	      eqmsWorkFlowCustombean.setCustomField5(ivrSummary.getSummaryDate());
	      eqmsWorkFlowCustombean.setCustomField10(ivrSummary.getCrtnEmployeeID());
	      eqmsWorkItem.setEqmsWorkFlowCustombean(eqmsWorkFlowCustombean);
	      
	      List<WorkItemRoleMgrBean> roleMgrList = getRoleManagerList(ivrSummary.getEmployeeID());	      
	     
	      eqmsWorkItem.setRoleMgrList(roleMgrList);
	      eqmsWorkItem.setReasonId(EQMSResnConstant.RESN_ID_IVR_SUMMARY);
	      eqmsWorkItem.setWorkItemCmnt(ivrSummary.getComments());
	      return eqmsWorkItem;
	}

	/**
	 * This method is used to populate role manager list by employeeID.
	 * @param ivrSummary
	 * @param roleMgrList
	 */
	private List<WorkItemRoleMgrBean> getRoleManagerList(String emplId) {
		
		final List<WorkItemRoleMgrBean> roleMgrList = new ArrayList<WorkItemRoleMgrBean>();
		WorkItemRoleMgrBean workItemRoleMgrBean = null;
	      final Integer[] roleArray = new Integer[]{EQMSConstant.ROLE_ID_LICENSING_USER, 
	                                       EQMSConstant.ROLE_ID_LICENSING_ADMIN, 
	                                       EQMSConstant.ROLE_ID_SYSTEM_ADMIN};
	      for (final Integer roleId : roleArray) {
	        workItemRoleMgrBean = new WorkItemRoleMgrBean();
	        workItemRoleMgrBean.setRoleId(roleId);
	        workItemRoleMgrBean.setCrtnDate(Calendar.getInstance());
	        workItemRoleMgrBean.setCrtnEmplId(EQMSConstant.DEFAULT_EQMS_USER);
	        workItemRoleMgrBean.setLastUptdDate(Calendar.getInstance());
	        workItemRoleMgrBean.setLastUptdEmplId(EQMSConstant.DEFAULT_EQMS_USER);
	        roleMgrList.add(workItemRoleMgrBean);
	      }
	      
	      final List<EqmAsgnDtls> eqmAsgnMgrList =  licensingService.getAssignedManagerList(emplId);
          
	      if(!eqmAsgnMgrList.isEmpty()){
            for(final EqmAsgnDtls eqmAsgnObj :eqmAsgnMgrList ){
              workItemRoleMgrBean = new WorkItemRoleMgrBean();
              workItemRoleMgrBean.setRoleId(EQMSConstant.ROLE_ID_MANAGER);
              workItemRoleMgrBean.setCrtnDate(Calendar.getInstance());
              workItemRoleMgrBean.setCrtnEmplId(EQMSConstant.DEFAULT_EQMS_USER);
              workItemRoleMgrBean.setLastUptdDate(Calendar.getInstance());
              workItemRoleMgrBean.setLastUptdEmplId(EQMSConstant.DEFAULT_EQMS_USER);
              workItemRoleMgrBean.setMgrId(eqmAsgnObj.getEqmEmplDtlsByMgrId().getEmplId());
              roleMgrList.add(workItemRoleMgrBean);
            }
          }
	      return roleMgrList;
	}

}
