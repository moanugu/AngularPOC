package com.uprr.lic.licensing.rest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.uprr.lic.dataaccess.Licensing.model.Restriction;
import com.uprr.lic.licensing.rest.service.IRestrictionService;

@Controller
public class RestrictionController {

	@Autowired
	private IRestrictionService restrictionService;
	
	@RequestMapping(value = "/licensing/getEmployeeDetailsForRestriction", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public Restriction getEmployeeDetailsForRestriction(@RequestParam(value="employeeId" , required=true) String employeeId) {
		return restrictionService.getEmployeeDetailsForRestriction(employeeId);
	}

	@RequestMapping(value = "/licensing/insertEmpRestrictionData", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public Boolean insertEmpRestrictionData(@RequestBody Restriction restriction) {
		return restrictionService.insertEmpRestrictionData(restriction);
	}

	@RequestMapping(value = "/licensing/getRailRoadList", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public List<String> getRailRoadList() {
		return restrictionService.getRailRoadList();
	}
}
