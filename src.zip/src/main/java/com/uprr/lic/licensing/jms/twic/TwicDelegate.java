package com.uprr.lic.licensing.jms.twic;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.uprr.lic.dataaccess.common.model.EqmEmplDtls;
import com.uprr.lic.dataaccess.twic.model.TwicBean;
import com.uprr.lic.dataaccess.twic.service.ITwicService;

/**
 * @author xsat212
 */
public class TwicDelegate {

	@Autowired
	private ITwicService twicService;

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	private final String className = TwicDelegate.class.getCanonicalName();

	/**
	 * 
	 * Classname / Method Name : TwicDelegate/getEmplName()
	 * 
	 * @param employeeID
	 * @return Description : This method is used to get employee details on
	 *         click of add button.
	 */
	public List<EqmEmplDtls> getEmplName(final String employeeID) {
		return twicService.getEmplName(employeeID);
	}

	/**
	 * 
	 * Classname / Method Name : TwicDelegate/submitTwicDetails()
	 * 
	 * @param employeeGridList
	 * @param crtnEmplId
	 * @param serviceUntNbr
	 *            Description : This method is used to submit twic Details
	 */
	public void submitTwicDetails(final List<TwicBean> employeeGridList, final String crtnEmplId,
			final Integer serviceUntNbr) {
		twicService.submitTwicDetails(employeeGridList, crtnEmplId, serviceUntNbr);
	}

	/**
	 * @param twicService
	 *            the twicService to set
	 */
	public void setTwicService(final ITwicService twicService) {
		this.twicService = twicService;
	}

	/**
	 * 
	 * Classname / Method Name : TwicDelegate/getTwicDtls()
	 * 
	 * @param employeeID
	 * @return Description : This method is used to get TWIC details base on
	 *         employee ID.
	 */
	public TwicBean getTwicDtls(final String employeeID) {
		return twicService.getTwicDtls(employeeID);
	}

}
