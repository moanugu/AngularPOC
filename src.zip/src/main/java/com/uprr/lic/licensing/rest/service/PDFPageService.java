/**
 * Class Name	: PDFPage
 * Description	: A common container page to prepare PDF document for various purpose such as Cover letter, employee letter etc. 
 * Created By	: Tech Mahindra Ltd.
 * Created On	:
 * 
 * Change History
 * ------------------------------------------------------------	
 * Date			Changed By	Description
 * ------------------------------------------------------------	
 * 20/06/2011	Lokesh		Changes are made for Print License in method getStringWriterForLicenseTemplate()
 * 12/12/2012	rk87137		Code change for Req99
 * 12/03/2012	xsat244		Req#193
 * 16/04/2012	xsat304		Req#198
 * 24/04/2012	xsat304		vtl changes
 * 14/12/2012	xsat489		Req#315
 * 14/02/2013	xsat013		REQ#382 - missing code for 315 added
 * 26/03/2013	xsat030		REQ 385   
 * 10/06/2013	xsat508		REQ#439- vtl changes
 * 29/01/2014	xsat030		REQ 526
 * 27/05/2014	xsat244		REQ#572
 * 26/01/2015   xsat244     REQ#627
 * 10/02/2015   xsat244     REQ#627
 * 09/02/2015   Xsat030    QC 1641
 * 28/09/2015   xsat568     Modified for QC#1630.
 * 16/12/2015   xsat568     Modified for REQ#689.
 * 17-May-2016  xsat849     Modified for QC#5463
 * 18/10/2016   xsat872  Modified for SS_QC#5427
 * 02/03/2017   xsat849  Modified for SS_QC#6974
 * ------------------------------------------------------------ 
 *
 * Copyright notice : "Copyright UPRR 2008"
 */
package com.uprr.lic.licensing.rest.service;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.VelocityEngine;
import org.apache.velocity.exception.MethodInvocationException;
import org.apache.velocity.exception.ParseErrorException;
import org.apache.velocity.exception.ResourceNotFoundException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lowagie.text.Document;
import com.lowagie.text.PageSize;
import com.lowagie.text.pdf.PdfAction;
import com.lowagie.text.pdf.PdfCopy;
import com.lowagie.text.pdf.PdfReader;
import com.uprr.lic.dataaccess.Licensing.model.CoverLetterDetails;
import com.uprr.lic.dataaccess.Licensing.model.CoverLetterForExistingLicenseDetails;
import com.uprr.lic.dataaccess.Licensing.model.CoverLetterForNewLicenseDetails;
import com.uprr.lic.dataaccess.Licensing.model.LabelTemplateDetails;
import com.uprr.lic.dataaccess.Licensing.model.License;
import com.uprr.lic.dataaccess.Licensing.model.LicenseCoverLetterTemplateDetails;
import com.uprr.lic.dataaccess.Licensing.model.LicenseTemplate;
import com.uprr.lic.dataaccess.Licensing.model.LicenseTemplateList;
import com.uprr.lic.dataaccess.Licensing.model.PdfPageSessionDetails;
import com.uprr.lic.dataaccess.Licensing.model.TempLicenseTemplate;
import com.uprr.lic.dataaccess.common.model.Address;
import com.uprr.lic.dataaccess.common.model.EqmComImag;
import com.uprr.lic.dataaccess.common.model.PersonBean;
import com.uprr.lic.dataaccess.components.licensing.service.ILicensingService;
import com.uprr.lic.dataaccess.components.masters.service.IManageMasterService;
import com.uprr.lic.dataaccess.decertification.util.LicensingUtil;
import com.uprr.lic.decert.service.ICreateUpdateEventService;
import com.uprr.lic.externalservice.xmf.service.GetEPIPersonPictureService;
import com.uprr.lic.util.DateUtil;
import com.uprr.lic.util.LicensingConstant;
import com.uprr.lic.util.SysParamBean;


/**
 * A common container page to prepare PDF document for various purpose such as Cover letter, employee letter etc. 
 *
 * @since 2008
 */
@Service
public class PDFPageService  {

	private static final String CLASSNAME = PrintLicenseService.class.getCanonicalName();
	private static final Logger logger = LoggerFactory.getLogger(PrintLicenseService.class);
	private Map<String,EqmComImag> emplMap;
	private  Map<String, SysParamBean> sysParmMap = null;;

  @Autowired
  private PdfConvertor pdfConvertor;
  
  @Autowired
  private ICreateUpdateEventService createUpdateEventService;
  
  @Autowired
  private ILicensingService licensingService;
  
  @Autowired
  private IManageMasterService manageMasterService;
  
  @Autowired
  private GetEPIPersonPictureService getEPIPersonPictureService;
 
  
 
  /**
   * Class-name / Method Name : PDFPage / generatePdf()
   * @param pdfPageSessionDetails
   * @param imageBean
   * @return : ByteArrayOutputStream
   * @exception : ResourceNotFoundException, ParseErrorException, MethodInvocationException, IOException, Exception
   * Description : Method is used to convert vtl file into the PDF format(Modified for REQ-198)
   */
  @SuppressWarnings("unused")
public ByteArrayOutputStream generatePdf(PdfPageSessionDetails pdfPageSessionDetails) throws ResourceNotFoundException, ParseErrorException, MethodInvocationException,
  IOException, Exception {
    List<String> employeeIdList = new ArrayList<String>();
    employeeIdList = pdfPageSessionDetails.getEmplIdList();
    Iterator<String> iterator = employeeIdList.iterator();
    ByteArrayOutputStream temp = new ByteArrayOutputStream();
    ByteArrayOutputStream baos = new ByteArrayOutputStream();
    Document document = new Document(PageSize.A4);
    PdfCopy writer = new PdfCopy(document, baos);
    PdfReader pdfReader = null;
    sysParmMap = createUpdateEventService.getSystemParam();
    document.open();

    if(pdfPageSessionDetails.isDisplayPrintDialogBox()){
      // on opening of a PDF page opening the Print Dialog Box
      PdfAction jAction = PdfAction.javaScript("this.print(true);\r", writer);
      writer.addJavaScript(jAction);
    }

  //Starts Modified for QC#6974
    //Boolean peopleSoftTeradatFlag = LicensingUtil.getPeopleSoftTeradataFlagStatus(webApplication.getSysparamMap());
    Boolean dataFlag = LicensingUtil.getSAPDataFlagStatus(sysParmMap);// Modified for QC#6974
    //Ends Modified for QC#6974
    
    if (pdfPageSessionDetails.isLabel()) {
      // for Print Label Template
      StringWriter stringWriter = getStringWriterForLabelTemplate(employeeIdList, dataFlag);// Added QC#6974
      temp = pdfConvertor.getPdf(stringWriter);
      if (temp != null && temp.toByteArray() != null && temp.toByteArray().length != 0) {
        pdfReader = new PdfReader(temp.toByteArray());
        pdfConvertor.merge(writer, pdfReader, document);
      }
    }
    //-- Selection of Templates
    selectionOfLicenses(writer, iterator, pdfPageSessionDetails, document, true);// modified for REQ-198,qc#6974
    document.close();
    return baos;
  }  
  
  /**
   * 
   * Method is used to select for all types of licenses(modified for REQ-198)
   *
   * @param writer
   * @param iterator
   * @param pdfPageSessionDetails
   * @param document
   * @param peopleSoftTeradatFlag
   * @throws ResourceNotFoundException
   * @throws ParseErrorException
   * @throws MethodInvocationException
   * @throws IOException
   * @throws Exception
   * @author xsat568
   * @since Sep 24, 2015
   * Modified for QC#1630,REQ#689.
   * Modified For SS_QC#5427
   */
  private void selectionOfLicenses(PdfCopy writer, Iterator<String> iterator, PdfPageSessionDetails pdfPageSessionDetails, 
      Document document, Boolean peopleSoftTeradatFlag) throws ResourceNotFoundException,
      ParseErrorException, MethodInvocationException, IOException, Exception {
    ByteArrayOutputStream temp = new ByteArrayOutputStream();
    
    // Start : Modified for QC#1630.
    final List<String> emplIds = pdfPageSessionDetails.getEmplIdList();   
    Map<String, PersonBean> personBeanMap = new HashMap<String, PersonBean>();    
    // Fetch employee address details from either Teradata or persondata service.
    if (null != peopleSoftTeradatFlag && peopleSoftTeradatFlag) {
      personBeanMap = licensingService.getAddressInfoForEmplFromTeradata(emplIds, personBeanMap);
    } else {
    	//TODO Test Response
      final List<PersonBean> personBeanList = getEmployeeDetailsFromPersonDataService(emplIds);
      personBeanMap = getMapFromPersonBeanList(personBeanList, personBeanMap);
    }
    // Fetch employees' basic details from EQMS table.
    personBeanMap = licensingService.getEmplDtlsFromEqms(emplIds,personBeanMap);
    // End : Modified for QC#1630.
    
    while (iterator.hasNext()) {
      // -- iterating for employee id's
      byte[] signImgByteData = null; // modified for REQ-198
      
      // Start : Modified for QC#1630.
      final String employeeId = (String) iterator.next();
      final PersonBean personBean = personBeanMap.get(employeeId);
      // End : Modified for QC#1630.
      
      // boolean peopleSoftTeradatFlag = getPeopleSoftTeradataFlagStatus();

      // Start : Added for REQ#689.
      // For Cover Letter Template in case of Re-certification packets from IVR Request.
      if (pdfPageSessionDetails.isCoverLetterForRecertPkts()) {
        final StringWriter stringWriter = getStringWriterForCoverLetterForRecertPktsTemplate(employeeId, personBean);
        temp = pdfConvertor.getPdf(stringWriter);
        if (temp != null && temp.toByteArray() != null && temp.toByteArray().length != 0) {
          pdfConvertor.merge(writer, createPDFReader(temp), document);
        }
      }
      // End : Added for REQ#689.
      
      // -- for Cover Letter Template in case of PrintDocs --> this is Employee Letter used for recertification only
      if (pdfPageSessionDetails.isCoverLetterForPrintDocs()) {        
        final StringWriter stringWriter = getStringWriterForCoverLetterForPrintDocsTemplate(employeeId, personBean);// Modified for QC#1630.
        temp = pdfConvertor.getPdf(stringWriter);
        if (temp != null && temp.toByteArray() != null && temp.toByteArray().length != 0) {
          pdfConvertor.merge(writer, createPDFReader(temp), document);
        }
      }


      // -- for Cover Letter Template in case of PrintDocs --> this is Employee Letter used for recertification only
      if (pdfPageSessionDetails.isCoverLetterForPrintDocsBlank()) {        
        final StringWriter stringWriter = getStringWriterForCoverLetterForPrintDocsTemplateBlank(employeeId, personBean);// Modified for QC#1630.
        temp = pdfConvertor.getPdf(stringWriter);
        if (temp != null && temp.toByteArray() != null && temp.toByteArray().length != 0) {
          pdfConvertor.merge(writer, createPDFReader(temp), document);
        }
      }
      // -- for Cover Letter for New License in case of PrintDocs on click of Print button
      if(pdfPageSessionDetails.isCoverLetterForNewLicense()){
        final StringWriter stringWriter = getStringWriterForCoverLetterForNewLicenseTemplate(employeeId, personBean,
            pdfPageSessionDetails.getStartDateForCoverLetter());// Modified for QC#1630.
        temp = pdfConvertor.getPdf(stringWriter);
        if (temp != null && temp.toByteArray() != null && temp.toByteArray().length != 0) {
          pdfConvertor.merge(writer, createPDFReader(temp), document);
        }
      }

      // -- for Medical Assessment Template in Print Docs both in case of icon link and on click of Print button
      if (pdfPageSessionDetails.isMedical()) {        
        StringWriter stringWriter = getStringWriterForMedicalTemplate();
        temp = pdfConvertor.getPdf(stringWriter);
        if (temp != null && temp.toByteArray() != null && temp.toByteArray().length != 0) {
          pdfConvertor.merge(writer, createPDFReader(temp), document);
        }
      }      
      
      // -- for NDR Template in case of Print Docs in click of Print button
      if (pdfPageSessionDetails.isNdr()) {        
        final StringWriter stringWriter = getStringWriterForNdrTemplate(employeeId, personBean);// Modified for QC#1630.
        temp = pdfConvertor.getPdf(stringWriter);
        if (temp != null && temp.toByteArray() != null && temp.toByteArray().length != 0) {
          pdfConvertor.merge(writer, createPDFReader(temp), document);
        }
      }

      // -- for NDR blank Template Preview in case of Print Docs on click of icon link
      if (pdfPageSessionDetails.isNdrTemplateForDisplay()) {        
        final StringWriter stringWriter = getStringWriterForNdrTemplateForDisplay();//Removed parameters for blank 
        temp = pdfConvertor.getPdf(stringWriter);
        if (temp != null && temp.toByteArray() != null && temp.toByteArray().length != 0) {
          pdfConvertor.merge(writer, createPDFReader(temp), document);
        }
      }

      // -- for MVR Template in case of Print Docs in click of Print button
      if (pdfPageSessionDetails.isMvr()) {        
        final StringWriter stringWriter = getStringWriterForMvrTemplate(employeeId, personBean);// Modified for QC#1630.
        temp = pdfConvertor.getPdf(stringWriter);
        if (temp != null && temp.toByteArray() != null && temp.toByteArray().length != 0) {
          pdfConvertor.merge(writer, createPDFReader(temp), document);
        }
      }

      // -- for Directions for Washington State Employee Letter in case of PrintDocs onclick of Print button
      if(pdfPageSessionDetails.isDirectionsForWashington()){
        StringWriter stringWriter = getStringWriterForDirectionsForWashingtonStateEmployeeLetterTemplate();
        temp = pdfConvertor.getPdf(stringWriter);
        if (temp != null && temp.toByteArray() != null && temp.toByteArray().length != 0) {
          pdfConvertor.merge(writer, createPDFReader(temp), document);
        }
      }

      // -- for Washington State NDR Form Template in case of PrintDocs on click of Print button
    if (pdfPageSessionDetails.isWashingtonStateNdrForm()) {
      List<String> emplList = new ArrayList<String>();// Req#439 start
     
      emplList.add(pdfPageSessionDetails.getLicManagerSign());
      final StringWriter stringWriter = getStringWriterForWashingtonStateNdrFormTemplate(employeeId, personBean,
            pdfPageSessionDetails.getLicManagerName());//REQ 526, Modified for QC#1630.
      emplMap = manageMasterService.getEmplMapForPrintLic(emplList,false);
      if (null != emplMap && !emplMap.isEmpty()) {
      //REQ 526
        if (null != emplMap.get(pdfPageSessionDetails.getLicManagerSign())) {
          signImgByteData = emplMap.get(pdfPageSessionDetails.getLicManagerSign()).getImagData();// Req#439 end//REQ 526
        }
      }
      // temp = pdfConvertor.getPdf(stringWriter);
      temp = pdfConvertor.addImagesToWashingtonPdf(stringWriter, signImgByteData);
      if (temp != null && temp.toByteArray() != null && temp.toByteArray().length != 0) {
        pdfConvertor.merge(writer, createPDFReader(temp), document);
      }
    }

      // -- for Washington State NDR Form Template in case of PrintDocs For Display on click of icon link
      if (pdfPageSessionDetails.isWashingtonStateNdrFormForDisplay()) {
        List<String> emplList = new ArrayList<String>();
        emplList.add(pdfPageSessionDetails.getLicManagerSign());// Req#439 start//REQ 526
      //REQ 526
        StringWriter stringWriter = getStringWriterForWashingtonStateNdrFormTemplateForDisplay(pdfPageSessionDetails.getLicManagerName());
        emplMap = manageMasterService.getEmplMapForPrintLic(emplList,false);
        if (null != emplMap && !emplMap.isEmpty()) {
          if (null != emplMap.get(pdfPageSessionDetails.getLicManagerSign())) {//REQ 526
            signImgByteData = emplMap.get(pdfPageSessionDetails.getLicManagerSign()).getImagData();// Req#439 end//REQ 526
          }
        }
        temp = pdfConvertor.addImagesToWashingtonPdf(stringWriter, signImgByteData);
        if (temp != null && temp.toByteArray() != null && temp.toByteArray().length != 0) {
          pdfConvertor.merge(writer, createPDFReader(temp), document);
        }
      }

      // -- for Cover Letter Template used for Faxing NDR in Fax Ndr popup
      if (pdfPageSessionDetails.isCoverLetter()) {        
        StringWriter stringWriter = getStringWriterForCoverLetterTemplate(employeeId);
        temp = pdfConvertor.getPdf(stringWriter);
        if (temp != null && temp.toByteArray() != null && temp.toByteArray().length != 0) {
          pdfConvertor.merge(writer, createPDFReader(temp), document);
        }
      }

      // -- for License Template in Print License screen on click of Print License button
      if (pdfPageSessionDetails.isLicense()) {         
        int flag=0;
        byte[] image= null;
      //As Per Abhishek, We do not need to implement getPersonPicture because PICTURE_FLAG is on in prod
       /* Map<String , SysParamBean> sysParmMap= sysParamService.getAllSystemParameter();
        SysParamBean sysParamBean=null;
        if(sysParmMap!=null)
        {
          sysParamBean= sysParmMap.get(LicensingConstant.PICTURE_FLAG);
        }
        
        //Have to get Image from beow services once they are available 
        if(sysParamBean!=null && sysParamBean.getParmValu().equalsIgnoreCase(LicensingConstant.PICTURE_FLAG_VALUE))
        {
          image =  personEPIPictureService.getEPIPersonPicture(employeeId);
        }
        else{
          image =  getPersonPictureService.getPersonPicture(employeeId);
        }*/
        
        image = getEPIPersonPictureService.getEPIPersonPicture(employeeId);
        
        File f = null;

        //read image
        /*try{
          f = new File("C:\\Users\\xsat004\\Documents\\06_29_holiday_op_plan.jpg"); //image file path
         // image = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
          image =  Files.readAllBytes(f.toPath());
        }catch(Exception e){
        	e.printStackTrace();
        }*/
        // changes for REQ-198 start

        emplMap=manageMasterService.getEmplMapForPrintLic(pdfPageSessionDetails.getEmplIdList(),true);// added for REQ-198

        if (null != emplMap && !emplMap.isEmpty()) {
          if (null != emplMap.get(employeeId)) {
            signImgByteData = emplMap.get(employeeId).getImagData();
          }
          // changes for REQ-198 end
        }


        if(!(image != null && image.length > 0)){
          flag=1;
        }
        StringWriter stringWriter = getStringWriterForLicenseTemplate(employeeId,flag);

        /* Changed for Req#193 by xsat244 */
        temp = pdfConvertor.addImagesToLicencePdf(stringWriter, image, signImgByteData);

        if (temp != null && temp.toByteArray() != null && temp.toByteArray().length != 0) {
          pdfConvertor.merge(writer, createPDFReader(temp), document);
        }
      }

        // -- for License Cover Letter Template in Print License screen on click of Print Cover Letter button
        if (pdfPageSessionDetails.isLicenseCoverLetter()) {        
          final StringWriter stringWriter = getStringWriterForLicenseCoverLetterTemplate(employeeId, personBean); //Modified for QC#1630.
          temp = pdfConvertor.getPdf(stringWriter);
          if (temp != null && temp.toByteArray() != null && temp.toByteArray().length != 0) {
            pdfConvertor.merge(writer, createPDFReader(temp), document);
          }
        }

        // -- for Temporary License Template in case of Print Temporary License screen on click of Print License button
        if (pdfPageSessionDetails.isTempLicense()) {
          if(pdfPageSessionDetails.getValidityPeriod()!=null){
            StringWriter stringWriter = getStringWriterForTempLicenseTemplatePortal(employeeId, pdfPageSessionDetails.getValidityPeriod());
            temp = pdfConvertor.getPdf(stringWriter);
            if (temp != null && temp.toByteArray() != null && temp.toByteArray().length != 0) {
              pdfConvertor.merge(writer, createPDFReader(temp), document);
            }
          }
          else{
            StringWriter stringWriter = getStringWriterForTempLicenseTemplate(employeeId);
            temp = pdfConvertor.getPdf(stringWriter);
            if (temp != null && temp.toByteArray() != null && temp.toByteArray().length != 0) {
              pdfConvertor.merge(writer, createPDFReader(temp), document);
            }
          }
        }

        // -- for Cover Letter for Existing License in case of PrintDocs on click of Print button 
        if(pdfPageSessionDetails.isCoverLetterForExtLicense()){
        final StringWriter stringWriter = getStringWriterForCoverLetterForExistingLicenseTemplate(employeeId,
            personBean, pdfPageSessionDetails.getStartDateForCoverLetter(), pdfPageSessionDetails.getLicenseClass());//Modified for QC#1630.
          temp = pdfConvertor.getPdf(stringWriter);
          if (temp != null && temp.toByteArray() != null && temp.toByteArray().length != 0) {
            pdfConvertor.merge(writer, createPDFReader(temp), document);
          }
        }
        
       //Added For SS_QC#5427:Start
      //For MVR Release Instruction Form in case of PrintDocs on click of Print button 
        if (pdfPageSessionDetails.isMvrReleaseInsForm()) {        
          StringWriter stringWriter = getStringWriterForMVRReleaseInsFormTemplate();
          temp = pdfConvertor.getPdf(stringWriter);
          if (temp != null && temp.toByteArray() != null && temp.toByteArray().length != 0) {
            pdfConvertor.merge(writer, createPDFReader(temp), document);
          }
        }
      //Added For SS_QC#5427:End
      }
  }

  /**
   * Classname / Method Name : PDFPage/createPDFReader()
   * @param : temp
   * @return : PdfReader
   * @throws : IOException
   * Description : Method is used to conver Byte Array Output Stream to PDF Reader
   */
  private PdfReader createPDFReader(ByteArrayOutputStream temp) throws IOException {
    PdfReader pdfReader = null;
    pdfReader = new PdfReader(temp.toByteArray());
    return pdfReader;
  }
  
  /**
   * 
   * Method is used to get StringWriter for MVR Template in case of Print Docs 
   * on click of both icon link and Print button.
   *
   * @param employeeId
   * @param personBean
   * @return stringWriter
   * @throws ResourceNotFoundException
   * @throws ParseErrorException
   * @throws MethodInvocationException
   * @throws IOException
   * @throws Exception
   * @author xsat568
   * @since Sep 24, 2015
   * Modified for QC#1630.
   */
  private StringWriter getStringWriterForMvrTemplate(final String employeeId, final PersonBean personBean)
      throws ResourceNotFoundException, ParseErrorException, MethodInvocationException, IOException, Exception {
    // Start : Modified for QC#1630.
    // -- Initializing VelocityEngine
    final VelocityEngine velecityEngine = new VelocityEngine();
    final Properties prop = new Properties();
    prop.put("resource.loader", LicensingConstant.ATTR_MDFR_CLASS);
    prop.put("class.resource.loader.class", "org.apache.velocity.runtime.resource.loader.ClasspathResourceLoader");
    prop.put("class.resource.loader.cache", LicensingConstant.FLAG_TRUE);
    velecityEngine.init(prop);

    // -- Getting Template
    final Template template = velecityEngine.getTemplate("templates/MVRTemplate.vtl");
    // -- Initializing velocity context
    final VelocityContext context = new VelocityContext();
    context.put(LicensingConstant.EMPLOYEENAME_WICKETID,
        ((null != personBean && null != personBean.getEmpFullName()) ? personBean.getEmpFullName()
            : LicensingConstant.EMPTY_STRING));   
    context.put(LicensingConstant.EMPLOYEEID_WICKETID, ((null != personBean) ? personBean.getEmplId()
        : LicensingConstant.EMPTY_STRING));
    
    String birthDate = LicensingConstant.EMPTY_STRING;
    if(null != personBean && null != personBean.getBirthDate()){
      final SimpleDateFormat sdf = new SimpleDateFormat("MM,dd,yyyy");
      birthDate = sdf.format(personBean.getBirthDate().getTime());
    }   
    
    context.put(LicensingConstant.DOB_WICKETID, birthDate);
    context.put("ssn", " ");

    Address address = null;
    if (null != personBean) {
      address = personBean.getAddress();
    }

    if (null == address) {
      context.put("address", LicensingConstant.EMPTY_STRING);
      context.put("cityStateAndZip", LicensingConstant.EMPTY_STRING);
    } else {
      context.put("address", address.getFirstLine());      
      final StringBuffer stringBuffer = new StringBuffer();
      stringBuffer.append(address.getCity() + ", ");
      stringBuffer.append(address.getState() + ", ");
      stringBuffer.append(address.getPostCode());
      context.put("cityStateAndZip", stringBuffer.toString());
    }   
    
    context.put("licenseNumber", " ");
    context.put("stateIssuedDriverLicense", " ");
    context.put("previousLicenseNumber", " ");
    context.put("stateIssuedPreviousDriverLicense", " ");

    // creating writer and merging context to it
    final StringWriter stringWriter = new StringWriter();
    template.merge(context, stringWriter);
    // End : Modified for QC#1630.
    return stringWriter;
  }

  /**
   * Class-name / Method Name : PDFPage / getStringWriterForMedicalTemplate()
   * @param : employeeId
   * @return : StringWriter
   * @exception : ResourceNotFoundException, ParseErrorException, MethodInvocationException, IOException, Exception
   * Description : Method is used to get StringWriter for Medical Template in case of Print Docs 
   * on click of both icon link and Print button
   */
  private StringWriter getStringWriterForMedicalTemplate() throws ResourceNotFoundException, ParseErrorException, MethodInvocationException, IOException, Exception {

    // -- Initializing VelocityEngine
    VelocityEngine velocityEngine = new VelocityEngine();
    Properties prop = new Properties();
    prop.put("resource.loader", LicensingConstant.ATTR_MDFR_CLASS);
    prop.put("class.resource.loader.class", "org.apache.velocity.runtime.resource.loader.ClasspathResourceLoader");
    prop.put("class.resource.loader.cache", LicensingConstant.FLAG_TRUE);
    velocityEngine.init(prop);

    // -- Getting Template
    Template template = velocityEngine.getTemplate("templates/MedicalAssessmentInstruction.vtl");

    // -- Initializing velocity context
    VelocityContext context = new VelocityContext();
    context.put("leq", "checked");
    context.put("rco", "checked");
    context.put("sle", "checked");

    // creating writer and merging context to it
    StringWriter stringWriter = new StringWriter();
    template.merge(context, stringWriter);

    return stringWriter;
  }
  
  /**
   * 
   * Method is used to get StringWriter for NDR Template in case of Print Docs 
   * on click of Print button
   *
   * @param employeeId
   * @param personBean
   * @return stringWriter
   * @throws ResourceNotFoundException
   * @throws ParseErrorException
   * @throws MethodInvocationException
   * @throws IOException
   * @throws Exception
   * @author xsat568
   * @since Sep 24, 2015
   * Modified for QC#1630.
   */
  private StringWriter getStringWriterForNdrTemplate(final String employeeId, final PersonBean personBean)
      throws ResourceNotFoundException, ParseErrorException, MethodInvocationException, IOException, Exception {
    // Start : Modified for QC#1630.
    Address address = null;
    if (null != personBean) {
      address = personBean.getAddress();
    }

    // -- Initializing VelocityEngine
    final VelocityEngine velocityEngine = new VelocityEngine();
    final Properties prop = new Properties();
    prop.put("resource.loader", LicensingConstant.ATTR_MDFR_CLASS);
    prop.put("class.resource.loader.class", "org.apache.velocity.runtime.resource.loader.ClasspathResourceLoader");
    prop.put("class.resource.loader.cache", LicensingConstant.FLAG_TRUE);
    velocityEngine.init(prop);

    // -- Getting Template
    final Template template = velocityEngine.getTemplate("templates/NDRTemplate.vtl");

    // -- Initializing velocity context
    final VelocityContext context = new VelocityContext();
    context.put(LicensingConstant.EMPLOYEENAME_WICKETID, ((null != personBean) ? personBean.getEmpFullName()
        : LicensingConstant.EMPTY_STRING));
    context.put("nickName", " ");
    context.put(LicensingConstant.DOB_WICKETID,
            ((null != personBean && null != personBean.getBirthDate()) ? DateUtil.getDateAsString(personBean
                .getBirthDate()) : LicensingConstant.EMPTY_STRING));
    context.put("weight", " ");
    context.put("licenseNumber", " ");
    context.put("state", LicensingConstant.EMPTY_STRING);
    context.put("ssn", " ");
    context.put(LicensingConstant.EMPLOYEEID_WICKETID, ((null != personBean) ? personBean.getEmplId()
        : LicensingConstant.EMPTY_STRING));
    context.put("heightFt", " ");
    context.put("heightInches", " ");

    if (null == address) {
      context.put("address", LicensingConstant.EMPTY_STRING);
      context.put("addressCity", LicensingConstant.EMPTY_STRING);
      context.put("addressState", LicensingConstant.EMPTY_STRING);
      context.put("addressZip", LicensingConstant.EMPTY_STRING);
    } else {
      context.put("address", address.getFirstLine());
      context.put("addressCity", address.getCity());
      context.put("addressState", address.getState());
      context.put("addressZip", address.getPostCode());
    }   
    
    // creating writer and merging context to it
    final StringWriter stringWriter = new StringWriter();
    template.merge(context, stringWriter);
    // End : Modified for QC#1630.
    return stringWriter;
  }

  /**
   * Class-name / Method Name : PDFPage / getStringWriterForCoverLetterTemplate()
   * @param : employeeId
   * @return : StringWriter
   * @exception : ResourceNotFoundException, ParseErrorException, MethodInvocationException, IOException, Exception
   * Description : Method is used to get StringWriter for Fax Cover Letter Template in case of  Fax NDR 
   * Popup
   */
  private StringWriter getStringWriterForCoverLetterTemplate(String employeeId) throws ResourceNotFoundException, ParseErrorException, MethodInvocationException, IOException,
  Exception {
    CoverLetterDetails coverLetterDetails = licensingService.getEmployeeDetailsForCoverLetterTemplate();

    // -- Initializing VelocityEngine
    VelocityEngine velocityEngine = new VelocityEngine();
    Properties prop = new Properties();
    prop.put("resource.loader", LicensingConstant.ATTR_MDFR_CLASS);
    prop.put("class.resource.loader.class", "org.apache.velocity.runtime.resource.loader.ClasspathResourceLoader");
    prop.put("class.resource.loader.cache", LicensingConstant.FLAG_TRUE);
    velocityEngine.init(prop);

    // -- Getting Template
    Template template = velocityEngine.getTemplate("templates/CoverLetterTemplate.vtl");

    // -- Initializing velocity context
    VelocityContext context = new VelocityContext();
    // context.put("uprrImage", "templates/uprr_image.gif");
    context.put("toFaxNumber", coverLetterDetails.getFaxNumber());
    context.put("faxDate", coverLetterDetails.getFaxDate());

    // creating writer and merging context to it
    StringWriter stringWriter = new StringWriter();
    template.merge(context, stringWriter);

    return stringWriter;
  }

  /**
   * Class-name / Method Name : PDFPage / getStringWriterForLicenseTemplate()
   * @param : employeeId
   * @return : StringWriter
   * @exception : ResourceNotFoundException, ParseErrorException, MethodInvocationException, IOException, Exception
   * Description : Method is used to get StringWriter for License Template in case of Print License screen 
   * on click of Print License button
   */

  private StringWriter getStringWriterForLicenseTemplate(String employeeId, int flag) throws ResourceNotFoundException, ParseErrorException, MethodInvocationException, IOException,
  Exception {
    StringWriter stringWriter = new StringWriter();
    LicenseTemplate licenseTemplateBean = licensingService.getLicenseTemplateDetails(employeeId);
    List<LicenseTemplateList> licenseList = (ArrayList<LicenseTemplateList>) licenseTemplateBean.getLicenseTemplateList();
    if (null==licenseList) {
      return null;
    } else if (!licenseList.isEmpty()) {
      // -- Initializing VelocityEngine
      VelocityEngine velocityEngine = new VelocityEngine();
      Properties prop = new Properties();
      prop.put("resource.loader", LicensingConstant.ATTR_MDFR_CLASS);
      prop.put("class.resource.loader.class", "org.apache.velocity.runtime.resource.loader.ClasspathResourceLoader");
      prop.put("class.resource.loader.cache", LicensingConstant.FLAG_TRUE);
      velocityEngine.init(prop);

      // -- Getting Template
      Template template = velocityEngine.getTemplate("templates/License.vtl");

      // -- Initializing velocity context
      VelocityContext velContext = new VelocityContext();
      velContext.put(LicensingConstant.EMPLOYEENAME_WICKETID, licenseTemplateBean.getEmployeeName());
      velContext.put(LicensingConstant.EMPLOYEEID_WICKETID, licenseTemplateBean.getEmployeeID());
      velContext.put(LicensingConstant.DOB_WICKETID, licenseTemplateBean.getDateOfBirth());
      velContext.put("birthLabel", licenseTemplateBean.getBirthLabel());
      velContext.put("issueDate", licenseTemplateBean.getIssueDate());
      velContext.put("expiryDate", licenseTemplateBean.getExpiryDate());
      velContext.put("effectiveDate", licenseTemplateBean.getEffDate());
      velContext.put("licenseList", licenseTemplateBean.getLicenseTemplateList());
      velContext.put("licNote", licenseTemplateBean.getLicNote());
      velContext.put("restList",licenseTemplateBean.getRestList());
      if(flag==1){
        //        velContext.put("image", "<header name=\"templates/shield.gif\" rightOffset=\"118\" topOffset=\"125\" />");
        velContext.put("image", "<headerImage name=\"templates/up2c.wmf\" height=\"64\" width=\"59\" rightOffset=\"121\" topOffset=\"128\" />");
      }
      else{
        velContext.put("image", LicensingConstant.BLANK_STRING); 
      }
      // creating writer and merging context to it
      template.merge(velContext, stringWriter);
    }
    // }
    return stringWriter;
  }

  /**
   * To get stringWriter for Temporary License Template in case of print Temporary License screen on click of Print License button.
   * Updated for REQ#572
   * 
   * @param employeeId
   * @return stringWriter
   * @exception ResourceNotFoundException
   * @exception ParseErrorException
   * @exception MethodInvocationException
   * @exception IOException
   * @exception Exception
   */
  private StringWriter getStringWriterForTempLicenseTemplate(String employeeId) throws ResourceNotFoundException, ParseErrorException, MethodInvocationException, IOException,
  Exception {
    boolean onlyConductorLicenseFlag = true;
    TempLicenseTemplate tempLicenseTemplateBean = licensingService.getTemporaryLicenseTemplateForPortal(employeeId);
    // -- Initializing VelocityEngine
    VelocityEngine velocityEngine = new VelocityEngine();
    Properties prop = new Properties();
    prop.put("resource.loader", LicensingConstant.ATTR_MDFR_CLASS);
    prop.put("class.resource.loader.class", "org.apache.velocity.runtime.resource.loader.ClasspathResourceLoader");
    prop.put("class.resource.loader.cache", LicensingConstant.FLAG_TRUE);
    velocityEngine.init(prop);

    // -- Getting Template
    Template template = velocityEngine.getTemplate("templates/TemporaryLicense.vtl");

    // -- Initializing velocity context
    VelocityContext context = new VelocityContext();
    context.put("date",  tempLicenseTemplateBean.getTempValidDate());
    context.put(LicensingConstant.EMPLOYEENAME_WICKETID, tempLicenseTemplateBean.getEmployeeName());
    context.put(LicensingConstant.EMPLOYEEID_WICKETID, tempLicenseTemplateBean.getEmployeeID());
    context.put("issueDate", tempLicenseTemplateBean.getIssueDate());
    context.put("tempLicenseList", tempLicenseTemplateBean.getTempLicenseTemplateList());
    context.put("restList",tempLicenseTemplateBean.getRestList());
    
    // Requirement 315 start
    List<License> licenseList = tempLicenseTemplateBean.getLicenseList();
    if (!licenseList.isEmpty()) {
      for (License license : licenseList) {
        if (!license.getLicenseClass().equalsIgnoreCase(
            LicensingConstant.LICENSE_CLASS_CLASS8)
            && !license.getLicenseClass().equalsIgnoreCase(
                LicensingConstant.LICENSE_CLASS_CLASS9)) {
          onlyConductorLicenseFlag = false;
        }
      }
    }

    if (onlyConductorLicenseFlag) {
      context.put("tempLicenseHeader",LicensingConstant.ONLY_CONDUCTOR_TEMP_LIC_HEADER);
    } else {
      context.put("tempLicenseHeader",LicensingConstant.GENERAL_TEMP_LIC_HEADER);
    }
      
    // Requirement 315 ends
    
    // -- for class of service
    //    context.put("licenseList", tempLicenseTemplateBean.getLicenseList());
    String classOfService = "";
    if(tempLicenseTemplateBean.getLicenseList()!=null 
        && !tempLicenseTemplateBean.getLicenseList().isEmpty()){
      for(License license : tempLicenseTemplateBean.getLicenseList()) {
        classOfService = classOfService.equalsIgnoreCase("") ? 
            classOfService + license.getLicenseClass() :
              classOfService + ", " + license.getLicenseClass();
      }
    }
    context.put("classOfService", classOfService);
    context.put("tempLicenseValidity", tempLicenseTemplateBean.getTempLicenseValidity());

    // creating writer and merging context to it
    StringWriter stringWriter = new StringWriter();
    template.merge(context, stringWriter);
    return stringWriter;
  }

  /**
   * To get stringWriter for Temporary License Template in case of print Temporary License screen on click of Print License button.
   *
   * @param employeeId
   * @param validityPeriod
   * @return stringWriter
   * @throws ResourceNotFoundException
   * @throws ParseErrorException
   * @throws MethodInvocationException
   * @throws IOException
   * @throws Exception
   * Description : Method is used to
   */
  private StringWriter getStringWriterForTempLicenseTemplatePortal(String employeeId,String validityPeriod) throws ResourceNotFoundException, ParseErrorException, MethodInvocationException, IOException,
  Exception {
    boolean onlyConductorLicenseFlag = true;
    TempLicenseTemplate tempLicenseTemplateBean = licensingService.getTemporaryLicenseTemplateForPortal(employeeId);

    // -- Initializing VelocityEngine
    VelocityEngine velocityEngine = new VelocityEngine();
    Properties prop = new Properties();
    prop.put("resource.loader", LicensingConstant.ATTR_MDFR_CLASS);
    prop.put("class.resource.loader.class", "org.apache.velocity.runtime.resource.loader.ClasspathResourceLoader");
    prop.put("class.resource.loader.cache", LicensingConstant.FLAG_TRUE);
    velocityEngine.init(prop);

    // -- Getting Template
    Template template = velocityEngine.getTemplate("templates/TemporaryLicense.vtl");

    // -- Initializing velocity context
    VelocityContext context = new VelocityContext();
    context.put("date",  tempLicenseTemplateBean.getTempValidDate());
    context.put(LicensingConstant.EMPLOYEENAME_WICKETID, tempLicenseTemplateBean.getEmployeeName());
    context.put(LicensingConstant.EMPLOYEEID_WICKETID, tempLicenseTemplateBean.getEmployeeID());
    context.put("issueDate", tempLicenseTemplateBean.getIssueDate());
    context.put("tempLicenseList", tempLicenseTemplateBean.getTempLicenseTemplateList());
    context.put("restList",tempLicenseTemplateBean.getRestList());
    
    // Requirement 315 start - done as part of Req#382
    List<License> licenseList = tempLicenseTemplateBean.getLicenseList();
    if (!licenseList.isEmpty()) {
      for (License license : licenseList) {
        if (!license.getLicenseClass().equalsIgnoreCase(
            LicensingConstant.LICENSE_CLASS_CLASS8)
            && !license.getLicenseClass().equalsIgnoreCase(
                LicensingConstant.LICENSE_CLASS_CLASS9)) {
          onlyConductorLicenseFlag = false;
        }
      }
    }

    if (onlyConductorLicenseFlag) {
      context.put("tempLicenseHeader",LicensingConstant.ONLY_CONDUCTOR_TEMP_LIC_HEADER);
    } else {
      context.put("tempLicenseHeader",LicensingConstant.GENERAL_TEMP_LIC_HEADER);
    }
    // -- for class of service
    String classOfService = "";
    if(tempLicenseTemplateBean.getLicenseList()!=null 
        && !tempLicenseTemplateBean.getLicenseList().isEmpty()){
      for(License license : tempLicenseTemplateBean.getLicenseList()) {
        classOfService = classOfService.equalsIgnoreCase("") ? 
            classOfService + license.getLicenseClass() :
              classOfService + ", " + license.getLicenseClass();
      }
    }
    context.put("classOfService", classOfService);
    context.put("tempLicenseValidity", tempLicenseTemplateBean.getTempLicenseValidity());

    // creating writer and merging context to it
    StringWriter stringWriter = new StringWriter();
    template.merge(context, stringWriter);
    return stringWriter;
  }
  /**
   * Class-name / Method Name : PDFPage / getStringWriterForLabelTemplate()
   * @param : employeeId
   * @return : StringWriter
   * @exception : ResourceNotFoundException, ParseErrorException, MethodInvocationException, IOException, Exception
   * Description : Method is used to get StringWriter for Label Template in case of Print Label screen 
   * on click of Print Label button.
   */
  private StringWriter getStringWriterForLabelTemplate(List<String> employeeIdList, Boolean peopleSoftTeradatFlag) throws ResourceNotFoundException, ParseErrorException, MethodInvocationException, IOException,
  Exception {

    List<LabelTemplateDetails> labelTemplateList = licensingService.getEmployeeDetailsForLabelTemplate(employeeIdList,  peopleSoftTeradatFlag);

    // -- Initializing VelocityEngine
    VelocityEngine velocityEngine = new VelocityEngine();
    Properties prop = new Properties();
    prop.put("resource.loader", LicensingConstant.ATTR_MDFR_CLASS);
    prop.put("class.resource.loader.class", "org.apache.velocity.runtime.resource.loader.ClasspathResourceLoader");
    prop.put("class.resource.loader.cache", LicensingConstant.FLAG_TRUE);
    velocityEngine.init(prop);

    // -- Getting Template
    Template template = velocityEngine.getTemplate("templates/LabelTemplate.vtl");

    // -- Initializing velocity context
    VelocityContext context = new VelocityContext();
    context.put("labelTemplateList", labelTemplateList);

    // creating writer and merging context to it
    StringWriter stringWriter = new StringWriter();
    template.merge(context, stringWriter);
    return stringWriter;
  }  
  
  /**
   * 
   * Method is used to get StringWriter for Cover Letter Template in case of Print Docs.
   * This is named as 'Employee Letter' and is effective for recertification only.
   *
   * @param employeeId
   * @param personBean
   * @return stringWriter
   * @throws ResourceNotFoundException
   * @throws ParseErrorException
   * @throws MethodInvocationException
   * @throws IOException
   * @throws Exception
   * @author xsat568
   * @since Sep 23, 2015
   * Modified for QC#1630.
   */
  private StringWriter getStringWriterForCoverLetterForPrintDocsTemplate(final String employeeId,
      final PersonBean personBean) throws ResourceNotFoundException, ParseErrorException, MethodInvocationException,
      IOException, Exception {
    
    // Start : Modified for QC#1630.
    final String mgrName = licensingService.getSysParmValue(LicensingConstant.LICENSING_DEPT_MANAGER_NAME)
        .getParmValu();
    
    Address address = null;
    if (null != personBean) {
      address = personBean.getAddress();
    }

    // -- Initializing VelocityEngine
    final VelocityEngine velocityEngine = new VelocityEngine();
    final Properties prop = new Properties();
    prop.put("resource.loader", LicensingConstant.ATTR_MDFR_CLASS);
    prop.put("class.resource.loader.class", "org.apache.velocity.runtime.resource.loader.ClasspathResourceLoader");
    prop.put("class.resource.loader.cache", LicensingConstant.FLAG_TRUE);
    velocityEngine.init(prop);

    // -- Getting Template
    final Template template = velocityEngine.getTemplate("templates/CoverLetterTemplateForPrintDocs.vtl");

    // -- Initializing velocity context
    final VelocityContext context = new VelocityContext();
    context.put(LicensingConstant.EMPLOYEENAME_WICKETID,
        (null != personBean && null != personBean.getEmpFullName()) ? personBean.getEmpFullName().toUpperCase()
            : LicensingConstant.EMPTY_STRING);
    /* REQ627 Changes:Begin */
    //final Map<String, SysParamBean> sysParmMap = webApplication.getSysparamMap();
    if (null != sysParmMap && null != sysParmMap.get(LicensingConstant.URL_EMPLOYEE_TODO_LIST)
        && null != sysParmMap.get(LicensingConstant.URL_EMPLOYEE_TODO_LIST).getParmValu()) {
      context.put("emplTodoListURL", sysParmMap.get(LicensingConstant.URL_EMPLOYEE_TODO_LIST).getParmValu());
    } else {
      context.put("emplTodoListURL", "");
    }
    /* REQ627 Changes:End */
    final StringBuffer stringBuffer = new StringBuffer();

    if (null == address) {
      context.put("address1", LicensingConstant.EMPTY_STRING);
      context.put("address2", LicensingConstant.EMPTY_STRING);
      context.put("city", LicensingConstant.EMPTY_STRING);
      context.put("state", LicensingConstant.EMPTY_STRING);
      context.put("zip", LicensingConstant.EMPTY_STRING);
    } else {
      context.put("address1", ((null != address.getFirstLine()) ? address.getFirstLine().toUpperCase()
          : LicensingConstant.EMPTY_STRING));
      context.put("address2", ((null != address.getSecondLine()) ? address.getSecondLine().toUpperCase()
          : LicensingConstant.EMPTY_STRING));
      stringBuffer.append(address.getCity().toUpperCase() + ", ");
      // context.put("city", address.getCity());
      stringBuffer.append(address.getState().toUpperCase() + " ");
      stringBuffer.append(address.getPostCode().toUpperCase());
      // context.put("zip", address.getPostCode());
    }
    context.put("cityStateCountryZip", stringBuffer.toString());   

    // -- SETTING SYS-PARAM DETAILS
    String sysLicDeptManagerName = null;
    if (null != mgrName && !LicensingConstant.BLANK_STRING.equals(mgrName)) {
      sysLicDeptManagerName = mgrName;
    } else {
      sysLicDeptManagerName = LicensingConstant.LIC_DEPT_MGR_NAME;
    }
    context.put("sysLicDeptManagerName", sysLicDeptManagerName); // modified for vtl changes
    // End : Modified for QC#1630.
    
    /*
     * context.put("rsdnPhNbr", coverLetterForPrintDocsTemplate.getRsdnPhNbr()); context.put("cellPhNbr",
     * coverLetterForPrintDocsTemplate.getCellPhNbr());
     */

    // creating writer and merging context to it
    final StringWriter stringWriter = new StringWriter();
    template.merge(context, stringWriter);

    return stringWriter;
  }
  
  /**
   * 
   * Method is used to get StringWriter for NDR Blank Template preview in case of Print Docs 
   * on click of icon link
   *
   * @param employeeId
   * @param personBean
   * @return stringWriter
   * @throws ResourceNotFoundException
   * @throws ParseErrorException
   * @throws MethodInvocationException
   * @throws IOException
   * @throws Exception
   * @author xsat568
   * @since Sep 24, 2015
   * Modified for QC#1630.
   */
  private StringWriter getStringWriterForNdrTemplateForDisplay()
      throws ResourceNotFoundException, ParseErrorException, MethodInvocationException, IOException, Exception {
    // Start : Modified for QC#1630.
    // -- Initializing VelocityEngine
    final VelocityEngine velocityEngine = new VelocityEngine();
    final Properties prop = new Properties();
    prop.put("resource.loader", LicensingConstant.ATTR_MDFR_CLASS);
    prop.put("class.resource.loader.class", "org.apache.velocity.runtime.resource.loader.ClasspathResourceLoader");
    prop.put("class.resource.loader.cache", LicensingConstant.FLAG_TRUE);
    velocityEngine.init(prop);

    // -- Getting Template
    final Template template = velocityEngine.getTemplate("templates/NDRTemplate.vtl");

    // -- Initializing velocity context
    final VelocityContext context = new VelocityContext();
    context.put(LicensingConstant.EMPLOYEENAME_WICKETID, LicensingConstant.EMPTY_STRING);
    context.put("nickName", "");
    context.put(LicensingConstant.DOB_WICKETID,LicensingConstant.EMPTY_STRING);
    context.put("weight", "");
    context.put("licenseNumber", "");
    context.put("state", LicensingConstant.EMPTY_STRING);
    context.put("ssn", "");
    context.put(LicensingConstant.EMPLOYEEID_WICKETID, LicensingConstant.EMPTY_STRING);
    context.put("heightFt", "");
    context.put("heightInches", "");
    context.put("address", LicensingConstant.EMPTY_STRING);
    context.put("addressCity", LicensingConstant.EMPTY_STRING);
    context.put("addressState", LicensingConstant.EMPTY_STRING);
    context.put("addressZip", LicensingConstant.EMPTY_STRING);
    
    // creating writer and merging context to it
    final StringWriter stringWriter = new StringWriter();
    template.merge(context, stringWriter);
    // End : Modified for QC#1630.
    return stringWriter;
  }
 
  /**
   * 
   * Method is used to get StringWriter for License cover Letter Template in case of 
   * Print License screen on click of Print Cover Letter button.
   *
   * @param employeeId
   * @param personBean
   * @return stringWriter
   * @throws ResourceNotFoundException
   * @throws ParseErrorException
   * @throws MethodInvocationException
   * @throws IOException
   * @throws Exception
   * @author xsat568
   * @since Sep 28, 2015
   * Modified for REQ#1630.
   */
  private StringWriter getStringWriterForLicenseCoverLetterTemplate(final String employeeId, final PersonBean personBean)
      throws ResourceNotFoundException, ParseErrorException, MethodInvocationException, IOException, Exception {
    // Start : Modified for QC#1630.
    final LicenseCoverLetterTemplateDetails licenseCoverLetterTemplateDetails = licensingService.getLicenseCoverLetterTemplateDetails(employeeId);
    Address address = null;
    if (null != personBean) {
      address = personBean.getAddress();
    }

    // -- Initializing VelocityEngine
    final VelocityEngine velocityEngine = new VelocityEngine();
    final Properties prop = new Properties();
    prop.put("resource.loader", LicensingConstant.ATTR_MDFR_CLASS);
    prop.put("class.resource.loader.class", "org.apache.velocity.runtime.resource.loader.ClasspathResourceLoader");
    prop.put("class.resource.loader.cache", LicensingConstant.FLAG_TRUE);
    velocityEngine.init(prop);

    // -- Getting Template
    final Template template = velocityEngine.getTemplate("templates/LicenseCoverLetterTemplate.vtl");

    // -- Initializing velocity context
    final VelocityContext context = new VelocityContext();
    // employee details
    context.put("employeeId", employeeId);
    context.put(LicensingConstant.EMPLOYEENAME_WICKETID, licenseCoverLetterTemplateDetails.getEmployeeName()
        .toUpperCase());

    // employee's license details
    // string to store license class in format : 01, 02, 06
    String licenseClassAll = "";
    if (licenseCoverLetterTemplateDetails != null
        && licenseCoverLetterTemplateDetails.getCoverLetterlicenseAll() != null) {
      for (License license : licenseCoverLetterTemplateDetails.getCoverLetterlicenseAll()) {
        if (license.getLicenseClass() != null) {
          licenseClassAll = licenseClassAll.equalsIgnoreCase("") ? licenseClassAll + license.getLicenseClass()
              : licenseClassAll + ", " + license.getLicenseClass();
        }
      }
    }
    context.put("coverLetterlicenseAll", licenseClassAll);
    // context.put("coverLetterlicenseAll", licenseCoverLetterTemplateDetails.getCoverLetterlicenseAll());

    context.put("licenseExpiryDate", licenseCoverLetterTemplateDetails.getLicenseExpiryDate());
    context.put("TEYVAL", "TE&Y");

    final StringBuffer stringBuffer = new StringBuffer();
    if (null == address) {
      context.put("empAddress1", LicensingConstant.EMPTY_STRING);
      context.put("empAddress2", LicensingConstant.EMPTY_STRING);
      context.put("city", LicensingConstant.EMPTY_STRING);
      context.put("state", LicensingConstant.EMPTY_STRING);
      context.put("zip", LicensingConstant.EMPTY_STRING);
    } else {
      context.put("empAddress1", ((null != address.getFirstLine()) ? address.getFirstLine().toUpperCase()
          : LicensingConstant.EMPTY_STRING));
      context.put("empAddress2", ((null != address.getSecondLine()) ? address.getSecondLine().toUpperCase()
          : LicensingConstant.EMPTY_STRING));      
      stringBuffer.append(address.getCity().toUpperCase() + ", ");
      stringBuffer.append(address.getState().toUpperCase() + ", ");
      stringBuffer.append(address.getPostCode().toUpperCase());
      context.put("cityStateCountryZip", stringBuffer.toString());
    }    

    // licensing department info from System Parameter table
    context.put("sysLicDeptManager", licenseCoverLetterTemplateDetails.getSysLicDeptManager());
    context.put("sysLicDepartment", licenseCoverLetterTemplateDetails.getSysLicDepartment());
    context.put("sysLicDepartmentAdd1", licenseCoverLetterTemplateDetails.getSysLicDepartmentAdd1());
    context.put("sysLicDepartmentAdd2", licenseCoverLetterTemplateDetails.getSysLicDepartmentAdd2());
    context.put("sysLicensingGroupNo", licenseCoverLetterTemplateDetails.getLicensingGroupNumber());
    context.put("sysBellLineNo", licenseCoverLetterTemplateDetails.getBellLineNumber());

    // creating writer and merging context to it
    final StringWriter stringWriter = new StringWriter();
    template.merge(context, stringWriter);

    return stringWriter;
  }

  /**
   * To get a String Writer for Washington State NDR Form Template 
   * in case of Print Docs on click icon link
   *
   * @param employeeId
   * @return
   * @throws ResourceNotFoundException
   * @throws ParseErrorException
   * @throws MethodInvocationException
   * @throws IOException
   * @throws Exception
   * @author XSAT508
   * @since Jun 10, 2013
   * QC 1641
   * //REQ 526
   */
  private StringWriter getStringWriterForWashingtonStateNdrFormTemplateForDisplay(String managerName) throws ResourceNotFoundException, ParseErrorException, MethodInvocationException,
  IOException, Exception {

    // -- Initializing VelocityEngine
    VelocityEngine velocityEngine = new VelocityEngine();
    Properties prop = new Properties();
    prop.put("resource.loader", LicensingConstant.ATTR_MDFR_CLASS);
    prop.put("class.resource.loader.class", "org.apache.velocity.runtime.resource.loader.ClasspathResourceLoader");
    prop.put("class.resource.loader.cache", LicensingConstant.FLAG_TRUE);
    velocityEngine.init(prop);

    // -- Getting Template
    Template template = velocityEngine.getTemplate("templates/WashingtonStateNdrFormTemplateNew.vtl");//Req#439 change
    // -- Initializing velocity context
    VelocityContext context = new VelocityContext();
    context.put("manager",managerName);
    /*REQ 572:Begin*/
    context.put("mgrTitle", licensingService.getSysParmValue(LicensingConstant.LICENSING_DEPT_MANAGER_TITLE).getParmValu());
    context.put("vendorTitle", licensingService.getSysParmValue(LicensingConstant.WA_FORM_VENDOR).getParmValu());//QC 1641
    context.put("currentDate", LicensingUtil.getDateFormatForCoverLetterTemplates(Calendar.getInstance()));
    /*REQ 572:End*/
    // -- creating writer and merging context to it
    StringWriter stringWriter = new StringWriter();
    template.merge(context, stringWriter);

    return stringWriter;
  }
  
  /**
   * 
   * Method is used to get a String Writer for Washington State NDR Form Template 
   * in case of Print Docs on click of Print button.
   *
   * @param employeeId
   * @param personBean
   * @param managerName
   * @return stringWriter
   * @throws ResourceNotFoundException
   * @throws ParseErrorException
   * @throws MethodInvocationException
   * @throws IOException
   * @throws Exception
   * @author xsat568
   * @since Sep 24, 2015
   * Modified for QC#1630.
   */
  @SuppressWarnings("static-access")
  private StringWriter getStringWriterForWashingtonStateNdrFormTemplate(final String employeeId,
      final PersonBean personBean, final String managerName) throws ResourceNotFoundException, ParseErrorException,
      MethodInvocationException, IOException, Exception {
    // Start : Modified for QC#1630.
    // -- Initializing VelocityEngine
    final VelocityEngine velocityEngine = new VelocityEngine();
    final Properties prop = new Properties();
    prop.put("resource.loader", LicensingConstant.ATTR_MDFR_CLASS);
    prop.put("class.resource.loader.class", "org.apache.velocity.runtime.resource.loader.ClasspathResourceLoader");
    prop.put("class.resource.loader.cache", LicensingConstant.FLAG_TRUE);
    velocityEngine.init(prop);

    // -- Getting Template
    final Template template = velocityEngine.getTemplate("WashingtonStateNdrFormTemplateNew.vtl");//Req#439 change

    // -- Initializing velocity context
    final VelocityContext context = new VelocityContext();
    /*REQ#572:Begin*/
    context.put("mgrTitle", licensingService.getSysParmValue(LicensingConstant.LICENSING_DEPT_MANAGER_TITLE).getParmValu());
    context.put("vendorTitle", licensingService.getSysParmValue(LicensingConstant.WA_FORM_VENDOR).getParmValu());//QC 1641
    context.put("currentDate", LicensingUtil.getDateFormatForCoverLetterTemplates(Calendar.getInstance()));
    /*REQ#572:End*/
    context.put("manager",managerName);//REQ 526
    context.put("driverEmployeeName",
        ((null != personBean && null != personBean.getEmpFullName()) ? personBean.getEmpFullName()
            : LicensingConstant.EMPTY_STRING));
    
    Address address = null;
    if(null != personBean){
      address = personBean.getAddress();
    }
    
    if (null == address) {
      context.put("residanceAddress", LicensingConstant.EMPTY_STRING);
      context.put("city", LicensingConstant.EMPTY_STRING);
      context.put("state", LicensingConstant.EMPTY_STRING);
      context.put("zipCode", LicensingConstant.EMPTY_STRING);
    } else {
      context
          .put("residanceAddress", address.getFirstLine() + LicensingConstant.EMPTY_STRING + address.getSecondLine());
      context.put("city", address.getCity());
      context.put("state", address.getState());
      context.put("zipCode", address.getPostCode());
    }
    
    String birthDate = LicensingConstant.EMPTY_STRING;
    if(null != personBean && null != personBean.getBirthDate()){
      final SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
      birthDate = sdf.format(personBean.getBirthDate().getTime());
    }     
    context.put("dateOfBirth", birthDate);

    // -- creating writer and merging context to it
    final StringWriter stringWriter = new StringWriter();
    template.merge(context, stringWriter);
    // End : Modified for QC#1630.
    
    return stringWriter;
  }
  
  /**
   * 
   * Method is used to get a String Writer for Cover Letter for Existing License Template 
   * in case of Print Docs on click of Print button.
   *
   * @param employeeId
   * @param personBean
   * @param startDateForCoverLetter
   * @param licClass
   * @return stringWriter
   * @throws ResourceNotFoundException
   * @throws ParseErrorException
   * @throws MethodInvocationException
   * @throws IOException
   * @throws Exception
   * @author xsat568
   * @since Sep 28, 2015
   * Modified for QC#1630.
   */
  private StringWriter getStringWriterForCoverLetterForExistingLicenseTemplate(final String employeeId,
      final PersonBean personBean, final String startDateForCoverLetter, final String licClass)
      throws ResourceNotFoundException, ParseErrorException, MethodInvocationException, IOException, Exception {

    // Start : Modified for QC#1630.
    // -- GETTING TEMPLATE DETAILS FROM DB
    final CoverLetterForExistingLicenseDetails coverLetterDetails = licensingService
        .getCoverLetterForExistingLicenseTemplateDetails(employeeId,licClass);
    Address address = null;
    if (null != personBean) {
      address = personBean.getAddress();
    }

    // -- Initializing VelocityEngine
    final VelocityEngine velocityEngine = new VelocityEngine();
    final Properties prop = new Properties();
    prop.put("resource.loader", LicensingConstant.ATTR_MDFR_CLASS);
    prop.put("class.resource.loader.class", "org.apache.velocity.runtime.resource.loader.ClasspathResourceLoader");
    prop.put("class.resource.loader.cache", LicensingConstant.FLAG_TRUE);
    velocityEngine.init(prop);

    // -- Getting Template
    final Template template = velocityEngine.getTemplate("templates/CoverLetterTemplateForExistingLicense.vtl");

    // -- Initializing velocity context
    final VelocityContext context = new VelocityContext();

    context.put("currentDate", LicensingUtil.getDateFormatForCoverLetterTemplates(Calendar.getInstance()));
    context.put("employeeName", ((null != personBean && null != personBean.getEmpFullName()) ? personBean
        .getEmpFullName().toUpperCase() : LicensingConstant.EMPTY_STRING));

    // -- TEMPLATE IS ALWAYS USED ONLY FOR CLASS 3 ONLY
    context.put("classNumber", coverLetterDetails.getLicenseClassName());

    // -- SETTING START DATE
    if (startDateForCoverLetter == null) {
      context.put("startDate", LicensingUtil.getDateFormatForCoverLetterTemplates(Calendar.getInstance()));
    } else {
      // converting date in string format --> into --> calendar format
      final Calendar cal = Calendar.getInstance();
      cal.setTime(DateUtil.convertStringToDate(startDateForCoverLetter));

      // getting desired formatting of date in string for cover letter display
      context.put("startDate", LicensingUtil.getDateFormatForCoverLetterTemplates(cal));
    }

    // -- SETTING ADDRESS DETAILS OF EMPLOYEE
    if (address == null) {
      context.put("address1", LicensingConstant.EMPTY_STRING);
      context.put("address2", LicensingConstant.EMPTY_STRING);
      context.put("cityStateCountyPin", LicensingConstant.EMPTY_STRING);
    } else {
      context.put("address1", ((null != address.getFirstLine()) ? address.getFirstLine().toUpperCase()
          : LicensingConstant.EMPTY_STRING));
      context.put("address2", ((null != address.getSecondLine()) ? address.getSecondLine().toUpperCase()
          : LicensingConstant.EMPTY_STRING));      
      final StringBuffer stringBuffer = new StringBuffer();
      stringBuffer.append(address.getCity().toUpperCase() + ", ");
      stringBuffer.append(address.getState().toUpperCase() + " ");
      stringBuffer.append(address.getPostCode().toUpperCase() + ".");
      context.put("cityStateCountyPin", stringBuffer.toString());
    }

    // -- SETTING SYS-PARAM DETAILS
    context.put("sysLicDeptManagerName", coverLetterDetails.getSysLicDeptManagerName());
    context.put("sysLicDepartmentName", coverLetterDetails.getSysLicDepartmentName());
    context.put("sysLicensingDeptNumber", coverLetterDetails.getSysLicensingDeptNo());
    context.put("sysBellLineNumber", coverLetterDetails.getSysBellLineNo());
    final StringWriter stringWriter = new StringWriter();
    template.merge(context, stringWriter);
    // End : Modified for QC#1630.
    
    return stringWriter;
  }
  
  /**
   * 
   * Method is used to get a String Writer for Cover Letter for New License Template 
   * in case of Print Docs on click of Print button.
   *
   * @param employeeId
   * @param personBean
   * @param startDateForCoverLetter
   * @return stringWriter
   * @throws ResourceNotFoundException
   * @throws ParseErrorException
   * @throws MethodInvocationException
   * @throws IOException
   * @throws Exception
   * @author xsat568
   * @since Sep 24, 2015
   * Modified for QC#1630.
   */
  private StringWriter getStringWriterForCoverLetterForNewLicenseTemplate(final String employeeId,
      final PersonBean personBean, final String startDateForCoverLetter) throws ResourceNotFoundException,
      ParseErrorException, MethodInvocationException, IOException, Exception {

    // Start : Modified for QC#1630.
    Address address = null;
    if (null != personBean) {
      address = personBean.getAddress();
    }

    // -- GETTING TEMPLATE DETAILS FROM DB
    final CoverLetterForNewLicenseDetails coverLetterDetails = licensingService
        .getCoverLetterForNewLicenseTemplateDetails(employeeId);

    // -- Initializing VelocityEngine
    final VelocityEngine velocityEngine = new VelocityEngine();
    final Properties prop = new Properties();
    prop.put("resource.loader", LicensingConstant.ATTR_MDFR_CLASS);
    prop.put("class.resource.loader.class", "org.apache.velocity.runtime.resource.loader.ClasspathResourceLoader");
    prop.put("class.resource.loader.cache", LicensingConstant.FLAG_TRUE);
    velocityEngine.init(prop);

    // -- Getting Template
    final Template template = velocityEngine.getTemplate("templates/CoverLetterTemplateForNewLicense.vtl");

    // -- Initializing velocity context
    final VelocityContext context = new VelocityContext();

    context.put("currentDate", LicensingUtil.getDateFormatForCoverLetterTemplates(Calendar.getInstance()));
    context.put("employeeName", (null != personBean && null != personBean.getEmpFullName()) ? personBean
        .getEmpFullName().toUpperCase() : LicensingConstant.EMPTY_STRING);

    // -- TEMPLATE WILL BE PRINTED FOR CLASS 3 ONLY
    context.put("classNumber", coverLetterDetails.getLicenseClassName());

    if (startDateForCoverLetter == null) {
      context.put("startDate", LicensingUtil.getDateFormatForCoverLetterTemplates(Calendar.getInstance()));
    } else {
      // converting date in string format --> into --> calendar format
      Calendar cal = Calendar.getInstance();
      cal.setTime(DateUtil.convertStringToDate(startDateForCoverLetter));

      // getting desired formatting of date in string for cover letter display
      context.put("startDate", LicensingUtil.getDateFormatForCoverLetterTemplates(cal));
    }

    // -- SETTING ADDRESS DETAILS OF EMPLOYEE
    if (null == address) {
      context.put("address1", LicensingConstant.EMPTY_STRING);
      context.put("address2", LicensingConstant.EMPTY_STRING);
      context.put("cityStateCountyPin", LicensingConstant.EMPTY_STRING);
    } else {
      context.put("address1", ((null != address.getFirstLine()) ? address.getFirstLine().toUpperCase()
          : LicensingConstant.EMPTY_STRING));
      context.put("address2", ((null != address.getSecondLine()) ? address.getSecondLine().toUpperCase()
          : LicensingConstant.EMPTY_STRING));     
      final StringBuffer stringBuffer = new StringBuffer();
      stringBuffer.append(address.getCity().toUpperCase() + ", ");
      stringBuffer.append(address.getState().toUpperCase() + " ");
      // stringBuffer.append(address.getCountry().toUpperCase()+" - ");
      stringBuffer.append(address.getPostCode() + ".");
      context.put("cityStateCountyPin", stringBuffer.toString());
    }
    // End : Modified for QC#1630.

    // -- SETTING SYS-PARAM DETAILS
    context.put("sysLicDeptManagerName", coverLetterDetails.getSysLicDeptManagerName());
    context.put("sysLicDepartmentName", coverLetterDetails.getSysLicDepartmentName());
    final StringWriter stringWriter = new StringWriter();
    template.merge(context, stringWriter);
    return stringWriter;
  }

  /**
   * Classname / Method Name : PDFPage/getStringWriterForDirectionsForWashingtonStateEmployeeLetterTemplate()
   * @return : StringWriter
   * @throws ResourceNotFoundException
   * @throws ParseErrorException
   * @throws MethodInvocationException
   * @throws IOException
   * @throws Exception
   * Description : Method is used to get string writer for 'Directions For Washington State employees letter'
   * template in case of Print Docs on click of Print button. 
   */
  private StringWriter getStringWriterForDirectionsForWashingtonStateEmployeeLetterTemplate()
  throws ResourceNotFoundException, ParseErrorException, MethodInvocationException, IOException, Exception{

    // -- Initializing VelocityEngine
    VelocityEngine velocityEngine = new VelocityEngine();
    Properties prop = new Properties();
    prop.put("resource.loader", LicensingConstant.ATTR_MDFR_CLASS);
    prop.put("class.resource.loader.class", "org.apache.velocity.runtime.resource.loader.ClasspathResourceLoader");
    prop.put("class.resource.loader.cache", LicensingConstant.FLAG_TRUE);
    velocityEngine.init(prop);

    // -- Getting Template
    Template template = velocityEngine.getTemplate("templates/DirectionsTemplateForWashington.vtl");

    // -- Initializing velocity context
    VelocityContext context = new VelocityContext();

    StringWriter stringWriter = new StringWriter();
    template.merge(context, stringWriter);
    return stringWriter;
  }

  /**
   * Classname / Method Name : PDFPage/getEmployeeDetailsFromPersonDataService()
   * @param : emplId
   * @return : PersonBean
   * Description : Method is used to get Employee Details from Secured Person Data Service of People Soft.
   */
  private PersonBean getEmployeeDetailsFromPersonDataService(String emplId){
    PersonBean personBean = null;

    //-- geting status of PEOPLESOFT_TERADATA flag from sys param
    Boolean peopleSoftTeradatFlag = LicensingUtil.getPeopleSoftTeradataFlagStatus(sysParmMap);

    if(peopleSoftTeradatFlag != null && !peopleSoftTeradatFlag) {
      //-- if PEOPLESOFT_TERADATA = OFF, then only call person data service
      //-- comment this line for offshore
      personBean = licensingService.getEmployeeDetails(emplId);
    }
    return personBean;
  }
 
  /**
   * 
   * Method is used to get StringWriter for Cover Letter Template in case of Print Docs.
   * This is named as 'Employee Letter' and is effective for recertification only
   *
   * @param employeeId
   * @param personBean
   * @return stringWriter
   * @throws ResourceNotFoundException
   * @throws ParseErrorException
   * @throws MethodInvocationException
   * @throws IOException
   * @throws Exception
   * @author xsat568
   * @since Sep 24, 2015
   * Modified for QC#1630.
   */
  private StringWriter getStringWriterForCoverLetterForPrintDocsTemplateBlank(final String employeeId,
      final PersonBean personBean) throws ResourceNotFoundException, ParseErrorException, MethodInvocationException,
      IOException, Exception {
    final String mgrName = licensingService.getSysParmValue(LicensingConstant.LICENSING_DEPT_MANAGER_NAME).getParmValu();
    // Start : Modified for QC#1630.
    
    // -- Initializing VelocityEngine
    final VelocityEngine velocityEngine = new VelocityEngine();
    final Properties prop = new Properties();
    prop.put("resource.loader", LicensingConstant.ATTR_MDFR_CLASS);
    prop.put("class.resource.loader.class", "org.apache.velocity.runtime.resource.loader.ClasspathResourceLoader");
    prop.put("class.resource.loader.cache", LicensingConstant.FLAG_TRUE);
    velocityEngine.init(prop);

    // -- Getting Template
    final Template template = velocityEngine.getTemplate("templates/CoverLetterTemplateForPrintDocsBlank.vtl");
    

    // -- Initializing velocity context
    final VelocityContext context = new VelocityContext();
    // creating writer and merging context to it
    /* REQ627 Changes:Begin */
    //final Map<String, SysParamBean> sysParmMap = webApplication.getSysparamMap();
    if (null != sysParmMap && null != sysParmMap.get(LicensingConstant.URL_EMPLOYEE_TODO_LIST)
        && null != sysParmMap.get(LicensingConstant.URL_EMPLOYEE_TODO_LIST).getParmValu()) {
      context.put("emplTodoListURL", sysParmMap.get(LicensingConstant.URL_EMPLOYEE_TODO_LIST).getParmValu());
    } else {
      context.put("emplTodoListURL", "");
    }
    /* REQ627 Changes:End */

    String sysLicDeptManagerName = null;
    if (null != mgrName && !LicensingConstant.BLANK_STRING.equals(mgrName)) {
      sysLicDeptManagerName = mgrName;
    } else {
      sysLicDeptManagerName = LicensingConstant.LIC_DEPT_MGR_NAME;
    }

    context.put("sysLicDeptManagerName", sysLicDeptManagerName);// modified for vtl changes
    // End : Modified for QC#1630.

    final StringWriter stringWriter = new StringWriter();
    template.merge(context, stringWriter);

    return stringWriter;
  }

  /*public static void main(String[] args){ 
    try { 
    PdfConvertor pdfc = new PdfConvertor();
    FileOutputStream  fileout; 
    fileout = new FileOutputStream("C:\\Users\\xsat004\\Documents\\PrintDocumentTemplates.pdf");
    ByteArrayOutputStream baos = pdfc.getPdf( getStringWriterForWashingtonStateNdrFormTemplate(null, null, null));
    fileout.write(baos.toByteArray()); 
    fileout.flush(); 
    fileout.close(); 
    } catch (Exception e) { 
      e.printStackTrace(); 
    } 
  }*/
  
  /**
   * 
   * To get employees' details from PersonData Service.
   *
   * @param emplIds
   * @return personBeanList
   * @author xsat568
   * @since Sep 24, 2015
   * Added for QC#1630.
   */
  private List<PersonBean> getEmployeeDetailsFromPersonDataService(final List<String> emplIds) {
    final List<PersonBean> personBeanList = licensingService.getEmployeeDetails(emplIds);
    return personBeanList;
  }
  
  /**
   * 
   * Prepare map from list of employees' details.
   *
   * @param personBeanList
   * @param personBeanMap
   * @return personBeanMap
   * @author xsat568
   * @since Sep 24, 2015
   * Added for QC#1630.
   */
  private Map<String, PersonBean> getMapFromPersonBeanList(final List<PersonBean> personBeanList,
      final Map<String, PersonBean> personBeanMap) {
    if (null != personBeanList && !personBeanList.isEmpty()) {
      for (final PersonBean personBean : personBeanList) {
        final String emplId = personBean.getEmplId();
        personBeanMap.put(emplId, personBean);
      }
    }
    return personBeanMap;
  }
  
  /**
   * 
   * Method is used to get StringWriter for re-certification packet cover letter Template 
   * on click of both icon link and Print button from IVR Request.
   *
   * @param employeeId
   * @param personBean
   * @return stringWriter
   * @throws ResourceNotFoundException
   * @throws ParseErrorException
   * @throws MethodInvocationException
   * @throws IOException
   * @throws Exception
   * @author xsat568
   * @since Dec 15, 2015
   * Added for REQ#689.
   */
  private StringWriter getStringWriterForCoverLetterForRecertPktsTemplate(final String employeeId,
      final PersonBean personBean) throws ResourceNotFoundException, ParseErrorException, MethodInvocationException,
      IOException, Exception {
    // -- Initializing VelocityEngine
    final VelocityEngine velecityEngine = new VelocityEngine();
    final Properties prop = new Properties();
    prop.put("resource.loader", LicensingConstant.ATTR_MDFR_CLASS);
    prop.put("class.resource.loader.class", "org.apache.velocity.runtime.resource.loader.ClasspathResourceLoader");
    prop.put("class.resource.loader.cache", LicensingConstant.FLAG_TRUE);
    velecityEngine.init(prop);

    // -- Getting Template
    final Template template = velecityEngine.getTemplate("templates/CoverLetterTemplateForRecertPkts.vtl");
    // -- Initializing velocity context
    final VelocityContext context = new VelocityContext();
    context.put(LicensingConstant.EMPLOYEENAME_WICKETID,
        ((null != personBean && null != personBean.getEmpFullName()) ? personBean.getEmpFullName()
            : LicensingConstant.EMPTY_STRING));
    context.put(LicensingConstant.EMPLOYEEID_WICKETID, ((null != personBean) ? personBean.getEmplId()
        : LicensingConstant.EMPTY_STRING));
    context.put("currentDate", LicensingUtil.getDateFormatForCoverLetterTemplates(Calendar.getInstance()));

    Address address = null;
    if (null != personBean) {
      address = personBean.getAddress();
    }

    // -- SETTING ADDRESS DETAILS OF EMPLOYEE
    if (null == address) {
      context.put("address1", LicensingConstant.EMPTY_STRING);
      context.put("address2", LicensingConstant.EMPTY_STRING);
      context.put("cityStateCountyPin", LicensingConstant.EMPTY_STRING);
    } else {
      context.put("address1", ((null != address.getFirstLine()) ? address.getFirstLine().toUpperCase()
          : LicensingConstant.EMPTY_STRING));
      context.put("address2", ((null != address.getSecondLine()) ? address.getSecondLine().toUpperCase()
          : LicensingConstant.EMPTY_STRING));
      final StringBuffer stringBuffer = new StringBuffer();
      stringBuffer.append(address.getCity().toUpperCase() + ", ");
      stringBuffer.append(address.getState().toUpperCase() + " ");
      stringBuffer.append(address.getPostCode() + ".");
      context.put("cityStateCountyPin", stringBuffer.toString());
    }

    // Creating writer and merging context to it
    final StringWriter stringWriter = new StringWriter();
    template.merge(context, stringWriter);
    return stringWriter;
  }
  
  //Added For SS_QC#5427:Start
   /**
   * Description : Method is used to get StringWriter for MVR Release Instruction Form Template in case of Print Docs 
   * on click of both icon link and Print button.
   * @return StringWriter
   * @author xsat872
   * @since  Oct 19, 2016
   */
  private StringWriter getStringWriterForMVRReleaseInsFormTemplate()
      throws ResourceNotFoundException, ParseErrorException, MethodInvocationException, IOException, Exception {
    // -- Initializing VelocityEngine
    VelocityEngine velocityEngine = new VelocityEngine();
    Properties prop = new Properties();
    prop.put("resource.loader", LicensingConstant.ATTR_MDFR_CLASS);
    prop.put("class.resource.loader.class", "org.apache.velocity.runtime.resource.loader.ClasspathResourceLoader");
    prop.put("class.resource.loader.cache", LicensingConstant.FLAG_TRUE);
    velocityEngine.init(prop);
    // -- Getting Template
    Template template = velocityEngine.getTemplate("templates/MVRReleaseInstructionForm.vtl");
    // -- Initializing velocity context
    VelocityContext context = new VelocityContext();
    context.put("leq", "checked");
    context.put("rco", "checked");
    context.put("sle", "checked");
    // creating writer and merging context to it
    StringWriter stringWriter = new StringWriter();
    template.merge(context, stringWriter);
    return stringWriter;
  }
  //Added For SS_QC#5427:End
  
 
}
