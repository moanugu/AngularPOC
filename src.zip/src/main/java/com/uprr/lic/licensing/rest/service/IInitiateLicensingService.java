package com.uprr.lic.licensing.rest.service;

import java.text.ParseException;
import java.util.List;
import java.util.Map;

import com.uprr.lic.dataaccess.Licensing.model.EmployeeDetailLicInit;
import com.uprr.lic.dataaccess.Licensing.model.InitiateLicensingRequestBean;
import com.uprr.lic.dataaccess.common.model.EqmEmplDtls;
import com.uprr.lic.dataaccess.common.model.EqmTestDtls;
import com.uprr.lic.dataaccess.common.model.PersonBean;
import com.uprr.lic.exception.EqmException;
import com.uprr.lic.util.DDChoice;
/**
 * 
 * @author xsat004
 *
 */
public interface IInitiateLicensingService {
	PersonBean getEmployeeDetails(final String emplId);
	boolean insertNewEmployee(PersonBean personBean);
	List<DDChoice> getAllLicenseTypeList(String licenseType);
	InitiateLicensingRequestBean initializeLicensingRequest(InitiateLicensingRequestBean licenseRequest,
			List<EmployeeDetailLicInit> finalList);
	Map<String, Map<String, EmployeeDetailLicInit>> createInitiateLicenseRequest(
			InitiateLicensingRequestBean licenseRequest);
	boolean isEmployeeLicensed(String employeeID,final Boolean flagHist);
	EqmTestDtls checkForValidTestDetailsAvailability(String employeeId, Integer selection);
	EmployeeDetailLicInit getEmployeeDetailsForInitiateLicenseRequest(InitiateLicensingRequestBean licenseRequest) throws EqmException, ParseException;
	EqmEmplDtls getEmplDtls(String employeeId);
	Map<String, Map<String, EmployeeDetailLicInit>> initializeAndCreateLicensingRequest(InitiateLicensingRequestBean licenseRequest,
			List<EmployeeDetailLicInit> finalList);
	List<EmployeeDetailLicInit> getEmployeeTestDetails(List<EmployeeDetailLicInit> employeebeans);
}
