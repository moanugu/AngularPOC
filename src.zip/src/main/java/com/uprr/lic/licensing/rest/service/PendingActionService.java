package com.uprr.lic.licensing.rest.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uprr.lic.auth.EQMSUserSession;
import com.uprr.lic.dataaccess.Licensing.model.PendingActionListGridDetail;
import com.uprr.lic.dataaccess.Licensing.model.PendingActionListPageDetail;
import com.uprr.lic.dataaccess.Licensing.model.PrintTemporaryLicenseGrid;
import com.uprr.lic.dataaccess.Licensing.model.TempLicenseTemplate;
import com.uprr.lic.dataaccess.components.licensing.service.ILicensingService;
import com.uprr.lic.exception.EqmDaoException;
import com.uprr.lic.externalservice.xmf.service.PrintXmfILataService;
import com.uprr.lic.licensing.rest.model.LicensingRequest;
import com.uprr.lic.licensing.rest.model.PendingActionDetail;
import com.uprr.lic.licensing.rest.model.PendingActionRequest;

import templates.LataTemplateForTempLicense;

/**
 * 
 * @author xsat956
 *
 */
@Service("pendingActionService")
public class PendingActionService implements IPendingActionService {

	@Autowired
	private ILicensingService licensingService;

	@Autowired
	private EQMSUserSession userSession;

	@Autowired
	private PrintXmfILataService printXmfLataService;

	@Autowired
	private EQMSUserSession eqmsUserSession;




	@Override
	public List<PendingActionDetail> getPendingActionDataList(PendingActionRequest pendingActionRequest) {
		PendingActionListPageDetail pendingActionListPageDetail = createPendingActionRequest(pendingActionRequest);
		List<PendingActionListGridDetail> pendingActionListGridDetails = licensingService.getPendingActionGridList(pendingActionListPageDetail);
		return createPendingActionDataListResponse(pendingActionListGridDetails);
	}

	/**
	 * Convert pendingActionRequest request object into pendingActionListPageDetail
	 * @param pendingActionRequest
	 * @return
	 */
	private PendingActionListPageDetail createPendingActionRequest(PendingActionRequest pendingActionRequest) {
		
		if(pendingActionRequest == null) {
			return new PendingActionListPageDetail();
		}
		
		PendingActionListPageDetail  pendingActionListPageDetail = new PendingActionListPageDetail();
		pendingActionListPageDetail.setFromDate( pendingActionRequest.getFromDate(  )  ) ; 
		pendingActionListPageDetail.setToDate( pendingActionRequest.getToDate(  )  ) ; 
		pendingActionListPageDetail.setRegion( pendingActionRequest.getRegion(  )  ) ; 
		pendingActionListPageDetail.setServiceUnit( pendingActionRequest.getServiceUnit(  )  ) ; 
		pendingActionListPageDetail.setLicense( pendingActionRequest.getLicense(  )  ) ; 
		pendingActionListPageDetail.setPending( pendingActionRequest.getPending(  )  ) ; 
		pendingActionListPageDetail.setEmployeeID( pendingActionRequest.getEmployeeID(  )  ) ; 
		return pendingActionListPageDetail;
	}

	private List<PendingActionDetail> createPendingActionDataListResponse(List<PendingActionListGridDetail> pendingActionListGridDetails) {

		List<PendingActionDetail> pendingActionDetailList = new ArrayList<>();
		if(pendingActionListGridDetails == null) {
			return pendingActionDetailList;
		}
		for( PendingActionListGridDetail objPendingActionListGridDetail: pendingActionListGridDetails) {
			PendingActionDetail pendingActionDetail = new PendingActionDetail();
			/*pendingActionDetail.setLoggedInUserId(userSession.getUser().getEmplId());*/
			pendingActionDetail.setEmployeeID( objPendingActionListGridDetail.getEmployeeID(  )  ) ; 
			pendingActionDetail.setEmployeeName( objPendingActionListGridDetail.getEmployeeName(  )  ) ; 
			pendingActionDetail.setCreatedDate( objPendingActionListGridDetail.getCreatedDate(  )  ) ; 
			pendingActionDetail.setServiceUnitName( objPendingActionListGridDetail.getServiceUnitName(  )  ) ; 
			pendingActionDetail.setAssignedManager( objPendingActionListGridDetail.getAssignedManager(  )  ) ; 
			pendingActionDetail.setLcnsExpnDate( objPendingActionListGridDetail.getLcnsExpnDate(  )  ) ; 
			pendingActionDetail.setPhotoStatus( objPendingActionListGridDetail.getPhotoStatus(  )  ) ; 
			pendingActionDetail.setPhotoExpnDate( objPendingActionListGridDetail.getPhotoExpnDate(  )  ) ; 
			pendingActionDetail.setPhotoTakenDate( objPendingActionListGridDetail.getPhotoTakenDate(  )  ) ; 
			pendingActionDetail.setServiceUnit( objPendingActionListGridDetail.getServiceUnit(  )  ) ; 
			pendingActionDetail.setServiceUnitNbr( objPendingActionListGridDetail.getServiceUnitNbr(  )  ) ; 
			pendingActionDetail.setDate( objPendingActionListGridDetail.getDate(  )  ) ; 
			pendingActionDetail.setLicense( objPendingActionListGridDetail.getLicense(  )  ) ; 
			pendingActionDetail.setReason( objPendingActionListGridDetail.getReason(  )  ) ; 
			pendingActionDetail.setAction( objPendingActionListGridDetail.getAction(  )  ) ; 
			pendingActionDetail.setSecondAction( objPendingActionListGridDetail.getSecondAction(  )  ) ; 
			pendingActionDetail.setThirdAction( objPendingActionListGridDetail.getThirdAction(  )  ) ;
			pendingActionDetail.setFourthAction( objPendingActionListGridDetail.getFourthAction(  )  ) ;
			pendingActionDetail.setDateOfBirth( objPendingActionListGridDetail.getDateOfBirth(  )  ) ; 
			pendingActionDetail.setMedical( objPendingActionListGridDetail.getMedical(  )  ) ; 
			pendingActionDetail.setSkillRide( objPendingActionListGridDetail.getSkillRide(  )  ) ; 
			pendingActionDetail.setRules( objPendingActionListGridDetail.getRules(  )  ) ; 
			pendingActionDetail.setMvr( objPendingActionListGridDetail.getMvr(  )  ) ; 
			pendingActionDetail.setNdr( objPendingActionListGridDetail.getNdr(  )  ) ; 
			pendingActionDetail.setFtxEvnt( objPendingActionListGridDetail.getFtxEvnt(  )  ) ; 
			pendingActionDetail.setOr6aExam( objPendingActionListGridDetail.getOr6aExam(  )  ) ; 
			pendingActionDetail.setConExamPinAval( objPendingActionListGridDetail.getConExamPinAval(  )  ) ; 
			pendingActionDetail.setWorkItemId( objPendingActionListGridDetail.getWorkItemId(  )  ) ; 
			pendingActionDetail.setReasonID( objPendingActionListGridDetail.getReasonID(  )  ) ; 
			pendingActionDetail.setLcnsOprnId( objPendingActionListGridDetail.getLcnsOprnId(  )  ) ; 
			pendingActionDetail.setLcnsOprnCode( objPendingActionListGridDetail.getLcnsOprnCode(  )  ) ; 
			pendingActionDetail.setRqmtId( objPendingActionListGridDetail.getRqmtId(  )  ) ; 
			pendingActionDetail.setJobCode( objPendingActionListGridDetail.getJobCode(  )  ) ; 
			pendingActionDetail.setLcnsDtlsId( objPendingActionListGridDetail.getLcnsDtlsId(  )  ) ; 
			pendingActionDetail.setSubmitFlag( objPendingActionListGridDetail.getSubmitFlag(  )  ) ; 
			pendingActionDetail.setRowVersionNoForLcnsOprn( objPendingActionListGridDetail.getRowVersionNoForLcnsOprn(  )  ) ; 
			pendingActionDetail.setRowVersionNoForWorkItem( objPendingActionListGridDetail.getRowVersionNoForWorkItem(  )  ) ; 
			pendingActionDetail.setLcnsMailDate( objPendingActionListGridDetail.getLcnsMailDate(  )  ) ; 
			pendingActionDetail.setKnlgExamRslt( objPendingActionListGridDetail.getKnlgExamRslt(  )  ) ; 
			pendingActionDetail.setKnlgExamDate( objPendingActionListGridDetail.getKnlgExamDate(  )  ) ; 
			pendingActionDetail.setErtCode( objPendingActionListGridDetail.getErtCode(  )  ) ; 
			pendingActionDetail.setAgrmntFlag( objPendingActionListGridDetail.getAgrmntFlag(  )  ) ; 
			pendingActionDetail.setMvrAuthRcvdDate( objPendingActionListGridDetail.getMvrAuthRcvdDate(  )  ) ; 
			pendingActionDetail.setOpccValue( objPendingActionListGridDetail.getOpccValue(  )  ) ; 
			pendingActionDetail.setOprcValue( objPendingActionListGridDetail.getOprcValue(  )  ) ; 
			pendingActionDetail.setOpecValue( objPendingActionListGridDetail.getOpecValue(  )  ) ; 
			pendingActionDetail.setOpccDate( objPendingActionListGridDetail.getOpccDate(  )  ) ; 
			pendingActionDetail.setOprcDate( objPendingActionListGridDetail.getOprcDate(  )  ) ; 
			pendingActionDetail.setOpecDate( objPendingActionListGridDetail.getOpecDate(  )  ) ; 
			pendingActionDetail.setCmtsStatCode( objPendingActionListGridDetail.getCmtsStatCode(  )  ) ; 
			pendingActionDetail.setJobEmpStatusDesc( objPendingActionListGridDetail.getJobEmpStatusDesc(  )  ) ;
			//Added for SS_QC#6703
			pendingActionDetail.setRiskScore(objPendingActionListGridDetail.getRiskScore());
			pendingActionDetailList.add(pendingActionDetail);
		}
		return pendingActionDetailList;
	}

	@Override
	public void removeRecordForPhotoID(String emplId,String crtnEmplId, List<Integer> packResn, List<String> workItemFlagList,
			String comments) {
		licensingService.removeRecordForPhotoID(emplId,crtnEmplId,packResn, workItemFlagList, comments);

	}

	public boolean printLataForTempLicense(List<PrintTemporaryLicenseGrid> printTemporaryLicenseGrid, String printId){
		String userId = eqmsUserSession.getUser().getEmplId();
		Boolean flag = false;
		LataTemplateForTempLicense template;
		String message;
		for (PrintTemporaryLicenseGrid gridValues : printTemporaryLicenseGrid) {

			// -- Template for employee
			TempLicenseTemplate licenseTemplate = licensingService
					.getTemporaryLicenseTemplateForPortal(gridValues.getEmployeeID());

			// -- Template for LATA printing.
			template = getLataTemplateInitiation();

			message = template.getBufferForLataPrintForTempLicense(licenseTemplate).toString();

			flag = printXmfLataService.getIlataPrint(userId, printId, message);
		}
		return flag;
	}

	private LataTemplateForTempLicense getLataTemplateInitiation() {
		return new LataTemplateForTempLicense();
	}

	@Override
	public void removeWorkItemEntry(List<LicensingRequest> licensingRequestList) throws EqmDaoException{
		if(licensingRequestList == null) {
			throw new EqmDaoException("Requested body is null");
		} else {
			for(LicensingRequest licensingRequest: licensingRequestList) {
				licensingService.removeWorkItemEntry(licensingRequest.getEmplId(),userSession.getUser().getEmplId(),
						licensingRequest.getWorkItemFlagList(), licensingRequest.getLicenseClass());
			}
		}
	}
}
