package com.uprr.lic.licensing.rest.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uprr.lic.auth.EQMSUserSession;
import com.uprr.lic.dataaccess.Licensing.model.TempLicenseTemplate;
import com.uprr.lic.dataaccess.components.licensing.service.ILicensingService;
import com.uprr.lic.externalservice.xmf.service.PrintXmfILataService;

/**
 * 
 * @author xsat004
 *
 */
@Service
public class PrintTempLicenseService  implements  IPrintTempLicenseService{

	@Autowired
	private ILicensingService licensingService;
	
	@Autowired
	private PrintXmfILataService printXmfLataService;
	
	@Autowired
	private EQMSUserSession eqmsUserSession;
	
	@Override
	public TempLicenseTemplate getTemporaryLicenseTemplateForPortal(String employeeId) {
		return licensingService.getTemporaryLicenseTemplateForPortal(employeeId);
	}

	@Override
	public Boolean getIlataPrint(String iLataNumber, String message) {
		//This is already done by Surbhi for her Use in pending ActionList
		return printXmfLataService.getIlataPrint(eqmsUserSession.getUser().getEmplId(), iLataNumber, message);
	}

}
