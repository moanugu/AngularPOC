/**
 * 
 */
package com.uprr.lic.licensing.rest.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author xsat976
 *
 */
@JsonIgnoreProperties(ignoreUnknown=true)
public class IVRSummary {
	
	private String employeeID;
	
	private String employeeName;
	
	private String summaryDate;
	
	private Integer callBackDays;
	
	private String comments;
	
	private String crtnEmployeeID;
	
	private String callBackInitiatedBy;
	
	private String fromDate;
	
	private String toDate;

	/**
	 * @return the employeeID
	 */
	public String getEmployeeID() {
		return employeeID;
	}

	/**
	 * @param employeeID the employeeID to set
	 */
	public void setEmployeeID(String employeeID) {
		this.employeeID = employeeID;
	}

	/**
	 * @return the employeeName
	 */
	public String getEmployeeName() {
		return employeeName;
	}

	/**
	 * @param employeeName the employeeName to set
	 */
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	/**
	 * @return the summaryDate
	 */
	public String getSummaryDate() {
		return summaryDate;
	}

	/**
	 * @param summaryDate the summaryDate to set
	 */
	public void setSummaryDate(String summaryDate) {
		this.summaryDate = summaryDate;
	}

	/**
	 * @return the callBackDays
	 */
	public Integer getCallBackDays() {
		return callBackDays;
	}

	/**
	 * @param callBackDays the callBackDays to set
	 */
	public void setCallBackDays(Integer callBackDays) {
		this.callBackDays = callBackDays;
	}

	/**
	 * @return the comments
	 */
	public String getComments() {
		return comments;
	}

	/**
	 * @param comments the comments to set
	 */
	public void setComments(String comments) {
		this.comments = comments;
	}

	/**
	 * @return the crtnEmployeeID
	 */
	public String getCrtnEmployeeID() {
		return crtnEmployeeID;
	}

	/**
	 * @param crtnEmployeeID the crtnEmployeeID to set
	 */
	public void setCrtnEmployeeID(String crtnEmployeeID) {
		this.crtnEmployeeID = crtnEmployeeID;
	}

	/**
	 * @return the callBackInitiatedBy
	 */
	public String getCallBackInitiatedBy() {
		return callBackInitiatedBy;
	}

	/**
	 * @param callBackInitiatedBy the callBackInitiatedBy to set
	 */
	public void setCallBackInitiatedBy(String callBackInitiatedBy) {
		this.callBackInitiatedBy = callBackInitiatedBy;
	}

	/**
	 * @return the fromDate
	 */
	public String getFromDate() {
		return fromDate;
	}

	/**
	 * @param fromDate the fromDate to set
	 */
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}

	/**
	 * @return the toDate
	 */
	public String getToDate() {
		return toDate;
	}

	/**
	 * @param toDate the toDate to set
	 */
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	
}
