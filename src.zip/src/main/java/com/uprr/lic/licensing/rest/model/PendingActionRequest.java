package com.uprr.lic.licensing.rest.model;

import java.sql.Date;

import com.uprr.lic.util.DDChoice;
import com.uprr.lic.util.LicensingConstant;
import com.uprr.lic.util.Util;

public class PendingActionRequest {

	  private Date fromDate;

	  private Date toDate;

	  private DDChoice region;

	  private DDChoice serviceUnit;
	  
	  private DDChoice license;

	  private String pending;

	  private String employeeID;

	  
	  private static final long serialVersionUID = 1L;

	  public Date getFromDate() {
	    return fromDate;
	  }

	  public void setFromDate(Date fromDate) {
	    this.fromDate = fromDate;
	  }

	  public Date getToDate() {
	    return toDate;
	  }

	  public void setToDate(Date toDate) {
	    this.toDate = toDate;
	  }

	  public DDChoice getRegion() {
	    return region;
	  }

	  public void setRegion(DDChoice region) {
	    this.region = region;
	  }

	  public DDChoice getServiceUnit() {
	    return serviceUnit;
	  }

	  public void setServiceUnit(DDChoice serviceUnit) {
	    this.serviceUnit = serviceUnit;
	  }

	  public DDChoice getLicense() {
	    return license;
	  }

	  public void setLicense(DDChoice license) {
	    this.license = license;
	  }

	  public String getPending() {
	    return pending;
	  }

	  public void setPending(String pending) {
	    this.pending = pending;
	  }

	  public String getEmployeeID() {
		  if(employeeID == null || employeeID.equalsIgnoreCase(LicensingConstant.BLANK_STRING)){
			  return null;		   
		  }else{
			  return Util.convertLookUpFormatToEmplID(employeeID); 
		  }
	  }

	  public void setEmployeeID(String employeeID) {
		  if(employeeID == null || employeeID.equalsIgnoreCase(LicensingConstant.BLANK_STRING)){
			  this.employeeID=null;    
		  }else{
			  this.employeeID = Util.convertLookUpFormatToEmplID(employeeID);
		  }
	  }

	}