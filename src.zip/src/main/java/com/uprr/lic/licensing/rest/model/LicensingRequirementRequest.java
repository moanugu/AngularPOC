package com.uprr.lic.licensing.rest.model;

import java.util.List;

import com.uprr.lic.dataaccess.Licensing.model.PendingRequirementResult;

public class LicensingRequirementRequest {

	private List<PendingRequirementResult> pendingRequirementResultList;
	private String comments;
	
	
	
	public List<PendingRequirementResult> getPendingRequirementResultList() {
		return pendingRequirementResultList;
	}

	public void setPendingRequirementResultList(List<PendingRequirementResult> pendingRequirementResultList) {
		this.pendingRequirementResultList = pendingRequirementResultList;
	}

	public String getComments() {
		return comments;
	}
	
	public void setComments(String comments) {
		this.comments = comments;
	}
}
