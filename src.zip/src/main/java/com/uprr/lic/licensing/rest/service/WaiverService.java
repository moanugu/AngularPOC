package com.uprr.lic.licensing.rest.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uprr.lic.auth.EQMSUserSession;
import com.uprr.lic.dataaccess.Licensing.model.WaiverDetails;
import com.uprr.lic.dataaccess.Licensing.model.WaiverGrid;
import com.uprr.lic.dataaccess.components.licensing.service.ILicensingService;

/**
 * 
 * @author xsat956
 *
 */
@Service("waiverService")
public class WaiverService implements IWaiverService {

	@Autowired
	private ILicensingService licensingService;
	
	@Autowired
	EQMSUserSession eqmsUserSession;

	@Override
	public WaiverDetails getWaiverDetail(String employeeId) {
		return licensingService.getWaiverDetail(employeeId);
	}

	@Override
	public List<WaiverGrid> hasLicenseWaivedSuccessfully(List<WaiverGrid> waiverList) {
		return licensingService.hasLicenseWaivedSuccessfully(waiverList, eqmsUserSession.getUser().getEmplId());
	}

	@Override
	public List<WaiverGrid> unwaiveEmployeesLicense(List<WaiverGrid> waiverList) {
		return licensingService.unwaiveEmployeesLicense(waiverList, eqmsUserSession.getUser().getEmplId());
	}

	
}
