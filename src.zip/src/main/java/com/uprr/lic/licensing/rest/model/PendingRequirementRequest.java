package com.uprr.lic.licensing.rest.model;

import java.util.Date;

import com.uprr.lic.util.DDChoice;
import com.uprr.lic.util.LicensingConstant;
import com.uprr.lic.util.Util;

public class PendingRequirementRequest{

  private Date fromDate;

  private Date toDate;

  private DDChoice region;

  private DDChoice serviceUnit;

  private String licenseClass;

  private String employeeID;

  private String requirement;


  public Date getFromDate() {
    return fromDate;
  }

  public void setFromDate(Date fromDate) {
    this.fromDate = fromDate;
  }

  public Date getToDate() {
    return toDate;
  }

  public void setToDate(Date toDate) {
    this.toDate = toDate;
  }

  public DDChoice getRegion() {
    return region;
  }

  public void setRegion(DDChoice region) {
    this.region = region;
  }

  public DDChoice getServiceUnit() {
    return serviceUnit;
  }

  public void setServiceUnit(DDChoice serviceUnit) {
    this.serviceUnit = serviceUnit;
  }

  public String getLicenseClass() {
    return licenseClass;
  }

  public void setLicenseClass(String licenseClass) {
    this.licenseClass = licenseClass;
  }

  public String getEmployeeID() {
    if(employeeID == null || employeeID.equalsIgnoreCase(LicensingConstant.BLANK_STRING)){
      return null;			
    }else{
      return Util.convertLookUpFormatToEmplID(employeeID);
    }
  }

  public void setEmployeeID(String employeeID) {
    if(employeeID == null || employeeID.equalsIgnoreCase(LicensingConstant.BLANK_STRING)){
      this.employeeID=null;			
    }else{
      this.employeeID = Util.convertLookUpFormatToEmplID(employeeID);
    }
  }

  public String getRequirement() {
    return requirement;
  }

  public void setRequirement(String requirement) {
    this.requirement = requirement;
  }

}
