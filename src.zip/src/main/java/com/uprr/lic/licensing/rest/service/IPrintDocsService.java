package com.uprr.lic.licensing.rest.service;

import java.util.List;
import java.util.Map;

import com.uprr.lic.dataaccess.common.model.EqmLcnsInit;

/**
 * 
 * @author xsat956
 *
 */
public interface IPrintDocsService {
	//This code is oriented to licensing and started by Abhishek
	List<String> insertPacketPrintingDetailsWithValidation(final String employeeId, final String comments);
	
	public String getEmployeesLicenseInitiationDetails(final Integer lcnsOprnId) ;
	
	public String updatePendingActionMarkAsPacketSent(final String employeeID, final String licenseClass, final Integer reasonID,
			final  Integer workItemID, final Integer oprnId);
	
	
	  //End By Abhishek
	
	//Started by Girish
	
	 Map<Boolean,Integer> getOprnIdforExistingLicense(final String emplId);
	  
	  EqmLcnsInit getInitDtlsByOprnId(final Integer lcnsOprnId);
	  
	Boolean isRecertificationInitiatedForEmployee(String employeeId, String licenseClassCode, Integer selection);
	  
	// End by Girish
}
