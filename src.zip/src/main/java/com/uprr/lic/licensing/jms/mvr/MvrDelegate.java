package com.uprr.lic.licensing.jms.mvr;

import org.springframework.beans.factory.annotation.Autowired;

import com.uprr.lic.dataaccess.mvr.model.MVRCommonBean;
import com.uprr.lic.dataaccess.mvr.service.IMVRAppServiceImpl;

public class MvrDelegate {

  @Autowired
  private IMVRAppServiceImpl mvrDtlAppService;

  public void processMVRResponse(MVRCommonBean anMVRCommonBean) {
    mvrDtlAppService.processMVRResponse(anMVRCommonBean);
  }

}
