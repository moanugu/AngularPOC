package com.uprr.lic.licensing.rest.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.uprr.lic.auth.EQMSUserBean;
import com.uprr.lic.auth.EQMSUserSession;
import com.uprr.lic.dataaccess.Licensing.model.EmpPacketStatusDetails;
import com.uprr.lic.dataaccess.Licensing.model.EmployeeDetail;
import com.uprr.lic.dataaccess.Licensing.model.EmployeePacketMvrNdrPopup;
import com.uprr.lic.dataaccess.Licensing.model.MvrNdrDetails;
import com.uprr.lic.dataaccess.Licensing.model.MvrNdrPopupPacketGridDetail;
import com.uprr.lic.dataaccess.Licensing.model.MvrNdrReplyPopupDetail;
import com.uprr.lic.dataaccess.Licensing.util.LicensingSchedulerUtil;
import com.uprr.lic.dataaccess.common.model.EqmEmplDtls;
import com.uprr.lic.dataaccess.common.model.EqmLcnsMvrRptDtls;
import com.uprr.lic.dataaccess.components.licensing.service.ILicensingService;
import com.uprr.lic.licensing.rest.model.EmpPacketStatusResponse;
import com.uprr.lic.licensing.rest.model.EqmLicensingMvrReportDetailsResponse;
import com.uprr.lic.licensing.rest.model.FeedbackMsgRequest;
import com.uprr.lic.licensing.rest.model.LicensingRequest;
import com.uprr.lic.util.LicensingConstant;
import com.uprr.lic.util.Util;
import com.uprr.netcontrol.frontend.client.xmf.XmfClientInvoker;
import com.uprr.netcontrol.frontend.client.xmf.siteminder.security.SiteMinderToken;

@Service("mvrAndNDRReplyService")
public class MVRAndNDRRestService implements IMVRAndNDRRestService {

	@Autowired
	private ILicensingService licensingService;

	@Autowired
	private EQMSUserSession eqmsUserSession;

	@Autowired
	@Qualifier("xmfMVRFilenetClientInvoker")
	private XmfClientInvoker xmfMVRFilenetClientInvoker;

	@Autowired
	private SiteMinderToken mvrSiteMinderToken;

	private final String DOCUMENT_CLASS_NAME = "MotorVehicleRecordReport";

	@Override
	public Boolean isEmployeeAlreadyLicensed(String employeeId) {
		return licensingService.isEmployeeAlreadyLicensed(employeeId);
	}

	@Override
	public List<Integer> getPackDtlsResn(String employeeId, List<Integer> regionIdList) {
		return licensingService.getPackDtlsResn(employeeId, regionIdList);
	}

	@Override
	public Integer insertEmployeeAuthorizationDetails(List<EmpPacketStatusResponse> detailsList,
			Integer number, String mvr_ndr_code, String comments, Boolean fromSupervision) {
		EQMSUserBean eqmsUserBean = eqmsUserSession.getUser();
		return licensingService.insertEmployeeAuthorizationDetails(createEmployeePacketStatusDetail(detailsList), eqmsUserBean.getEmplId(), number, mvr_ndr_code, comments, fromSupervision);
	}

	@Override
	public boolean setMvrNdrResult(MvrNdrReplyPopupDetail details, String code, Integer rqmtId,
			Integer svcNbr) {
		EQMSUserBean eqmsUserBean = eqmsUserSession.getUser();
		return licensingService.setMvrNdrResult(details, code, rqmtId, eqmsUserBean.getEmplId(), svcNbr);
	}

	@Override
	public boolean oprnForCallbackOption(String code,  String emplId, String comments) {
		EQMSUserBean eqmsUserBean = eqmsUserSession.getUser();
		return licensingService.oprnForCallbackOption(code, eqmsUserBean.getEmplId(), emplId, comments);
	}

	@Override
	public MvrNdrDetails getNdrDetails(int rqmtId, String emplId) {
		return licensingService.getNdrDetails(rqmtId, emplId);
	}

	@Override
	public Integer insertEmployeeAuthorizationPacketDetails(List<EmpPacketStatusResponse> detailsList,
			Integer number, String mvr_ndr_code, String comments, Boolean fromSupervision) {
		return licensingService.insertEmployeeAuthorizationPacketDetails(createEmployeePacketStatusDetail(detailsList), eqmsUserSession.getUser().getEmplId(), number, mvr_ndr_code, comments, fromSupervision);
	}

	@Override
	public List<MvrNdrPopupPacketGridDetail> getMvrNDrReplyPacketStatusList(Integer rqmtId, String code,
			String emplId) {
		return licensingService.getMvrNDrReplyPacketStatusList(rqmtId, code, emplId);
	}

	/**
	 * Classname / Method Name : LicensingService/ getEmployeeFaxDetail
	 * 
	 * @param :InitiateReplaceLicenseBean(obj)
	 * @return :EmployeeDetail
	 * @exception :
	 * @description : This method use for getEmployeeFaxDetail
	 */
	public EmployeeDetail getEmployeeFaxDetail(String empID) {
		EmployeeDetail employeeDetail = licensingService.getEmployeeFaxDetail(empID);
		return employeeDetail;
	}

	/**
	 * Classname / Method Name : LicensingService/ getEmployeeFaxDetail
	 * 
	 * @param :InitiateReplaceLicenseBean(obj)
	 * @return :EmployeeDetail
	 * @exception :
	 * @description : This method use for getEmployeeFaxDetail
	 */
	public Integer updateFaxDetails(String faxNum, Integer lcnsOprnID, String faxContentText) {
		return  licensingService.updateFaxDetails(faxNum,lcnsOprnID,  eqmsUserSession.getUser().getEmplId(),faxContentText);
	}





	@Override
	public List<MvrNdrPopupPacketGridDetail> getMVRAuthDetailsFromReorpts(String employeeId) {
		return licensingService.getMVRAuthDetailsFromReorpts(employeeId);
	}

	@Override
	public MvrNdrDetails getMVRDetails(Integer requirmentId, String employeeId) {
		return licensingService.getMVRDetails(requirmentId, employeeId);
	}

	@Override
	public void doAuthAndCreateMVRReq(List<String> emplIdLst, boolean fromErrWrkItm,
			boolean fromSendRequest) {
		licensingService.doAuthAndCreateMVRReq(emplIdLst, eqmsUserSession.getUser().getEmplId(), fromErrWrkItm, fromSendRequest);
	}

	@Override
	public EqmLicensingMvrReportDetailsResponse doGetMvrReportDtl(String employeeId) {
		return createDoMvrReportDetails(licensingService.doGetMvrRptDtl(employeeId));
	}


	private EqmLicensingMvrReportDetailsResponse createDoMvrReportDetails( EqmLcnsMvrRptDtls objEqmLcnsMvrRptDtls) {
		EqmLicensingMvrReportDetailsResponse objResponse = new EqmLicensingMvrReportDetailsResponse();
		if(objEqmLcnsMvrRptDtls == null) {
			return null;
		}
		objResponse.setMvrRptId( objEqmLcnsMvrRptDtls.getMvrRptId(  )  ) ; 
		objResponse.setEmplId( objEqmLcnsMvrRptDtls.getEmplId(  )  ) ; 
		objResponse.setMvrReqTxt(Util.convertClobToString(objEqmLcnsMvrRptDtls.getMvrReqTxt(  ) ) ) ; 
		objResponse.setMvrRespTxt(Util.convertClobToString(objEqmLcnsMvrRptDtls.getMvrRespTxt(  ))) ; 
		objResponse.setGufnId( objEqmLcnsMvrRptDtls.getGufnId(  )  ) ; 
		objResponse.setHistRcdFlag( objEqmLcnsMvrRptDtls.getHistRcdFlag(  )  ) ; 
		objResponse.setCrtnEmplId( objEqmLcnsMvrRptDtls.getCrtnEmplId(  )  ) ; 
		objResponse.setCrtnDate( objEqmLcnsMvrRptDtls.getCrtnDate(  )  ) ; 
		objResponse.setLastUpdtEmplId( objEqmLcnsMvrRptDtls.getLastUpdtEmplId(  )  ) ; 
		objResponse.setLastUptdDate( objEqmLcnsMvrRptDtls.getLastUptdDate(  )  ) ; 
		objResponse.setEqmPackDtlses( objEqmLcnsMvrRptDtls.getEqmPackDtlses(  )  ) ; 
		return objResponse;
	}

	@Override
	public void removeRecordForRCVDNDRMVR(String emplId, List<Integer> packResn, List<String> workQueueFlagLst,
			String comments) {
		licensingService.removeRecordForRCVDNDRMVR(emplId, eqmsUserSession.getUser().getEmplId(), packResn, workQueueFlagLst, comments);
	}

	@Override
	public List<Map<String, Object>> getMVRReportDetails(List<String> eqmlcnsMvrLst) {
		return licensingService.getMVRReportDetails(eqmlcnsMvrLst);
	}

	@Override
	public Boolean insertMvrNdrResultWithDate(LicensingRequest licensingRequest) {
		return licensingService.insertMvrNdrResultWithDate(createEmployeePacketStatusDetail(licensingRequest.getEmpPacketStatusDetails()), 
				licensingRequest.getDocumentTypeCode(), licensingRequest.getMvrNdrResultPass(), eqmsUserSession.getUser().getEmplId(), licensingRequest.getPacketDate());
	}


	/**
	 * Convert EmpPacketStatusResponse to EmpPacketStatusDetails
	 * @param employeePacketStatusList
	 * @return 
	 */
	private List<EmpPacketStatusDetails> createEmployeePacketStatusDetail(List<EmpPacketStatusResponse> employeePacketStatusList) {

		List<EmpPacketStatusDetails> employeeStatusResponseList = new ArrayList<EmpPacketStatusDetails>();
		
		if(employeePacketStatusList == null) {
			return employeeStatusResponseList;
		}
		
		for( EmpPacketStatusResponse  objEmpPacketStatusDetails : employeePacketStatusList) {
			EmpPacketStatusDetails objResponse = new EmpPacketStatusDetails();
			objResponse.setPacketDate( objEmpPacketStatusDetails.getPacketDate(  )  ) ; 
			objResponse.setReply( objEmpPacketStatusDetails.getReply(  )  ) ; 
			objResponse.setResultPassOrFail( objEmpPacketStatusDetails.getResultPassOrFail(  )  ) ; 
			objResponse.setResult( objEmpPacketStatusDetails.getResult(  )  ) ; 
			objResponse.setStatus( objEmpPacketStatusDetails.getStatus(  ) ) ; 
			objResponse.setResultEmpAuth( objEmpPacketStatusDetails.getResultEmpAuth(  )  ) ; 
			objResponse.setActionTakenBy( objEmpPacketStatusDetails.getActionTakenBy(  )  ) ; 
			objResponse.setEmployeeID( objEmpPacketStatusDetails.getEmployeeID(  )  ) ; 
			objResponse.setEmployeeName( objEmpPacketStatusDetails.getEmployeeName(  )  ) ; 
			objResponse.setServiceUnit( objEmpPacketStatusDetails.getServiceUnit(  )  ) ; 
			objResponse.setLicense( objEmpPacketStatusDetails.getLicense(  )  ) ; 
			objResponse.setResultDate( objEmpPacketStatusDetails.getResultDate(  )  ) ; 
			objResponse.setSvcUnitNbr( objEmpPacketStatusDetails.getSvcUnitNbr(  )  ) ; 
			objResponse.setRecordType( objEmpPacketStatusDetails.getRecordType(  )  ) ; 
			objResponse.setResnId( objEmpPacketStatusDetails.getResnId(  )  ) ; 
			objResponse.setPackStatCmnt( objEmpPacketStatusDetails.getPackStatCmnt(  )  ) ; 
			objResponse.setCallBackCmnt( objEmpPacketStatusDetails.getCallBackCmnt(  )  ) ; 
			objResponse.setDocumentTypeRadioGrp( objEmpPacketStatusDetails.getDocumentTypeRadioGrp(  )  ) ; 
			objResponse.setHistRcdFlag( objEmpPacketStatusDetails.getHistRcdFlag(  )  ) ; 
			objResponse.setViewMVR( objEmpPacketStatusDetails.getViewMVR(  )  ) ; 
			objResponse.setEntrMVRAuth( objEmpPacketStatusDetails.getEntrMVRAuth(  )  ) ; 
			objResponse.setRcvdDate( objEmpPacketStatusDetails.getRcvdDate(  )  ) ; 
			employeeStatusResponseList.add(objResponse);
		}
		return employeeStatusResponseList;
	}

	/**
	 * @param packetStatus
	 * @return
	 */
	public List<MvrNdrPopupPacketGridDetail> getPacketHistoryNdrList(EmployeePacketMvrNdrPopup packetStatus) {
		return licensingService.getPacketHistoryNdrList(packetStatus);
	}

	/**
	 * @param packetStatus
	 * @return
	 * @throws Exception
	 */
	public List<MvrNdrPopupPacketGridDetail> getPacketHistoryMvrList(EmployeePacketMvrNdrPopup packetStatus) {
		return licensingService.getPacketHistoryMvrList(packetStatus);
	}

	public byte[] downloadFormUsingGuid(String guid) {
		
		return licensingService.getFormFromFileNetDownloadService(guid, mvrSiteMinderToken, xmfMVRFilenetClientInvoker,DOCUMENT_CLASS_NAME);
	}


	/**
	 * Classname / Method Name : LicensingService/ getEmployeeFaxDetail
	 * 
	 * @param :InitiateReplaceLicenseBean(obj)
	 * @return :EmployeeDetail
	 * @exception :
	 * @description : This method use for getEmployeeFaxDetail
	 */
	public Integer updateMarkAsSentFaxDetails(String faxNum, Integer lcnsOprnID, String faxContentText) {
		Integer flag = licensingService.updateFaxDetails(faxNum, lcnsOprnID,  eqmsUserSession.getUser().getEmplId(), faxContentText);
		licensingService.reFaxNdrDetails(lcnsOprnID,  eqmsUserSession.getUser().getEmplId());
		return flag; 
	}
	
	@Override
	public String getFeedbackMsgForEmployeePacket(FeedbackMsgRequest feedbackMsgRequest) {
		
		 List<String> lstNotAuthEmpl = feedbackMsgRequest.getLstNotAuthEmpl();
         List<String> emplAuthlst = feedbackMsgRequest.getEmplAuthlst();
         List<String> emplNTValidlst = feedbackMsgRequest.getEmplNTValidlst();
         String validate = feedbackMsgRequest.getValidate();
		String feedbackMsg = "";
		//Modified for SS_QC#6678 -- Start
	      if (null != lstNotAuthEmpl && !lstNotAuthEmpl.isEmpty()) {
	        feedbackMsg += LicensingConstant.NO_MVR_AUTH_FOUND;
	        feedbackMsg = getFeedbackMessage(feedbackMsg, lstNotAuthEmpl);
	      }
	      
	      if (null != emplNTValidlst && !emplNTValidlst.isEmpty()) { //Modified for SS_QC#6302-Part A
	        feedbackMsg += (!validate.equalsIgnoreCase("")? "\n"+validate : "\n") +  LicensingConstant.VALID_FAIL_SEND_REQUEST;
	        feedbackMsg = getFeedbackMessage(feedbackMsg, emplNTValidlst);
	      }

	      if (null != emplAuthlst && !emplAuthlst.isEmpty()) {
	        LicensingSchedulerUtil.clearNotValidEmplIdList();
	        doAuthAndCreateMVRReq(emplAuthlst, feedbackMsgRequest.isFromErrWrkItm(),feedbackMsgRequest.isFromSendRequest()); //Modified for SS_QC#6302 ,Modified for for SS_QC#6732,Modified for SS_QC#6866 change parameter to true
	        if(!LicensingSchedulerUtil.getNotValidEmplIdList().isEmpty() && LicensingSchedulerUtil.getNotValidEmplIdList().size() > 0){
	          List<String> emplIdList = LicensingSchedulerUtil.getNotValidEmplIdList();
	          feedbackMsg += "\n" + LicensingConstant.MVR_AUTH_NT_VALID; 
	          feedbackMsg = getFeedbackMessage(feedbackMsg, emplIdList); 
	          LicensingSchedulerUtil.clearNotValidEmplIdList();
	        }else{
	          feedbackMsg += "\n" + LicensingConstant.MVR_REQUEST_SEND;
	          feedbackMsg = getFeedbackMessage(feedbackMsg, emplAuthlst);
	        }                
	      }
	      //Modified for SS_QC#6678 -- End
		return feedbackMsg;
	}
	
	private String getFeedbackMessage(String feedbackMsg, List<String> emplIdList) {
	    final List<EqmEmplDtls> emplDtlsList = licensingService.getEmplDtlsLsit(emplIdList);
	      if (null != emplDtlsList && !emplDtlsList.isEmpty()) {
	        for(EqmEmplDtls emplDtls : emplDtlsList){
	        String emplName = Util.getEmployeeName(emplDtls.getEmplFirName(), emplDtls.getEmplMidName(),
	            emplDtls.getEmplLastName()) + "(" + emplDtls.getEmplId() + ")";
	        feedbackMsg += emplName + ",";
	      }
	    }
	    feedbackMsg = feedbackMsg.substring(0, feedbackMsg.length()-1); //to remove extra comma.
	    return feedbackMsg;
	  } 
	
}
