/**
 * 
 * Classname    : PsftQualificationMessageConvertor
 * Description  : 
 * author   : Pranob 
 * Date of creation :
 *
 * Change History
 * ------------------------------------------------------------  
 *   Date         Changed By    Description
 * ------------------------------------------------------------  
 * 10/28/2013     xsat013       Req#503
 * 22-Jun-2015    XSAT568       Modified for REQ#687.
 * 08-Jun-2017    XSAT976       Modified for SS_QC#8447
 * 12-Jul-2017    xsat976       Modified for SS_QC#8123
 * 09-27-2017     XSAT976       Modified for SS_QC#9670
 * 12-06-2017     xsat671    	Modified for SS_QC#10199: Merged SS_QC#9670
 * ------------------------------------------------------------  
 *
 * Copyright notice : "Copyright UPRR 2008"
 */
package com.uprr.lic.licensing.jms.qualification;

import java.io.StringReader;
import java.util.Arrays;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.apache.commons.lang.StringEscapeUtils;
import org.apache.xmlbeans.XmlException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.support.converter.MessageConversionException;
import org.springframework.jms.support.converter.MessageConverter;

import com.uprr.lic.dataaccess.Licensing.model.PeopleSoftQualificationBean;
import com.uprr.lic.dataaccess.components.licensing.service.IPsftService;
import com.uprr.lic.externalservice.xmf.service.EmailNotificationService;
import com.uprr.lic.util.EQMSConstant;
import com.uprr.lic.util.EqmsUtil;
import com.uprr.lic.util.ScoreConstants;
import com.uprr.netcontrol.shared.xml_bindings.jaxb2.person.learning_completion_updated_1_0.LearningCompletionUpdated;
import com.uprr.netcontrol.shared.xml_bindings.jaxb2.person.learning_completion_updated_1_0.LmsLearningCompletionUpdated;

public class PsftQualificationMessageConvertor implements MessageConverter {

	private static Logger logger = LoggerFactory.getLogger(PsftQualificationMessageConvertor.class);


	private static final String className = PsftQualificationMessageConvertor.class
			.getName();

	@Autowired
	private IPsftService psftDelegate; //Req#503

	@Autowired
	private EmailNotificationService emailNotificationService;

	//Added for SS_QC#8123 - Start
	public static final String PASS = "Passed";

	public static final String PASS_RETEST = "Passed Retest";

	public static final String FLAG_YES = "Y";

	public static final String FLAG_NO = "N";

	private final String QUAL_COURSE_TYPE = "COURSE";
	
	// Modified for SS_QC#10199: Merged SS_QC#9670: Start
	
	private final Double GRADE_VALUE_PASS = 90.0; //Modified for SS_QC#9670
	
	private final Double GRADE_VALUE_FAIL = 40.0; //Modified for SS_QC#9670
	
	private final String RESULT_FAIL_FLAG = "FAIL"; //Modified for SS_QC#9670
	
	// Modified for SS_QC#10199: Merged SS_QC#9670 : End

	//Added for SS_QC#8123 - End

	//Modified for SS_QC#8447 -- Start
	private static final String mailSubject = "Rules service error - The XML not parse Successfully.";


	/**
	 * 
	 * This method is used to Parse the Qualification Xml obtained as input.
	 *
	 * @param message
	 * @return peopleSoftQualificationObject
	 * @author xsat568
	 * @since Jun 26, 2015
	 * Modified for SS_QC#8447
	 * Modified for SS_QC#8123
	 */
	public Object fromMessage(Message message) {

		PeopleSoftQualificationBean peopleSoftQualificationObject = null;
		//Modified for SS_QC#8447 -- Start
		final String[] recipientEmailAddressess = EqmsUtil.getEqmsSupportEmailIds().split(",");
		TextMessage textMessage = (TextMessage) message;
		String xmlMessage = "";
		try {
			//Modified for SS_QC#8123 - Start
			StringBuffer subStringMessage = new StringBuffer();
			if (null != textMessage.getText()) {
				subStringMessage.append(textMessage.getText().split("<wsnb:Message>")[1].split("</wsnb:Message>")[0]);
				xmlMessage = subStringMessage.toString();
			}
			Integer primaryKey = psftDelegate.insertMessageInPsftNtfnDtl(textMessage.getText(),EQMSConstant.QUALIFICATION_QUEUE, null); // req#503, Modified For REQ#687(Added NULL param).
			logger.debug(" Inside fromMessage method :: Start :: Message  Obtained  is  : "
					+ getRepsonseMessage(xmlMessage) + ScoreConstants.DOUBLE_COLON + className);
			//Modified for SS_QC#8123 - End
			logger
			.debug(" Inside fromMessage method :: Start :: Message  Obtained  is  : "
					+ getRepsonseMessage(textMessage.getText())
					+ ScoreConstants.DOUBLE_COLON + className);
			peopleSoftQualificationObject = parseMessage(xmlMessage,primaryKey);//Modified for SS_QC#8123

		} catch (XmlException xmlException) {
			String mailContent = "The XML not parse Successfully. <br><hr><br>" + StringEscapeUtils.escapeXml(xmlMessage);

			emailNotificationService.sendEmailNotification(Arrays.asList(recipientEmailAddressess), null, null,  mailSubject, mailContent, EmailNotificationService.EQMS_EMAIL_DESCRIPTION);

			logger
			.error(" Inside fromMessage method :: XmlException :: The XML is ::  : "
					+ xmlException.getMessage()
					+ " :: was not parse Successfull :: " + className);
			logger
			.error(" Inside fromMessage method :: XmlException :: The XML is ::  : "
					+ xmlException.getMessage()
					+ " :: was not parse Successfull :: " + className);
		} catch (Exception exception) {

			String mailContent = "The XML not parse Successfully. <br><hr><br>" + StringEscapeUtils.escapeXml(xmlMessage);

			emailNotificationService.sendEmailNotification(Arrays.asList(recipientEmailAddressess), null, null, mailSubject, mailContent, EmailNotificationService.EQMS_EMAIL_DESCRIPTION);

			logger
			.error(" Inside fromMessage method :: Exception : The XML is :: "
					+ exception.getMessage()
					+ " :: was not parse Successfully :: " + className);
			logger
			.error(" Inside fromMessage method :: Exception : The XML is :: "
					+ exception.getMessage()
					+ " :: was not parse Successfully :: " + className);
		}
		//Modified for SS_QC#8447 -- End
		logger.debug(" Inside fromMessage method :: Ends :: " + className);
		return peopleSoftQualificationObject;
	}

	public Message toMessage(Object arg0, Session arg1) throws JMSException,
	MessageConversionException {
		// TODO Auto-generated method stub
		return null;
	}

	private String getRepsonseMessage(String response) throws XmlException {
		// Factory.parse(response);
		return response;
	}

	/**
	 * This method is used to set the parsed xml value to
	 * peopleSoftQualificationBean bean.
	 * 
	 * @param response
	 * @return
	 * @throws XmlException
	 * @throws Exception
	 * Modified for SS_QC#8123
	 * Modified for SS_QC#9670
	 * Modified for SS_QC#10199: Merged SS_QC#9670
	 */
	private PeopleSoftQualificationBean parseMessage(String response, final Integer psftNtfnDtlId) //Req#503
			throws XmlException {
	  //Modified for SS_QC#8123  - Start
		PeopleSoftQualificationBean peopleSoftQualificationBean = null;
		
		logger.debug(" Inside parseMessage method :: Start :: Message  Obtained  is  : "
        + response + ScoreConstants.DOUBLE_COLON + className);
		logger.debug(" Inside parseMessage Starts  :: " + className);

		LmsLearningCompletionUpdated lmsLearningCompletionUpdated = null;
		JAXBContext jaxbContext = null;
		try {
			jaxbContext = JAXBContext.newInstance(LmsLearningCompletionUpdated.class);

			Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
			StringReader reader = new StringReader(response);
			lmsLearningCompletionUpdated = (LmsLearningCompletionUpdated)jaxbUnmarshaller.unmarshal(reader);

		} catch (JAXBException e1) {
			logger.error("Unable to create jaxbContext ", e1);
		} catch( Exception e ) {
			logger.error("Unable to create jaxbContext ", e);
		}

		if (lmsLearningCompletionUpdated != null) {

		  LearningCompletionUpdated learningCompletionUpdate = lmsLearningCompletionUpdated.getLearningCompletionUpdated();

			if (learningCompletionUpdate == null) {
				return null;
			} else {
				peopleSoftQualificationBean = new PeopleSoftQualificationBean();
				peopleSoftQualificationBean.setEventAction(ScoreConstants.INSERT); // set default insert action because of we use this action everywhere in existing code.

				if (learningCompletionUpdate.getStudentId() != null && !learningCompletionUpdate.getStudentId().equals(ScoreConstants.BLANK_VALUE)) {
					peopleSoftQualificationBean.setEmployeeId(learningCompletionUpdate.getStudentId());
				}
				if (learningCompletionUpdate.getComponentId() != null && !learningCompletionUpdate.getComponentId().equals(ScoreConstants.BLANK_VALUE)) {
					peopleSoftQualificationBean.setExamCode(learningCompletionUpdate.getComponentId());
				}
				if (learningCompletionUpdate.getCompletionStatusId() != null && !learningCompletionUpdate.getCompletionStatusId().equals(ScoreConstants.BLANK_VALUE)) {
				  if(PASS.equalsIgnoreCase(learningCompletionUpdate.getCompletionStatusId()) || PASS_RETEST.equalsIgnoreCase(learningCompletionUpdate.getCompletionStatusId())){
				    peopleSoftQualificationBean.setExamResult(FLAG_YES);
				  }else if (QUAL_COURSE_TYPE.equalsIgnoreCase(learningCompletionUpdate.getComponentTypeId())){
                                   peopleSoftQualificationBean.setExamResult(FLAG_YES);// If request data type is course then set by default pass.
                                  }else{
				    peopleSoftQualificationBean.setExamResult(FLAG_NO);
				  }
				}
				// Modified for SS_QC#10199: Merged SS_QC#9670: Start
				//Modified for SS_QC#9670 - Start
				if (learningCompletionUpdate.getGradeValue() != null && !learningCompletionUpdate.getGradeValue().equals(ScoreConstants.BLANK_VALUE)) {
				  if (QUAL_COURSE_TYPE.equalsIgnoreCase(learningCompletionUpdate.getComponentTypeId())){
				    if (learningCompletionUpdate.getGradeValue().toUpperCase().equalsIgnoreCase(RESULT_FAIL_FLAG)) {
				      peopleSoftQualificationBean.setExamScore(GRADE_VALUE_FAIL);// If request data type is course and grade value as fail then set default 40.
				    }else{
				      peopleSoftQualificationBean.setExamScore(GRADE_VALUE_PASS);// If request data type is course and grade value as pass or complete then set default 90.
				    }
				  }else{
				      peopleSoftQualificationBean.setExamScore(Double.parseDouble(learningCompletionUpdate.getGradeValue()));
				  }
				}else{
				      peopleSoftQualificationBean.setExamScore(GRADE_VALUE_PASS);// If request data type is course and grade value null then set default 90.
				}
				//Modified for SS_QC#9670 - End
				// Modified for SS_QC#10199: Merged SS_QC#9670: End
				if (learningCompletionUpdate.getCompletionDate() != null) {
					peopleSoftQualificationBean.setEventDateTime(learningCompletionUpdate.getCompletionDate().toGregorianCalendar());
				}
				peopleSoftQualificationBean.setPsftNtfnDtlId(psftNtfnDtlId); //Req#503
			}
		} else {
			throw new XmlException(response);
		}

		logger.debug(" Inside parseMessage method Ends :: " + className);
		//Modified for SS_QC#8123 - End
		return peopleSoftQualificationBean;
	}
}