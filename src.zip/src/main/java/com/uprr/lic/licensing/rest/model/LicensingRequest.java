package com.uprr.lic.licensing.rest.model;

import java.util.Calendar;
import java.util.List;
import java.util.Set;

import com.uprr.lic.dataaccess.Licensing.model.InitiateReplaceLicenseBean;
import com.uprr.lic.dataaccess.Licensing.model.LcnsDtlsObj;
import com.uprr.lic.dataaccess.Licensing.model.WaiverGrid;

public class LicensingRequest {
	private Integer workItemID;
	private Integer licOprnID;
	private String oprnCode;
	private String comment;
	private Integer serviceNumber; 
	private String emplId;
	private String initiatorId;
	private boolean studentFlag;
	private List<String> employeeIdList;
	private List<String> licenseClassList;
	private List<EmpPacketStatusResponse> empPacketStatusDetails;
	private String mvrNdrResultPass;
	private String documentTypeCode;
    private Calendar packetDate;
    private Set<Integer> resnList;
	private String mvrOrNdrValue;
	private List<WaiverGrid> waiverItemList;
	private List<InitiateReplaceLicenseBean> initiateReplaceLicenseList;
	private List<TwicDetailResponse> twicDetailList;
	private List<LcnsDtlsObj> licenseDetailList;
	private List<String> workItemFlagList;
	
	private String licenseClass;
	
	public Integer getWorkItemID() {
		return workItemID;
	}
	
	public void setWorkItemID(Integer workItemID) {
		this.workItemID = workItemID;
	}
	
	public Integer getLicOprnID() {
		return licOprnID;
	}
	
	public void setLicOprnID(Integer licOprnID) {
		this.licOprnID = licOprnID;
	}
	
	public String getOprnCode() {
		return oprnCode;
	}
	
	public void setOprnCode(String oprnCode) {
		this.oprnCode = oprnCode;
	}
	
	public String getComment() {
		return comment;
	}
	
	public void setComment(String comment) {
		this.comment = comment;
	}
	
	public Integer getServiceNumber() {
		return serviceNumber;
	}
	
	public void setServiceNumber(Integer serviceNumber) {
		this.serviceNumber = serviceNumber;
	}
	
	public String getEmplId() {
		return emplId;
	}
	
	public void setEmplId(String emplId) {
		this.emplId = emplId;
	}
	
	public String getInitiatorId() {
		return initiatorId;
	}
	
	public void setInitiatorId(String initiatorId) {
		this.initiatorId = initiatorId;
	}
	
	public boolean isStudentFlag() {
		return studentFlag;
	}
	
	public void setStudentFlag(boolean studentFlag) {
		this.studentFlag = studentFlag;
	}
	
	public List<String> getEmployeeIdList() {
		return employeeIdList;
	}
	
	public void setEmployeeIdList(List<String> employeeIdList) {
		this.employeeIdList = employeeIdList;
	}
	
	public List<EmpPacketStatusResponse> getEmpPacketStatusDetails() {
		return empPacketStatusDetails;
	}

	public void setEmpPacketStatusDetails(List<EmpPacketStatusResponse> empPacketStatusDetails) {
		this.empPacketStatusDetails = empPacketStatusDetails;
	}

	public String getMvrNdrResultPass() {
		return mvrNdrResultPass;
	}

	public void setMvrNdrResultPass(String mvrNdrResultPass) {
		this.mvrNdrResultPass = mvrNdrResultPass;
	}

	public String getDocumentTypeCode() {
		return documentTypeCode;
	}

	public void setDocumentTypeCode(String documentTypeCode) {
		this.documentTypeCode = documentTypeCode;
	}

	public Calendar getPacketDate() {
		return packetDate;
	}

	public void setPacketDate(Calendar packetDate) {
		this.packetDate = packetDate;
	}

	public String getMvrOrNdrValue() {
		return mvrOrNdrValue;
	}
	
	public void setMvrOrNdrValue(String mvrOrNdrValue) {
		this.mvrOrNdrValue = mvrOrNdrValue;
	}
	
	public Set<Integer> getResnList() {
		return resnList;
	}
	
	public void setResnList(Set<Integer> resnList) {
		this.resnList = resnList;
	}
	
	public List<WaiverGrid> getWaiverItemList() {
		return waiverItemList;
	}
	
	public void setWaiverItemList(List<WaiverGrid> waiverItemList) {
		this.waiverItemList = waiverItemList;
	}
	
	public List<InitiateReplaceLicenseBean> getInitiateReplaceLicenseList() {
		return initiateReplaceLicenseList;
	}
	
	public void setInitiateReplaceLicenseList(List<InitiateReplaceLicenseBean> initiateReplaceLicenseList) {
		this.initiateReplaceLicenseList = initiateReplaceLicenseList;
	}
	
	public List<TwicDetailResponse> getTwicDetailList() {
		return twicDetailList;
	}
	
	public void setTwicDetailList(List<TwicDetailResponse> twicDetailList) {
		this.twicDetailList = twicDetailList;
	}
	
	public List<String> getLicenseClassList() {
		return licenseClassList;
	}
	
	public void setLicenseClassList(List<String> licenseClassList) {
		this.licenseClassList = licenseClassList;
	}
	
	public List<LcnsDtlsObj> getLicenseDetailList() {
		return licenseDetailList;
	}
	
	public void setLicenseDetailList(List<LcnsDtlsObj> licenseDetailList) {
		this.licenseDetailList = licenseDetailList;
	}
	
	public List<String> getWorkItemFlagList() {
		return workItemFlagList;
	}
	
	public void setWorkItemFlagList(List<String> workItemFlagList) {
		this.workItemFlagList = workItemFlagList;
	}
	
	public String getLicenseClass() {
		return licenseClass;
	}
	
	public void setLicenseClass(String licenseClass) {
		this.licenseClass = licenseClass;
	}
}
