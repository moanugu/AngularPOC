package com.uprr.lic.licensing.rest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.uprr.lic.dataaccess.common.model.EqmEmplDtls;
import com.uprr.lic.licensing.rest.model.LicensingRequest;
import com.uprr.lic.licensing.rest.model.TwicDetailResponse;
import com.uprr.lic.licensing.rest.service.ITwicRestService;

/**
 * This Controller is using for TwicController
 * @author xsat956
 *
 */
@Controller
public class TwicController {
	
	@Autowired
	private ITwicRestService twicRestService;
		
	@RequestMapping(value = "/licensing/getEmployeeNameList", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public List<EqmEmplDtls> getEmplName(@RequestParam(value="employeeId", required=true) String employeeID) {
		return twicRestService.getEmplName(employeeID);
	}

	
	@RequestMapping(value = "/licensing/submitTwicDetails", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public void submitTwicDetails(@RequestBody LicensingRequest licensingRequest, @RequestParam(value="serviceUntNbr", required=true) Integer serviceUntNbr) {
		twicRestService.submitTwicDetails(licensingRequest.getTwicDetailList(), serviceUntNbr);
	}

	@RequestMapping(value = "/licensing/getTwicDetails", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public TwicDetailResponse getTwicDtls(@RequestParam(value="employeeId", required=true) String employeeID) {
		return twicRestService.getTwicDtls(employeeID)
				;
	}
	
}
