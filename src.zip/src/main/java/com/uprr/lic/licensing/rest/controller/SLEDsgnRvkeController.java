package com.uprr.lic.licensing.rest.controller;



import java.text.ParseException;
import java.util.Calendar;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.uprr.lic.dataaccess.Licensing.model.Designate;
import com.uprr.lic.dataaccess.Licensing.model.DesignationRequirement;
import com.uprr.lic.dataaccess.Licensing.model.License;
import com.uprr.lic.dataaccess.Licensing.model.ManagerList;
import com.uprr.lic.dataaccess.Licensing.model.SLERevokeDesignation;
import com.uprr.lic.dataaccess.Licensing.model.SleDesignateInitReq;
import com.uprr.lic.dataaccess.Licensing.model.SleDesignationRequest;
import com.uprr.lic.dataaccess.Licensing.model.SleDesignationResult;
import com.uprr.lic.dataaccess.common.model.EqmEmplSleDsgn;
import com.uprr.lic.dataaccess.common.model.EqmLcnsOprn;
import com.uprr.lic.dataaccess.workflow.impl.EqmsWorkItemBean;
import com.uprr.lic.decert.rest.model.DesignateResponse;
import com.uprr.lic.licensing.rest.service.ISLEDsgnRvkeService;
import com.uprr.lic.util.DDChoice;

@Controller
public class SLEDsgnRvkeController{

	@Autowired
	private ISLEDsgnRvkeService sleDsgnRvkeService;

	@RequestMapping(value = "/licensing/getDesignationRequirement", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public List<DesignationRequirement> getDesignationRequirement(@RequestBody Designate designate){
		return sleDsgnRvkeService.getDesignationRequirement(designate);
	}

	@RequestMapping(value = "/licensing/getDesignateEmployeeLicenseDtls", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public List<License> getDesignateEmployeeLicenseDtls(@RequestBody Designate designate){
		return sleDsgnRvkeService.getDesignateEmployeeLicenseDtls(designate);
	}
	@RequestMapping(value = "/licensing/getDesignationInitiatorDetails", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public 	List<Designate> getDesignationInitiatorDetails(@RequestBody Designate designate){
		return sleDsgnRvkeService.getDesignationInitiatorDetails(designate);
	}

	@RequestMapping(value = "/licensing/getAllServiceUnitList", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public 	List<DDChoice> getAllServiceUnitList(){
		return sleDsgnRvkeService.getAllServiceUnitList();
	}

	@RequestMapping(value = "/licensing/getManagers", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public List<DDChoice> getManagers(@RequestParam(value = "svcNbr", required = true) int svcNbr,@RequestParam(value = "lcnsClass", required = true) String lcnsClass ){
		return sleDsgnRvkeService.getManagers(svcNbr,lcnsClass);
	}

	@RequestMapping(value = "/licensing/getDSCount", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public String getDSCount(@RequestParam(value = "managerId", required = true) String managerId ){
		return sleDsgnRvkeService.getDSCount(managerId);
	}

	@RequestMapping(value = "/licensing/designateEmployee", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public 	Object designateEmployee(@RequestBody Designate designate){
		return sleDsgnRvkeService.designateEmployee(designate);
	}

	@RequestMapping(value = "/licensing/getWorkItemForRevoke", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public EqmsWorkItemBean getWorkItemForRevoke(@RequestParam(value = "workItemId", required = true) Integer workItemId ){
		return sleDsgnRvkeService.getWorkItemForRevoke(workItemId);
	}

	@RequestMapping(value = "/licensing/getEmployeeDetailsForRevokeInitiation", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public SLERevokeDesignation getEmployeeDetailsForRevokeInitiation(@RequestParam(value = "employeeId", required = true) String employeeId ){
		return sleDsgnRvkeService.getEmployeeDetailsForRevokeInitiation(employeeId);
	}

	@RequestMapping(value = "/licensing/getDesignationDetailsForRevokeInitiation", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public  List<SleDesignationResult> getDesignationDetailsForRevokeInitiation(@RequestParam(value = "employeeId", required = true) String employeeId,
			@RequestParam(value = "status", required = true) String status ){
		return sleDsgnRvkeService.getDesignationDetailsForRevokeInitiation(employeeId,status);
	}

	@RequestMapping(value = "/licensing/getInitiatorDetailsForRevoke", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public  SLERevokeDesignation getInitiatorDetailsForRevoke(@RequestBody SLERevokeDesignation revokeDesignationPageBean,  
			@RequestParam(value = "workItemId", required = true) Integer workItemId){
		return sleDsgnRvkeService.getInitiatorDetailsForRevoke(revokeDesignationPageBean,workItemId);
	}

	@RequestMapping(value = "/licensing/getComment", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public  String getComment(@RequestParam(value = "lcnsOprnId", required = true) int lcnsOprnId){
		return sleDsgnRvkeService.getComment(lcnsOprnId);
	}

	@RequestMapping(value = "/licensing/getDesignationDetailsListForRevokePage", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public  List<SleDesignationResult> getDesignationDetailsListForRevokePage(@RequestParam(value = "employeeId", required = true) String employeeId,
			@RequestParam(value = "licClass", required = true) String licClass){
		return sleDsgnRvkeService.getDesignationDetailsListForRevokePage(employeeId,licClass);
	}

	@RequestMapping(value = "/licensing/insertForRevoke", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public  DesignateResponse insertForRevoke(@RequestBody EqmsWorkItemBean eqmworkItemBean,
			@RequestParam(value = "initiatorId", required = true) String initiatorId){
		return sleDsgnRvkeService.insertForRevoke(eqmworkItemBean,initiatorId);
	}

	@RequestMapping(value = "/licensing/insertSleRevokeInitiationRequest", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public  Boolean insertSleRevokeInitiationRequest(@RequestBody List<SleDesignationResult> rvkeRequestList,
			@RequestParam(value = "employeeId", required = true) String employeeId,@RequestParam(value = "comments", required = true) String comments){
		return sleDsgnRvkeService.insertSleRevokeInitiationRequest(rvkeRequestList,employeeId,comments);
	}

	@RequestMapping(value = "/licensing/isRevokeInitiatedForEmployee", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public  String isRevokeInitiatedForEmployee(@RequestParam(value = "employeeId", required = true) String employeeId){
		return sleDsgnRvkeService.isRevokeInitiatedForEmployee(employeeId);
	}


	@RequestMapping(value = "/licensing/isEmployeeMeetMinimumDesignationRequirement", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public  List<String> isEmployeeMeetMinimumDesignationRequirement(@RequestParam(value = "employeeId", required = true) String employeeId,
			@RequestParam(value = "isDsleChecked", required = true) boolean isDsleChecked,@RequestParam(value = "isDsrcoChecked", required = true) boolean isDsrcoChecked){
		return sleDsgnRvkeService.isEmployeeMeetMinimumDesignationRequirement(employeeId,isDsleChecked,isDsrcoChecked);
	}

	@RequestMapping(value = "/licensing/insertSLEDesignateInitiateRequest", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public  Boolean insertSLEDesignateInitiateRequest(@RequestParam(value = "dsle", required = true) String dsle,
			@RequestParam(value = "dsrco", required = true) String dsrco,@RequestParam(value = "employeeId", required = true) String employeeId,
			@RequestBody List<SleDesignationRequest> designationDtlList){
		try {
			return sleDsgnRvkeService.insertSLEDesignateInitiateRequest(dsle, dsrco, employeeId, designationDtlList);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}

	@RequestMapping(value = "/licensing/getDesignateRequestInitiationDetails", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public  List<EqmLcnsOprn> getDesignateRequestInitiationDetails(@RequestParam(value="employeeId",required=true) String employeeId){
		return sleDsgnRvkeService.getDesignateRequestInitiationDetails( employeeId);
	}


	@RequestMapping(value = "/licensing/getAlreadyDesignatedEmployeeDetails", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public  List<EqmEmplSleDsgn> getAlreadyDesignatedEmployeeDetails(@RequestParam(value="employeeId",required=true) String employeeId){
		return sleDsgnRvkeService.getAlreadyDesignatedEmployeeDetails(employeeId);
	}

	@RequestMapping(value = "/licensing/getDesignationRequirementsForInitiation", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public  List<SleDesignationRequest> getDesignationRequirementsForInitiation(@RequestBody SleDesignateInitReq designationDtlBean,
			@RequestParam(value="rxmlTrainingDate",required=false) Long date){
		Calendar rxmlTrainingDate = null;
		if(date != null && date > 0) {
			rxmlTrainingDate = Calendar.getInstance();
			rxmlTrainingDate.setTimeInMillis(date);
		}
		return sleDsgnRvkeService.getDesignationRequirementsForInitiation(designationDtlBean,rxmlTrainingDate);
	}

	@RequestMapping(value = "/licensing/getSLEDesignationInitiateEmpDetails", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public  SleDesignateInitReq getSLEDesignationInitiateEmpDetails(@RequestParam(value="employeeId",required=true) String employeeId){
		return sleDsgnRvkeService.getSLEDesignationInitiateEmpDetails(employeeId);
	}

	@RequestMapping(value = "/licensing/getDesignatedEmployeeDetailsListForRevokeInitiation", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public  List<ManagerList> getDesignatedEmployeeDetailsListForRevokeInitiation(@RequestParam(value="employeeId",required=true) String employeeId){
		return sleDsgnRvkeService.getDesignatedEmployeeDetailsListForRevokeInitiation(employeeId);
	}

	@RequestMapping(value = "/licensing/isEmployeeSelectedFromAutoCompleteListForRevokeInitiation", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public  Boolean isEmployeeSelectedFromAutoCompleteListForRevokeInitiation(@RequestParam(value="employeeId",required=true) String employeeId){
		return sleDsgnRvkeService.isEmployeeSelectedFromAutoCompleteListForRevokeInitiation(employeeId);
	}

	@RequestMapping(value = "/licensing/isDsleOrDsrco", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public  Boolean isDsleOrDsrco(@RequestParam(value="employeeId",required=true) String employeeId){
		return sleDsgnRvkeService.isDsleOrDsrco(employeeId);
	}

	@RequestMapping(value = "/licensing/isRevokeDesignationInitiatedForEmployee", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public  String isRevokeDesignationInitiatedForEmployee(@RequestParam(value="employeeId",required=true) String employeeId){
		return sleDsgnRvkeService.isRevokeDesignationInitiatedForEmployee(employeeId);
	}

	@RequestMapping(value = "/licensing/viewDisciplineHistoryLink", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public  String viewDisciplineHistoryLink(@RequestParam(value="employeeId",required=true) String employeeId){
		return sleDsgnRvkeService.viewDisciplineHistoryLink(employeeId);
	}

	@RequestMapping(value = "/licensing/viewCMTSLink", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public  String viewCMTSLink(){
		return sleDsgnRvkeService.viewCMTSLink();
	}

	@RequestMapping(value = "/licensing/viewEmpLicenseHist", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public  String viewEmpLicenseHist(@RequestParam(value="employeeId",required=true) String employeeId){
		return sleDsgnRvkeService.viewEmpLicenseHist(employeeId);
	}

	@RequestMapping(value = "/licensing/getRXMLTrainingDateFromService", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public  Calendar getRXMLTrainingDateFromService(@RequestParam(value="employeeId",required=true) String employeeId){
		return sleDsgnRvkeService.getRXMLTrainingDateFromService(employeeId);
	}

}