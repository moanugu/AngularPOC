package com.uprr.lic.licensing.rest.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.uprr.lic.dataaccess.Licensing.model.TempLicenseTemplate;
import com.uprr.lic.licensing.rest.service.IPrintTempLicenseService;

/**
 * 
 * @author xsat004
 *
 */
@Controller
public class PrintTempLicenseController {

	@Autowired
	private IPrintTempLicenseService printTempLicenseService;
	
	@RequestMapping(method = RequestMethod.POST, value = "/licensing/getTemporaryLicenseTemplateForPortal", produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public TempLicenseTemplate getTemporaryLicenseTemplateForPortal(@RequestParam final String employeeID) {
		 return printTempLicenseService.getTemporaryLicenseTemplateForPortal(employeeID);
	 
	 }
	
	@RequestMapping(method = RequestMethod.POST, value = "/licensing/getIlataPrint", produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public Boolean getIlataPrint(final String iLataNumber, final String message) {
		return printTempLicenseService.getIlataPrint(iLataNumber,message);
	}
}
