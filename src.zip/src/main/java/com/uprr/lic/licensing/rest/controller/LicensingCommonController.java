package com.uprr.lic.licensing.rest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.uprr.lic.dataaccess.common.model.EqmEmplDtls;
import com.uprr.lic.dataaccess.common.model.EqmSysParm;
import com.uprr.lic.licensing.rest.model.LicensingRequest;
import com.uprr.lic.licensing.rest.service.ILicensingCommonRestService;

@Controller
public class LicensingCommonController {

	@Autowired
	private ILicensingCommonRestService licensingCommonRestService;
	
	
	@RequestMapping(value = "/licensing/getSysParmValue", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public EqmSysParm getSysParmValue(@RequestParam(value = "sysParamName", required = true) String sysParamName) {
		return licensingCommonRestService.getSysParmValue(sysParamName);
	}
	
	

	@RequestMapping(value = "/licensing/getCFMUrlForMVRFromECL", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public String getCFMUrlForMVRFromECL(@RequestParam(value="employeeId") String employeeId){
	    return  licensingCommonRestService.getCFMUrlForMVRFromECL(employeeId);
	}
	
	
	@RequestMapping(value = "/licensing/getEmplDtlsLsit", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public List<EqmEmplDtls> getEmplDtlsLsit(@RequestBody LicensingRequest licensingRequest) {
	    return  licensingCommonRestService.getEmplDtlsLsit(licensingRequest.getEmployeeIdList());
	}
	
	
}
