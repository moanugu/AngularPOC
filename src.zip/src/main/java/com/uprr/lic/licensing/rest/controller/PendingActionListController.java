package com.uprr.lic.licensing.rest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.uprr.lic.auth.EQMSUserSession;
import com.uprr.lic.dataaccess.Licensing.model.PrintTemporaryLicenseGrid;
import com.uprr.lic.exception.EqmDaoException;
import com.uprr.lic.licensing.rest.model.LicensingRequest;
import com.uprr.lic.licensing.rest.model.PendingActionDetail;
import com.uprr.lic.licensing.rest.model.PendingActionRequest;
import com.uprr.lic.licensing.rest.model.PhotoIDRequestBean;
import com.uprr.lic.licensing.rest.service.IPendingActionService;

@Controller
public class PendingActionListController {

	@Autowired
	private IPendingActionService pendingActionService;

	@Autowired
	private EQMSUserSession eqmsUserSession;

	@RequestMapping(value = "/licensing/getPendingActionDataList", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public List<PendingActionDetail> getPendingActionDataList(@RequestBody PendingActionRequest pendingActionRequest){
		return pendingActionService.getPendingActionDataList(pendingActionRequest);
	}

	@RequestMapping(value = "/licensing/removeRecordForPhotoID", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public void removeRecordForPhotoID(@RequestBody PhotoIDRequestBean photoIDRequestBean){
		pendingActionService.removeRecordForPhotoID(photoIDRequestBean.getEmplId(),eqmsUserSession.getUser().getEmplId(),photoIDRequestBean.getPackResn(),photoIDRequestBean.getWorkItemFlagList(),photoIDRequestBean.getComments());
	}


	@RequestMapping(value = "/licensing/PrintLataForTempLicense", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public boolean printLataForTempLicense(@RequestBody List<PrintTemporaryLicenseGrid> pendingActionDetail, @RequestParam(value="printId") String printId){
		return pendingActionService.printLataForTempLicense(pendingActionDetail, printId);
	}

	@RequestMapping(value = "/licensing/removeWorkItemEntry", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public void removeWorkItemEntry(@RequestBody List<LicensingRequest> licensingRequestList) throws EqmDaoException{
		pendingActionService.removeWorkItemEntry(licensingRequestList);
	}

	//	removeRecordForPhotoID
}
