/**
 * Classname    : TwicMessageConvertor
 * Description  : 
 * author   : Satyam Computer Services LTD.
 * Date of creation :
 *
 * Change History
 * ------------------------------------------------------------  
 *   Date  Changed By    Description
 * ------------------------------------------------------------  
 * 02-Feb-2017   xsat737     Modified for SS_QC#7958:Generic exceptions replaced with EqmException for Sonar fix
 *
 * ------------------------------------------------------------  
 *
 * Copyright notice : "Copyright � UPRR 2008"
 */
package com.uprr.lic.licensing.jms.twic;

import java.io.StringReader;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jms.support.converter.MessageConversionException;
import org.springframework.jms.support.converter.MessageConverter;

import com.uprr.lic.dataaccess.twic.model.TwicResponseOfEmployee;
import com.uprr.lic.exception.EqmException;
import com.uprr.lic.shared.xml_bindings.jaxb2.employee.twic.EmployeeTwicResponse;

/**
 * @author xsat212
 */
public class TwicMessageConvertor implements MessageConverter {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	public Object fromMessage(final Message message) {
		TwicResponseOfEmployee responseOfEmployee = new TwicResponseOfEmployee();

		try {
			final TextMessage textMessage = (TextMessage) message;

			if (textMessage.getText() == null) {
				logger.error("fromMessage textMessage.getText() is null");
				throw new EqmException("textMessage.getText() is null from the queue");
			}


			// parse the xml message
			final EmployeeTwicResponse response = parseResponse(textMessage.getText());

			if (response.getError() != null) {
				logger.error("fromMessage Error message =" + response.getError().getMessage());
			}

			responseOfEmployee.setReplyMessage(textMessage.getText());

			// get the message number
			responseOfEmployee.setCmtsDocDtlsId(response.getMessageNumber().trim());


		} catch (Exception exception) {
			logger.error("fromMessage =" + exception.getMessage(), exception);
		}
		return responseOfEmployee;
	}

	private EmployeeTwicResponse parseResponse(String text) {
		JAXBContext jaxbContext = null;

		try {
			jaxbContext = JAXBContext.newInstance(EmployeeTwicResponse.class);

			Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
			StringReader reader = new StringReader(text);
			EmployeeTwicResponse EmployeeTwicResponse = (EmployeeTwicResponse) jaxbUnmarshaller.unmarshal(reader);
			return EmployeeTwicResponse;
		} catch (JAXBException e1) {
			logger.error("Unable to create jaxbContext ", e1);
		}
		return null;
	}

	public Message toMessage(final Object arg0, final Session arg1) throws JMSException, MessageConversionException {
		return null;
	}

}
