package com.uprr.lic.licensing.rest.model;

import com.uprr.lic.dataaccess.Licensing.model.License;
import com.uprr.lic.dataaccess.Licensing.model.Ndr;
import com.uprr.lic.dataaccess.Licensing.model.Or6a;
import com.uprr.lic.dataaccess.Licensing.model.SkillRide;
import com.uprr.lic.dataaccess.common.model.FTXEvent;
import com.uprr.lic.dataaccess.common.model.Medical;
import com.uprr.lic.dataaccess.common.model.Mvr;
import com.uprr.lic.dataaccess.common.model.Rules;
import com.uprr.lic.util.LicensingConstant;
import com.uprr.lic.util.Util;

public class PendingActionDetail {

	private String employeeID;

	private String employeeName;

	//Added for QC#8231--Start

	private String createdDate;

	private String serviceUnitName;

	private String assignedManager;

	private String lcnsExpnDate;

	private String photoStatus;

	private String photoExpnDate;

	private String photoTakenDate;

	//Added for QC#8231--End

	private String serviceUnit;

	private Integer serviceUnitNbr;

	private String date;

	private License license;

	private String reason;

	private String action;

	private String secondAction;

	private String thirdAction;

	private String fourthAction;//Added for SS_QC#9070 

	private String dateOfBirth;

	private Medical medical;

	private SkillRide skillRide;

	private Rules rules;

	private Mvr mvr;

	private Ndr ndr;

	// Added For Conductor License - Start
	private FTXEvent ftxEvnt;

	private Or6a or6aExam;

	private String conExamPinAval;
	// End

	private Integer workItemId;

	private Integer reasonID;

	private Integer lcnsOprnId;

	private String lcnsOprnCode;

	private Integer rqmtId;

	private String jobCode;

	private Integer lcnsDtlsId;

	private String submitFlag;

	private Integer rowVersionNoForLcnsOprn;

	private Integer rowVersionNoForWorkItem;

	private String lcnsMailDate;// For Req133

	private String knlgExamRslt; // REQ# 194.

	private String knlgExamDate; // REQ# 194.

	//added for Req#347
	private String ertCode;
	//added for Req 347
	private String agrmntFlag;

	private String mvrAuthRcvdDate; // Added for SS_QC#7321
	//Added for SS_QC#7287:start
	private String opccValue;
	private String oprcValue;
	private String opecValue;//Added for SS_QC#7287:end

	//Added for 6702:Start
	private String opccDate;
	private String oprcDate;
	private String opecDate;
	//Added for 6702:End

	//Added for SS_QC#8230 -- Start
	private String cmtsStatCode;

	private String jobEmpStatusDesc;

	//private String loggedInUserId;


	/**
	 * @return the cmtsStatCode
	 */
	public String getCmtsStatCode() {
		return cmtsStatCode;
	}

	/**
	 * @param cmtsStatCode the cmtsStatCode to set
	 */
	public void setCmtsStatCode(final String cmtsStatCode) {
		this.cmtsStatCode = cmtsStatCode;
	}

	/**
	 * @return the jobEmpStatusDesc
	 */
	public String getJobEmpStatusDesc() {
		return jobEmpStatusDesc;
	}

	/**
	 * @param jobEmpStatusDesc the jobEmpStatusDesc to set
	 */
	public void setJobEmpStatusDesc(final String jobEmpStatusDesc) {
		this.jobEmpStatusDesc = jobEmpStatusDesc;
	}

	//Added for SS_QC#8230 -- End

	// Added for SS_QC#8231 -- Start

	/**
	 * @return the createdDate
	 */
	public String getCreatedDate() {
		return createdDate;
	}

	/**
	 * @param createdDate the createdDate to set
	 */
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 * @return the serviceUnitName
	 */
	public String getServiceUnitName() {
		return serviceUnitName;
	}

	/**
	 * @param serviceUnitName the serviceUnitName to set
	 */
	public void setServiceUnitName(String serviceUnitName) {
		this.serviceUnitName = serviceUnitName;
	}

	/**
	 * @return the assignedManager
	 */
	public String getAssignedManager() {
		return assignedManager;
	}

	/**
	 * @param assignedManager the assignedManager to set
	 */
	public void setAssignedManager(String assignedManager) {
		this.assignedManager = assignedManager;
	}

	/**
	 * @return the lcnsExpnDate
	 */
	public String getLcnsExpnDate() {
		return lcnsExpnDate;
	}

	/**
	 * @param lcnsExpnDate the lcnsExpnDate to set
	 */
	public void setLcnsExpnDate(String lcnsExpnDate) {
		this.lcnsExpnDate = lcnsExpnDate;
	}

	/**
	 * @return the photoStatus
	 */
	public String getPhotoStatus() {
		return photoStatus;
	}

	/**
	 * @param photoStatus the photoStatus to set
	 */
	public void setPhotoStatus(String photoStatus) {
		this.photoStatus = photoStatus;
	}

	/**
	 * @return the photoExpnDate
	 */
	public String getPhotoExpnDate() {
		return photoExpnDate;
	}

	/**
	 * @param photoExpnDate the photoExpnDate to set
	 */
	public void setPhotoExpnDate(String photoExpnDate) {
		this.photoExpnDate = photoExpnDate;
	}

	/**
	 * @return the photoTakenDate
	 */
	public String getPhotoTakenDate() {
		return photoTakenDate;
	}

	/**
	 * @param photoTakenDate the photoTakenDate to set
	 */
	public void setPhotoTakenDate(String photoTakenDate) {
		this.photoTakenDate = photoTakenDate;
	}

	// Added for SS_QC#8231 -- End

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public Medical getMedical() {
		return medical;
	}

	public void setMedical(Medical medical) {
		this.medical = medical;
	}

	public SkillRide getSkillRide() {
		return skillRide;
	}

	public void setSkillRide(SkillRide skillRide) {
		this.skillRide = skillRide;
	}

	public Rules getRules() {
		return rules;
	}

	public void setRules(Rules rules) {
		this.rules = rules;
	}

	public Mvr getMvr() {
		return mvr;
	}

	public void setMvr(Mvr mvr) {
		this.mvr = mvr;
	}

	public Ndr getNdr() {
		return ndr;
	}

	public void setNdr(Ndr ndr) {
		this.ndr = ndr;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getEmployeeID() {
		if(employeeID == null || employeeID.equalsIgnoreCase(LicensingConstant.BLANK_STRING)){
			return null;			
		}else{
			return Util.removeExtraZeroEmployeeId(employeeID);
		}
	}

	public void setEmployeeID(String employeeID) {
		if(employeeID == null || employeeID.equalsIgnoreCase(LicensingConstant.BLANK_STRING)){
			this.employeeID=null;		
		}else{
			this.employeeID = Util.removeExtraZeroEmployeeId(employeeID);
		}
	}

	public String getServiceUnit() {
		return serviceUnit;
	}

	public void setServiceUnit(String serviceUnit) {
		this.serviceUnit = serviceUnit;
	}

	public License getLicense() {
		return license;
	}

	public void setLicense(License license) {
		this.license = license;
	}

	public Integer getWorkItemId() {
		return workItemId;
	}

	public void setWorkItemId(Integer workItemId) {
		this.workItemId = workItemId;
	}

	public String getSecondAction() {
		return secondAction;
	}

	public void setSecondAction(String secondAction) {
		this.secondAction = secondAction;
	}

	public Integer getReasonID() {
		return reasonID;
	}

	public void setReasonID(Integer reasonID) {
		this.reasonID = reasonID;
	}

	public Integer getLcnsOprnId() {
		return lcnsOprnId;
	}

	public void setLcnsOprnId(Integer oprnId) {
		lcnsOprnId = oprnId;
	}

	public String getLcnsOprnCode() {
		return lcnsOprnCode;
	}

	public void setLcnsOprnCode(String oprnCode) {
		lcnsOprnCode = oprnCode;
	}

	public Integer getRqmtId() {
		return rqmtId;
	}

	public void setRqmtId(Integer rqmtId) {
		this.rqmtId = rqmtId;
	}

	/**
	 * @return the m_serviceUnitNbr
	 */
	public Integer getServiceUnitNbr()
	{
		return serviceUnitNbr;
	}

	/**
	 * @param unitNbr the m_serviceUnitNbr to set
	 */
	public void setServiceUnitNbr(Integer unitNbr)
	{
		serviceUnitNbr = unitNbr;
	}

	/**
	 * @return the m_jobCode
	 */
	public String getJobCode() {
		return jobCode;
	}

	/**
	 * @param code the m_jobCode to set
	 */
	public void setJobCode(String code) {
		jobCode = code;
	}

	/**
	 * @return the m_lcnsDtlsId
	 */
	public Integer getLcnsDtlsId() {
		return lcnsDtlsId;
	}

	/**
	 * @param dtlsId the m_lcnsDtlsId to set
	 */
	public void setLcnsDtlsId(Integer dtlsId) {
		lcnsDtlsId = dtlsId;
	}

	public String getSubmitFlag() {
		return submitFlag;
	}

	public void setSubmitFlag(String flag) {
		submitFlag = flag;
	}

	public String getThirdAction() {
		return thirdAction;
	}

	public void setThirdAction(String action) {
		thirdAction = action;
	}

	public Integer getRowVersionNoForLcnsOprn() {
		return rowVersionNoForLcnsOprn;
	}

	public void setRowVersionNoForLcnsOprn(Integer rowVersionNoForLcnsOprn) {
		this.rowVersionNoForLcnsOprn = rowVersionNoForLcnsOprn;
	}

	public Integer getRowVersionNoForWorkItem() {
		return rowVersionNoForWorkItem;
	}

	public void setRowVersionNoForWorkItem(Integer rowVersionNoForWorkItem) {
		this.rowVersionNoForWorkItem = rowVersionNoForWorkItem;
	}

	/**
	 * @return the ftxEvnt
	 */
	public FTXEvent getFtxEvnt() {
		return ftxEvnt;
	}

	/**
	 * @param ftxEvnt the ftxEvnt to set
	 */
	public void setFtxEvnt(FTXEvent ftxEvnt) {
		this.ftxEvnt = ftxEvnt;
	}

	/**
	 * @return the or6aExam
	 */
	public Or6a getOr6aExam() {
		return or6aExam;
	}

	/**
	 * @param or6aExam the or6aExam to set
	 */
	public void setOr6aExam(Or6a or6aExam) {
		this.or6aExam = or6aExam;
	}

	/**
	 * @return the conExamPinAval
	 */
	public String getConExamPinAval() {
		return conExamPinAval;
	}

	/**
	 * @param conExamPinAval the conExamPinAval to set
	 */
	public void setConExamPinAval(String conExamPinAval) {
		this.conExamPinAval = conExamPinAval;
	}

	public String getLcnsMailDate() {
		return lcnsMailDate;
	}

	public void setLcnsMailDate(String lcnsMailDate) {
		this.lcnsMailDate = lcnsMailDate;
	}

	/**
	 * @return the knlgExamDate
	 */
	public String getKnlgExamDate() {
		return knlgExamDate;
	}

	/**
	 * @param knlgExamDate the knlgExamDate to set
	 */
	public void setKnlgExamDate(String knlgExamDate) {
		this.knlgExamDate = knlgExamDate;
	}

	/**
	 * @return the knlgExamRslt
	 */
	public String getKnlgExamRslt() {
		return knlgExamRslt;
	}

	/**
	 * @param knlgExamRslt the knlgExamRslt to set
	 */
	public void setKnlgExamRslt(String knlgExamRslt) {
		this.knlgExamRslt = knlgExamRslt;
	}
	//start: added for Req347
	/**
	 * @return the ertCode
	 */
	public String getErtCode() {
		return ertCode;
	}
	/**
	 * @param ertCode the ertCode to set
	 */
	public void setErtCode(String ertCode) {
		this.ertCode = ertCode;
	}
	/**
	 * @return the agrmntFlag
	 */
	public String getAgrmntFlag() {
		return agrmntFlag;
	}
	/**
	 * @param agrmntFlag the agrmntFlag to set
	 */
	public void setAgrmntFlag(String agrmntFlag) {
		this.agrmntFlag = agrmntFlag;
	}
	//end: added for req 347

	//Added for SS_QC#7287:start
	/**
	 * @return the opccValue
	 */
	public String getOpccValue() {
		return opccValue;
	}

	/**
	 * @param opccValue the opccValue to set
	 */
	public void setOpccValue(String opccValue) {
		this.opccValue = opccValue;
	}

	/**
	 * @return the oprcValue
	 */
	public String getOprcValue() {
		return oprcValue;
	}

	/**
	 * @param oprcValue the oprcValue to set
	 */
	public void setOprcValue(String oprcValue) {
		this.oprcValue = oprcValue;
	}

	/**
	 * @return the opecValue
	 */
	public String getOpecValue() {
		return opecValue;
	}

	/**
	 * @param opecValue the opecValue to set
	 */
	public void setOpecValue(String opecValue) {
		this.opecValue = opecValue;
	}//Added for SS_QC#7287:end

	// Added for SS_QC#7321 --Start
	/**
	 * @return the mvrAuthRcvdDate
	 */
	public String getMvrAuthRcvdDate() {
		return mvrAuthRcvdDate;
	}

	/**
	 * @param mvrAuthRcvdDate
	 *          the mvrAuthRcvdDate to set
	 */
	public void setMvrAuthRcvdDate(final String mvrAuthRcvdDate) {
		this.mvrAuthRcvdDate = mvrAuthRcvdDate;
	} // Added for SS_QC#7321 --End

	//Added for SS_QC#6702:Start
	/**
	 * @return the opccDate
	 */
	public String getOpccDate() {
		return opccDate;
	}

	/**
	 * @param opccDate the opccDate to set
	 */
	public void setOpccDate(String opccDate) {
		this.opccDate = opccDate;
	}

	/**
	 * @return the oprcDate
	 */
	public String getOprcDate() {
		return oprcDate;
	}

	/**
	 * @param oprcDate the oprcDate to set
	 */
	public void setOprcDate(String oprcDate) {
		this.oprcDate = oprcDate;
	}

	/**
	 * @return the opecDate
	 */
	public String getOpecDate() {
		return opecDate;
	}

	/**
	 * @param opecDate the opecDate to set
	 */
	public void setOpecDate(String opecDate) {
		this.opecDate = opecDate;
	}

	//	public String getLoggedInUserId() {
	//		return loggedInUserId;
	//	}
	//
	//	public void setLoggedInUserId(String loggedInUserId) {
	//		this.loggedInUserId = loggedInUserId;
	//	}

	//Added for SS_QC#6703:start
	private String riskScore;

	public String getRiskScore() {
		return riskScore;
	}

	public void setRiskScore(String riskScore) {
		this.riskScore = riskScore;
	}
	//Added for SS_QC#6703:end

	//Added for SS_QC#9070 
	public String getFourthAction() {
		return fourthAction;
	}

	public void setFourthAction(String fourthAction) {
		this.fourthAction = fourthAction;
	}
	//Added for SS_QC#9070 
}
