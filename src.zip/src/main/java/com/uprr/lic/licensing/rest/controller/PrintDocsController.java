package com.uprr.lic.licensing.rest.controller;



import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.uprr.lic.dataaccess.common.model.EqmLcnsInit;
import com.uprr.lic.licensing.rest.service.IPrintDocsService;

@Controller
public class PrintDocsController{
	
	@Autowired
	private IPrintDocsService printDocsService;

	@RequestMapping(value = "/licensing/insertPacketPrintDocs", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public List<String> insertPacketPrintingDetailsWithValidation(@RequestParam(value = "employeeId", required = true) String employeeId
			,@RequestParam(value = "comments", required = true) String comments){
	     return printDocsService.insertPacketPrintingDetailsWithValidation(employeeId, comments);
	}
	
	@RequestMapping(value = "/licensing/getLicenseInitiationDetails/{lcnsOprnId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public String getEmployeesLicenseInitiationDetails(@PathVariable Integer lcnsOprnId){
	     return printDocsService.getEmployeesLicenseInitiationDetails(lcnsOprnId);
	}
	
	
	@RequestMapping(value = "/licensing/updateMarkAsPacketSent", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public String updatePendingActionMarkAsPacketSent(@RequestParam(value = "employeeID", required = true) String employeeID
			,@RequestParam(value = "licenseClass", required = true) String licenseClass,
			@RequestParam(value = "reasonID", required = true) Integer reasonID,
			@RequestParam(value = "workItemID", required = true) Integer workItemID,
			@RequestParam(value = "oprnID", required = true) Integer oprnID){
	     return printDocsService.updatePendingActionMarkAsPacketSent(employeeID, licenseClass, reasonID, workItemID,oprnID);
	}
	
	
	// Started by Girish
	
	@RequestMapping(value = "/licensing/getOprnIdforExistingLicense", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public Map<Boolean, Integer> getOprnIdforExistingLicense(@RequestParam(value = "employeeID", required = true) String employeeID){
	     return printDocsService.getOprnIdforExistingLicense(employeeID);
	}
	
	
	@RequestMapping(value = "/licensing/getInitDtlsByOprnId", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public EqmLcnsInit getInitDtlsByOprnId(
			@RequestParam(value = "oprnID", required = true) Integer lcnsOprnId){
	     return printDocsService.getInitDtlsByOprnId(lcnsOprnId);
	}
	
	
	@RequestMapping(value = "/licensing/isRecertificationInitiatedForEmployee", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public boolean isRecertificationInitiatedForEmployee(@RequestParam(value = "employeeId", required = true) String employeeId, @RequestParam(value = "licenseClassCode", required = true) String licenseClassCode,
			@RequestParam(value = "selection", required = true) Integer selection){
	     return printDocsService.isRecertificationInitiatedForEmployee(employeeId, licenseClassCode, selection);
	}
	
// End By girish
	
}