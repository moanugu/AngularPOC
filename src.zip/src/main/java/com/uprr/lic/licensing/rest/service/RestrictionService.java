package com.uprr.lic.licensing.rest.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uprr.lic.auth.EQMSUserSession;
import com.uprr.lic.dataaccess.Licensing.model.Restriction;
import com.uprr.lic.dataaccess.components.licensing.service.ILicensingService;
import com.uprr.lic.exception.EqmDaoException;
import com.uprr.lic.util.LicensingConstant;

/**
 * 
 * @author xsat956
 *
 */
@Service("restrictionService")
public class RestrictionService implements IRestrictionService {

	private final Logger logger = LoggerFactory.getLogger(RestrictionService.class);
	@Autowired
	private ILicensingService licensingService;

	@Autowired
	private EQMSUserSession eqmsUserSession;

	@Override
	public Restriction getEmployeeDetailsForRestriction(String employeeId) {
		return licensingService.getEmployeeDetailsInRestrictionPage(employeeId);
	}

	@Override
	public Boolean insertEmpRestrictionData(Restriction restriction) {
		try {
			return licensingService.insertEmpRestrictionData(restriction, eqmsUserSession.getUser().getEmplId());
		} catch(Exception exception) {
			logger.error(LicensingConstant.LOGGER_EQMEXCEPTION + "updateButtonComponent :  Method " + exception.getMessage(), exception);
			throw new EqmDaoException(exception.getMessage());
		}
	}

	@Override
	public List<String> getRailRoadList() {
		return licensingService.getRailRoadList();
	}




}
