/**
 * 
 */
package com.uprr.lic.licensing.rest.model;

/**
 * 
 * @author xsat956
 *
 */
public class CertRideSummaryResponse{


  private String manager;

  private String evaluationDate;

  private String serviceUnit;

  /**
   * Field use in Train details
   */

  private String trainID;

  private Long totalLoads;

  private String crewOnDutyCirc7;

  private String serviceType;

  private Long length;

  private String simulator;

  private String dPU;

  private String forignInitial;

  private Long weight;

  private Long totalEmpties;

  private String remoteControl;

  private String helper;

  /**
   * Field use in Crew Details
   */

  private String crewMember;

  private String position;

  private String student;

  private String reason;

  private Long totalMiles;

  private String startDate;

  private String stopDate;
  

  private String originCirc7;

  private String destCirc7;

  private Double overAllScore;

  private Integer trainHandlingScore;

  /**
   * Field for Manager Comments
   */

  private String mngrComments;

public String getManager() {
	return manager;
}

public void setManager(String manager) {
	this.manager = manager;
}

public String getEvaluationDate() {
	return evaluationDate;
}

public void setEvaluationDate(String evaluationDate) {
	this.evaluationDate = evaluationDate;
}

public String getServiceUnit() {
	return serviceUnit;
}

public void setServiceUnit(String serviceUnit) {
	this.serviceUnit = serviceUnit;
}

public String getTrainID() {
	return trainID;
}

public void setTrainID(String trainID) {
	this.trainID = trainID;
}

public Long getTotalLoads() {
	return totalLoads;
}

public void setTotalLoads(Long totalLoads) {
	this.totalLoads = totalLoads;
}

public String getCrewOnDutyCirc7() {
	return crewOnDutyCirc7;
}

public void setCrewOnDutyCirc7(String crewOnDutyCirc7) {
	this.crewOnDutyCirc7 = crewOnDutyCirc7;
}

public String getServiceType() {
	return serviceType;
}

public void setServiceType(String serviceType) {
	this.serviceType = serviceType;
}

public Long getLength() {
	return length;
}

public void setLength(Long length) {
	this.length = length;
}

public String getSimulator() {
	return simulator;
}

public void setSimulator(String simulator) {
	this.simulator = simulator;
}

public String getdPU() {
	return dPU;
}

public void setdPU(String dPU) {
	this.dPU = dPU;
}

public String getForignInitial() {
	return forignInitial;
}

public void setForignInitial(String forignInitial) {
	this.forignInitial = forignInitial;
}

public Long getWeight() {
	return weight;
}

public void setWeight(Long weight) {
	this.weight = weight;
}

public Long getTotalEmpties() {
	return totalEmpties;
}

public void setTotalEmpties(Long totalEmpties) {
	this.totalEmpties = totalEmpties;
}

public String getRemoteControl() {
	return remoteControl;
}

public void setRemoteControl(String remoteControl) {
	this.remoteControl = remoteControl;
}

public String getHelper() {
	return helper;
}

public void setHelper(String helper) {
	this.helper = helper;
}

public String getCrewMember() {
	return crewMember;
}

public void setCrewMember(String crewMember) {
	this.crewMember = crewMember;
}

public String getPosition() {
	return position;
}

public void setPosition(String position) {
	this.position = position;
}

public String getStudent() {
	return student;
}

public void setStudent(String student) {
	this.student = student;
}

public String getReason() {
	return reason;
}

public void setReason(String reason) {
	this.reason = reason;
}

public Long getTotalMiles() {
	return totalMiles;
}

public void setTotalMiles(Long totalMiles) {
	this.totalMiles = totalMiles;
}

public String getStartDate() {
	return startDate;
}

public void setStartDate(String startDate) {
	this.startDate = startDate;
}

public String getStopDate() {
	return stopDate;
}

public void setStopDate(String stopDate) {
	this.stopDate = stopDate;
}

public String getOriginCirc7() {
	return originCirc7;
}

public void setOriginCirc7(String originCirc7) {
	this.originCirc7 = originCirc7;
}

public String getDestCirc7() {
	return destCirc7;
}

public void setDestCirc7(String destCirc7) {
	this.destCirc7 = destCirc7;
}

public Double getOverAllScore() {
	return overAllScore;
}

public void setOverAllScore(Double overAllScore) {
	this.overAllScore = overAllScore;
}

public Integer getTrainHandlingScore() {
	return trainHandlingScore;
}

public void setTrainHandlingScore(Integer trainHandlingScore) {
	this.trainHandlingScore = trainHandlingScore;
}

public String getMngrComments() {
	return mngrComments;
}

public void setMngrComments(String mngrComments) {
	this.mngrComments = mngrComments;
}

  

}
