package com.uprr.lic.licensing.rest.model;

import java.util.List;

public class RemoveRCVDNDRMVRRequest {
	
	private String employeeID;
	private List<Integer> packetResnIdList;
	private List<String> workQueueFlagLst;
	private String comments;

	public String getEmployeeID() {
		return employeeID;
	}
	public void setEmployeeID(String employeeID) {
		this.employeeID = employeeID;
	}
	public List<Integer> getPacketResnIdList() {
		return packetResnIdList;
	}
	public void setPacketResnIdList(List<Integer> packetResnIdList) {
		this.packetResnIdList = packetResnIdList;
	}
	public List<String> getWorkQueueFlagLst() {
		return workQueueFlagLst;
	}
	public void setWorkQueueFlagLst(List<String> workQueueFlagLst) {
		this.workQueueFlagLst = workQueueFlagLst;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	
	

}
