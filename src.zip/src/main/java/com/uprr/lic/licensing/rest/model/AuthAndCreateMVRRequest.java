package com.uprr.lic.licensing.rest.model;

import java.util.List;

public class AuthAndCreateMVRRequest {

	private List<String> emplIdLst;
    private  boolean fromErrWrkItm;
    private boolean fromSendRequest;
    
    
	public List<String> getEmplIdLst() {
		return emplIdLst;
	}
	public void setEmplIdLst(List<String> emplIdLst) {
		this.emplIdLst = emplIdLst;
	}
	public boolean isFromErrWrkItm() {
		return fromErrWrkItm;
	}
	public boolean isFromSendRequest() {
		return fromSendRequest;
	}
    
	public void setFromErrWrkItm(boolean fromErrWrkItm) {
		this.fromErrWrkItm = fromErrWrkItm;
	}
	
	
	public void setFromSendRequest(boolean fromSendRequest) {
		this.fromSendRequest = fromSendRequest;
	}
    
    
}
