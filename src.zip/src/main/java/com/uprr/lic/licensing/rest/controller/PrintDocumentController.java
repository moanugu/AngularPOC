package com.uprr.lic.licensing.rest.controller;

import org.springframework.stereotype.Controller;

@Controller
public class PrintDocumentController {

}
