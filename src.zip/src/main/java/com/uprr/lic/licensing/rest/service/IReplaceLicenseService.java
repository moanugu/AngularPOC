package com.uprr.lic.licensing.rest.service;

import java.util.List;
import java.util.Set;

import com.uprr.lic.dataaccess.Licensing.model.InitiateReplaceLicenseBean;
import com.uprr.lic.exception.EqmException;

/**
 * 
 * @author xsat956
 *
 */
public interface IReplaceLicenseService {
	//This code is oriented to licensing and started by xsat956(Girish)
	 /**
	   * @param employeeid
	   * @return
	   * @throws Exception
	   */
	  Set<String> isReplaceLicenseRequestInitiated(String employeeid) ;
	  
	 /** @param replacePendingActionPrintWorkQueue
	   * @param details
	   * @param crtnEmplId
	   * @param aEqmsRole
	   * @return
	   * @throws Exception
	   */
	  /** @param replacePendingActionPrintWorkQueue
	   * @param details
	   * @param crtnEmplId
	   * @param aEqmsRole
	   * @return
	   * @throws Exception
	   */
	  Integer insertReplaceLicenseWorkItemEntry(final String reason,
		      final List<InitiateReplaceLicenseBean> details);
	  
	  
	  /**
	   * @param replacePendingActionPrintWorkQueue
	   * @param licClass
	   * @return
	   * @throws EqmException
	   * @throws Exception
	   */
	  List<InitiateReplaceLicenseBean> getReplaceLicenseEmployeeDetails(String employeeId, Set<String> licClass) ;
	  
	  boolean isEmployeeLicenseValid(final String employeeID);
	  //End By Girish
}
