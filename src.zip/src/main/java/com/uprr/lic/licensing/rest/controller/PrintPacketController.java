package com.uprr.lic.licensing.rest.controller;

import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.uprr.lic.auth.EQMSUserSession;
import com.uprr.lic.dataaccess.Licensing.model.CoverLetterForPrintDocsTemplate;
import com.uprr.lic.dataaccess.common.model.EqmLcnsRqmt;
import com.uprr.lic.licensing.rest.model.NdrTemplateDetail;
import com.uprr.lic.licensing.rest.service.IPrintPacketService;

@Controller
public class PrintPacketController {

	@Autowired
	private IPrintPacketService printPacketService;
	
	/*@Autowired
	private EQMSUserSession eqmsUserSession;*/ // Commented For SS_QC#10235



	@RequestMapping(value = "/licensing/isStudentLicense", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public boolean isStudentLicense(@RequestParam(value = "employeeId", required = true) String employeeID){
		return printPacketService.isStudentLicense(employeeID);
	}


	/**
	 * 
	 * @param employeeId
	 * @param sysParamName is a Constant key for System param value
	 * @return
	 */
	@RequestMapping(value = "/licensing/getAddressInfoForEmplCoverLetterFromTeradata", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public CoverLetterForPrintDocsTemplate getAddressInfoForEmplCoverLetterFromTeradata(
			@RequestParam(value = "employeeId", required = true) String employeeId, @RequestParam(value = "sysParamName", required = true) String sysParamName){
		return printPacketService.getAddressInfoForEmplCoverLetterFromTeradata(employeeId, sysParamName);
	}


	@RequestMapping(value = "/licensing/getEmployeeDetailsForNDRTemplate", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public NdrTemplateDetail getEmployeeDetailsForNDRTemplate(@RequestParam(value = "employeeId", required = true) String employeeId){
		return printPacketService.getEmployeeDetailsForNDRTemplate(employeeId);
	}

	@RequestMapping(value = "/licensing/getRecertificationInitiatedDetailsForEmployee", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public List<EqmLcnsRqmt> getRecertificationInitiatedDetailsForEmployee(@RequestParam(value = "employeeId", required = true) String employeeId, @RequestParam(value = "licenseClassCode", required = false) String licenseClassCode){
		return printPacketService.getRecertificationInitiatedDetailsForEmployee(employeeId, licenseClassCode);
	}

	/**
	 * Print Packet for Covert lerr
	 * @param iLataNumber
	 * @return
	 * Modified for SS_QC#10235
	 */
	@RequestMapping(value = "/licensing/printLataPackets", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public Map<String, String> printLataPacket(@RequestParam(value = "iLataNumber", required = false) String iLataNumber,@RequestParam(value = "employeeId", required = false) String employeeId){
	  
		return printPacketService.printLataPacket(iLataNumber,employeeId); // Added  Parameter For SS_QC#10235
	}
	
	
	
	@RequestMapping(value = "/licensing/getAOTRoleSet", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public Set<Integer> getAOTRoleSet(){
		return printPacketService.getAOTRoleSet();
	}
}
