package com.uprr.lic.licensing.rest.service;

import java.util.List;

import com.uprr.lic.dataaccess.Licensing.model.WaiverDetails;
import com.uprr.lic.dataaccess.Licensing.model.WaiverGrid;

/**
 * 
 * @author xsat956
 *
 */
public interface IWaiverService {
	//This code is oriented to licensing and started by xsat956(Girish)
	WaiverDetails getWaiverDetail(String employeeId);
	  
	List<WaiverGrid> hasLicenseWaivedSuccessfully(List<WaiverGrid> waiverList);
	
	List<WaiverGrid> unwaiveEmployeesLicense(List<WaiverGrid> waiverList);
	  //End By Girish
}
