package com.uprr.lic.licensing.rest.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uprr.lic.auth.EQMSUserSession;
import com.uprr.lic.dataaccess.common.model.EqmEmplDtls;
import com.uprr.lic.dataaccess.common.model.EqmSysParm;
import com.uprr.lic.dataaccess.components.licensing.service.ILicensingService;

@Service
public class LicensingCommonRestService implements ILicensingCommonRestService {
	
	@Autowired
	private ILicensingService licensingService;
	

	@Autowired
	private EQMSUserSession userSession;
	
	public EqmSysParm getSysParmValue(String sysParamName) {
		return licensingService.getSysParmValue(sysParamName);
	}
	

	/**
	 * Return URL for CFM for MVR From ECL
	 * @param employeeId
	 * @return @String
	 */
	public String getCFMUrlForMVRFromECL(String employeeId) {
		String crtnEmpl = userSession.getUser().getEmplId();
		String param1="/emp/operating/tey/edr/new/secure/MVR_Form_ECL.cfm?ss_Employee=";
		//String param2=employeeId+"&ss_CreationId=DEQM999')";
		String param2=employeeId+"&ss_CreationId="+crtnEmpl;
		/*String env="";
		String appEnvironment = System.getProperty("uprr.implementation.environment");
		if(appEnvironment.trim().equals("win")||appEnvironment.trim().equals("dev")){
			env="'https://xdev.home.www.uprr.com";
		}else if(appEnvironment.trim().equalsIgnoreCase("test")){
			env="'https://xtest.home.www.uprr.com";
		}else if(appEnvironment.trim().equalsIgnoreCase("prod")){
			env="'https://home.www.uprr.com";
		}*/
		return param1+param2;
	}


	@Override
	public List<EqmEmplDtls> getEmplDtlsLsit(List<String> emplIdList) {
		return licensingService.getEmplDtlsLsit(emplIdList);
	}


}
