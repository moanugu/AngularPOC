package com.uprr.lic.config.jms;

import javax.naming.NamingException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Conditional;
import org.springframework.context.annotation.Configuration;
import org.springframework.jms.listener.DefaultMessageListenerContainer;
import org.springframework.jms.listener.adapter.MessageListenerAdapter;

import com.uprr.lic.dataaccess.twic.dao.ITwicDao;
import com.uprr.lic.licensing.jms.twic.TwicMessageConvertor;

@Configuration
public class TwicJmsConfig extends JMSContextConfig {

	@Autowired
	private ITwicDao twicDao;

	@Bean
	@Qualifier("twicListenerContainer")
	@Conditional(LICEnvironment.class)
	public DefaultMessageListenerContainer createTwicListenerContainer(@Value("${JAVA_NAMING_PROVIDER_URL}") String url,
			@Value("${JMS_USER_NAME}") String userName, @Value("${JMS_PASSWORD}") String password,
			@Value("${EQM_XMF_FACTORYNAME}") String jmsQueueCF, @Value("${TWIC_RES_QUEUE}") final String requestQueue)
			throws NamingException {

		DefaultMessageListenerContainer defaultMessageListenerContainer = new DefaultMessageListenerContainer();
		defaultMessageListenerContainer
				.setConnectionFactory(createSingleConnectionFactory(url, userName, password, jmsQueueCF));
		defaultMessageListenerContainer.setDestination(createTibjmsQueue(requestQueue));
		defaultMessageListenerContainer
				.setMessageListener(createTwicMessageListener(url, userName, password, jmsQueueCF));
		defaultMessageListenerContainer.setConcurrentConsumers(1);
		return defaultMessageListenerContainer;
	}

	private MessageListenerAdapter createTwicMessageListener(String url, String userName, String password,
			String jmsQueueCF) throws NamingException {
		MessageListenerAdapter messageListenerAdapter = new MessageListenerAdapter();
		messageListenerAdapter.setMessageConverter(new TwicMessageConvertor());
		messageListenerAdapter.setDelegate(twicDao);
		messageListenerAdapter.setDefaultListenerMethod("processTwicDetailsResponse");
		return messageListenerAdapter;
	}

}
