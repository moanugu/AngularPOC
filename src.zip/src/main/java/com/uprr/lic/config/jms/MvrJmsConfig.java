package com.uprr.lic.config.jms;

import javax.naming.NamingException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Conditional;
import org.springframework.context.annotation.Configuration;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.listener.DefaultMessageListenerContainer;
import org.springframework.jms.listener.adapter.MessageListenerAdapter;
import org.springframework.jms.support.converter.MessageConverter;

import com.uprr.lic.decert.jms.mvr.MVRCreateRequestSender;
import com.uprr.lic.licensing.jms.mvr.MvrDelegate;
import com.uprr.lic.licensing.jms.mvr.MvrRestrictionMessageConvertor;

@Configuration
public class MvrJmsConfig extends JMSContextConfig {

	@Bean
	@Qualifier("mvrRequestJmsTemplate")
	public JmsTemplate createMVRJmsTemplate(@Value("${JAVA_NAMING_PROVIDER_URL}") String url,
			@Value("${JMS_USER_NAME}") String userName, @Value("${JMS_PASSWORD}") String password,
			@Value("${DQS_FACTORY_MVR}") String jmsQueueCF, @Value("${MVR_REQ_QUEUE}")
	final String requestQueue) throws NamingException {
		JmsTemplate jmsTemplate = new JmsTemplate();
		jmsTemplate.setConnectionFactory(createSingleConnectionFactory(url, userName, password, jmsQueueCF));
		jmsTemplate.setDefaultDestination(createTibjmsQueue(requestQueue));
		return jmsTemplate;
	}

	@Bean
	public MVRCreateRequestSender createMVRRequestSender(
			@Qualifier("mvrRequestJmsTemplate") JmsTemplate mvrRequestJmsTemplate) throws NamingException {
		return new MVRCreateRequestSender(mvrRequestJmsTemplate);
	}

	@Bean
	@Qualifier("mvrListenerContainer")
	@Conditional(LICEnvironment.class)
	public DefaultMessageListenerContainer createMVRListenerContainer(@Value("${JAVA_NAMING_PROVIDER_URL}") String url,
			@Value("${JMS_USER_NAME}") String userName, @Value("${JMS_PASSWORD}") String password,
			@Value("${MVR_FACTORY}") String jmsQueueCF, @Value("${EQMS_MVR_RESPONSE_QUEUE}")
	final String requestQueue) throws NamingException {
		DefaultMessageListenerContainer defaultMessageListenerContainer = new DefaultMessageListenerContainer();
		defaultMessageListenerContainer
		.setConnectionFactory(createSingleConnectionFactory(url, userName, password, jmsQueueCF));
		defaultMessageListenerContainer.setDestination(createTibjmsQueue(requestQueue));
		defaultMessageListenerContainer.setMessageListener(createMvrMessageListener());
		defaultMessageListenerContainer.setConcurrentConsumers(1);
		return defaultMessageListenerContainer;
	}

	private MessageListenerAdapter createMvrMessageListener() throws NamingException {
		MessageListenerAdapter messageListenerAdapter = new MessageListenerAdapter();
		messageListenerAdapter.setMessageConverter(createMVRMessageConverter());
		messageListenerAdapter.setDelegate(createMvrDelegate());
		messageListenerAdapter.setDefaultListenerMethod("processMVRResponse");
		return messageListenerAdapter;
	}

	@Bean
	@Conditional(LICEnvironment.class)
	public MvrDelegate createMvrDelegate() throws NamingException {
		return new MvrDelegate();
	}

	@Bean
	@Conditional(LICEnvironment.class)
	public MessageConverter createMVRMessageConverter() {
		return new MvrRestrictionMessageConvertor();
	}
}
