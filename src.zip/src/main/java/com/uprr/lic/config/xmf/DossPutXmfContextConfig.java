package com.uprr.lic.config.xmf;

import java.net.UnknownHostException;
import java.util.Collections;

import javax.naming.NamingException;

import org.springframework.aop.target.CommonsPoolTargetSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;
import org.springframework.jms.connection.SingleConnectionFactory;
import org.springframework.jms.connection.UserCredentialsConnectionFactoryAdapter;

import com.tibco.tibjms.TibjmsConnectionFactory;
import com.uprr.app.xmf.RequestHandler;
import com.uprr.app.xmf.client.ServiceProxy;
import com.uprr.app.xmf.client.ServiceProxyException;
import com.uprr.app.xmf.client.core.ServiceProxyFactoryImpl;
import com.uprr.lic.config.xmf.util.LicXmfClientId;
import com.uprr.lic.config.xmf.util.XmfUtil;
import com.uprr.netcontrol.businesstransactiontracingxmftoolkit.BttXmfServiceProxyFactoryImpl;
import com.uprr.netcontrol.frontend.client.xmf.XmfClientInvoker;
import com.uprr.netcontrol.frontend.client.xmf.XmfClientInvokerImpl;

@Configuration
public class DossPutXmfContextConfig extends XMFConfig {

	private static final String DOS_PUT_SERVICE_PROXY_BEAN_NAME = "dossPutServiceProxy";

	@Autowired
	@Qualifier("dossPutServiceProxyFactory")
	private ServiceProxyFactoryImpl dossPutServiceProxyFactory;

	@Autowired(required = false)
	@Qualifier("eqmSecurityHandler")
	private RequestHandler securityHandler;

	@Autowired
	@Qualifier("dossPutServiceProxyPool")
	private CommonsPoolTargetSource dossPutServiceProxyPool;

	/**
	 * The XmfServiceProxyPool for use in XMF Client creation.
	 *
	 * @param maxSize
	 * @param maxIdle
	 * @param maxWait
	 * @param whenExhaustedActionName
	 * @param timeBetweenEvictionRunsMillis
	 * @param minEvictableIdleTimeMillis
	 * @return
	 */
	@Bean(name = "dossPutServiceProxyPool")
	public CommonsPoolTargetSource createDosPutTargetSource(@Value("${xmf.proxypool.size.max}") final int maxSize,
			@Value("${xmf.proxypool.size.idle}") final int maxIdle,
			@Value("${xmf.proxypool.wait.time}") final long maxWait,
			@Value("${xmf.proxypool.action}") final String whenExhaustedActionName,
			@Value("${xmf.proxypool.evictionRunTime}") final long timeBetweenEvictionRunsMillis,
			@Value("${xmf.serviceProxy.evictableIdleTime}") final long minEvictableIdleTimeMillis) {
		final CommonsPoolTargetSource proxyPool = new CommonsPoolTargetSource();
		proxyPool.setTargetBeanName(DOS_PUT_SERVICE_PROXY_BEAN_NAME);
		proxyPool.setMaxSize(maxSize);
		proxyPool.setMaxIdle(maxIdle);
		proxyPool.setMaxWait(maxWait);
		proxyPool.setTimeBetweenEvictionRunsMillis(timeBetweenEvictionRunsMillis);
		proxyPool.setMinEvictableIdleTimeMillis(minEvictableIdleTimeMillis);
		proxyPool.setWhenExhaustedActionName(whenExhaustedActionName);
		// proxyPool.setBlockWhenExhausted(true);
		return proxyPool;
	}

	/**
	 * This PROTOTYPE method is invoked each time the ServiceProxy pool is
	 * empty.
	 *
	 * @return a new Service Proxy
	 * @throws ServiceProxyException
	 */
	@Bean(name = DOS_PUT_SERVICE_PROXY_BEAN_NAME, destroyMethod = "close")
	@Scope(value = BeanDefinition.SCOPE_PROTOTYPE)
	public ServiceProxy createDossPutServiceProxy(@Value("${DOSS_PUT_QUEUE}") final String requestQueueName)
			throws ServiceProxyException {
		final ServiceProxy proxy = dossPutServiceProxyFactory.createServiceProxy();
		proxy.setRequestDestination(createTibjmsQueue(requestQueueName));
		if (securityHandler != null) {
			proxy.setRequestHandlers(Collections.singletonList(securityHandler));
		}
		return proxy;
	}

	/**
	 * Business Transaction Tracing based factory for XMF
	 *
	 * @param jmsUserName
	 * @param jmsPassword
	 * @param jmsUrl
	 * @param jmsConnectionFactoryName
	 * @param jmsClientId
	 * @return
	 * @throws ServiceProxyException
	 * @throws NamingException
	 */
	@Bean(name = "dossPutServiceProxyFactory")
	public ServiceProxyFactoryImpl createDossPutServiceProxyFactory(
			@Value("${eqm.xmf.jms.password}") final String jmsPassword,
			@Value("${JAVA_NAMING_PROVIDER_URL}") final String jmsUrl,
			@Value("${DOSS_FACTORYNAME}") final String jmsConnectionFactoryName,
			@Value("${app.name}") final String appName, @Value("${eqm.xmf.jms.userId}") final String jmsUserName)
			throws ServiceProxyException, NamingException, UnknownHostException {
		final TibjmsConnectionFactory jmsQueueCF = createTibjmsQueueConnectionFactory(jmsUrl, jmsUserName, jmsPassword,
				jmsConnectionFactoryName);
		final UserCredentialsConnectionFactoryAdapter userCredentialsConnectionFactory = createUserCredentialsConnectionFactory(
				jmsUserName, jmsPassword, jmsQueueCF);
		final SingleConnectionFactory singleConnectionFactory = new org.springframework.jms.connection.SingleConnectionFactory();
		singleConnectionFactory.setReconnectOnException(true);
		singleConnectionFactory.setClientId(XmfUtil.getJmsClientId(jmsUserName, appName));
		singleConnectionFactory.setTargetConnectionFactory(userCredentialsConnectionFactory);
		return new BttXmfServiceProxyFactoryImpl(singleConnectionFactory, "eqmdoss",
				DossPutXmfContextConfig.POOL_IS_LAZY);
	}

	@Bean(name = "dossPutXmfClientInvoker")
	public XmfClientInvoker createDossPutXmfClientInvoker(@Value("${eqm.xmf.jms.userId}") final String jmsUserName,
			@Value("${eqm.xmf.jms.userId}") final String udi, @Value("${app.name}") final String appName) {
		return new XmfClientInvokerImpl(new LicXmfClientId(jmsUserName, null), dossPutServiceProxyPool, appName);
	}
}
