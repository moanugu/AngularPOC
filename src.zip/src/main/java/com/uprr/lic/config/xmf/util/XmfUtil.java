package com.uprr.lic.config.xmf.util;

import java.net.UnknownHostException;
import java.util.Properties;

import com.uprr.netcontrol.shared.components.datetime.NCDateTimeFactory;

public class XmfUtil {
	public static Properties buildJNDIProperties(final String url, final String userId, final String password) {
		final Properties environment = new Properties();
		environment.put("java.naming.factory.initial", "com.tibco.tibjms.naming.TibjmsInitialContextFactory");
		environment.put("java.naming.provider.url", url);
		environment.put("java.naming.security.principal", userId);
		environment.put("java.naming.security.credentials", password);
		return environment;
	}

	public static String getJmsClientId(final String xmfUserId, final String appName) throws UnknownHostException {
		final String clientId = "cn=" + xmfUserId + ",ou=uprr,o=up," + "udi=" + xmfUserId + ",duName=" + appName
				+ ",started:" + NCDateTimeFactory.createTimestamp().getServiceUTCString();
		return clientId;
	}
}
