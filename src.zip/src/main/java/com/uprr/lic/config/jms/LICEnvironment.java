package com.uprr.lic.config.jms;

import org.springframework.context.annotation.Condition;
import org.springframework.context.annotation.ConditionContext;
import org.springframework.core.type.AnnotatedTypeMetadata;

public class LICEnvironment implements Condition {

	@Override
	public boolean matches(ConditionContext context, AnnotatedTypeMetadata metadata) {
		final String environment = System.getProperty("uprr.implementation.environment").toUpperCase();
		 return !(environment.equals("WIN") || environment.equals("LOCAL"));
//		return true;
	}

}
