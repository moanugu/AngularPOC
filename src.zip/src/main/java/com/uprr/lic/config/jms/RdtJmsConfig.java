package com.uprr.lic.config.jms;

import javax.naming.NamingException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Conditional;
import org.springframework.context.annotation.Configuration;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.listener.DefaultMessageListenerContainer;
import org.springframework.jms.listener.adapter.MessageListenerAdapter;

import com.uprr.lic.dataaccess.components.common.service.IAuthDao;
import com.uprr.lic.dataaccess.decertification.services.interfaces.IDecertificationService;
import com.uprr.lic.dataaccess.masters.service.IReasonService;
import com.uprr.lic.decert.jms.rdt.RDTDelegate;
import com.uprr.lic.decert.jms.rdt.RDTJmsServiceImpl;
import com.uprr.lic.decert.jms.rdt.RDTMessageConvertor;
import com.uprr.lic.decert.jms.rdt.RDTService;

@Configuration
public class RdtJmsConfig extends JMSContextConfig {

	@Autowired
	private IDecertificationService decertService;

	@Autowired
	private IAuthDao eqmsDao;

	@Autowired
	private IReasonService reasonService;

	@Bean
	@Qualifier("rdtJmsTemplate")
	@Conditional(LICEnvironment.class)
	public JmsTemplate createRdtJmsTemplate(@Value("${JAVA_NAMING_PROVIDER_URL}") String url,
			@Value("${JMS_USER_NAME}") String userName, @Value("${JMS_PASSWORD}") String password,
			@Value("${RDT_RESPONSE_FACTORYNAME}") String jmsQueueCF,
			@Value("${RDT_RESPONSE_QUEUE}") final String responseQueue) throws NamingException {
		JmsTemplate jmsTemplate = new JmsTemplate();
		jmsTemplate.setConnectionFactory(createSingleConnectionFactory(url, userName, password, jmsQueueCF));
		jmsTemplate.setDefaultDestination(createTibjmsQueue(responseQueue));
		return jmsTemplate;
	}

	@Bean
	@Qualifier("rdtListenerContainer")
	@Conditional(LICEnvironment.class)
	public DefaultMessageListenerContainer createRDTMsgListenerContainer(
			@Value("${JAVA_NAMING_PROVIDER_URL}") String url, @Value("${JMS_USER_NAME}") String userName,
			@Value("${JMS_PASSWORD}") String password, @Value("${RDT_REQUEST_FACTORYNAME}") String jmsQueueCF,
			@Value("${RDT_REQUEST_QUEUE}") final String requestQueue,
			@Qualifier("rdtJmsTemplate") JmsTemplate rdtJmsTemplate) throws NamingException {
		DefaultMessageListenerContainer defaultMessageListenerContainer = new DefaultMessageListenerContainer();
		defaultMessageListenerContainer
				.setConnectionFactory(createSingleConnectionFactory(url, userName, password, jmsQueueCF));
		defaultMessageListenerContainer.setDestination(createTibjmsQueue(requestQueue));
		defaultMessageListenerContainer
				.setMessageListener(createRDTMessageListener(url, userName, password, jmsQueueCF, rdtJmsTemplate));
		defaultMessageListenerContainer.setConcurrentConsumers(1);
		return defaultMessageListenerContainer;
	}

	@Bean
	@Conditional(LICEnvironment.class)
	public RDTService createRDTService(String url, String userName, String password, String jmsQueueCF,
			JmsTemplate rdtJmsTemplate) throws NamingException {
		return new RDTJmsServiceImpl(decertService, eqmsDao, reasonService, rdtJmsTemplate);
	}

	private MessageListenerAdapter createRDTMessageListener(String url, String userName, String password,
			String jmsQueueCF, JmsTemplate rdtJmsTemplate) throws NamingException {
		MessageListenerAdapter messageListenerAdapter = new MessageListenerAdapter();
		messageListenerAdapter.setMessageConverter(new RDTMessageConvertor(decertService));
		messageListenerAdapter.setDelegate(createRDTDelegate(url, userName, password, jmsQueueCF, rdtJmsTemplate));
		messageListenerAdapter.setDefaultListenerMethod("processRdtRequest");
		return messageListenerAdapter;
	}

	private RDTDelegate createRDTDelegate(String url, String userName, String password, String jmsQueueCF,
			JmsTemplate rdtJmsTemplate) throws NamingException {
		return new RDTDelegate(createRDTService(url, userName, password, jmsQueueCF, rdtJmsTemplate));
	}

}
