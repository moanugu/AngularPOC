package com.uprr.lic.config.xmf.util;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.uprr.app.xmf.client.security.core.DefaultSecurityPolicy;
import com.uprr.app.xmf.client.security.core.SecurityHandler;
import com.uprr.app.xmf.client.security.core.SecurityTokenService;
import com.uprr.app.xmf.client.security.core.SecurityTokenServiceProxy;
import com.uprr.app.xmf.security.SecurityPolicy;
import com.uprr.lic.medical.qualification.MedicalQualificationXmfImpl;
import com.uprr.lic.person_search_learning_history_2_0.SearchLearningHistoryClientXmfImpl;
import com.uprr.lic.service_qualification.GetQualificationServiceXmfImpl;

@Configuration
public class XmfSecurityHandler {
	private static final String[] SECURED_SERVICE_NAMES = { GetQualificationServiceXmfImpl.SERVICE_NAME.getName(),
			SearchLearningHistoryClientXmfImpl.SERVICE_NAME.getName(),
			MedicalQualificationXmfImpl.SERVICE_NAME.getName() };

	public static final String EQM_KEYSTORE_FILENAME = "deqm999.jks";

	public static final String EQM_CERTIFICATE_ALIAS = "deqm999";

	public static final String EQM_KEYSTORE_PASSWORD = "VpJSVLSD6H9Lym1C";

	public static final String EQM_PRIVATE_KEY_PASSWORD = "8jP9RTDy7fyVyk6h";

	@Bean
	@Qualifier("eqmSecurityHandler")
	public SecurityHandler createEqmSecurityHandler(@Value("${eqm.xmf.jms.userId}") String userId) {
		SecurityHandler securityHandler = new com.uprr.app.xmf.client.security.core.SecurityHandler();
		Map<String, SecurityPolicy> policies = new HashMap<String, SecurityPolicy>();
		for (String serviceName : SECURED_SERVICE_NAMES) {
			policies.put(serviceName, createDefaultPolicy(EQM_CERTIFICATE_ALIAS, EQM_KEYSTORE_FILENAME,
					EQM_KEYSTORE_PASSWORD, EQM_PRIVATE_KEY_PASSWORD));
		}
		securityHandler.setServicePolicies(policies);
		return securityHandler;
	}

	private SecurityPolicy createDefaultPolicy(String CERTIFICATE_ALIAS, String KEYSTORE_FILENAME,
			String KEYSTORE_PASSWORD, String PRIVATE_KEY_PASSWORD) {
		DefaultSecurityPolicy dsp = new DefaultSecurityPolicy();
		SecurityTokenService securityTokenService = new SecurityTokenServiceProxy();
		dsp.setSecurityTokenService(securityTokenService);
		dsp.setCertificateAlias(CERTIFICATE_ALIAS);
		dsp.setKeyStoreLocation(KEYSTORE_FILENAME);
		dsp.setKeyStorePassword(KEYSTORE_PASSWORD);
		dsp.setPrivateKeyPassword(PRIVATE_KEY_PASSWORD);
		return dsp;
	}
}
