package com.uprr.lic.config.jms;

import javax.naming.NamingException;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Conditional;
import org.springframework.context.annotation.Configuration;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.listener.DefaultMessageListenerContainer;
import org.springframework.jms.listener.adapter.MessageListenerAdapter;
import org.springframework.jms.support.converter.MessageConverter;

import com.uprr.lic.licensing.jms.ivr.IVRDelegate;
import com.uprr.lic.licensing.jms.ivr.IVRMessageConverter;

@Configuration
public class IvrJmsConfig extends JMSContextConfig {

  @Bean
  @Qualifier("ivrJmsTemplate")
  public JmsTemplate createIVRJmsTemplate(@Value("${IVR_PROVIDER_URL}") String url,
      @Value("${JMS_USER_NAME}") String userName, @Value("${JMS_PASSWORD}") String password,
      @Value("${EQM_XMF_FACTORYNAME}") String jmsQueueCF, @Value("${IVR_RESPONSE_QUEUE}")
      final String responseQueue) throws NamingException {
    JmsTemplate jmsTemplate = new JmsTemplate();
    jmsTemplate.setConnectionFactory(createSingleConnectionFactory(url, userName, password, jmsQueueCF));
    jmsTemplate.setDefaultDestination(createTibjmsQueue(responseQueue));
    return jmsTemplate;
  }

  @Bean
  @Qualifier("IvrListenerContainer")
  @Conditional(LICEnvironment.class)
  public DefaultMessageListenerContainer createIvrListenerContainer(@Value("${IVR_PROVIDER_URL}") String url,
      @Value("${JMS_USER_NAME}") String userName, @Value("${JMS_PASSWORD}") String password,
      @Value("${EQM_XMF_FACTORYNAME}") String jmsQueueCF, @Value("${IVR_REQUEST_QUEUE}")
      final String requestQueue, @Qualifier("ivrJmsTemplate") JmsTemplate ivrJmsTemplate) throws NamingException {
    DefaultMessageListenerContainer defaultMessageListenerContainer = new DefaultMessageListenerContainer();
    defaultMessageListenerContainer
        .setConnectionFactory(createSingleConnectionFactory(url, userName, password, jmsQueueCF));
    defaultMessageListenerContainer.setDestination(createTibjmsQueue(requestQueue));
    defaultMessageListenerContainer.setMessageListener(createIVRMessageListener());
    defaultMessageListenerContainer.setConcurrentConsumers(1);
    return defaultMessageListenerContainer;
  }

  private MessageListenerAdapter createIVRMessageListener() throws NamingException {
    MessageListenerAdapter messageListenerAdapter = new MessageListenerAdapter();
    messageListenerAdapter.setMessageConverter(createIVRMessageConverter());
    messageListenerAdapter.setDelegate(createIvrDelegate());
    messageListenerAdapter.setDefaultListenerMethod("processIvrRequest");
    return messageListenerAdapter;
  }

  @Bean
  @Conditional(LICEnvironment.class)
  public IVRDelegate createIvrDelegate() throws NamingException {
    return new IVRDelegate();
  }

  @Bean
  @Conditional(LICEnvironment.class)
  public MessageConverter createIVRMessageConverter() {
    return new IVRMessageConverter();
  }
}
