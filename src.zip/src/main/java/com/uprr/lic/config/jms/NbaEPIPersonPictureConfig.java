package com.uprr.lic.config.jms;

import java.net.UnknownHostException;
import java.util.Properties;

import javax.naming.NamingException;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jms.connection.SingleConnectionFactory;
import org.springframework.jms.connection.UserCredentialsConnectionFactoryAdapter;
import org.springframework.jndi.JndiTemplate;

import com.tibco.tibjms.TibjmsConnectionFactory;
import com.tibco.tibjms.TibjmsQueue;
import com.uprr.lic.config.xmf.XMFConfig;
import com.uprr.lic.config.xmf.util.XmfUtil;

@Configuration
public class NbaEPIPersonPictureConfig extends XMFConfig {

  // THIS IS A NON STANDARD XMF SERVICE AND DOES NOT RETURN STANDARD REPLY MESSAGE. THEREFORE USING THE SAME OLD WAY
  // OF CALLING SERVICE.

  @Bean(name = "pictureEPIQueue")
  @Qualifier("pictureEPIQueue")
  public TibjmsQueue createTibjmsQueue(@Value("${PICTURE_EPI_SERVICE_QUEUE}")
  final String requestQueueName) {
    return new TibjmsQueue(requestQueueName);
  }

  @Bean(name = "pictureEPIQueueConnectionFactory")
  @Qualifier("pictureEPIQueueConnectionFactory")
  public SingleConnectionFactory createNBATibjmsQueueConnectionFactory(@Value("${eqm.xmf.jms.password}")
  final String jmsPassword, @Value("${JAVA_NAMING_PROVIDER_URL}")
  final String jmsUrl, @Value("${EQM_XMF_FACTORYNAME}")
  final String jmsConnectionFactoryName, @Value("${eqm.xmf.jms.userId}")
  final String jmsUserName) throws NamingException, UnknownHostException {
    final JndiTemplate jndiTemplate = new JndiTemplate();
    final Properties environment = XmfUtil.buildJNDIProperties(jmsUrl, jmsUserName, jmsPassword);
    jndiTemplate.setEnvironment(environment);

    final TibjmsConnectionFactory jmsQueueCF = (TibjmsConnectionFactory) jndiTemplate.lookup(jmsConnectionFactoryName);
    final UserCredentialsConnectionFactoryAdapter userCredentialsConnectionFactory = createUserCredentialsConnectionFactory(
        jmsUserName, jmsPassword, jmsQueueCF);
    final SingleConnectionFactory singleConnectionFactory = new org.springframework.jms.connection.SingleConnectionFactory();
    singleConnectionFactory.setReconnectOnException(true);
    singleConnectionFactory.setClientId(XmfUtil.getJmsClientId(jmsUserName, jmsUserName));
    singleConnectionFactory.setTargetConnectionFactory(userCredentialsConnectionFactory);
    return singleConnectionFactory;
  }
}
