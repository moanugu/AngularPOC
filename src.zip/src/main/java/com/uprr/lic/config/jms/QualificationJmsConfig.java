package com.uprr.lic.config.jms;

import javax.naming.NamingException;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Conditional;
import org.springframework.context.annotation.Configuration;
import org.springframework.jms.listener.DefaultMessageListenerContainer;
import org.springframework.jms.listener.adapter.MessageListenerAdapter;
import org.springframework.jms.support.converter.MessageConverter;

import com.uprr.lic.licensing.jms.qualification.HscMedicalQualificationMessageConvertor;
import com.uprr.lic.licensing.jms.qualification.PsftQualificationMessageConvertor;
import com.uprr.lic.licensing.jms.qualification.QualificationDelegate;

@Configuration
public class QualificationJmsConfig extends JMSContextConfig {

	@Bean
	@Qualifier("qualificationListenerContainer")
	@Conditional(LICEnvironment.class)
	public DefaultMessageListenerContainer createQualificationListenerContainer(@Value("${HSC_NAMING_PROVIDER_URL}") String url,
			@Value("${JMS_USER_NAME}") String userName, @Value("${JMS_PASSWORD}") String password,
			@Value("${LMS_EEB_QUAL_MED_FACTORY_NAME}") String jmsQueueCF,
			@Value("${LMS_EEB_LEARNING_COMPLETION_QUEUE}") final String requestQueue) throws NamingException {

		DefaultMessageListenerContainer defaultMessageListenerContainer = new DefaultMessageListenerContainer();
		defaultMessageListenerContainer
				.setConnectionFactory(createSingleConnectionFactory(url, userName, password, jmsQueueCF));
		defaultMessageListenerContainer.setDestination(createTibjmsQueue(requestQueue));
		defaultMessageListenerContainer.setMessageListener(createMessageListener(url, userName, password, jmsQueueCF));
		defaultMessageListenerContainer.setConcurrentConsumers(1);
		return defaultMessageListenerContainer;
	}
	
	/**
	 * MessageListenerAdapter for LMS Qualification Service
	 * @param url
	 * @param userName
	 * @param password
	 * @param jmsQueueCF
	 * @return
	 * @throws NamingException
	 */
	private MessageListenerAdapter createMessageListener(String url, String userName, String password,
			String jmsQueueCF) throws NamingException {
		MessageListenerAdapter messageListenerAdapter = new MessageListenerAdapter();
		messageListenerAdapter.setMessageConverter(createQualificationMessageConverter());
		messageListenerAdapter.setDelegate(createQualificationDelegate());
		messageListenerAdapter.setDefaultListenerMethod("processQualification");
		return messageListenerAdapter;
	}
	
	@Bean
	@Qualifier("hscMedicalListenerContainer")
	@Conditional(LICEnvironment.class)
	public DefaultMessageListenerContainer createMedicalQualListenerContainer(@Value("${HSC_NAMING_PROVIDER_URL}") String url,
			@Value("${JMS_USER_NAME}") String userName, @Value("${JMS_PASSWORD}") String password,
			@Value("${LMS_EEB_QUAL_MED_FACTORY_NAME}") String jmsQueueCF,
			@Value("${LMS_EEB_HSC_MEDICAL_QUEUE}") final String requestQueue) throws NamingException {

		DefaultMessageListenerContainer defaultMessageListenerContainer = new DefaultMessageListenerContainer();
		defaultMessageListenerContainer
				.setConnectionFactory(createSingleConnectionFactory(url, userName, password, jmsQueueCF));
		defaultMessageListenerContainer.setDestination(createTibjmsQueue(requestQueue));
		defaultMessageListenerContainer.setMessageListener(createMedicalQualMessageListener());
		defaultMessageListenerContainer.setConcurrentConsumers(1);
		return defaultMessageListenerContainer;
	}

	
	/**
	 *  MessageListenerAdapter for Medical Qualification
	 * @return
	 * @throws NamingException
	 */
	private MessageListenerAdapter createMedicalQualMessageListener() throws NamingException {
		MessageListenerAdapter messageListenerAdapter = new MessageListenerAdapter();
		messageListenerAdapter.setMessageConverter(createMedicalQualMessageConverter());
		messageListenerAdapter.setDelegate(createQualificationDelegate());
		messageListenerAdapter.setDefaultListenerMethod("processQualification");
		return messageListenerAdapter;
	}

	@Bean
	@Conditional(LICEnvironment.class)
	public QualificationDelegate createQualificationDelegate() throws NamingException {
		return new QualificationDelegate();
	}

	
	@Bean
	@Conditional(LICEnvironment.class)
	public MessageConverter createQualificationMessageConverter() {
		return new PsftQualificationMessageConvertor();
	}

	
	@Bean
	@Conditional(LICEnvironment.class)
	public MessageConverter createMedicalQualMessageConverter() {
		return new HscMedicalQualificationMessageConvertor();
	}

}
