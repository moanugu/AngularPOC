package com.uprr.lic.config.spring.trn;

//import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * The Spring configuration file for the sample application.
 */
@Configuration
public class ServiceConfig {

	/**
	 * Initializes the Service Bean
	 */
//	@Bean
//	public SearchEventService createSearchEventService(IDecertificationService serviceImpl) {
//		return new SearchEventService();
//	}
//
//	@Bean
//	public IDecertificationService createDecertificationService() {
//		return new DecertificationServiceImpl();
//	}

	/**
	 * Initializes the Controller. Now the call the createTrainService will in
	 * fact return the singleton that Spring creates due the the @Bean
	 * annotation.
	 * 
	 * @param service
	 *            the TrainService fully initialized by Spring.
	 */
//	@Bean
//	public SearchEventController createTrainController() {
//		return new SearchEventController();
//	}
}
