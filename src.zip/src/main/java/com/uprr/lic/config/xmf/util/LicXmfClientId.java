package com.uprr.lic.config.xmf.util;

import com.uprr.netcontrol.frontend.client.xmf.XmfClientId;

public class LicXmfClientId implements XmfClientId {

  String jmsUserId;

  String udi;

  private static final String CN = "cn=";

  public static final String CLIENT_ID = ",ou=uprr,o=up";

  private static final String UPTD_UPRR_O_UP_UDI = ",ou=uprr,o=up,udi=";

  public LicXmfClientId(String jmsUserId, String udi) {
    this.jmsUserId = jmsUserId;
    this.udi = udi;
  }

  @Override
  public String getId() {

    if (udi == null || udi.isEmpty()) {
      return CN + jmsUserId + CLIENT_ID;
    }
    return CN + jmsUserId + UPTD_UPRR_O_UP_UDI + udi;
  }

}
