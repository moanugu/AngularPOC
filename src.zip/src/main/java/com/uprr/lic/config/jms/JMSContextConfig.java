package com.uprr.lic.config.jms;

import javax.naming.NamingException;

import org.springframework.jms.connection.SingleConnectionFactory;
import org.springframework.jms.connection.UserCredentialsConnectionFactoryAdapter;

import com.tibco.tibjms.TibjmsConnectionFactory;
import com.uprr.lic.config.xmf.XMFConfig;

public class JMSContextConfig extends XMFConfig {

	public SingleConnectionFactory createSingleConnectionFactory(String url, String userName, String password,
			String jmsQueueCF) throws NamingException {
		final SingleConnectionFactory singleConnectionFactory = new SingleConnectionFactory();
		singleConnectionFactory.setReconnectOnException(true);
		final TibjmsConnectionFactory connectionFactory = createTibjmsQueueConnectionFactory(url, userName, password,
				jmsQueueCF);
		final UserCredentialsConnectionFactoryAdapter userCredentialsConnectionFactory = createUserCredentialsConnectionFactory(
				userName, password, connectionFactory);
		singleConnectionFactory.setTargetConnectionFactory(userCredentialsConnectionFactory);
		return singleConnectionFactory;

	}
}
