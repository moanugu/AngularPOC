package com.uprr.lic.config.xmf.util;

import java.io.File;
import java.io.FileInputStream;
import java.util.Arrays;
import java.util.Calendar;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FileUtils;
import org.apache.xmlbeans.XmlException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.uprr.lic.dataaccess.Licensing.model.EmployeeDetailLicInit;
import com.uprr.lic.dataaccess.masters.service.ISysParamService;
import com.uprr.lic.doss.get.DossGetServiceClient;
import com.uprr.lic.doss.get.DossGetServiceClientXmfImpl;
import com.uprr.lic.doss.put.DossPutServiceClient;
import com.uprr.lic.doss.put.DossPutServiceClientXmfImpl;
import com.uprr.lic.doss.put.domain.DossPutServiceRequest;
import com.uprr.lic.doss.put.domain.DossPutServiceResponse;
import com.uprr.lic.exception.EqmException;
import com.uprr.lic.externalservice.xmf.service.EmailNotificationService;
import com.uprr.lic.externalservice.xmf.service.GetEPIPersonPictureService;
import com.uprr.lic.externalservice.xmf.service.LMSQualificationService;
import com.uprr.lic.externalservice.xmf.service.PersonDataService;
import com.uprr.lic.externalservice.xmf.service.QualificationService;
import com.uprr.lic.licensing.rest.controller.MVRAndNDRController;
import com.uprr.lic.person.PersonDataServiceClientXmfImpl;
import com.uprr.lic.person.job_history.JobHistoryGetServiceClient;
import com.uprr.lic.person.job_history.JobHistoryGetServiceClientXmfImpl;
import com.uprr.lic.save_discipline.SaveDisciplineInvestigationClient;
import com.uprr.lic.save_discipline.SaveDisciplineInvestigationClientXmfImpl;
import com.uprr.lic.save_discipline.domain.IncidentInfoRequest;
import com.uprr.lic.save_discipline.domain.InvestigationRequest;
import com.uprr.lic.save_discipline.domain.SourceEventInfo;
import com.uprr.lic.save_discipline.domain.SourceEventStatusType;
import com.uprr.lic.save_discipline.domain.SourceSystemType;
import com.uprr.lic.send_lata_message.PrintLataClient;
import com.uprr.lic.send_lata_message.PrintLataXmfImpl;
import com.uprr.lic.send_myUp_messaging.SendMyUpMessagingClient;
import com.uprr.lic.send_myUp_messaging.SendMyUpMessagingClientXmfImpl;
import com.uprr.lic.send_myUp_messaging.domain.MyUpRequest;
import com.uprr.lic.send_myUp_messaging.domain.PriorityEnum;
import com.uprr.lic.service_qualification.GetQualificationService;
import com.uprr.lic.service_qualification.GetQualificationServiceXmfImpl;
import com.uprr.lic.service_qualification.domain.GetQualificationRequest;
import com.uprr.lic.service_qualification.domain.GetQualificationResponse;
import com.uprr.netcontrol.frontend.client.xmf.XmfClientInvoker;
import com.uprr.netcontrol.shared.xml_bindings.jaxb2.get_qualifications.QualificationCategoryType;
import com.uprr.sft.send_notification.SendNotificationClient;
import com.uprr.sft.send_notification.SendNotificationClientXmfImpl;
import com.uprr.sft.send_notification.domain.NotificationModeEnum;
import com.uprr.sft.send_notification.domain.SendNotificationRequest;

//Please add any new service to the list here: http://wiki.www.uprr.com/confluence/display/~xsat414/LIC+XMF+Services
@Service
public class XMFTestHelper {
  Logger logger = LoggerFactory.getLogger(XMFTestHelper.class);

  @Autowired
  EmailNotificationService emailNotificationService;

  @Autowired
  @Qualifier("dossGetXmfClientInvoker")
  XmfClientInvoker dosGetInvoker;

  @Autowired
  @Qualifier("dossPutXmfClientInvoker")
  XmfClientInvoker dosPutInvoker;

  @Autowired
  @Qualifier("secureInvokerEqm")
  XmfClientInvoker secureInvokerEqm;

  @Autowired
  @Qualifier("eqmXmfClientInvoker")
  XmfClientInvoker eqmXmfClientInvoker;

  @Autowired
  @Qualifier("jobHistoryXmfClientInvoker")
  XmfClientInvoker jobHistoryXmfClientInvoker;

  @Autowired
  PersonDataService personDataService;

  @Autowired
  private LMSQualificationService lmsQualificationService;

  @Autowired
  private QualificationService qualificationService;

  @Autowired
  ISysParamService iSysParamService;
  
  @Autowired
  GetEPIPersonPictureService nbaEpiPersonPictureService;
  
  @Autowired
  MVRAndNDRController mvrAndNDRController;
  
  @Autowired
  HttpServletResponse httpServletResponse;
  
  public String testDosGetService(String gufnID) {
    try {
      DossGetServiceClient client = new DossGetServiceClientXmfImpl(dosGetInvoker);
      client.getDataDocumentAsByteArray(gufnID);
      return successMessage("lic-onb-data-object-get-1_0");
    } catch (Exception e) {
      logger.error("lic-onb-data-object-get-1_0", e.getMessage());
      return errorMessage("lic-onb-data-object-get-1_0", e.getMessage());
    }
  }

  public String testDosPutService() {
    try {
      DossPutServiceClient client = new DossPutServiceClientXmfImpl(dosPutInvoker);
      String instanseId = "DEV01";
      String moduleBusinessType = "DE";
      String fileName = "testDosPut.xml";
      String ownerId = "UP";
      String producerId = "EQMS";

      File file = new File("testDosPut.xml");
      FileUtils.writeStringToFile(file, "Test file for doss put");
      // Get file from resources folder
      byte[] bytesArray = new byte[(int) file.length()];

      FileInputStream fis = new FileInputStream(file);
      fis.read(bytesArray); // read file into bytes[]
      fis.close();

      DossPutServiceRequest request = new DossPutServiceRequest(instanseId, moduleBusinessType, fileName, bytesArray,
          ownerId, producerId, producerId);
      DossPutServiceResponse putDataDocumentAndGetGUFN = client.putDataDocumentAndGetGUFN(request);
      file.delete();
      return successMessage("GUFN ID :" + putDataDocumentAndGetGUFN.getGufn() + " lic-onb-data-object-put-1_0");
    } catch (Exception e) {
      logger.error("lic-onb-data-object-put-1_0", e.getMessage());
      return errorMessage("lic-onb-data-object-put-1_0", e.getMessage());
    }
  }

  public String testgetEmployeeDetails() {
    PersonDataServiceClientXmfImpl personDataServiceClient = new PersonDataServiceClientXmfImpl(eqmXmfClientInvoker);
    personDataServiceClient.getEmployeesDetail("0438242");
    return successMessage("lic-person-get-employee-details-3_0");
  }

  public String testjobHistory() {
    JobHistoryGetServiceClient jobHistoryGetServiceClien = new JobHistoryGetServiceClientXmfImpl(
        jobHistoryXmfClientInvoker);
    jobHistoryGetServiceClien.getJobHistoryInfo("0448655");
    return successMessage("person-get-job-history-1.0");
  }

  // UNUSED ONLY NBA PICTURE SERVICE IS USED
  public String testGetPicture() {
    return successMessage("person-get-picture-1.0 ::: UNUSED ONLY NBA PICTURE SERVICE IS USED");
  }

  public String testNBAgetEmployeePhoto() {
    nbaEpiPersonPictureService.getEPIPersonPicture("0448655");
    return successMessage("nbaEpiPersonPictureService");
  }

  public String testQualificationService() {
    try {
      GetQualificationService client = new GetQualificationServiceXmfImpl(secureInvokerEqm);
      GetQualificationRequest qualificationRequest = new GetQualificationRequest();
      qualificationRequest.setEmplId("0189889");
      String[] pinsCodeList = new String[1];
      pinsCodeList[0] = "OR6A";
      qualificationRequest.setPinsCodeList(pinsCodeList);
      qualificationRequest.setQualCategory(QualificationCategoryType.TEST);
      GetQualificationResponse qualificationResponse = client.getQualificationDetails(qualificationRequest);
      return successMessage("get-qualifications");

    } catch (XmlException e) {
      logger.error("get-qualifications invoker", e.getMessage());
      return errorMessage("get-qualifications", e.getMessage());
    }
  }

  public String testsearchLearningHistory() {
    try {
      lmsQualificationService.getLearningHistory("9000018", "OC20,OB3F", "EXAM,COURSE");
      return successMessage("search-learning-history");
    } catch (EqmException e) {
      logger.error("search-learning-history", e.getMessage());
      return errorMessage("search-learning-history", e.getMessage());
    }
  }

  public String testMedicalQualification() {
    try {
      lmsQualificationService.getMedicalQualification("0402295", null, null);
      return successMessage("get-medical-qualifications/1.0");
    } catch (EqmException e) {
      logger.error("get-medical-qualifications/1.0", e.getMessage());
      return errorMessage("get-medical-qualifications/1.0", e.getMessage());
    }
  }

  public EmployeeDetailLicInit testGetQualificationService(String employeeId) {
    EmployeeDetailLicInit employeeDetailLicInit = new EmployeeDetailLicInit();
    employeeDetailLicInit.setEmployeeID(employeeId);
    employeeDetailLicInit = qualificationService.getEmployeeTestDetails(employeeDetailLicInit,
        iSysParamService.getAllSystemParameter(), "OP1Z");
    return employeeDetailLicInit;
  }
  
  	public void testDownloadMVRForm() {
	  	mvrAndNDRController.downloadMVRForm("{08C14708-C463-4929-A9F0-594FBCD4D1A1}", null, httpServletResponse);
	    return;
	  }
  
  public String testDisciplineInvestigation() {
    SaveDisciplineInvestigationClient client = new SaveDisciplineInvestigationClientXmfImpl(eqmXmfClientInvoker);
    InvestigationRequest request = new InvestigationRequest();
  
    SourceEventInfo sourceEventInfo = new SourceEventInfo();
    sourceEventInfo.setSourceSystem(SourceSystemType.EQMS);
    sourceEventInfo.setSourceEventStatus(SourceEventStatusType.DECERTIFIED);
    sourceEventInfo.setSourceSystemInternalId("26337");
    request.setSourceEventInfo(sourceEventInfo);
    
    IncidentInfoRequest incidentInfo = new IncidentInfoRequest();
    incidentInfo.setIncidentDate(Calendar.getInstance());
    incidentInfo.setIncidentDescription("Desc");
    request.setIncidentInfo(incidentInfo);
    
    request.setInvolvedPersonEmployeeId("0481471");
    
    
    request.setEmployeeId("0448655");
    client.sendMessageToDDMS(request);
    return successMessage("save-discipline-investigation-info");
  }

  public String testMyupService() {
    try {
      SendMyUpMessagingClient client = new SendMyUpMessagingClientXmfImpl(eqmXmfClientInvoker);
      MyUpRequest request = new MyUpRequest();
      request.setSenderId("DEQM999");
      request.setSenderName("ECL");
      request.setMessageSubject("EPI Photo Required");
      request.setMessageContent(
          "Employee Photo Identification and Credentials (EPI) photo is required. Please contact your manager to obtain a new photo.");
      request.setMessagePriority(PriorityEnum.MEDIUM);
      request.setEmployeeIdList(Arrays.asList("0452084", "0448655"));
      request.setExpiresOn(Calendar.getInstance());
      request.setDeliverOn(Calendar.getInstance());
      client.sendMessageMyUpRequest(request);
      return successMessage("send-enterprise-notification");

    } catch (Exception e) {
      logger.error("testMyup Failed, ", e.getMessage());
      return errorMessage("send-enterprise-notification", e.getMessage());
    }
  }

  public String testSendLataMessage() {
    PrintLataClient client = new PrintLataXmfImpl(eqmXmfClientInvoker);
    client.sendToLata("0452084", "N101082", "test Send Lata Message working!");
    return successMessage("utility-send-lata-message-1.0");
  }

  public String testEmailNotifcation() {
    try {
      SendNotificationRequest emailRequest = new SendNotificationRequest();
      emailRequest.setPublisherId("cn=deqm999,ou=uprr,o=up");
      emailRequest.setSenderFromAddress("EQMSTechSupport@up.com");
      emailRequest.setSenderName("EQMS(Employee Quality Management System)");
      emailRequest.setSenderReplyAddress("NoReply@up.com");
      emailRequest.setMimeType("text/html");
      emailRequest.setNotificationMode(NotificationModeEnum.EMAIL);
      emailRequest.setPublisherId("cn=deqm999,ou=uprr,o=up");
      emailRequest.setDescription("Test desc");
      emailRequest.setRecipientEmailAddressess(Arrays.asList("mbhide@upcontractor.up.com"));
      emailRequest.setSubject("Test XMF");
      emailRequest.setContent("Email notification working");

      SendNotificationClient sendNotificationClient = new SendNotificationClientXmfImpl(eqmXmfClientInvoker);
      sendNotificationClient.sendEmailNotification(emailRequest);
      return successMessage("send-enterprise-notification");
    } catch (Exception e) {
      logger.error("send-enterprise-notification", e.getMessage());
      return errorMessage("send-enterprise-notification", e.getMessage());
    }
  }

  private String successMessage(String serviceName) {
    return serviceName + " request completed successfully. Please check logs for request and reply messages";
  }

  private String errorMessage(String serviceName, String error) {
    return "Failed to execute " + serviceName + " request . \n" + error
        + "\nPlease check logs for request and reply messages";
  }

}
