package com.uprr.lic.config.spring.common;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.format.FormatterRegistrar;
import org.springframework.format.support.FormattingConversionService;
import org.springframework.format.support.FormattingConversionServiceFactoryBean;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.method.support.HandlerMethodArgumentResolver;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurationSupport;
import org.springframework.web.servlet.mvc.WebContentInterceptor;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.hibernate4.Hibernate4Module;
import com.uprr.enterprise.datetime.jackson2.serialization.UTCDateTimeCoreModule2;
import com.uprr.enterprise.datetime.springmvc.UTCDateTimeFormatterRegistrar;
import com.uprr.enterprise.i18n.UPRRTranslator;
import com.uprr.lic.auth.SessionInterceptor;
import com.uprr.lic.error.UPAlertErrorInterceptor;
import com.uprr.ui.shared.user.spring.mvc.ActiveUserHandlerMethodArgumentResolver;

@Import({ I18NConfig.class })
@Configuration
public class MVCConfig extends WebMvcConfigurationSupport {

  private Logger LOGGER = LoggerFactory.getLogger(MVCConfig.class);

  /**
   * Creates a default error handler for all controllers.
   * 
   * @param translator
   *          is declared in the I18NConfig class
   */

  @Bean
  public UPAlertErrorInterceptor createUPAlertErrorInterceptor(UPRRTranslator translator) {
    return new UPAlertErrorInterceptor(translator);
  }

  @Bean
  public SessionInterceptor getSessionInterceptor() {
    return new SessionInterceptor();
  }

  /**
   * Adds the ArgumentResolver that allows @ActiveUser annotation to inject the ActiveUserId in Controller methods.
   */
  @Override
  public void addArgumentResolvers(final List<HandlerMethodArgumentResolver> argumentResolvers) {
    argumentResolvers.add(new ActiveUserHandlerMethodArgumentResolver());
    super.addArgumentResolvers(argumentResolvers);
  }

  /**
   * Disabling client side caching for proper REST call handling
   */
  @Override
  public void addInterceptors(final InterceptorRegistry registry) {
    registry.addInterceptor(buildWebContentInterceptor());
    registry.addInterceptor(getSessionInterceptor());
    super.addInterceptors(registry);
  }

  private HandlerInterceptor buildWebContentInterceptor() {
    final WebContentInterceptor interceptor = new WebContentInterceptor();
    interceptor.setCacheSeconds(0);
    return interceptor;
  }

  /**
   * Adds uprr-date-time Jackson converters
   */
  @Override
  public void configureMessageConverters(final List<HttpMessageConverter<?>> converters) {
    converters.add(jsonConverter());
    super.addDefaultHttpMessageConverters(converters); // enables other defaults to continue to function
  }

  @Bean
  public MappingJackson2HttpMessageConverter jsonConverter() {
    final MappingJackson2HttpMessageConverter converter = new MappingJackson2HttpMessageConverter();
    final ObjectMapper mapper = new ObjectMapper();
    mapper.registerModule(new UTCDateTimeCoreModule2());
    mapper.registerModule(new Hibernate4Module());
    converter.setObjectMapper(mapper);
    return converter;
  }

  @Override
  public FormattingConversionService mvcConversionService() {
    return getConversionService().getObject();
  }

  /**
   * Adds uprr-date-time formatters
   */
  @Bean
  public FormattingConversionServiceFactoryBean getConversionService() {
    final FormattingConversionServiceFactoryBean fb = new FormattingConversionServiceFactoryBean();
    final Set<FormatterRegistrar> formatterRegistrars = new HashSet<FormatterRegistrar>();
    formatterRegistrars.add(new UTCDateTimeFormatterRegistrar());
    fb.setFormatterRegistrars(formatterRegistrars);
    return fb;
  }

}
