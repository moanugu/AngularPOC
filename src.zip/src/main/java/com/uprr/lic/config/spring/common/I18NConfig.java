package com.uprr.lic.config.spring.common;

import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ResourceBundleMessageSource;

import com.uprr.enterprise.i18n.UPRRTranslator;
import com.uprr.enterprise.i18n.spring.UPRRTranslatorSpringMessageSourceImpl;

/**
 * The Internationalization Spring Configuration
 */
@Configuration
public class I18NConfig {
	
    @Bean
	public MessageSource translationMessageSource() {
		final ResourceBundleMessageSource source = new ResourceBundleMessageSource();
		source.setBasenames("i18n/messages");  //Look in src/main/resources/i18n for messages[_*].properties
		source.setUseCodeAsDefaultMessage(true);  //returns the lookup code if no message is found 
		source.setFallbackToSystemLocale(false);
		return source;
	}
	
	@Bean
	public UPRRTranslator createTranslator(MessageSource translationMessageSource) {
	    return new UPRRTranslatorSpringMessageSourceImpl(translationMessageSource);
	}
}
