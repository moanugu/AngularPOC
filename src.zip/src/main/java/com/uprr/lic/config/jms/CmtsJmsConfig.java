package com.uprr.lic.config.jms;

import javax.naming.NamingException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jms.core.JmsTemplate;

import com.uprr.lic.decert.jms.cmts.EmployeeLicenseRestrictionSender;
import com.uprr.lic.decert.jms.cmts.PendingRulesSender;

@Configuration
public class CmtsJmsConfig extends JMSContextConfig {
	@Autowired
	@Qualifier("cmtsJmsTemplate")
	private JmsTemplate cmtsJmsTemplate;

	@Autowired
	@Qualifier("cmtsLicensingJmsTemplate")
	private JmsTemplate cmtsLicensingJmsTemplate;

	@Bean
	@Qualifier("cmtsLicensingJmsTemplate")
	public JmsTemplate createCMTSLicensingJmsTemplate(@Value("${CMTS_JAVA_NAMING_PROVIDER_URL}") String url,
			@Value("${JMS_USER_NAME}") String userName, @Value("${JMS_PASSWORD}") String password,
			@Value("${EQM_XMF_FACTORYNAME}") String jmsQueueCF,
			@Value("${CMTS_REQ_LIC_QUEUE}") final String requestQueue) throws NamingException {
		JmsTemplate jmsTemplate = new JmsTemplate();
		jmsTemplate.setConnectionFactory(createSingleConnectionFactory(url, userName, password, jmsQueueCF));
		jmsTemplate.setDefaultDestination(createTibjmsQueue(requestQueue));
		return jmsTemplate;
	}

	@Bean
	@Qualifier("cmtsJmsTemplate")
	public JmsTemplate createCMTSJmsTemplate(@Value("${CMTS_JAVA_NAMING_PROVIDER_URL}") String url,
			@Value("${JMS_USER_NAME}") String userName, @Value("${JMS_PASSWORD}") String password,
			@Value("${EQM_XMF_FACTORYNAME}") String jmsQueueCF, @Value("${CMTS_REQ_QUEUE}") final String requestQueue)
			throws NamingException {
		JmsTemplate jmsTemplate = new JmsTemplate();
		jmsTemplate.setConnectionFactory(createSingleConnectionFactory(url, userName, password, jmsQueueCF));
		jmsTemplate.setDefaultDestination(createTibjmsQueue(requestQueue));
		return jmsTemplate;
	}

	@Bean
	public PendingRulesSender createPendingRuleService() throws NamingException {

		return new PendingRulesSender(cmtsJmsTemplate);
	}

	@Bean
	public EmployeeLicenseRestrictionSender createEmployeeLicenseRestrictionSender() throws NamingException {

		return new EmployeeLicenseRestrictionSender(cmtsLicensingJmsTemplate);
	}
}
