package com.uprr.lic.config.spring;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.transaction.annotation.EnableTransactionManagement;

/**
 * This is the hub "Main" config, the first configuration file triggered by the ApplicationInitializer
 */
@Configuration
@ComponentScan("com.uprr.lic")
@EnableTransactionManagement
@PropertySource({ "classpath:${uprr.implementation.environment}.properties", "classpath:default.properties",
    "classpath:xmf-client.properties" })
@ImportResource({ "classpath:HibernateApplicationContext.xml", "classpath:ConnectionPoolDataSource.xml",
    "classpath:ExternalJdbcTemplatesApplicationContext.xml", "classpath:EqmTransactionApplicationContext.xml" })
public class MainConfig {

  @Bean
  public static PropertySourcesPlaceholderConfigurer propertySourcesPlaceholderConfigurer() {
    return new PropertySourcesPlaceholderConfigurer();
  }

}
