package com.uprr.lic.config.xmf;

import java.security.KeyStoreException;
import java.util.Collections;

import org.acegisecurity.providers.ProviderManager;
import org.acegisecurity.providers.x509.X509AuthenticationProvider;
import org.acegisecurity.providers.x509.populator.DaoX509AuthoritiesPopulator;
import org.springframework.aop.target.CommonsPoolTargetSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

import com.uprr.app.xmf.client.security.core.IdentityUserDetailsService;
import com.uprr.lic.config.xmf.util.XmfSecurityHandler;
import com.uprr.netcontrol.frontend.client.xmf.XmfClientInvoker;
import com.uprr.netcontrol.frontend.client.xmf.XmfClientInvokerSecurityCertificateImpl;

/**
 * These are Secure XMF client Configurations specialized for use with NFE
 * Applications (specifically our XmfClientInvoker).
 */
@Configuration
@Import({ XmfSecurityHandler.class })
public class EqmXmfSecureConfig {
	@Autowired
	private DaoX509AuthoritiesPopulator x509AuthoritiesPopulator;

	@Autowired
	@Qualifier("eqmServiceProxyPool")
	private CommonsPoolTargetSource eqmServiceProxyPool;

	@Bean
	public DaoX509AuthoritiesPopulator createDaoX509AuthoritiesPopulator() {
		DaoX509AuthoritiesPopulator x509AuthoritiesPopulator = new DaoX509AuthoritiesPopulator();
		x509AuthoritiesPopulator.setUserDetailsService(new IdentityUserDetailsService());
		return x509AuthoritiesPopulator;
	}

	@Bean(name = "secureInvokerEqm")
	public XmfClientInvoker createXMFClientInvokerEQM(@Value("${eqm.xmf.jms.userId}") String userId)
			throws KeyStoreException {
		return new XmfClientInvokerSecurityCertificateImpl(userId, eqmServiceProxyPool, createAuthenticationManager(),
				XmfSecurityHandler.EQM_CERTIFICATE_ALIAS, XmfSecurityHandler.EQM_KEYSTORE_FILENAME,
				XmfSecurityHandler.EQM_KEYSTORE_PASSWORD, "lic");
	}


	@Bean(name = "secureMedicalInvoker")
	public XmfClientInvoker createXMFSecureMedicalInvokerLIC(@Value("${eqm.xmf.jms.userId}") String userId)
			throws KeyStoreException {
		return new XmfClientInvokerSecurityCertificateImpl(userId, eqmServiceProxyPool, createAuthenticationManager(),
				XmfSecurityHandler.EQM_CERTIFICATE_ALIAS, XmfSecurityHandler.EQM_KEYSTORE_FILENAME,
				XmfSecurityHandler.EQM_KEYSTORE_PASSWORD, "medical-qualification");
	}

	private ProviderManager createAuthenticationManager() {
		ProviderManager mgr = new ProviderManager();
		X509AuthenticationProvider x509Provider = new X509AuthenticationProvider();
		x509Provider.setX509AuthoritiesPopulator(x509AuthoritiesPopulator);
		mgr.setProviders(Collections.singletonList(x509Provider));
		return mgr;
	}

}
