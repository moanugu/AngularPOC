package com.uprr.lic.config.xmf;

import java.util.Properties;

import javax.naming.NamingException;

import org.springframework.jms.connection.UserCredentialsConnectionFactoryAdapter;
import org.springframework.jndi.JndiTemplate;

import com.tibco.tibjms.TibjmsConnectionFactory;
import com.tibco.tibjms.TibjmsQueue;
import com.uprr.lic.config.xmf.util.XmfUtil;

public class XMFConfig {
	public static final boolean POOL_IS_LAZY = false;

	public UserCredentialsConnectionFactoryAdapter createUserCredentialsConnectionFactory(final String username,
			final String password, final TibjmsConnectionFactory jmsQueueCF) {
		final UserCredentialsConnectionFactoryAdapter userCredentialsConnectionFactoryAdapter = new UserCredentialsConnectionFactoryAdapter();
		userCredentialsConnectionFactoryAdapter.setTargetConnectionFactory(jmsQueueCF);
		userCredentialsConnectionFactoryAdapter.setUsername(username);
		userCredentialsConnectionFactoryAdapter.setPassword(password);
		return userCredentialsConnectionFactoryAdapter;
	}

	public TibjmsConnectionFactory createTibjmsQueueConnectionFactory(final String url, final String userId,
			final String password, final String connectionFactoryName) throws NamingException {
		final JndiTemplate jndiTemplate = new JndiTemplate();
		final Properties environment = XmfUtil.buildJNDIProperties(url, userId, password);
		jndiTemplate.setEnvironment(environment);
		return (TibjmsConnectionFactory) jndiTemplate.lookup(connectionFactoryName);
	}

	public TibjmsQueue createTibjmsQueue(final String requestQueueName) {
		return new TibjmsQueue(requestQueueName);
	}
}
