package com.uprr.lic.config.spring;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.uprr.ui.shared.user.spring.mvc.UserValidationFilter;

/**
 * This configuration file contains ServletFilters 
 * that will be used by the DelegatingFilterProxy in the ApplicationInitializer
 * Note the bean name given each filter must match the name of the filter in the application context 
 */
@Configuration
public class FilterConfig {
    
    public static final String USER_VALIDATION_FILTER = "userValidationFilter";
    
    @Bean(name=USER_VALIDATION_FILTER)
    public UserValidationFilter createUserValidationFilter() {
        return new UserValidationFilter();
    }
}
