/**
 * Classname    : XmfContextConfig
 * Description  : 
 * author   : Tech Mahindra Ltd.
 * Date of creation :
 *
 * Change History
 * ------------------------------------------------------------  
 *   Date           Changed By    Description
 * ------------------------------------------------------------  
 *  25-Apr-2017    xsat794      Modified for Denial of Certification bundled QCs(SS_QC#5120) 
 *
 * ------------------------------------------------------------  
 *
 * Copyright notice : "Copyright UPRR 2008"
 */
package com.uprr.lic.config.xmf;

import java.net.UnknownHostException;
import java.util.Collections;

import javax.naming.NamingException;

import org.springframework.aop.target.CommonsPoolTargetSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.jms.connection.SingleConnectionFactory;
import org.springframework.jms.connection.UserCredentialsConnectionFactoryAdapter;

import com.tibco.tibjms.TibjmsConnectionFactory;
import com.uprr.app.xmf.MessageUtilities;
import com.uprr.app.xmf.RequestHandler;
import com.uprr.app.xmf.StaxMessageUtilities;
import com.uprr.app.xmf.client.ServiceProxy;
import com.uprr.app.xmf.client.ServiceProxyException;
import com.uprr.app.xmf.client.core.ServiceProxyFactoryImpl;
import com.uprr.lic.config.xmf.util.LicXmfClientId;
import com.uprr.lic.config.xmf.util.XmfUtil;
import com.uprr.netcontrol.businesstransactiontracingxmftoolkit.BttXmfServiceProxyFactoryImpl;
import com.uprr.netcontrol.frontend.client.xmf.XmfClientInvoker;
import com.uprr.netcontrol.frontend.client.xmf.XmfClientInvokerImpl;
import com.uprr.netcontrol.frontend.client.xmf.siteminder.security.SiteMinderStandaloneToken;
import com.uprr.netcontrol.frontend.client.xmf.siteminder.security.SiteMinderToken;

@Configuration
public class EqmXmfContextConfig extends XMFConfig {

  private static final String SERVICE_PROXY_BEAN_NAME = "licServiceProxy";

  @Autowired
  @Qualifier("eqmServiceProxyFactory")
  private ServiceProxyFactoryImpl eqmServiceProxyFactory;

  @Autowired(required = false)
  @Qualifier("eqmSecurityHandler")
  private RequestHandler securityHandler;

  @Autowired
  @Qualifier("eqmServiceProxyPool")
  private CommonsPoolTargetSource eqmServiceProxyPool;

  @Autowired
  @Qualifier("siteMinderToken")
  private SiteMinderToken siteMinderToken;

  /**
   * The XmfServiceProxyPool for use in XMF Client creation.
   *
   * @param maxSize
   * @param maxIdle
   * @param maxWait
   * @param whenExhaustedActionName
   * @param timeBetweenEvictionRunsMillis
   * @param minEvictableIdleTimeMillis
   * @return
   */
  @Bean(name = "eqmServiceProxyPool")
  public CommonsPoolTargetSource createTargetSource(@Value("${xmf.proxypool.size.max}") final int maxSize,
			@Value("${xmf.proxypool.size.idle}") final int maxIdle,
			@Value("${xmf.proxypool.wait.time}") final long maxWait,
      @Value("${xmf.proxypool.action}") final String whenExhaustedActionName,
      @Value("${xmf.proxypool.evictionRunTime}") final long timeBetweenEvictionRunsMillis,
      @Value("${xmf.serviceProxy.evictableIdleTime}") final long minEvictableIdleTimeMillis) {
    final CommonsPoolTargetSource proxyPool = new CommonsPoolTargetSource();
    proxyPool.setTargetBeanName(SERVICE_PROXY_BEAN_NAME);
    proxyPool.setMaxSize(maxSize);
    proxyPool.setMaxIdle(maxIdle);
    proxyPool.setMaxWait(maxWait);
    proxyPool.setTimeBetweenEvictionRunsMillis(timeBetweenEvictionRunsMillis);
    proxyPool.setMinEvictableIdleTimeMillis(minEvictableIdleTimeMillis);
    proxyPool.setWhenExhaustedActionName(whenExhaustedActionName);
    // proxyPool.setBlockWhenExhausted(true);
    return proxyPool;
  }

  /**
	 * This PROTOTYPE method is invoked each time the ServiceProxy pool is
	 * empty.
   *
   * @return a new Service Proxy
   * @throws ServiceProxyException
   */
  @Bean(name = SERVICE_PROXY_BEAN_NAME, destroyMethod = "close")
  @Scope(value = BeanDefinition.SCOPE_PROTOTYPE)
  public ServiceProxy createServiceProxy(@Value("${xmf.jms.request.queue}") final String requestQueueName)
      throws ServiceProxyException {
    final ServiceProxy proxy = eqmServiceProxyFactory.createServiceProxy();
    proxy.setRequestDestination(createTibjmsQueue(requestQueueName));
    if (securityHandler != null) {
      proxy.setRequestHandlers(Collections.singletonList(securityHandler));
    }
    return proxy;
  }

  @Bean(name = "messageUtilities")
  public MessageUtilities createMessageUtilities() {
    return new StaxMessageUtilities();
  }

  /**
   * Business Transaction Tracing based factory for XMF
   *
   * @param jmsUserName
   * @param jmsPassword
   * @param jmsUrl
   * @param jmsConnectionFactoryName
   * @param jmsClientId
   * @return
   * @throws ServiceProxyException
   * @throws NamingException
   */
  @Bean(name = "eqmServiceProxyFactory")
	public ServiceProxyFactoryImpl createEqmServiceProxyFactory(@Value("${eqm.xmf.jms.password}") final String jmsPassword,
      @Value("${JAVA_NAMING_PROVIDER_URL}") final String jmsUrl,
      @Value("${xmf.jms.connectionFactoryName}") final String jmsConnectionFactoryName,
      @Value("${app.name}") final String appName, @Value("${eqm.xmf.jms.userId}") final String jmsUserName)
          throws ServiceProxyException, NamingException, UnknownHostException {
    final TibjmsConnectionFactory jmsQueueCF = createTibjmsQueueConnectionFactory(jmsUrl, jmsUserName, jmsPassword,
        jmsConnectionFactoryName);
    final UserCredentialsConnectionFactoryAdapter userCredentialsConnectionFactory = createUserCredentialsConnectionFactory(
        jmsUserName, jmsPassword, jmsQueueCF);
    final SingleConnectionFactory singleConnectionFactory = new org.springframework.jms.connection.SingleConnectionFactory();
    singleConnectionFactory.setReconnectOnException(true);
    singleConnectionFactory.setClientId(XmfUtil.getJmsClientId(jmsUserName, appName));
    singleConnectionFactory.setTargetConnectionFactory(userCredentialsConnectionFactory);
    return new BttXmfServiceProxyFactoryImpl(singleConnectionFactory, POOL_IS_LAZY);
  }

  @Bean(name = "eqmXmfClientInvoker")
  public XmfClientInvoker createEqmXMFClientInvoker(@Value("${eqm.xmf.jms.userId}") final String jmsUserName,
      @Value("${app.name}") final String appName) {
    return new XmfClientInvokerImpl(new LicXmfClientId(jmsUserName, jmsUserName), eqmServiceProxyPool, appName);
  }

  // Denial of Certification bundled QCs(SS_QC#5120) :Start
  /**
	   * 
   * This method is used to create site minder token
   *
   * @param smUserId
   * @param smPassword
   * @return SiteMinderToken
   * @author xsat794
   * @since Jul 6, 2017
   */
  @Bean(name = "siteMinderToken")
  @Scope(value = "session", proxyMode = ScopedProxyMode.TARGET_CLASS)
	  public static SiteMinderToken createSiteMinderToken(@Value("${eqm.xmf.jms.userId}") final String smUserId,
	    @Value("${eqm.xmf.siteminder.password}") final String smPassword) {
    SiteMinderToken siteMinderToken = null;
    // if the environment is local then we need to change it dev in order to site minder object. Once done we need to
    // again change it back to local so that other objects gets created as expected.
    if (null != System.getProperty("uprr.implementation.environment")
        && "local".equalsIgnoreCase(System.getProperty("uprr.implementation.environment"))) {
      System.setProperty("uprr.implementation.environment", "dev");
      siteMinderToken = new SiteMinderStandaloneToken(smUserId, smPassword);
      System.setProperty("uprr.implementation.environment", "local");
    } else {
      siteMinderToken = new SiteMinderStandaloneToken(smUserId, smPassword);
    }
    return siteMinderToken;
  }

  /**
	   * 
   * This method is used to create invoker for site minder token
   *
   * @param jmsUserName
   * @param udi
   * @param appName
   * @return XmfClientInvoker
   * @author xsat794
   * @since Jul 6, 2017
   */
  @Bean(name = "xmfFilenetClientInvoker")
	  public XmfClientInvoker createXMFFilenetClientInvoker(@Value("${eqm.xmf.jms.userId}")
	  final String jmsUserName, @Value("${eqm.xmf.jms.userId}")
	  final String udi, @Value("${app.name}")
	  final String appName) {
	    return new XmfClientInvokerImpl(new LicXmfClientId(jmsUserName, null), eqmServiceProxyPool, appName);
  }
  // Denial of Certification bundled QCs(SS_QC#5120) :End
  
  
  /**
   * This method is used to create invoker to access MVR document
   *
   * @param jmsUserName
   * @param udi
   * @param appName
   * @return XmfClientInvoker
   * @author xsat956
   * @since OCT 11, 2017
   */
  @Bean(name = "xmfMVRFilenetClientInvoker")
  public XmfClientInvoker createXMFMVRFilenetClientInvoker(@Value("${mvr.xmf.jms.userId}") final String jmsUserName,
      @Value("${mvr.xmf.jms.userId}") final String udi, @Value("${app.name}") final String appName) {
    return new XmfClientInvokerImpl(new LicXmfClientId(jmsUserName, null), eqmServiceProxyPool, appName);
  }
  
  /**
   * This method is used to create site minder token for MVR
   *
   * @param smUserId
   * @param smPassword
   * @return SiteMinderToken
   * @author xsat794
   * @since Jul 6, 2017
   */
  @Bean(name = "mvrSiteMinderToken")
  @Scope(value = "session", proxyMode = ScopedProxyMode.TARGET_CLASS)
  public static SiteMinderToken createMvrSiteMinderToken(@Value("${eqm.xmf.jms.userId}") final String smUserId,
      @Value("${mvr.xmf.siteminder.password}") final String smPassword) {
    SiteMinderToken siteMinderToken = null;
    // if the environment is local then we need to change it dev in order to site minder object. Once done we need to
    // again change it back to local so that other objects gets created as expected.
    if (null != System.getProperty("uprr.implementation.environment")
        && "local".equalsIgnoreCase(System.getProperty("uprr.implementation.environment"))) {
      System.setProperty("uprr.implementation.environment", "dev");
      siteMinderToken = new SiteMinderStandaloneToken(smUserId, smPassword);
      System.setProperty("uprr.implementation.environment", "local");
    }  else {
    	siteMinderToken = new SiteMinderStandaloneToken(smUserId, smPassword);
    }
    return siteMinderToken;
  }
}
