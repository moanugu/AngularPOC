package com.uprr.lic.menus;

import java.util.ArrayList;
import java.util.List;

public class LicMenuItem {

  private String label;

  private String url;

  private String sref;

  private List<LicMenuItem> sub = null;

  public LicMenuItem(String label) {
    super();
    this.label = label;
  }
  // public LicMenuItem(String label, String url) {
  // super();
  // this.label = label;
  // this.url = url;
  // }

  public LicMenuItem(String label, String url, String sref) {
    super();
    this.label = label;
    this.url = url;
    this.sref = sref;
  }

  public void addSubMenu(LicMenuItem subMenu) {
    if (sub == null) {
      sub = new ArrayList<>();
    }
    sub.add(subMenu);
  }

  public String getLabel() {
    return label;
  }

  public void setLabel(String label) {
    this.label = label;
  }

  public String getUrl() {
    return url;
  }

  public void setUrl(String url) {
    this.url = url;
  }

  public String getSref() {
    return sref;
  }

  public void setSref(String sref) {
    this.sref = sref;
  }

  public List<LicMenuItem> getSub() {
    return sub;
  }

}
