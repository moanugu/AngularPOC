package com.uprr.lic.menus;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.uprr.lic.auth.EQMSUserBean;
import com.uprr.lic.auth.EQMSUserSession;
import com.uprr.lic.dataaccess.components.licensing.delegate.LicensingDelegate;
import com.uprr.lic.exception.EqmDaoException;
import com.uprr.lic.exception.EqmException;
import com.uprr.lic.util.EQMSConstant;

@Controller
public class MenuController {

  private static final String BLANK_STATE = null;

  private static final String BLANK_URL = null;

  private Logger logger = LoggerFactory.getLogger(MenuController.class);

//  private Map<Integer, Boolean> menuTabForUserMap = null;

  @Autowired
  private EQMSUserSession session;

  @Autowired
  private LicensingDelegate licDelegate;// added for REQ-276

  public MenuController() {
    super();
  }

  @RequestMapping(value = "/getMenuListByUserRole", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
  @ResponseBody
  public List<LicMenuItem> getMenuListByUserRole() {
    String loggedEmpId = null;
    String appEnvironment = System.getProperty("uprr.implementation.environment");
    EQMSUserBean eqmsUsrBean = session.getUser();

    if (null != eqmsUsrBean && null != eqmsUsrBean.getEmplId()) {
      loggedEmpId = eqmsUsrBean.getEmplId();
    } else {
      throw new EqmException("Invalid user session ");
    }

    Set<Integer> roleSet = null;
    if (loggedEmpId == null || eqmsUsrBean == null) {
      throw new EqmException("Invalid user session ");
    } else if (loggedEmpId != null && !eqmsUsrBean.getEmplId().equalsIgnoreCase(loggedEmpId)) {
      eqmsUsrBean = null;
      throw new EqmException("Invalid user session ");
    }

    try {
      final List<LicMenuItem> listOfMenuItems = new ArrayList<LicMenuItem>();

      final LicMenuItem rmiLicHome = new LicMenuItem("Home", "#/", "eqmUiLicensing.decert");
      listOfMenuItems.add(rmiLicHome);

      if (eqmsUsrBean.isLoggedInUserAsYardMaster()) {
        logger.info("Logged in employee is a Yard Master.");

        // Training Module Changes start
        if (licDelegate.isStudentLicense(eqmsUsrBean.getEmplId())) { // Req#411
          final LicMenuItem rmiLic = new LicMenuItem("Licensing", BLANK_URL, BLANK_STATE);
          final LicMenuItem rmiPrintPkt = new LicMenuItem("Print Packets", "#!/print-packets",BLANK_STATE);
          rmiLic.addSubMenu(rmiPrintPkt);           
          listOfMenuItems.add(rmiLic);
        }
      } else {
        logger.info("Entered  :: setApplicationMenu(): Logged in employee is not Yard Master." + eqmsUsrBean);
        logger.info("LDAP roles eqmsUsrBean.getLdapRoleList() " + eqmsUsrBean.getLdapRoleList());
        logger.info("Entered  :: setApplicationMenu(): Logged in employee::eqmsUsrBean.isNonEqmsUser()"
            + eqmsUsrBean.isNonEqmsUser());
        if (eqmsUsrBean != null) {
          final LicMenuItem rmiLic = new LicMenuItem("Licensing");
          /* code changes for REQ-276 start */
            roleSet = eqmsUsrBean.getRoleSet();
//            menuTabForUserMap = eqmsUsrBean.getMenuTabForUserMap();
            logger.info("ManageAssignmentService :EQMSBasePage cons :execution start");
            // Licensing Menu Starts
//            if (menuTabForUserMap.get(EQMSConstant.LICENSING_MODULE_ID)) {

              if (roleSet.contains(EQMSConstant.SYSTEM_ADMIN_ROLE_ID)
                  || roleSet.contains(EQMSConstant.ROLE_ID_LICENSING_ADMIN)
                  || roleSet.contains(EQMSConstant.ROLE_ID_LICENSING_USER)
                  || roleSet.contains(EQMSConstant.ROLE_ID_MANPOWER_ADMIN)) {
            	  rmiLic.addSubMenu(new LicMenuItem("Initiate Licensing Request", "#!/licenseRequest","eqmUiLicensing.licenseRequest"));
              }

              if (roleSet.contains(EQMSConstant.ROLE_ID_SU_ADMIN) || roleSet.contains(EQMSConstant.ROLE_ID_REGION_ADMIN)
                  || roleSet.contains(EQMSConstant.SYSTEM_ADMIN_ROLE_ID)) {
                final LicMenuItem rimSle = new LicMenuItem("SLE Designation Request", BLANK_URL, BLANK_STATE);
                rimSle.addSubMenu(new LicMenuItem("Initiate SLE Request", "#!/initiate-sle-request",
                    "eqmUiLicensing.initiateSLERequest"));
                rimSle.addSubMenu(new LicMenuItem("Revoke SLE Designation", "#!/revoke-sle-request",
                    "eqmUiLicensing.revokeSLERequest"));
                rmiLic.addSubMenu(rimSle);
              }

             /* if (roleSet.contains(EQMSConstant.ROLE_ID_LICENSING_USER)
                  || roleSet.contains(EQMSConstant.ROLE_ID_LICENSING_ADMIN)
                  || roleSet.contains(EQMSConstant.ROLE_ID_SYSTEM_ADMIN)) {
                rmiLic.addSubMenu(new LicMenuItem("Initiate Recertification", "#!/initiate-recertification",
                    "eqmUiLicensing.initiateRecertification"));
              }*/ //Not in use in new angular migration  App
              if (roleSet.contains(EQMSConstant.ROLE_ID_LICENSING_USER)
                  || roleSet.contains(EQMSConstant.ROLE_ID_LICENSING_ADMIN)
                  || roleSet.contains(EQMSConstant.ROLE_ID_SYSTEM_ADMIN)
                  || roleSet.contains(EQMSConstant.ROLE_ID_SU_ADMIN)
                  || roleSet.contains(EQMSConstant.ROLE_ID_REGION_ADMIN)) {
                rmiLic.addSubMenu(new LicMenuItem("Pending Requirements", "#!/pending-requirement",
                    "eqmUiLicensing.pendingRequirement"));
              }
              if (roleSet.contains(EQMSConstant.SYSTEM_ADMIN_ROLE_ID)
                  || roleSet.contains(EQMSConstant.ROLE_ID_LICENSING_ADMIN)
                  || roleSet.contains(EQMSConstant.ROLE_ID_LICENSING_USER)
                  || roleSet.contains(EQMSConstant.ROLE_ID_SU_ADMIN)
                  || roleSet.contains(EQMSConstant.ROLE_ID_REGION_ADMIN)) {
                rmiLic.addSubMenu(
                    new LicMenuItem("Pending Action List", "#!/pending-action", "eqmUiLicensing.pendingAction"));
              }
              // a new role(ROLE_ID_MANAGER) added for Req106
              if (roleSet.contains(EQMSConstant.ROLE_ID_SU_ADMIN) || roleSet.contains(EQMSConstant.ROLE_ID_REGION_ADMIN)
                  || roleSet.contains(EQMSConstant.ROLE_ID_LICENSING_ADMIN)
                  || roleSet.contains(EQMSConstant.SYSTEM_ADMIN_ROLE_ID)
                  || roleSet.contains(EQMSConstant.ROLE_ID_LICENSING_USER)
                  || roleSet.contains(EQMSConstant.ROLE_ID_MANAGER)) {
                final LicMenuItem rimPrint = new LicMenuItem("Print", BLANK_URL, BLANK_STATE);
                if (roleSet.contains(EQMSConstant.ROLE_ID_LICENSING_ADMIN)
                    || roleSet.contains(EQMSConstant.SYSTEM_ADMIN_ROLE_ID)
                    || roleSet.contains(EQMSConstant.ROLE_ID_LICENSING_USER)) {
                 /* rmiLic.addSubMenu(
                      new LicMenuItem("Print Label", "#!/print-label-page", "eqmUiLicensing.print-label-page"));*/ // Not in use in new angular migration  App
                rimPrint.addSubMenu(new LicMenuItem("Print License", "#!/print-license", "eqmUiLicensing.printLicense"));  //  Not in use in in new angular migration  App
                 // rimPrint.addSubMenu(new LicMenuItem("Print Conductor License", BLANK_URL, BLANK_STATE));
                }
                // a new role(ROLE_ID_MANAGER) added for Req106
                if (roleSet.contains(EQMSConstant.ROLE_ID_SU_ADMIN)
                    || roleSet.contains(EQMSConstant.ROLE_ID_REGION_ADMIN)
                    || roleSet.contains(EQMSConstant.ROLE_ID_LICENSING_ADMIN)
                    || roleSet.contains(EQMSConstant.SYSTEM_ADMIN_ROLE_ID)
                    || roleSet.contains(EQMSConstant.ROLE_ID_LICENSING_USER)
                    || roleSet.contains(EQMSConstant.ROLE_ID_MANAGER)) {
                  rimPrint.addSubMenu(new LicMenuItem("Print Temporary License", "#!/temporary-license",
                      "eqmUiLicensing.printTemporary"));
                }
                // Code added to let Manager Print Packets for Req 106

                // Code Changes for REQ-252 start
                if (roleSet.contains(EQMSConstant.ROLE_ID_SU_ADMIN)
                    || roleSet.contains(EQMSConstant.ROLE_ID_REGION_ADMIN)
                    || roleSet.contains(EQMSConstant.ROLE_ID_LICENSING_ADMIN)
                    || roleSet.contains(EQMSConstant.SYSTEM_ADMIN_ROLE_ID)
                    || roleSet.contains(EQMSConstant.ROLE_ID_LICENSING_USER)
                    || roleSet.contains(EQMSConstant.ROLE_ID_MANAGER)) {
                  rimPrint.addSubMenu(
                      new LicMenuItem("Print Documents", "#!/print-document", "eqmUiLicensing.printDocument"));
                }
                // Code Changes for REQ-252 end
                if (roleSet.contains(EQMSConstant.ROLE_ID_MANAGER)) {
                	rimPrint.addSubMenu(new LicMenuItem("Print Packets", "#!/print-packets",BLANK_STATE));
                	
                 /* if (appEnvironment != null && appEnvironment.toUpperCase().equals("DEV")) {
                    final LicMenuItem printRecrtPacketsForMgrDev = new LicMenuItem("Print Packets", "#!/print-packets",
                        "eqmUiLicensing.printPackets");
                    rimPrint.addSubMenu(printRecrtPacketsForMgrDev);
                  }*/
                }
                rmiLic.addSubMenu(rimPrint);
              }
              if (roleSet.contains(EQMSConstant.ROLE_ID_LICENSING_USER)
                  || roleSet.contains(EQMSConstant.ROLE_ID_LICENSING_ADMIN)
                  || roleSet.contains(EQMSConstant.ROLE_ID_SYSTEM_ADMIN)) {
                rmiLic.addSubMenu(new LicMenuItem("Employee Packet Status", "#!/employee-packet-status",
                    "eqmUiLicensing.employeePacketStatus"));
              }
              if (roleSet.contains(EQMSConstant.ROLE_ID_SU_ADMIN) || roleSet.contains(EQMSConstant.ROLE_ID_REGION_ADMIN)
                  || roleSet.contains(EQMSConstant.ROLE_ID_SYSTEM_ADMIN)
                  || roleSet.contains(EQMSConstant.LICENSING_ADMIN) || roleSet.contains(EQMSConstant.LICENSING_USER)) {
                rmiLic.addSubMenu(new LicMenuItem("Waive License", "#!/waive-license", "eqmUiLicensing.waiveLicense"));
              }

              if (roleSet.contains(EQMSConstant.ROLE_ID_REGION_ADMIN)
                  || roleSet.contains(EQMSConstant.ROLE_ID_SYSTEM_ADMIN)
                  || roleSet.contains(EQMSConstant.ROLE_ID_SU_ADMIN) || roleSet.contains(EQMSConstant.LICENSING_ADMIN)
                  || roleSet.contains(EQMSConstant.LICENSING_USER)) {
                rmiLic.addSubMenu(new LicMenuItem("Restriction", "#!/restriction", "eqmUiLicensing.restriction"));
              }
              if (roleSet.contains(EQMSConstant.ROLE_ID_LICENSING_USER)
                  || roleSet.contains(EQMSConstant.ROLE_ID_LICENSING_ADMIN)
                  || roleSet.contains(EQMSConstant.ROLE_ID_MANAGER)) {

                rmiLic.addSubMenu(new LicMenuItem("Replace License Request", "#!/replace-license-request",
                    "eqmUiLicensing.replaceLicense"));
              }

              final LicMenuItem rimLicenseStatus = new LicMenuItem("License Status", BLANK_URL, BLANK_STATE);
              if (roleSet.contains(EQMSConstant.ROLE_ID_SU_ADMIN)
                  || roleSet.contains(EQMSConstant.ROLE_ID_LICENSING_ADMIN)
                  || roleSet.contains(EQMSConstant.ROLE_ID_LICENSING_USER)
                  || roleSet.contains(EQMSConstant.ROLE_ID_MANAGER)
                  || roleSet.contains(EQMSConstant.ROLE_ID_REGION_ADMIN)
                  || roleSet.contains(EQMSConstant.SYSTEM_ADMIN_ROLE_ID)) {
                rimLicenseStatus
                    .addSubMenu(new LicMenuItem("Enter an Event", "#!/createUpdateEvent", "createUpdateEvent"));
                // QC-6846 Changes for Sub Menu End
              }
              if (roleSet.contains(EQMSConstant.ROLE_ID_REGION_ADMIN) || roleSet.contains(EQMSConstant.ROLE_ID_SU_ADMIN)
                  || roleSet.contains(EQMSConstant.ROLE_ID_LICENSING_ADMIN)
                  || roleSet.contains(EQMSConstant.ROLE_ID_LICENSING_USER)
                  || roleSet.contains(EQMSConstant.ROLE_ID_MANAGER)
                  || roleSet.contains(EQMSConstant.ROLE_ID_OPERATIONAL_PRACTICE)
                  || roleSet.contains(EQMSConstant.SYSTEM_ADMIN_ROLE_ID)) {
                rimLicenseStatus
                    .addSubMenu(new LicMenuItem("View/Update Event(s)", "#!/search", "eqmUiLicensing.decert"));
              }
//              if (roleSet.contains(EQMSConstant.ROLE_ID_LICENSING_ADMIN)
//                  || roleSet.contains(EQMSConstant.ROLE_ID_LICENSING_USER)
//                  || roleSet.contains(EQMSConstant.SYSTEM_ADMIN_ROLE_ID)) {
//                rimLicenseStatus.addSubMenu(new LicMenuItem("Receive Document", BLANK_URL, BLANK_STATE));
//              }
              //Modified for Denial of Certification(SS_QC_5120)
              if ( roleSet.contains(EQMSConstant.ROLE_ID_LICENSING_ADMIN)
                  || roleSet.contains(EQMSConstant.ROLE_ID_LICENSING_USER)) {
                rimLicenseStatus.addSubMenu(new LicMenuItem("Denial Of Certification", "#!/denial", "eqmUiLicensing.denial"));
              }
              rmiLic.addSubMenu(rimLicenseStatus);
              if (roleSet.contains(EQMSConstant.SYSTEM_ADMIN_ROLE_ID)
                  || roleSet.contains(EQMSConstant.ROLE_ID_LICENSING_ADMIN)
                  || roleSet.contains(EQMSConstant.ROLE_ID_LICENSING_USER)) {
                rmiLic
                    .addSubMenu(new LicMenuItem("Suspend/Unsuspend", "#!/suspend-employee", "eqmUiLicensing.suspend"));
              }
              if (roleSet.contains(EQMSConstant.ROLE_ID_MANAGER) || roleSet.contains(EQMSConstant.ROLE_ID_SU_ADMIN)
                  || roleSet.contains(EQMSConstant.ROLE_ID_SYSTEM_ADMIN)
                  || roleSet.contains(EQMSConstant.ROLE_ID_REGION_ADMIN)) {
                rmiLic.addSubMenu(new LicMenuItem("TWIC", "#!/twic/", "eqmUiLicensing.twic"));
              }
              if (roleSet.contains(EQMSConstant.SYSTEM_ADMIN_ROLE_ID)
                  || roleSet.contains(EQMSConstant.ROLE_ID_LICENSING_ADMIN)
                  || roleSet.contains(EQMSConstant.ROLE_ID_LICENSING_USER)) {
                rmiLic.addSubMenu(new LicMenuItem("Notify CMTS", "#!/notify-cmts", "eqmUiLicensing.notifyCMTS"));
              } /* REQ#643:End of changes */
              if (roleSet.contains(EQMSConstant.SYSTEM_ADMIN_ROLE_ID)
                  || roleSet.contains(EQMSConstant.ROLE_ID_LICENSING_ADMIN)
                  || roleSet.contains(EQMSConstant.ROLE_ID_LICENSING_USER)) {
            	  
            	  final LicMenuItem rimIvr = new LicMenuItem("IVR", BLANK_URL, BLANK_STATE);
            	  rimIvr.addSubMenu(new LicMenuItem("IVR Summary", "#!/ivrSummary",
                      "eqmUiLicensing.ivrSummary"));
            	  rimIvr.addSubMenu(new LicMenuItem("IVR History", "#!/ivrSummaryHistory",
                      "eqmUiLicensing.ivrSummaryHistory"));
            	  rmiLic.addSubMenu(rimIvr);
              }
            //SS_QC#6700 - Start
              if (roleSet.contains(EQMSConstant.SYSTEM_ADMIN_ROLE_ID)
                      || roleSet.contains(EQMSConstant.ROLE_ID_LICENSING_ADMIN)
                      || roleSet.contains(EQMSConstant.ROLE_ID_LICENSING_USER)) {
			final LicMenuItem auditCertRecertMenu = new LicMenuItem("Audit Certification/Recertification", BLANK_URL, BLANK_STATE);
              auditCertRecertMenu.addSubMenu(new LicMenuItem("Initiate Audit Certification/Recertification", "#!/initiate-audit", "eqmUiLicensing.auditCertRecert"));
              auditCertRecertMenu.addSubMenu(new LicMenuItem("Audit Certification/Recertification", "#!/audit-records", "eqmUiLicensing.auditRecords"));
              rmiLic.addSubMenu(auditCertRecertMenu); 
              }
            //SS_QC#6700 - End
          listOfMenuItems.add(rmiLic);
        }
      }
      return listOfMenuItems;
    } catch (final EqmDaoException e) {
      logger.error("Exception ::  EQMSBasePage()" + e.getMessage(), e);
      throw new EqmException("Invalid user session");
    } catch (final Exception e) {
      logger.error("Exception ::  EQMSBasePage()", e);
      throw new EqmException("Invalid user session");
    }
  }
}

