package com.uprr.lic.decert.rest.model;

public class ReceivedDocumentRequest {

	private String employeeID;
	private Integer evntDtlId;
	private String userEmpId;
	private DropdownChoice documentType;
	private Integer reasonId;
	private String assignedManager;
	private Integer serviceUnitNbr;

	public String getEmployeeID() {
		return employeeID;
	}

	public void setEmployeeID(String employeeID) {
		this.employeeID = employeeID;
	}

	public Integer getEvntDtlId() {
		return evntDtlId;
	}

	public void setEvntDtlId(Integer evntDtlId) {
		this.evntDtlId = evntDtlId;
	}

	public String getUserEmpId() {
		return userEmpId;
	}

	public void setUserEmpId(String userEmpId) {
		this.userEmpId = userEmpId;
	}

	public DropdownChoice getDocumentType() {
		return documentType;
	}

	public void setDocumentType(DropdownChoice documentType) {
		this.documentType = documentType;
	}

	public Integer getReasonId() {
		return reasonId;
	}

	public void setReasonId(Integer reasonId) {
		this.reasonId = reasonId;
	}

	public String getAssignedManager() {
		return assignedManager;
	}

	public void setAssignedManager(String assignedManager) {
		this.assignedManager = assignedManager;
	}

	public Integer getServiceUnitNbr() {
		return serviceUnitNbr;
	}

	public void setServiceUnitNbr(Integer serviceUnitNbr) {
		this.serviceUnitNbr = serviceUnitNbr;
	}

}
