package com.uprr.lic.decert.rest.model;

public class EmployeeOffenceDetails {
	
	private String trackCode;
	
	private String noOffnInOneYear;
	
	private Integer conOffnCount;

	public String getTrackCode() {
		return trackCode;
	}

	public void setTrackCode(String trackCode) {
		this.trackCode = trackCode;
	}

	public String getNoOffnInOneYear() {
		return noOffnInOneYear;
	}

	public void setNoOffnInOneYear(String noOffnInOneYear) {
		this.noOffnInOneYear = noOffnInOneYear;
	}

	public Integer getConOffnCount() {
		return conOffnCount;
	}

	public void setConOffnCount(Integer conOffnCount) {
		this.conOffnCount = conOffnCount;
	}

}
