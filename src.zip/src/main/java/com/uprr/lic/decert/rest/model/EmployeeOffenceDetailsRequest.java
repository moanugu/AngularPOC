package com.uprr.lic.decert.rest.model;

import java.util.Calendar;

public class EmployeeOffenceDetailsRequest {
	private Integer eventDetailId;
	
	private Calendar eventDate;
	
	private String regulationFlag;
	
	private String employeeId;

	public Integer getEventDetailId() {
		return eventDetailId;
	}

	public void setEventDetailId(Integer eventDetailId) {
		this.eventDetailId = eventDetailId;
	}

	public Calendar getEventDate() {
		return eventDate;
	}

	public void setEventDate(Calendar eventDate) {
		this.eventDate = eventDate;
	}

	public String getRegulationFlag() {
		return regulationFlag;
	}

	public void setRegulationFlag(String regulationFlag) {
		this.regulationFlag = regulationFlag;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

}
