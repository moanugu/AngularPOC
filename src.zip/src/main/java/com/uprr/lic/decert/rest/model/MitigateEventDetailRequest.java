/**
 * Interface Name	: MitigateEventDetail
 * Description		: To be used as page bean to mitigate event.
 * Created By		: Tech Mahindra Ltd.
 * Created On		: 2008
 * 
 * Date of creation :
 *
 * Change History
 * ------------------------------------------------------------  
 * Date			Changed By	Description
 * ------------------------------------------------------------  
 * 09/12/2012	xsat244		QC#333
 *        
 * ------------------------------------------------------------  
 *
 * Copyright notice : "Copyright UPRR 2008"
 */
package com.uprr.lic.decert.rest.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class MitigateEventDetailRequest {

	private Integer eventDetailId;
	private String comment;
	private String typeOfEvent;
	private String regulation;
	private String employeeId;
	@JsonProperty("isUnsuspendEmpl")
	private boolean isUnsuspendEmpl;
	private String typeOfEventAndRegulation;
	private String userId;
	/*private List<MultipartFile> documents;*/
	
	public Integer getEventDetailId() {
		return eventDetailId;
	}
	
	public void setEventDetailId(Integer EventDetailId) {
		this.eventDetailId = EventDetailId;
	}
	
	public String getComment() {
		return comment;
	}
	
	public void setComment(String comment) {
		this.comment = comment;
	}
	
	public String getTypeOfEvent() {
		return typeOfEvent;
	}
	
	public void setTypeOfEvent(String typeOfEvent) {
		this.typeOfEvent = typeOfEvent;
	}
	
	public String getRegulation() {
		return regulation;
	}
	
	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public boolean isUnsuspendEmpl() {
		return isUnsuspendEmpl;
	}

	public void setUnsuspendEmpl(boolean isUnsuspendEmpl) {
		this.isUnsuspendEmpl = isUnsuspendEmpl;
	}

	public String getTypeOfEventAndRegulation() {
		return typeOfEventAndRegulation;
	}

	public void setTypeOfEventAndRegulation(String typeOfEventAndRegulation) {
		this.typeOfEventAndRegulation = typeOfEventAndRegulation;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public void setRegulation(String regulation) {
		this.regulation = regulation;
	}
	
	/*public List<MultipartFile> getDocuments() {
		return documents;
	}
	
	public void setDocuments(List<MultipartFile> documents) {
		this.documents = documents;
	}*/
}
