package com.uprr.lic.decert.rest.model;

import com.uprr.lic.util.DDChoice;

public class EventLocationResponse {

	protected String subDivision;

	protected String milePost;

	protected DDChoice region;

	protected DDChoice serviceUnit;

	protected String signalTerritory;

	protected String typeOfTrack;

	protected String typeOfAuthority;

	protected String railRoad;

	protected String milesOfTerminal;

	protected String initOrFinalTerminal;

	protected String station;

	private String typeAuthRadioGp;

	private String signalRadioGp;

	private String typeAuthTWCRadioGp;

	private String answerTypeAuthSelected;

	private String answerSignalSelected;

	private String answerTypeAuthTWCSelected;

	/**
	 * @return the typeAuthTWCRadioGp
	 */
	public String getTypeAuthTWCRadioGp() {
		return typeAuthTWCRadioGp;
	}

	/**
	 * @param typeAuthTWCRadioGp
	 *            the typeAuthTWCRadioGp to set
	 */
	public void setTypeAuthTWCRadioGp(final String typeAuthTWCRadioGp) {
		this.typeAuthTWCRadioGp = typeAuthTWCRadioGp;
	}

	/**
	 * @return the answerTypeAuthTWCSelected
	 */
	public String getAnswerTypeAuthTWCSelected() {
		return answerTypeAuthTWCSelected;
	}

	/**
	 * @param answerTypeAuthTWCSelected
	 *            the answerTypeAuthTWCSelected to set
	 */
	public void setAnswerTypeAuthTWCSelected(final String answerTypeAuthTWCSelected) {
		this.answerTypeAuthTWCSelected = answerTypeAuthTWCSelected;
	}

	/**
	 * @return the answerTypeAuthSelected
	 */
	public String getAnswerTypeAuthSelected() {
		return answerTypeAuthSelected;
	}

	/**
	 * @param answerTypeAuthSelected
	 *            the answerTypeAuthSelected to set
	 */
	public void setAnswerTypeAuthSelected(final String answerTypeAuthSelected) {
		this.answerTypeAuthSelected = answerTypeAuthSelected;
	}

	/**
	 * @return the answerSignalSelected
	 */
	public String getAnswerSignalSelected() {
		return answerSignalSelected;
	}

	/**
	 * @param answerSignalSelected
	 *            the answerSignalSelected to set
	 */
	public void setAnswerSignalSelected(final String answerSignalSelected) {
		this.answerSignalSelected = answerSignalSelected;
	}

	/**
	 * @return the typeAuthRadioGp
	 */
	public String getTypeAuthRadioGp() {
		return typeAuthRadioGp;
	}

	/**
	 * @param typeAuthRadioGp
	 *            the typeAuthRadioGp to set
	 */
	public void setTypeAuthRadioGp(final String typeAuthRadioGp) {
		this.typeAuthRadioGp = typeAuthRadioGp;
	}

	/**
	 * @return the signalRadioGp
	 */
	public String getSignalRadioGp() {
		return signalRadioGp;
	}

	/**
	 * @param signalRadioGp
	 *            the signalRadioGp to set
	 */
	public void setSignalRadioGp(final String signalRadioGp) {
		this.signalRadioGp = signalRadioGp;
	}

	// end:Added For REQ#401-Part5.
	/**
	 * @return String
	 */
	public String getSubDivision() {
		return subDivision;
	}

	/**
	 * @param subDivision
	 */
	public void setSubDivision(final String subDivision) {
		this.subDivision = subDivision;
	}

	/**
	 * @return String
	 */
	public String getMilePost() {
		return milePost;
	}

	/**
	 * @param milePost
	 */
	public void setMilePost(final String milePost) {
		this.milePost = milePost;
	}

	/**
	 * @return String
	 */
	public DDChoice getRegion() {
		return region;
	}

	/**
	 * @param region
	 */
	public void setRegion(final DDChoice region) {
		this.region = region;
	}

	/**
	 * @return String
	 */
	public DDChoice getServiceUnit() {
		return serviceUnit;
	}

	/**
	 * @param serviceUnit
	 */
	public void setServiceUnit(final DDChoice serviceUnit) {
		this.serviceUnit = serviceUnit;
	}

	/**
	 * @return String
	 */
	public String getSignalTerritory() {
		return signalTerritory;
	}

	/**
	 * @param signalTerritory
	 */
	public void setSignalTerritory(final String signalTerritory) {
		this.signalTerritory = signalTerritory;
	}

	/**
	 * @return String
	 */
	public String getTypeOfTrack() {
		return typeOfTrack;
	}

	/**
	 * @param typeOfTrack
	 */
	public void setTypeOfTrack(final String typeOfTrack) {
		this.typeOfTrack = typeOfTrack;
	}

	/**
	 * @return String
	 */
	public String getTypeOfAuthority() {
		return typeOfAuthority;
	}

	/**
	 * @param typeOfAuthority
	 */
	public void setTypeOfAuthority(final String typeOfAuthority) {
		this.typeOfAuthority = typeOfAuthority;
	}

	/**
	 * @return String
	 */
	public String getRailRoad() {
		return railRoad;
	}

	/**
	 * @param railRoad
	 */
	public void setRailRoad(final String railRoad) {
		this.railRoad = railRoad;
	}

	/**
	 * @return String
	 */
	public String getMilesOfTerminal() {
		return milesOfTerminal;
	}

	/**
	 * @param milesOfTerminal
	 */
	public void setMilesOfTerminal(final String milesOfTerminal) {
		this.milesOfTerminal = milesOfTerminal;
	}

	/**
	 * @return String
	 */
	public String getInitOrFinalTerminal() {
		return initOrFinalTerminal;
	}

	/**
	 * @param initOrFinalTerminal
	 */
	public void setInitOrFinalTerminal(final String initOrFinalTerminal) {
		this.initOrFinalTerminal = initOrFinalTerminal;
	}

	/**
	 * @return the station
	 */
	public String getStation() {
		return station;
	}

	/**
	 * @param station
	 *            the station to set
	 */
	public void setStation(final String station) {
		this.station = station;
	}

}
