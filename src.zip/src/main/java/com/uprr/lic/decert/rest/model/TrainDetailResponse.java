package com.uprr.lic.decert.rest.model;

import java.util.List;

public class TrainDetailResponse {
	private long serialVersionUID;
	private Integer trainKey;
	private String trainSymbol;
	private String symbol;
	private String trainSection;
	private String loads;
	private String empties;
	private String tonnages;
	private String length;
	private String maxAuthorisedSpeed;
	private String speedTimeOfIncident;
	private String originDate;
	private String trainDay;
	private List eventEmployeeList;
	private String previosTrainSymbol;
	private String trainId;
	private String trainDate;

	public long getSerialVersionUID() {
		return serialVersionUID;
	}

	public void setSerialVersionUID(final long serialVersionUID) {
		this.serialVersionUID = serialVersionUID;
	}

	public Integer getTrainKey() {
		return trainKey;
	}

	public void setTrainKey(final Integer trainKey) {
		this.trainKey = trainKey;
	}

	public String getTrainSymbol() {
		return trainSymbol;
	}

	public void setTrainSymbol(final String trainSymbol) {
		this.trainSymbol = trainSymbol;
	}

	public String getSymbol() {
		return symbol;
	}

	public void setSymbol(final String symbol) {
		this.symbol = symbol;
	}

	public String getTrainSection() {
		return trainSection;
	}

	public void setTrainSection(final String trainSection) {
		this.trainSection = trainSection;
	}

	public String getLoads() {
		return loads;
	}

	public void setLoads(final String loads) {
		this.loads = loads;
	}

	public String getEmpties() {
		return empties;
	}

	public void setEmpties(final String empties) {
		this.empties = empties;
	}

	public String getTonnages() {
		return tonnages;
	}

	public void setTonnages(final String tonnages) {
		this.tonnages = tonnages;
	}

	public String getLength() {
		return length;
	}

	public void setLength(final String length) {
		this.length = length;
	}

	public String getMaxAuthorisedSpeed() {
		return maxAuthorisedSpeed;
	}

	public void setMaxAuthorisedSpeed(final String maxAuthorisedSpeed) {
		this.maxAuthorisedSpeed = maxAuthorisedSpeed;
	}

	public String getSpeedTimeOfIncident() {
		return speedTimeOfIncident;
	}

	public void setSpeedTimeOfIncident(final String speedTimeOfIncident) {
		this.speedTimeOfIncident = speedTimeOfIncident;
	}

	public String getOriginDate() {
		return originDate;
	}

	public void setOriginDate(final String originDate) {
		this.originDate = originDate;
	}

	public String getTrainDay() {
		return trainDay;
	}

	public void setTrainDay(final String trainDay) {
		this.trainDay = trainDay;
	}

	public List getEventEmployeeList() {
		return eventEmployeeList;
	}

	public void setEventEmployeeList(final List eventEmployeeList) {
		this.eventEmployeeList = eventEmployeeList;
	}

	public String getPreviosTrainSymbol() {
		return previosTrainSymbol;
	}

	public void setPreviosTrainSymbol(final String previosTrainSymbol) {
		this.previosTrainSymbol = previosTrainSymbol;
	}

	public String getTrainId() {
		return trainId;
	}

	public void setTrainId(final String trainId) {
		this.trainId = trainId;
	}

	public String getTrainDate() {
		return trainDate;
	}

	public void setTrainDate(final String trainDate) {
		this.trainDate = trainDate;
	}
}
