package com.uprr.lic.decert.rest.model;

import java.util.List;

import com.uprr.lic.dataaccess.decertification.model.LicenseGridDetail;

public class EmployeeDetailResponse {

	 private static final long serialVersionUID = 1L;
	
	 private String employeeID;

	  private String employeeName;

	  private String region;

	  private String serviceUnit;

	  private String yearsInCraft;

	  private String hireDate;

	  private String lastStopTestDate;

	  private String conductorDate;

	  private String tripsOnTerritory;

	  private List<LicenseGridDetail> licenseAll;

	public String getEmployeeID() {
		return employeeID;
	}

	public void setEmployeeID(String employeeID) {
		this.employeeID = employeeID;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getServiceUnit() {
		return serviceUnit;
	}

	public void setServiceUnit(String serviceUnit) {
		this.serviceUnit = serviceUnit;
	}

	public String getYearsInCraft() {
		return yearsInCraft;
	}

	public void setYearsInCraft(String yearsInCraft) {
		this.yearsInCraft = yearsInCraft;
	}

	public String getHireDate() {
		return hireDate;
	}

	public void setHireDate(String hireDate) {
		this.hireDate = hireDate;
	}

	public String getLastStopTestDate() {
		return lastStopTestDate;
	}

	public void setLastStopTestDate(String lastStopTestDate) {
		this.lastStopTestDate = lastStopTestDate;
	}

	public String getConductorDate() {
		return conductorDate;
	}

	public void setConductorDate(String conductorDate) {
		this.conductorDate = conductorDate;
	}

	public String getTripsOnTerritory() {
		return tripsOnTerritory;
	}

	public void setTripsOnTerritory(String tripsOnTerritory) {
		this.tripsOnTerritory = tripsOnTerritory;
	}

	public List<LicenseGridDetail> getLicenseAll() {
		return licenseAll;
	}

	public void setLicenseAll(List<LicenseGridDetail> licenseAll) {
		this.licenseAll = licenseAll;
	}
 	  
}
