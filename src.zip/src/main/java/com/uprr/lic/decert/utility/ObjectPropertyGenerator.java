package com.uprr.lic.decert.utility;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;

import com.uprr.lic.dataaccess.Licensing.model.EmpPacketStatusDetails;


// TO BE USED BY DEVELOPER TO GENERATE CLASS BEANS AND properties
public class ObjectPropertyGenerator {

	private static final String EQUALS_CHAR = " = ";
	private static final String THIS = "this.";
	private static final String SPACE_CHAR = " ";
	private static final String FINAL = " final ";
	private static final String VOID = "void";
	private static final String RETURN = "return ";
	private static final String OPENING_ROUND = "( ";
	private static final String CLOSING_ROUND = " ) ";
	public static String OPENING_CURLY_BRACE = "{ ";
	public static String CLOSING_CURLY_BRACE = " }";
	private static final String GET_BRACKETS = "() ";
	private static final String GET = " get";
	private static final String SET = " set";
	private static final String NEWLINE = "\n";
	private static final String PACKAGE = "package ";
	private static final String CLASS = "class ";
	public static String PUBLIC = "public ";
	public static String PRIVATE = "private ";
	public static String SEMICOLON = "; ";

	public static void main(String[] args) {
		// new ObjectPropertyGenerator().generateBeanClass(TrainDetail.class,
		// new DestinationClass("", "TrainDetailResponse"))
		new ObjectPropertyGenerator().assignProperties(EmpPacketStatusDetails.class, new DestinationClass("", "Response"));
	}

	public void assignProperties(Class sourceClass, DestinationClass destClass) {

		StringBuilder classBuilder = new StringBuilder();
		Field[] allFields = sourceClass.getDeclaredFields();
		for (Field field : allFields) {
			if (Modifier.isPrivate(field.getModifiers())
					|| Modifier.isProtected(field.getModifiers()) && !Modifier.isStatic(field.getModifiers())) {
				String firstChar = field.getName().charAt(0) + "";
				String fieldName = firstChar.toUpperCase() + field.getName().substring(1);
				classBuilder.append("obj" + destClass.className + ".set" + fieldName + OPENING_ROUND + "obj"
						+ sourceClass.getSimpleName() + ".get" + fieldName + OPENING_ROUND + CLOSING_ROUND
						+ CLOSING_ROUND + SEMICOLON + NEWLINE);
			}
		}
	}

	public void generateBeanClass(Class sourceClass, DestinationClass destClass) {

		StringBuilder classBuilder = new StringBuilder();
		classBuilder.append(PACKAGE + destClass.packageName + SEMICOLON + NEWLINE);
		classBuilder.append(PUBLIC + SPACE_CHAR + CLASS + destClass.className + OPENING_CURLY_BRACE + NEWLINE);
		Field[] allFields = sourceClass.getDeclaredFields();

		createClassMembers(classBuilder, allFields);
		generateGetterSetters(classBuilder, allFields);
		classBuilder.append(CLOSING_CURLY_BRACE);
	}

	private void generateGetterSetters(StringBuilder classBuilder, Field[] allFields) {
		for (Field field : allFields) {
			if (Modifier.isPrivate(field.getModifiers())
					|| Modifier.isProtected(field.getModifiers()) && !Modifier.isStatic(field.getModifiers())) {
				createGetter(classBuilder, field);
				createSetter(classBuilder, field);
			}
		}
	}

	private void createClassMembers(StringBuilder classBuilder, Field[] allFields) {
		for (Field field : allFields) {
			if (Modifier.isPrivate(field.getModifiers())
					|| Modifier.isProtected(field.getModifiers()) && !Modifier.isStatic(field.getModifiers())) {
				classBuilder.append(
						PRIVATE + field.getType().getSimpleName() + SPACE_CHAR + field.getName() + SEMICOLON + NEWLINE);
			}
		}
	}

	private void createGetter(StringBuilder classBuilder, Field field) {
		String firstChar = field.getName().charAt(0) + "";
		String getter = firstChar.toUpperCase() + field.getName().substring(1);
		classBuilder.append(PUBLIC + field.getType().getSimpleName());
		classBuilder.append(GET + getter + GET_BRACKETS + OPENING_CURLY_BRACE + NEWLINE);
		classBuilder.append(RETURN + field.getName() + SEMICOLON + NEWLINE);
		classBuilder.append(CLOSING_CURLY_BRACE);
	}

	private void createSetter(StringBuilder classBuilder, Field field) {
		String firstChar = field.getName().charAt(0) + "";
		String setter = firstChar.toUpperCase() + field.getName().substring(1);
		classBuilder.append(PUBLIC + VOID);
		classBuilder.append(SET + setter + OPENING_ROUND + FINAL + field.getType().getSimpleName() + SPACE_CHAR
				+ field.getName() + CLOSING_ROUND + OPENING_CURLY_BRACE + NEWLINE);
		classBuilder.append(THIS + field.getName() + EQUALS_CHAR + field.getName() + SEMICOLON + NEWLINE);
		classBuilder.append(CLOSING_CURLY_BRACE);
	}

	public static class DestinationClass {

		public DestinationClass(String packageName, String className) {
			super();
			this.packageName = packageName;
			this.className = className;
		}

		String packageName;
		String className;

	}
}
