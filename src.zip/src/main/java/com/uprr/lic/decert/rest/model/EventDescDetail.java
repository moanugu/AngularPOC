package com.uprr.lic.decert.rest.model;

import com.uprr.lic.util.DDChoice;

public class EventDescDetail {

	protected DDChoice evntDesc;

	private String mngrCmnts;

	public DDChoice getEvntDesc() {
		return evntDesc;
	}

	public void setEvntDesc(DDChoice evntDesc) {
		this.evntDesc = evntDesc;
	}

	public String getMngrCmnts() {
		return mngrCmnts;
	}

	public void setMngrCmnts(String mngrCmnts) {
		this.mngrCmnts = mngrCmnts;
	}

}
