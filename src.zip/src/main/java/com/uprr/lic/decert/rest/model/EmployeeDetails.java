package com.uprr.lic.decert.rest.model;

import java.util.Date;

public class EmployeeDetails {

  private Integer eventDetailId;

  private String employeeId;

  private String comments;

  private Integer resnId;

//  //TODO remove this field. use userid from session object
//  private String userId;

  private Integer emplCmntDtlId;

  private Integer workItemId;

  private Integer serviceUnitNbr;

  private String reinstateWorkItemDate;

  private String eventAndRegulation;

  private String eventType;

  private Date eapDate;

  private Integer eventTypeId;

  private String eventStatus;

  private String eventDate;

  private String crtnId;

  private EventIncidentHistoryResponse employeeHistoryData;

  private EmployeeViewIncidentPopupResponse employeeViewIncidentPopupData;

  private String updatedManagerId;

  public EventIncidentHistoryResponse getEmployeeHistoryData() {
    return employeeHistoryData;
  }

  public String getUpdatedManagerId() {
    return updatedManagerId;
  }

  public void setUpdatedManagerId(String updatedManagerId) {
    this.updatedManagerId = updatedManagerId;
  }

  public void setEmployeeHistoryData(EventIncidentHistoryResponse employeeHistoryData) {
    this.employeeHistoryData = employeeHistoryData;
  }

  public EmployeeViewIncidentPopupResponse getEmployeeViewIncidentPopupData() {
    return employeeViewIncidentPopupData;
  }

  public void setEmployeeViewIncidentPopupData(EmployeeViewIncidentPopupResponse employeeViewIncidentPopupData) {
    this.employeeViewIncidentPopupData = employeeViewIncidentPopupData;
  }

  public String getEventDate() {
    return eventDate;
  }

  public void setEventDate(String eventDate) {
    this.eventDate = eventDate;
  }

  public String getCrtnId() {
    return crtnId;
  }

  public void setCrtnId(String crtnId) {
    this.crtnId = crtnId;
  }

  public Integer getEventDetailId() {
    return eventDetailId;
  }

  public String getEventAndRegulation() {
    return eventAndRegulation;
  }

  public String getEventStatus() {
    return eventStatus;
  }

  public void setEventStatus(String eventStatus) {
    this.eventStatus = eventStatus;
  }

  public void setEventAndRegulation(String eventAndRegulation) {
    this.eventAndRegulation = eventAndRegulation;
  }

  public String getEventType() {
    return eventType;
  }

  public void setEventType(String eventType) {
    this.eventType = eventType;
  }

  public Date getEapDate() {
    return eapDate;
  }

  public void setEapDate(Date eapDate) {
    this.eapDate = eapDate;
  }

  public Integer getEventTypeId() {
    return eventTypeId;
  }

  public void setEventTypeId(Integer eventTypeId) {
    this.eventTypeId = eventTypeId;
  }

  public void setEventDetailId(Integer eventDetailId) {
    this.eventDetailId = eventDetailId;
  }

  public String getEmployeeId() {
    return employeeId;
  }

  public void setEmployeeId(String employeeId) {
    this.employeeId = employeeId;
  }

  public String getComments() {
    return comments;
  }

  public void setComments(String comments) {
    this.comments = comments;
  }

  public Integer getResnId() {
    return resnId;
  }

  public void setResnId(Integer resnId) {
    this.resnId = resnId;
  }

  // public String getUserId() {
  // return userId;
  // }
  //
  // public void setUserId(String userId) {
  // this.userId = userId;
  // }

  public Integer getEmplCmntDtlId() {
    return emplCmntDtlId;
  }

  public void setEmplCmntDtlId(Integer emplCmntDtlId) {
    this.emplCmntDtlId = emplCmntDtlId;
  }

  public Integer getWorkItemId() {
    return workItemId;
  }

  public void setWorkItemId(Integer workItemId) {
    this.workItemId = workItemId;
  }

  public Integer getServiceUnitNbr() {
    return serviceUnitNbr;
  }

  public void setServiceUnitNbr(Integer serviceUnitNbr) {
    this.serviceUnitNbr = serviceUnitNbr;
  }

  public String getReinstateWorkItemDate() {
    return reinstateWorkItemDate;
  }

  public void setReinstateWorkItemDate(String reinstateWorkItemDate) {
    this.reinstateWorkItemDate = reinstateWorkItemDate;
  }

//  public String getUserId() {
//    return userId;
//  }
//
//  public void setUserId(String userId) {
//    this.userId = userId;
//  }

}
