package com.uprr.lic.decert.handler;

import java.io.IOException;
import java.util.Map;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.xml.sax.Attributes;

import com.lowagie.text.Chunk;
import com.lowagie.text.DocListener;
import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.Image;
import com.lowagie.text.Phrase;
import com.lowagie.text.pdf.PdfContentByte;
import com.lowagie.text.pdf.PdfImportedPage;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfReader;
import com.lowagie.text.pdf.PdfWriter;
import com.lowagie.text.xml.SAXiTextHandler;
import com.lowagie.text.xml.XmlPeer;
import com.uprr.lic.util.LicensingConstant;

public class CustomTagHandler extends SAXiTextHandler {

	  /** Automatically generated javadoc for: FOURTY */
	  private static final int FOURTY = 40;

	  /** Automatically generated javadoc for: ONEFIFTEEN */
	  private static final int ONEFIFTEEN = 115;

	  private Map myTags = null;

	  private PdfWriter writer = null;

	  private DocListener doclistener = null;

	  private/** This is the contentbyte object of the writer */
	  PdfContentByte contentByte = null;

	  private String strMethodName = null;

	  private java.util.Stack stackThis;

	  private boolean isStackReadyForText;

	  private String leftText = null;

	  private String centerText = null;

	  private String rightText = null;
	  
	  /* Modifiers changed by xsat244.*/
	  private static final Logger m_logger = LoggerFactory.getLogger(CustomTagHandler.class);

	  private static final String m_className = CustomTagHandler.class.getCanonicalName();

	  /**
	   * handles customised tags
	   * 
	   * @param _doclistener
	   * @param _writer
	   * @param hashmap
	   */
	  public CustomTagHandler(DocListener _doclistener, PdfWriter _writer, Map hashmap) throws DocumentException, IOException {
	    super(_doclistener);
	    setStrMethodName("CustomTagHandler"); /* NOI18N */
	    // setBaseFont(BaseFont.createFont("templates/pl_PL/arial.ttf",
	    // encoding,BaseFont.EMBEDDED));
	    setMyTags(hashmap);
	    setWriter(_writer);
	    setDoclistener(_doclistener);
	    setContentByte(_writer.getDirectContent());
	    stackThis = new java.util.Stack();
	    isStackReadyForText = false;
	    leftText = null;
	    centerText = null;
	    rightText = null;
	  }

	  /**
	   * cheks the start element
	   * 
	   * @param attributes
	   * @param text2
	   * @param text1
	   * @param text
	   */
	  public void startElement(String text, String text1, String text2, Attributes attributes) {
	    /* Loggers removed by xsat244.*/
	    setStrMethodName("startElement"); /* NOI18N */
	    isStackReadyForText = false;
	    if (getMyTags().containsKey(text2)) {
	      if ("leftText".equals(text2) || "centerText".equals(text2) || "rightText".equals(text2)) { /* NOI18N *//* NOI18N *//* NOI18N */
	        stackThis.push(new StringBuffer());
	        isStackReadyForText = true;
	      } /*
	         * else if ("footerText".equals(text2)) { NOI18N NOI18N }
	         */else if ("footer".equals(text2)) { /* NOI18N */
	        try {
	          Document doc = null;
	          PdfPTable table = new PdfPTable(3);
	          // initialization of the header table
	          table.getDefaultCell().setBorderWidth(0);
	          table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	          table.addCell(new Phrase(attributes.getValue("leftText"), new Font(Font.HELVETICA, 8, Font.NORMAL))); /* NOI18N */
	          table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	          table.addCell(new Phrase(attributes.getValue("centerText"), new Font(Font.HELVETICA, 8, Font.NORMAL))); /* NOI18N */
	          table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	          table.addCell(new Phrase(attributes.getValue("rightText"), new Font(Font.HELVETICA, 8, Font.NORMAL))); /* NOI18N */
	          getContentByte().saveState();
	          // write the headertable
	          doc = (Document) getDoclistener();
	          table.setTotalWidth(doc.right() - doc.left());
	          table.writeSelectedRows(0, -1, doc.left(), doc.bottom() + 10, getContentByte());
	        } catch (Exception e) {
	          m_logger.error(LicensingConstant.LOGGER_EQMEXCEPTION + "startElement() :: " + e.getMessage(), e);
	        }
	      } else if ("header".equals(text2)) { /* NOI18N */
	        try {
	          Document document = null;
	          int right, top;
	          /** An Image that goes in the header. */
	          Image headerImage = Image.getInstance(this.getClass().getClassLoader().getResource(attributes.getValue("name"))); /* NOI18N */
	          /** An Image that goes in the header. */
	          
//	          headerImage.setTransparency(new int[]{0x5B,0x5D});
	          PdfPTable table = new PdfPTable(1);
	          // initialization of the header table
	          table.getDefaultCell().setBorderWidth(0);
	          table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	          // table.addCell(new Phrase("sssssss"));
	          table.addCell(new Phrase(new Chunk(headerImage, 0, 0)));
	          getContentByte().saveState();
	          // write the headertable
	          document = (Document) getDoclistener();
	      /*    height = Integer.parseInt(attributes.getValue("height"));  NOI18N 
	          width = Integer.parseInt(attributes.getValue("width"));  NOI18N 
	          headerImage.scaleAbsolute(width, height);*/
	          table.setTotalWidth(document.right() - document.left() - ONEFIFTEEN);
	          right = Integer.parseInt(attributes.getValue("rightOffset")); /* NOI18N */
	          top = Integer.parseInt(attributes.getValue("topOffset")); /* NOI18N */
	          table.writeSelectedRows(0, -1, right, top, getContentByte());

	        } catch (Exception e) {
	          m_logger.error(LicensingConstant.LOGGER_EQMEXCEPTION + "startElement() :: " + e.getMessage(), e);
	        }
	      }
	      else if ("signheader".equals(text2)) { /* NOI18N */
	        try {
	          Document document = null;
	          int right, top,height,width;
	          /** An Image that goes in the header. */
	          Image headerImage = Image.getInstance(this.getClass().getClassLoader().getResource(attributes.getValue("name"))); /* NOI18N */
	          /** An Image that goes in the header. */
	          PdfPTable table = new PdfPTable(1);
	          // initialization of the header table
	          table.getDefaultCell().setBorderWidth(0);
	          table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	          //Start Req 183
	          height = Integer.parseInt(attributes.getValue("height")); /* NOI18N */
	          width = Integer.parseInt(attributes.getValue("width")); /* NOI18N */
	          headerImage.scaleAbsolute(width, height);
	          //end Req 183
	          // table.addCell(new Phrase("sssssss"));
	          table.addCell(new Phrase(new Chunk(headerImage, 0, 0)));
	          getContentByte().saveState();
	          // write the headertable
	          document = (Document) getDoclistener();
	          table.setTotalWidth(document.right() - document.left() - ONEFIFTEEN);
	          right = Integer.parseInt(attributes.getValue("rightOffset")); /* NOI18N */
	          top = Integer.parseInt(attributes.getValue("topOffset")); /* NOI18N */
	          table.writeSelectedRows(0, -1, right, top, getContentByte());

	        } catch (Exception e) {
	          m_logger.error(LicensingConstant.LOGGER_EQMEXCEPTION + "startElement() :: " + e.getMessage(), e);
	        }
	      }
	      else if ("headerImage".equals(text2)) { /* NOI18N */
	          try {
	            Document document = null;
	            int right, top,height,width;
	            /** An Image that goes in the header. */
	            Image headerImage = Image.getInstance(this.getClass().getClassLoader().getResource(attributes.getValue("name"))); /* NOI18N */
	            height = Integer.parseInt(attributes.getValue("height")); /* NOI18N */
	            width = Integer.parseInt(attributes.getValue("width")); /* NOI18N */
	           headerImage.scaleAbsolute(width, height);
	           byte gradient[] = new byte[256];
	           for (int k = 0; k < 256; ++k)
	             gradient[k] = (byte) 75;
	           Image smask = Image.getInstance(256, 1, 1, 8, gradient);
	           smask.makeMask();
	           headerImage.setImageMask(smask);
	            /** An Image that goes in the header. */
	            PdfPTable table = new PdfPTable(1);
	            // initialization of the header table
	            table.getDefaultCell().setBorderWidth(0);
	            table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            // table.addCell(new Phrase("sssssss"));
	            table.addCell(new Phrase(new Chunk(headerImage, 0, 0)));
	            getContentByte().saveState();
	            // write the headertable
	            document = (Document) getDoclistener();
	            table.setTotalWidth(document.right() - document.left() - ONEFIFTEEN);
	            right = Integer.parseInt(attributes.getValue("rightOffset")); /* NOI18N */
	            top = Integer.parseInt(attributes.getValue("topOffset")); /* NOI18N */
	            table.writeSelectedRows(0, -1, right, top, getContentByte());

	          } catch (Exception e) {
	            m_logger.error(LicensingConstant.LOGGER_EQMEXCEPTION + "startElement() :: " + e.getMessage(), e);
	          }
	        } 
	        else if ("headerImageTrans".equals(text2)) { 
	    	  try {
	          Document document = null;
	          int right, top,height,width;
	          /** An Image that goes in the header. */
	          Image headerImage = Image.getInstance(this.getClass().getClassLoader().getResource(attributes.getValue("name"))); /* NOI18N */
	          /** An Image that goes in the header. */
//	          headerImage.setTransparency(new int[]{255,255});
	          height = Integer.parseInt(attributes.getValue("height")); /* NOI18N */
	          width = Integer.parseInt(attributes.getValue("width")); /* NOI18N */
	          headerImage.scaleAbsolute(width, height);
	          byte gradient[] = new byte[256];
				for (int k = 0; k < 256; ++k)
					gradient[k] = (byte) 80;
				Image smask = Image.getInstance(256, 1, 1, 8, gradient);
				smask.makeMask();
				headerImage.setImageMask(smask);
				  

	          PdfPTable table = new PdfPTable(1);
	          // initialization of the header table
	          table.getDefaultCell().setBorderWidth(0);
	          table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	          // table.addCell(new Phrase("sssssss"));
	          table.addCell(new Phrase(new Chunk(headerImage, 0, 0)));
	          getContentByte().saveState();
	          // write the headertable
	          document = (Document) getDoclistener();
	          table.setTotalWidth(document.right() - document.left() - ONEFIFTEEN);
	          right = Integer.parseInt(attributes.getValue("rightOffset")); /* NOI18N */
	          top = Integer.parseInt(attributes.getValue("topOffset")); /* NOI18N */
	          table.writeSelectedRows(0, -1, right, top, getContentByte());

	        } catch (Exception e) {
	          m_logger.error(LicensingConstant.LOGGER_EQMEXCEPTION + "startElement() :: " + e.getMessage(), e);
	        }
	        }
	  else if ("insert".equals(text2)) /* NOI18N */
	      {
	        try {
	          PdfReader reader = new PdfReader(attributes.getValue("file")); /* NOI18N */
	          int loop = Integer.parseInt(attributes.getValue(1));
	          int len = Integer.parseInt(attributes.getValue(2));
	          PdfContentByte contentByte1 = getWriter().getDirectContent();
	          PdfImportedPage page = null;
	          while (loop <= len) {
	            page = getWriter().getImportedPage(reader, loop);
	            contentByte1.addTemplate(page, 0, 0);
	            getDoclistener().newPage();
	            // writer.addPage(writer.getImportedPage(reader, loop));
	            loop++;
	          }
	        } catch (Exception e) {
	          m_logger.error(LicensingConstant.LOGGER_EQMEXCEPTION + "startElement() :: " + e.getMessage(), e);
	        }
	      } else {
	        XmlPeer xmlpeer = (XmlPeer) getMyTags().get(text2);
	        handleStartingTags(xmlpeer.getTag(), xmlpeer.getAttributes(attributes));
	      }
	    } else {
	      Properties properties = new Properties();
	      if (attributes != null) {
	        for (int i = 0; i < attributes.getLength(); i++) {
	          String text3 = attributes.getQName(i);
	          properties.setProperty(text3, attributes.getValue(i));
	        }

	      }
	      handleStartingTags(text2, properties);
	    }
	    /* Loggers removed by xsat244.*/
	  }

	  /**
	   * checks the end element
	   * 
	   * @param text2
	   * @param text1
	   * @param text
	   */

	  public void endElement(String text, String text1, String text2) {
	    /* Loggers removed by xsat244.*/
	    setStrMethodName("endElement"); /* NOI18N */
	    isStackReadyForText = false;
	    if ("leftText".equals(text2)) { /* NOI18N */
	      Object tmp = stackThis.pop();
	      leftText = tmp.toString();
	    } else if ("centerText".equals(text2)) { /* NOI18N */
	      Object tmp = stackThis.pop();
	      centerText = tmp.toString();
	    } else if ("rightText".equals(text2)) { /* NOI18N */
	      Object tmp = stackThis.pop();
	      rightText = tmp.toString();
	    } else if ("footerText".equals(text2)) { /* NOI18N */
	      writePDFFooter();
	    } else if (getMyTags().containsKey(text2)) {
	      XmlPeer xmlpeer = (XmlPeer) getMyTags().get(text2);
	      handleEndingTags(xmlpeer.getTag());
	    } else {
	      handleEndingTags(text2);
	    }
	    /* Loggers removed by xsat244.*/
	  }

	  /**
	   * checks the characters
	   * 
	   * @param length
	   * @param start
	   * @param data
	   */
	  public void characters(char[] data, int start, int length) {
	    /* Loggers removed by xsat244.*/
	    setStrMethodName("characters"); /* NOI18N */
	    if (isStackReadyForText) {
	      ((java.lang.StringBuffer) stackThis.peek()).append(data, start, length);
	    } else {
	      super.characters(data, start, length);
	    }
	    /* Loggers removed by xsat244.*/
	  }

	  /**
	   * 
	   * 
	   */
	  private void writePDFFooter() {
	    setStrMethodName("writePDFFooter"); /* NOI18N */
	    try {
	      Document document = null;
	      PdfPTable table = new PdfPTable(3);
	      // initialization of the header table
	      table.getDefaultCell().setBorderWidth(0);

	      table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	      table.addCell(new Phrase(leftText, new Font(Font.HELVETICA, 8, Font.NORMAL)));
	      table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	      table.addCell(new Phrase(centerText, new Font(Font.HELVETICA, 8, Font.NORMAL)));
	      table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	      table.addCell(new Phrase(rightText, new Font(Font.HELVETICA, 8, Font.NORMAL)));

	      getContentByte().saveState();
	      // write the headertable
	      document = (Document) getDoclistener();
	      table.setTotalWidth(document.right() - document.left());

	      table.writeSelectedRows(0, -1, document.left(), document.bottom() + FOURTY, getContentByte());
	    } catch (Exception e) {
	      m_logger.error(LicensingConstant.LOGGER_EQMEXCEPTION + "writePDFFooter() :: " + e.getMessage(), e);
	    }

	  }

	  /**
	   * sets tags
	   * 
	   * @param hashmap
	   */
	  private void setMyTags(Map hashmap) {
	    this.myTags = hashmap;
	  }

	  /**
	   * gets tags
	   * 
	   * @return
	   */
	  protected Map getMyTags() {
	    return myTags;
	  }

	  /**
	   * sets writer
	   * 
	   * @param _writer
	   */
	  private void setWriter(PdfWriter _writer) {
	    this.writer = _writer;
	  }

	  /**
	   * gets writer
	   * 
	   * @return
	   */
	  protected PdfWriter getWriter() {
	    return writer;
	  }

	  private void setDoclistener(DocListener _doclistener) {
	    this.doclistener = _doclistener;
	  }

	  protected DocListener getDoclistener() {
	    return doclistener;
	  }

	  private void setContentByte(PdfContentByte _cb) {
	    this.contentByte = _cb;
	  }

	  protected PdfContentByte getContentByte() {
	    return contentByte;
	  }

	  private void setStrMethodName(String _strMethodName) {
	    this.strMethodName = _strMethodName;
	  }

	  protected String getStrMethodName() {
	    return strMethodName;
	  }

	}
