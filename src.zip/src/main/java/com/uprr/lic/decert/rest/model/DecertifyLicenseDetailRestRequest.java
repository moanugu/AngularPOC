package com.uprr.lic.decert.rest.model;

import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.uprr.lic.dataaccess.decertification.model.LicenseGridDetail;

public class DecertifyLicenseDetailRestRequest {

	private Integer eventDetailID;

	private String employeeID;

	private String employeeName;

	private Integer workItemID;

	private DropdownChoice revocationPeriod;

	@JsonProperty("isLerbAction")
	private boolean isLerbAction;

	private String effDate;
	
	private String noOfDays;
	
	private String eapRequired;

	private Integer evntRvkeDtlsId;

	private DropdownChoice region;

	private DropdownChoice serviceUnit;

	private DropdownChoice typeOfEvent;

	private String regulation;

	private String eventDate;

	private String eventDateTime; 

	private String onDutyDateTime; 

	private String responsibleManager;

	private String responsibleManageId;

	private String resultOfEvent;

	private Date effectiveDate;

	private String effectiveDateStr;

	private String numberOfDays;

	private String eapCompleteDate;

	private Date reinstateDate;

	private String offcCount;

	private String regFlag;

	private String radioGroup = "No"; 

	private Date lastOnDutyDateTimeDate;

	private String lastOnDutyDateTime;

	private String eventRecorder;

	private String lastOnDutyDateTimeLabel;

	private String emplStatus;

	 private String workHistoryLink;
	  
	  private String disciplineHistoryLink;
	  
	  private String jobHistoryLink;
	  
	  private List<LicenseGridDetail> licenseDetailAll;

	public List<LicenseGridDetail> getLicenseDetailAll() {
		return licenseDetailAll;
	}

	public void setLicenseDetailAll(List<LicenseGridDetail> licenseDetailAll) {
		this.licenseDetailAll = licenseDetailAll;
	}

	public Integer getEventDetailID() {
		return eventDetailID;
	}

	public void setEventDetailID(final Integer eventID) {
		eventDetailID = eventID;
	}

	public String getEmployeeID() {
		return employeeID;
	}

	public void setEmployeeID(final String employeeID) {
		this.employeeID = employeeID;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(final String employeeName) {
		this.employeeName = employeeName;
	}


	/**
	 * @return the emplStatus
	 */
	public String getEmplStatus() {
		return emplStatus;
	}

	/**
	 * @param emplStatus the emplStatus to set
	 */
	public void setEmplStatus(final String emplStatus) {
		this.emplStatus = emplStatus;
	}

	public Integer getWorkItemID() {
		return workItemID;
	}

	public void setWorkItemID(Integer workItemID) {
		this.workItemID = workItemID;
	}

	public DropdownChoice getRevocationPeriod() {
		return revocationPeriod;
	}

	public boolean isLerbAction() {
		return isLerbAction;
	}

	public void setLerbAction(boolean isLerbAction) {
		this.isLerbAction = isLerbAction;
	}

	public void setRevocationPeriod(DropdownChoice revocationPeriod) {
		this.revocationPeriod = revocationPeriod;
	}

	public String getEffDate() {
		return effDate;
	}

	public void setEffDate(String effDate) {
		this.effDate = effDate;
	}

	public String getNoOfDays() {
		return noOfDays;
	}

	public void setNoOfDays(String noOfDays) {
		this.noOfDays = noOfDays;
	}

	public String getEapRequired() {
		return eapRequired;
	}

	public void setEapRequired(String eapRequired) {
		this.eapRequired = eapRequired;
	}

	public Integer getEvntRvkeDtlsId() {
		return evntRvkeDtlsId;
	}

	public void setEvntRvkeDtlsId(Integer evntRvkeDtlsId) {
		this.evntRvkeDtlsId = evntRvkeDtlsId;
	}

	public DropdownChoice getRegion() {
		return region;
	}

	public void setRegion(DropdownChoice region) {
		this.region = region;
	}

	public DropdownChoice getServiceUnit() {
		return serviceUnit;
	}

	public void setServiceUnit(DropdownChoice serviceUnit) {
		this.serviceUnit = serviceUnit;
	}

	public DropdownChoice getTypeOfEvent() {
		return typeOfEvent;
	}

	public void setTypeOfEvent(DropdownChoice typeOfEvent) {
		this.typeOfEvent = typeOfEvent;
	}

	public String getRegulation() {
		return regulation;
	}

	public void setRegulation(String regulation) {
		this.regulation = regulation;
	}

	public String getEventDate() {
		return eventDate;
	}

	public void setEventDate(String eventDate) {
		this.eventDate = eventDate;
	}

	public String getEventDateTime() {
		return eventDateTime;
	}

	public void setEventDateTime(String eventDateTime) {
		this.eventDateTime = eventDateTime;
	}

	public String getOnDutyDateTime() {
		return onDutyDateTime;
	}

	public void setOnDutyDateTime(String onDutyDateTime) {
		this.onDutyDateTime = onDutyDateTime;
	}

	public String getResponsibleManager() {
		return responsibleManager;
	}

	public void setResponsibleManager(String responsibleManager) {
		this.responsibleManager = responsibleManager;
	}

	public String getResponsibleManageId() {
		return responsibleManageId;
	}

	public void setResponsibleManageId(String responsibleManageId) {
		this.responsibleManageId = responsibleManageId;
	}

	public String getResultOfEvent() {
		return resultOfEvent;
	}

	public void setResultOfEvent(String resultOfEvent) {
		this.resultOfEvent = resultOfEvent;
	}

	public Date getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public String getEffectiveDateStr() {
		return effectiveDateStr;
	}

	public void setEffectiveDateStr(String effectiveDateStr) {
		this.effectiveDateStr = effectiveDateStr;
	}

	public String getNumberOfDays() {
		return numberOfDays;
	}

	public void setNumberOfDays(String numberOfDays) {
		this.numberOfDays = numberOfDays;
	}

	public String getEapCompleteDate() {
		return eapCompleteDate;
	}

	public void setEapCompleteDate(String eapCompleteDate) {
		this.eapCompleteDate = eapCompleteDate;
	}

	public Date getReinstateDate() {
		return reinstateDate;
	}

	public void setReinstateDate(Date reinstateDate) {
		this.reinstateDate = reinstateDate;
	}

	public String getOffcCount() {
		return offcCount;
	}

	public void setOffcCount(String offcCount) {
		this.offcCount = offcCount;
	}

	public String getRegFlag() {
		return regFlag;
	}

	public void setRegFlag(String regFlag) {
		this.regFlag = regFlag;
	}

	public String getRadioGroup() {
		return radioGroup;
	}

	public void setRadioGroup(String radioGroup) {
		this.radioGroup = radioGroup;
	}

	public Date getLastOnDutyDateTimeDate() {
		return lastOnDutyDateTimeDate;
	}

	public void setLastOnDutyDateTimeDate(Date lastOnDutyDateTimeDate) {
		this.lastOnDutyDateTimeDate = lastOnDutyDateTimeDate;
	}

	public String getLastOnDutyDateTime() {
		return lastOnDutyDateTime;
	}

	public void setLastOnDutyDateTime(String lastOnDutyDateTime) {
		this.lastOnDutyDateTime = lastOnDutyDateTime;
	}

	public String getEventRecorder() {
		return eventRecorder;
	}

	public void setEventRecorder(String eventRecorder) {
		this.eventRecorder = eventRecorder;
	}

	public String getLastOnDutyDateTimeLabel() {
		return lastOnDutyDateTimeLabel;
	}

	public void setLastOnDutyDateTimeLabel(String lastOnDutyDateTimeLabel) {
		this.lastOnDutyDateTimeLabel = lastOnDutyDateTimeLabel;
	}
	
	public String getWorkHistoryLink() {
		return workHistoryLink;
	}

	public void setWorkHistoryLink(String workHistoryLink) {
		this.workHistoryLink = workHistoryLink;
	}

	public String getDisciplineHistoryLink() {
		return disciplineHistoryLink;
	}

	public void setDisciplineHistoryLink(String disciplineHistoryLink) {
		this.disciplineHistoryLink = disciplineHistoryLink;
	}

	public String getJobHistoryLink() {
		return jobHistoryLink;
	}

	public void setJobHistoryLink(String jobHistoryLink) {
		this.jobHistoryLink = jobHistoryLink;
	}
}
