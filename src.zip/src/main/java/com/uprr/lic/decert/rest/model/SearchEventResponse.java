package com.uprr.lic.decert.rest.model;

public class SearchEventResponse {
  private String serviceUnit;

  private Integer serviceUnitNbr;

  private String eventDate;

  private String typeOfEventAndRegulation;

  private String eventStatus;

  private String responsibleManager;

  private String responsibleManagerID;

  private String employeeID;

  private String employeePositionAndName;

  private String employeeStatus;

  private String date;

  private Integer eventDetailID;

  private Integer eventTypeID;

  private String creationEmployeeID;

  private String employeeDetailsGroup;

  private String responsibleManagerSvcUnit;

  private String evntSrc;

  private String regulation;

  private String selectedEvent;
  //added for displaying date only
  private String eventDateOnly;
  private String eventTime;

  public String getServiceUnit() {
    return serviceUnit;
  }

  public void setServiceUnit(String serviceUnit) {
    this.serviceUnit = serviceUnit;
  }

  public Integer getServiceUnitNbr() {
    return serviceUnitNbr;
  }

  public void setServiceUnitNbr(Integer serviceUnitNbr) {
    this.serviceUnitNbr = serviceUnitNbr;
  }

  public String getEventDate() {
    return eventDate;
  }

  public void setEventDate(String eventDate) {
    this.eventDate = eventDate;
  }

  public String getTypeOfEventAndRegulation() {
    return typeOfEventAndRegulation;
  }

  public void setTypeOfEventAndRegulation(String typeOfEventAndRegulation) {
    this.typeOfEventAndRegulation = typeOfEventAndRegulation;
  }

  public String getEventStatus() {
    return eventStatus;
  }

  public void setEventStatus(String eventStatus) {
    this.eventStatus = eventStatus;
  }

  public String getResponsibleManager() {
    return responsibleManager;
  }

  public void setResponsibleManager(String responsibleManager) {
    this.responsibleManager = responsibleManager;
  }

  public String getResponsibleManagerID() {
    return responsibleManagerID;
  }

  public void setResponsibleManagerID(String responsibleManagerID) {
    this.responsibleManagerID = responsibleManagerID;
  }

  public String getEmployeeID() {
    return employeeID;
  }

  public void setEmployeeID(String employeeID) {
    this.employeeID = employeeID;
  }

  public String getEmployeePositionAndName() {
    return employeePositionAndName;
  }

  public void setEmployeePositionAndName(String employeePositionAndName) {
    this.employeePositionAndName = employeePositionAndName;
  }

  public String getEmployeeStatus() {
    return employeeStatus;
  }

  public void setEmployeeStatus(String employeeStatus) {
    this.employeeStatus = employeeStatus;
  }

  public String getDate() {
    return date;
  }

  public void setDate(String date) {
    this.date = date;
  }

  public Integer getEventDetailID() {
    return eventDetailID;
  }

  public void setEventDetailID(Integer eventDetailID) {
    this.eventDetailID = eventDetailID;
  }

  public Integer getEventTypeID() {
    return eventTypeID;
  }

  public void setEventTypeID(Integer eventTypeID) {
    this.eventTypeID = eventTypeID;
  }

  public String getCreationEmployeeID() {
    return creationEmployeeID;
  }

  public void setCreationEmployeeID(String creationEmployeeID) {
    this.creationEmployeeID = creationEmployeeID;
  }

  public String getEmployeeDetailsGroup() {
    return employeeDetailsGroup;
  }

  public void setEmployeeDetailsGroup(String employeeDetailsGroup) {
    this.employeeDetailsGroup = employeeDetailsGroup;
  }

  public String getResponsibleManagerSvcUnit() {
    return responsibleManagerSvcUnit;
  }

  public void setResponsibleManagerSvcUnit(String responsibleManagerSvcUnit) {
    this.responsibleManagerSvcUnit = responsibleManagerSvcUnit;
  }

  public String getEvntSrc() {
    return evntSrc;
  }

  public void setEvntSrc(String evntSrc) {
    this.evntSrc = evntSrc;
  }

  public String getRegulation() {
    return regulation;
  }

  public void setRegulation(String regulation) {
    this.regulation = regulation;
  }

  public String getSelectedEvent() {
    return selectedEvent;
  }

  public void setSelectedEvent(String selectedEvent) {
    this.selectedEvent = selectedEvent;
  }

public String getEventDateOnly() {
	return eventDateOnly;
}

public void setEventDateOnly(String eventDateOnly) {
	this.eventDateOnly = eventDateOnly;
}

public String getEventTime() {
	return eventTime;
}

public void setEventTime(String eventTime) {
	this.eventTime = eventTime;
}
  

}
