package com.uprr.lic.decert.rest.model;

import com.uprr.lic.dataaccess.decertification.model.IncidentHistory;

public class IncidentHistoryDeleteCommentDetails {
	private IncidentHistory incidentHistory;
	
	
	private boolean onlyCmntDeleteFlag;
	
	private boolean suspDocFlag;
	
	private String subjectMail;
	
	private String employeeId;
	
	private String employeeName;

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public IncidentHistory getIncidentHistory() {
		return incidentHistory;
	}

	public void setIncidentHistory(IncidentHistory incidentHistory) {
		this.incidentHistory = incidentHistory;
	}

	public boolean isOnlyCmntDeleteFlag() {
		return onlyCmntDeleteFlag;
	}

	public void setOnlyCmntDeleteFlag(boolean onlyCmntDeleteFlag) {
		this.onlyCmntDeleteFlag = onlyCmntDeleteFlag;
	}

	public boolean isSuspDocFlag() {
		return suspDocFlag;
	}

	public void setSuspDocFlag(boolean suspDocFlag) {
		this.suspDocFlag = suspDocFlag;
	}

	public String getSubjectMail() {
		return subjectMail;
	}

	public void setSubjectMail(String subjectMail) {
		this.subjectMail = subjectMail;
	}
	

}
