package com.uprr.lic.decert.restcontroller;

import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

//This controller is used to ping from UI to check app working
//or 
//if the app is running in local environment, validate user
@Controller
public class PingController {

  @RequestMapping(value = "/pingservice", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
  @ResponseBody
  public boolean ping() {
    return true;
  }
}
