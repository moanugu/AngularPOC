package com.uprr.lic.decert.rest.model;

import java.util.Date;

public class RemedialTrainingDetails {
	private Integer eventDetailId;
	
	private String employeeId;
	
	private Date  reinstateDate;
	
	private String comments;
	
	private boolean eapReqdAndCompleted;
	
	private Integer serviceUnitNumber;
	
	private String responsibleManagerId;
	
	private String crtnId;
	
	private Integer workItemId;

	public Integer getEventDetailId() {
		return eventDetailId;
	}

	public void setEventDetailId(Integer eventDetailId) {
		this.eventDetailId = eventDetailId;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public Date getReinstateDate() {
		return reinstateDate;
	}

	public void setReinstateDate(Date reinstateDate) {
		this.reinstateDate = reinstateDate;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public boolean getEapReqdAndCompleted() {
		return eapReqdAndCompleted;
	}

	public void setEapReqdAndCompleted(boolean eapReqdAndCompleted) {
		this.eapReqdAndCompleted = eapReqdAndCompleted;
	}

	public Integer getServiceUnitNumber() {
		return serviceUnitNumber;
	}

	public void setServiceUnitNumber(Integer serviceUnitNumber) {
		this.serviceUnitNumber = serviceUnitNumber;
	}

	public String getResponsibleManagerId() {
		return responsibleManagerId;
	}

	public void setResponsibleManagerId(String responsibleManagerId) {
		this.responsibleManagerId = responsibleManagerId;
	}

	public String getCrtnId() {
		return crtnId;
	}

	public void setCrtnId(String crtnId) {
		this.crtnId = crtnId;
	}

	public Integer getWorkItemId() {
		return workItemId;
	}

	public void setWorkItemId(Integer workItemId) {
		this.workItemId = workItemId;
	}

}
