package com.uprr.lic.decert.restcontroller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.uprr.lic.dataaccess.decertification.model.LicenseGridDetail;
import com.uprr.lic.decert.service.ISuspendUnsuspendService;

@Controller
public class SuspendUnsuspendController {
	
	@Autowired
	private ISuspendUnsuspendService suspendUnsuspendServ;

	@RequestMapping(method = RequestMethod.GET, value="/checkEmplToAdd/{employeeId}", headers="Accept=application/json")
	@ResponseBody
	public String isValidEmployee(@PathVariable String employeeId) {
		return  suspendUnsuspendServ.checkEmplToAdd(employeeId);
	}
	
	@RequestMapping(method = RequestMethod.POST, value="/getLicGridList/{employeeId}")
	@ResponseBody
	public  List<LicenseGridDetail> getLicenseGridList(@PathVariable String employeeId) {
	return suspendUnsuspendServ.getLicenseGridList(employeeId);
	}
	@RequestMapping(method = RequestMethod.GET, value="/isRevoCnfrmForEmpl/{employeeId}")
	@ResponseBody
	public Boolean isRevocationConfirmedForEmployee(@PathVariable final String employeeId) {
	    return suspendUnsuspendServ.isRevocationConfirmedForEmployee(employeeId);
	  }
	@RequestMapping(method = RequestMethod.GET, value="/isEmplDecertified/{employeeId}")
	@ResponseBody
	public Boolean isEmployeeDecertified(@PathVariable final String employeeId){
		return suspendUnsuspendServ.isEmployeeDecertified(employeeId);
	}
	@RequestMapping(method = RequestMethod.GET, value="/isEmplPrsntInAnyEvnt/{employeeId}")
	@ResponseBody
	public Boolean isEmployeePresentInAnyEvent(@PathVariable final String employeeId){
		return suspendUnsuspendServ.isEmployeePresentInAnyEvent(employeeId);
	}
	@RequestMapping(method = RequestMethod.GET, value="/isEmployeeSuspended/{employeeId}")
	@ResponseBody
	public Boolean isEmployeeSuspended(@PathVariable final String employeeId){
		return suspendUnsuspendServ.isEmployeePresentInAnyEvent(employeeId);
	}
	
	@RequestMapping(method = RequestMethod.GET, value="/insertEmployeeSuspensionDetails/{employeeId}/{comments}/{loggedInEmpl}")//change parameter
	@ResponseBody
	public Boolean insertEmployeeSuspensionDetails(@PathVariable String employeeId,@PathVariable String comments,@PathVariable String loggedInEmpl){
		return suspendUnsuspendServ.insertEmployeeSuspensionDetails(employeeId,comments,loggedInEmpl);
	}
	
	@RequestMapping(method = RequestMethod.GET, value="/updateEmployeeSuspensionDetails/{employeeId}/{comments}/{loggedInEmpl}")//change parameter
	@ResponseBody
	public Boolean updateEmployeeSuspensionDetails(@PathVariable String employeeId,@PathVariable String comments,@PathVariable String loggedInEmpl){
		return suspendUnsuspendServ.updateEmployeeSuspensionDetails(employeeId,comments,loggedInEmpl);
	}
	
}
