package com.uprr.lic.decert.rest.model;
import com.uprr.lic.dataaccess.common.model.EqmEmplCmntDtls;

public class VerifyMapsDetails {
	private Integer veifyMapsWorkItem;
	private EqmEmplCmntDtls EqmEmplCmntDtls;
	public Integer getVeifyMapsWorkItem() {
		return veifyMapsWorkItem;
	}
	public void setVeifyMapsWorkItem(Integer veifyMapsWorkItem) {
		this.veifyMapsWorkItem = veifyMapsWorkItem;
	}
	public EqmEmplCmntDtls getEqmEmplCmntDtls() {
		return EqmEmplCmntDtls;
	}
	public void setEqmEmplCmntDtls(EqmEmplCmntDtls eqmEmplCmntDtls) {
		EqmEmplCmntDtls = eqmEmplCmntDtls;
	}
}
