package com.uprr.lic.decert.restcontroller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.uprr.lic.auth.EQMSUserSession;
import com.uprr.lic.dataaccess.decertification.model.WorkQueueLcnsDtl;
import com.uprr.lic.decert.jms.cmts.PendingRulesSender;
import com.uprr.lic.decert.service.IWorkQueueService;
@Controller
public class WorkQueueController {
  @Autowired
  IWorkQueueService iworkqueueservice;

  @Autowired
  PendingRulesSender pendingRulesSender;

  @Autowired
  EQMSUserSession eqmsUserSession;

  @RequestMapping(method = RequestMethod.POST, value = "/updateWorkQueueDetailst")
  @ResponseBody
  public boolean updateWorkQueueDetailst(@RequestBody WorkQueueLcnsDtl workQueueLcnsDtl) {
    workQueueLcnsDtl.setLoggedInUserId(eqmsUserSession.getUser().getEmplId());
	
    boolean isapprove = iworkqueueservice.updateWorkQueueDetailst(workQueueLcnsDtl, pendingRulesSender);
    return isapprove;
  }

  @RequestMapping(method = RequestMethod.POST, value = "/updateWorkQueueDetailstfordaa")
  @ResponseBody
  public boolean updateWorkQueueDetailstForDAA(@RequestBody WorkQueueLcnsDtl workQueueLcnsDtl) {
    workQueueLcnsDtl.setLoggedInUserId(eqmsUserSession.getUser().getEmplId());
    boolean isapprove = iworkqueueservice.updateWorkQueueDetailstForDAA(workQueueLcnsDtl, pendingRulesSender);
    return isapprove;
  }

} 



