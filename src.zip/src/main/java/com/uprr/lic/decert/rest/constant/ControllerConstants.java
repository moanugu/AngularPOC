package com.uprr.lic.decert.rest.constant;

public class ControllerConstants {
	
	public static final String GET_REGION_LIST = "/getRegionList"; 
	public static final String GET_TYPE_OF_EVENTS = "/getTypeOfEvents"; 
	public static final String GET_SEARCH_EVENTS = "/searchEvents";
	public static final String GET_SERVICE_UNITS_BY_REGION = "/getServiceUnitsByRegion/{region}";
}
