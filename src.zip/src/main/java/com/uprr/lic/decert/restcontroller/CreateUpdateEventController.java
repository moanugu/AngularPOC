package com.uprr.lic.decert.restcontroller;

import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.uprr.lic.dataaccess.common.model.DecertDDChoice;
import com.uprr.lic.dataaccess.common.model.EqmGisMpLoc;
import com.uprr.lic.dataaccess.decertification.model.EventEmployeeDetail;
import com.uprr.lic.dataaccess.decertification.model.FaxSuspensionDetail;
import com.uprr.lic.dataaccess.decertification.model.TrainDetail;
import com.uprr.lic.dataaccess.fte.model.Train;
import com.uprr.lic.decert.rest.model.CreateEventRequest;
import com.uprr.lic.decert.rest.model.DropdownChoice;
import com.uprr.lic.decert.rest.model.EmployeeDetailResponse;
import com.uprr.lic.decert.rest.model.EventDescDetail;
import com.uprr.lic.decert.service.ICreateUpdateEventService;
import com.uprr.lic.util.SysParamBean;



@Controller
public class CreateUpdateEventController {

	@Autowired
	private ICreateUpdateEventService createUpdateEventService;

	@RequestMapping(method = RequestMethod.GET, value="/getResultOfEvents", headers="Accept=application/json")
	@ResponseBody
	public  List<String> getResultOfEventList() {
		return createUpdateEventService.getResultOfEventList();	
	}
	

	@SuppressWarnings("unchecked")
	@RequestMapping(method = RequestMethod.GET, value="/getLerbActionList", headers="Accept=application/json")
	@ResponseBody
	public List<DropdownChoice>  getLerbActionList() {
		return createUpdateEventService.getSysParmLerbAction();
	}
	
	@RequestMapping(method = RequestMethod.GET, value="/getEventTypes", headers="Accept=application/json")
	@ResponseBody
	public  List<DropdownChoice> getEventTypeList() {
		return createUpdateEventService.getEventTypeList();	
	}
	
	@RequestMapping(method = RequestMethod.GET, value="/getEventDescriptions", headers="Accept=application/json")
	@ResponseBody
	public  List<EventDescDetail> getEventDescriptionList() {			
		return createUpdateEventService.getEventDescriptionList();
	}
	
	@RequestMapping(method = RequestMethod.GET, value="/getSignalTerritories", headers="Accept=application/json")
	@ResponseBody
	public  List<String> getSignalTerritoryList() {
		return createUpdateEventService.getSignalTerritoryList();	
	}
	
	@RequestMapping(method = RequestMethod.GET, value="/getTypeOfTracks", headers="Accept=application/json")
	@ResponseBody
	public  List<String> getTypeOfTrackList() {
		return createUpdateEventService.getTypeOfTrackList();	
	}
	
	@SuppressWarnings("unchecked")
	@RequestMapping(method = RequestMethod.GET, value="/getRailRoads", headers="Accept=application/json")
	@ResponseBody
	public  List<DropdownChoice> getRailRoadList() {
		return  createUpdateEventService.getRailRoadList()	;
	}
	
	@RequestMapping(method = RequestMethod.GET, value="/getTypeofAuthorities", headers="Accept=application/json")
	@ResponseBody
	public  List<String> getTypeofAuthorityList() {
		return createUpdateEventService.getTypeofAuthorityList();	
	}
	
	@RequestMapping(method = RequestMethod.GET, value="/getWeathers", headers="Accept=application/json")
	@ResponseBody
	public  List<DropdownChoice> getWeatherList() {
		return createUpdateEventService.getWeatherList();	
	}
	
	@RequestMapping(method = RequestMethod.GET, value="/getVisibilities", headers="Accept=application/json")
	@ResponseBody
	public  List<DropdownChoice> getVisibilityList() {
		return createUpdateEventService.getVisibilityList();	
	}
	
	@RequestMapping(method = RequestMethod.GET, value="/getOperations", headers="Accept=application/json")
	@ResponseBody
	public  List<String> getOperationList() {
		return createUpdateEventService.getOperationList();	
	}
	
	@RequestMapping(method = RequestMethod.GET, value="/getGrades", headers="Accept=application/json")
	@ResponseBody
	public  List<String> getGradeList() {
		return createUpdateEventService.getGradeList();	
	}
	
	@RequestMapping(method = RequestMethod.GET, value="/getCurvatures", headers="Accept=application/json")
	@ResponseBody
	public  List<String> getCurvatureList() {
		return createUpdateEventService.getCurvatureList();	
	}
	
	@RequestMapping(method = RequestMethod.GET, value="/getCrewTypes", headers="Accept=application/json")
	@ResponseBody
	public  List<String> getCrewTypeList() {
		return createUpdateEventService.getCrewTypeList();	
	}
	
	@RequestMapping(method = RequestMethod.GET, value="/getEmployeeDetailsByID/{employeeId}", headers="Accept=application/json")
	@ResponseBody
	public EmployeeDetailResponse getEmployeeDetailsByID(@PathVariable String employeeId) {
		return  createUpdateEventService.getEmployeeDetailsByID(employeeId);
	}
	
	@RequestMapping(method = RequestMethod.GET, value="/getPositions", headers="Accept=application/json")
	@ResponseBody
	public List<DropdownChoice> getPositionList() {
		return  createUpdateEventService.getPositionList();
	}
	
	@RequestMapping(method = RequestMethod.GET, value="/getLicensedPositions", headers="Accept=application/json")
	@ResponseBody
	public List<String> getLicensedPositionList() {
		return  createUpdateEventService.getLicensedPositionList();
	}
	
	@RequestMapping(method = RequestMethod.GET, value="/getDirections", headers="Accept=application/json")
	@ResponseBody
	public List<String> getDirectionList() {
		return  createUpdateEventService.getDirectionList();
	}
	
	@RequestMapping(method = RequestMethod.GET, value="/getLastJobBrefs", headers="Accept=application/json")
	@ResponseBody
	public List<String> getLastJobBrefList() {
		return  createUpdateEventService.getLastJobBrefList();
	}
	
	@RequestMapping(method = RequestMethod.GET, value="/getDecertRegulations/{position}", headers="Accept=application/json")
	@ResponseBody
	public List<DropdownChoice> getDecertRegulationList(String position) {
		return  createUpdateEventService.getDecertRegulationList(position);
	}
	
	@RequestMapping(method = RequestMethod.GET, value="/getOtherRegulations", headers="Accept=application/json")
	@ResponseBody
	public List<DropdownChoice> getOtherRegulationList() {
		return  createUpdateEventService.getOtherRegulationList();
	}	
	
	@RequestMapping(method = RequestMethod.GET, value="/getSuspensions", headers="Accept=application/json")
	@ResponseBody
	public List<String> getSuspendedList() {
		return  createUpdateEventService.getSuspendedList();
	}
	
	@RequestMapping(method = RequestMethod.POST, value="/insertEventDetails")
	@ResponseBody	 
	public Boolean insertEvent(MultipartHttpServletRequest  multipartRequest) {			
		return createUpdateEventService.insertEvent(multipartRequest);
	}
	
	@RequestMapping(method = RequestMethod.POST, value="/updateEventDetails")
	@ResponseBody	
	public Boolean updateEvent(MultipartHttpServletRequest  multipartRequest) {			
		return createUpdateEventService.updateEvent(multipartRequest);
	}
	
	@RequestMapping(method = RequestMethod.GET, value="/getSubDivision/{svcUnitName}")
	@ResponseBody
	public Collection<DropdownChoice> getSubDivision(@PathVariable String svcUnitName) {		
		return  createUpdateEventService.getSubDivision(svcUnitName);
	}	
	 
	@RequestMapping(method = RequestMethod.POST, value="/getEventDetails/{eventDetailID}")
	@ResponseBody
	public CreateEventRequest getEventDetails(@PathVariable Integer eventDetailID) { 
	    return createUpdateEventService.getEventDetails(eventDetailID);
	}
	
	
	@RequestMapping(method = RequestMethod.GET, value="/getPrimRulesForEvntDate")
	@ResponseBody
	public Map<Integer,List<DecertDDChoice>> getPrimRulesForEvntDate(@RequestParam("eventDate") String eventDate)  { 
	    return createUpdateEventService.getPrimRulesForEvntDate(eventDate);
	}
	
	@RequestMapping(method = RequestMethod.GET, value="/getRegulations")
	@ResponseBody
	public Map<String, List<DecertDDChoice>> getRegulations() {
		 return createUpdateEventService.getRegulations();
	}
	
	@RequestMapping(method = RequestMethod.GET, value="/getConductorVisibFlag")
	@ResponseBody
	public boolean getConductorVisibFlag() {
		return createUpdateEventService.getConductorVisibFlag();
	}
	

	@RequestMapping(method = RequestMethod.POST, value="/updatelerbAssignedTo/{lerbAssignedTo}")
	@ResponseBody
	public boolean updatelerbAssignedTo(@RequestBody FaxSuspensionDetail faxSuspensionDetail,@PathVariable String lerbAssignedTo) {
	  faxSuspensionDetail.setLerbAssignedTo(lerbAssignedTo);
	  return createUpdateEventService.updatelerbAssignedTo(faxSuspensionDetail);
	}
	
	
	@RequestMapping(method = RequestMethod.POST, value="/isValidEmployee/{employeeId}", headers="Accept=application/json")
	@ResponseBody
	public boolean isValidEmployee(@PathVariable String employeeId) {
		return  createUpdateEventService.isValidEmployee(employeeId);
	}

	@RequestMapping(method = RequestMethod.GET, value="/getRegSubDiv/{subDvsn}/{milePost}")
	@ResponseBody
	public List<EqmGisMpLoc> getRegSvcUnit(@PathVariable String subDvsn, @PathVariable String milePost) { 
	    return createUpdateEventService.getServiceUnitBySubdvsnMp(subDvsn,milePost);
	}
	
	@RequestMapping(method = RequestMethod.GET, value="/getCrewData")
	@ResponseBody
	public Map<String, HashSet<EventEmployeeDetail>> getCrewData(@RequestParam(value = "section", required=false) String section, @RequestParam("symbol") String symbol, @RequestParam("day") String day, 
			@RequestParam("eventDate") String eventDate) { 
	    return createUpdateEventService.getCrewData(section, symbol, day, eventDate);
	}
	
	@RequestMapping(method = RequestMethod.POST, value="/validateHowLongOperating/{condVisibFlag}")
	@ResponseBody
	public boolean validateHowLongOperating(@RequestBody CreateEventRequest createEventRequest,@PathVariable boolean condVisibFlag) {
		return createUpdateEventService.validateHowLongOperating(createEventRequest,condVisibFlag);
	}

	@RequestMapping(method = RequestMethod.GET, value="/getSystemParam")
	@ResponseBody
	public Map<String, SysParamBean> getSystemParam() {
		 return createUpdateEventService.getSystemParam();
	}
	
	@RequestMapping(method = RequestMethod.POST, value="/checkIfEmployeeDetailsCanBeUpdated/{eventDetailId}/{eventStatus}")
	@ResponseBody
	public String checkIfEmployeeDetailsCanBeUpdated(@PathVariable Integer eventDetailId, @PathVariable String eventStatus) {
		return createUpdateEventService.checkIfEmployeeDetailsCanBeUpdated(eventDetailId,eventStatus);
	}
	
	@RequestMapping(method = RequestMethod.GET, value = "/getTrainDetails")
	@ResponseBody
	public List<Train> getTrainDetails(@RequestParam(value = "section", required=false) String section, @RequestParam(value = "symbol", required=false) String symbol, 
			@RequestParam(value = "day", required=false) String day) {
		return createUpdateEventService.getTrainDetails(section,symbol,day);
	}
	
	@RequestMapping(method = RequestMethod.GET, value = "/getTrainDetail")
	@ResponseBody
	public List<TrainDetail> getTrainDetail(@RequestParam(value = "section", required=false) String section, @RequestParam("symbol") String symbol, @RequestParam("day") String day, 
			@RequestParam("eventDate") String eventDate) {
		return createUpdateEventService.getTrainDetail(section,symbol,day,eventDate);
	}

	@RequestMapping(method = RequestMethod.GET, value="/getSignalMasterData")
	@ResponseBody
	public List<DecertDDChoice> getSignalMasterData() {
		 return createUpdateEventService.getSignalMasterData();
	}

	@RequestMapping(method = RequestMethod.GET, value="/validateMilePostSvcUntAndSubDv")
	@ResponseBody
	public boolean validateMilePostSvcUntAndSubDv(@PathVariable String milePost, @PathVariable Integer svcUnitNbr, @PathVariable String subDvsn) {		 
		 return createUpdateEventService.validateMilePostSvcUntAndSubDv(Integer.parseInt(milePost), svcUnitNbr, subDvsn);
	}
	
	@RequestMapping(method = RequestMethod.POST, value="/sendHFRReport")
	@ResponseBody	 
	public Map<String, String> sendHFRReport(@RequestBody CreateEventRequest createEventRequest) {			
		return createUpdateEventService.sendHFRReport(createEventRequest);
	}
	
}
