package com.uprr.lic.decert.rest.model;

import java.util.List;

import com.uprr.lic.dataaccess.decertification.model.EventLocationDetail;
import com.uprr.lic.dataaccess.decertification.model.OtherDetail;
import com.uprr.lic.dataaccess.decertification.model.TrainDetail;
import com.uprr.lic.util.DDChoice;

public class EventDetailsResponse {
	
	private Integer evntDtlId;
	private boolean isDrugAlcoholRegulation;
	private String eventDate;
	private String typeOfEvent;
	private String regulation;
	private String occurredOn;
	private String respMngr;
	private List resultOfEventAll;
	private String resultOfEvent;
	private String mngrDescOfIncd;
	private String mngrComments;
	private String mngrComments1;
	private TrainDetail trainDetail;
	private EventLocationDetail locationDetail;
	private OtherDetail otherDetail;
	private List eventDocumentGridBean;
	private List eventEmployeeAll;
	private String eventTime;
	private Integer reasonID;
	private String docketNumber;
	private String responseType;
	private String evntSrc;
	private String evntDescrptn;
	private String userID;
	private boolean isDecert;
	private String firstDrugEvent;	  
	private boolean firAlco;	 
	private boolean firDrug;
	private boolean isOtherEvnt;	  
	private boolean isLerbAction;
	private boolean isUpdate;
	private DDChoice typeOfEventAll;
	 private DDChoice evntDesc;
  // QC 1056 - LERB - Starts
    private List eventLerbDetailAll;
	

	public Integer getEvntDtlId() {
		return evntDtlId;
	}

	public void setEvntDtlId(Integer evntDtlId) {
		this.evntDtlId = evntDtlId;
	}

	public boolean isDrugAlcoholRegulation() {
		return isDrugAlcoholRegulation;
	}

	public void setDrugAlcoholRegulation(boolean isDrugAlcoholRegulation) {
		this.isDrugAlcoholRegulation = isDrugAlcoholRegulation;
	}

	public String getEventDate() {
		return eventDate;
	}

	public void setEventDate(String eventDate) {
		this.eventDate = eventDate;
	}

	

	public String getMngrComments1() {
		return mngrComments1;
	}

	public void setMngrComments1(String mngrComments1) {
		this.mngrComments1 = mngrComments1;
	}

	public String getTypeOfEvent() {
		return typeOfEvent;
	}

	public void setTypeOfEvent(String typeOfEvent) {
		this.typeOfEvent = typeOfEvent;
	}

	public String getEvntDescrptn() {
		return evntDescrptn;
	}

	public void setEvntDescrptn(String evntDescrptn) {
		this.evntDescrptn = evntDescrptn;
	}

	public String getUserID() {
		return userID;
	}

	public void setUserID(String userID) {
		this.userID = userID;
	}

	public boolean isDecert() {
		return isDecert;
	}

	public void setDecert(boolean isDecert) {
		this.isDecert = isDecert;
	}

	public String getFirstDrugEvent() {
		return firstDrugEvent;
	}

	public void setFirstDrugEvent(String firstDrugEvent) {
		this.firstDrugEvent = firstDrugEvent;
	}

	public boolean isFirAlco() {
		return firAlco;
	}

	public void setFirAlco(boolean firAlco) {
		this.firAlco = firAlco;
	}

	public boolean isFirDrug() {
		return firDrug;
	}

	public void setFirDrug(boolean firDrug) {
		this.firDrug = firDrug;
	}

	public boolean isOtherEvnt() {
		return isOtherEvnt;
	}

	public void setOtherEvnt(boolean isOtherEvnt) {
		this.isOtherEvnt = isOtherEvnt;
	}

	public boolean isLerbAction() {
		return isLerbAction;
	}

	public void setLerbAction(boolean isLerbAction) {
		this.isLerbAction = isLerbAction;
	}

	public boolean isUpdate() {
		return isUpdate;
	}

	public void setUpdate(boolean isUpdate) {
		this.isUpdate = isUpdate;
	}

	public String getRegulation() {
		return regulation;
	}

	public void setRegulation(final String regulation) {
		this.regulation = regulation;
	}

	public String getOccurredOn() {
		return occurredOn;
	}

	public void setOccurredOn(final String occurredOn) {
		this.occurredOn = occurredOn;
	}

	public String getRespMngr() {
		return respMngr;
	}

	public void setRespMngr(final String respMngr) {
		this.respMngr = respMngr;
	}

	public List getResultOfEventAll() {
		return resultOfEventAll;
	}

	public void setResultOfEventAll(final List resultOfEventAll) {
		this.resultOfEventAll = resultOfEventAll;
	}

	public String getResultOfEvent() {
		return resultOfEvent;
	}

	public void setResultOfEvent(final String resultOfEvent) {
		this.resultOfEvent = resultOfEvent;
	}

	public String getMngrDescOfIncd() {
		return mngrDescOfIncd;
	}

	public void setMngrDescOfIncd(final String mngrDescOfIncd) {
		this.mngrDescOfIncd = mngrDescOfIncd;
	}

	public String getMngrComments() {
		return mngrComments;
	}

	public void setMngrComments(final String mngrComments) {
		this.mngrComments = mngrComments;
	}

	public TrainDetail getTrainDetail() {
		return trainDetail;
	}

	public void setTrainDetail(final TrainDetail trainDetail) {
		this.trainDetail = trainDetail;
	}

	public EventLocationDetail getLocationDetail() {
		return locationDetail;
	}

	public void setLocationDetail(final EventLocationDetail locationDetail) {
		this.locationDetail = locationDetail;
	}

	public OtherDetail getOtherDetail() {
		return otherDetail;
	}

	public void setOtherDetail(final OtherDetail otherDetail) {
		this.otherDetail = otherDetail;
	}

	public List getEventDocumentGridBean() {
		return eventDocumentGridBean;
	}

	public void setEventDocumentGridBean(final List eventDocumentGridBean) {
		this.eventDocumentGridBean = eventDocumentGridBean;
	}

	public List getEventEmployeeAll() {
		return eventEmployeeAll;
	}

	public void setEventEmployeeAll(final List eventEmployeeAll) {
		this.eventEmployeeAll = eventEmployeeAll;
	}

	public String getEventTime() {
		return eventTime;
	}

	public void setEventTime(final String eventTime) {
		this.eventTime = eventTime;
	}

	public Integer getReasonID() {
		return reasonID;
	}

	public void setReasonID(final Integer reasonID) {
		this.reasonID = reasonID;
	}

	public String getDocketNumber() {
		return docketNumber;
	}

	public void setDocketNumber(final String docketNumber) {
		this.docketNumber = docketNumber;
	}

	public String getResponseType() {
		return responseType;
	}

	public void setResponseType(final String responseType) {
		this.responseType = responseType;
	}

	public String getEvntSrc() {
		return evntSrc;
	}

	public void setEvntSrc(final String evntSrc) {
		this.evntSrc = evntSrc;
	}
	
	public DDChoice getEvntDesc() {
		return evntDesc;
	}
	
	public void setEvntDesc(DDChoice evntDesc) {
		this.evntDesc = evntDesc;
	}
	
	public DDChoice getTypeOfEventAll() {
		return typeOfEventAll;
	}
	
	public void setTypeOfEventAll(DDChoice typeOfEventAll) {
		this.typeOfEventAll = typeOfEventAll;
	}
	
	public List getEventLerbDetailAll() {
	    return eventLerbDetailAll;
	  }

	  public void setEventLerbDetailAll(final List eventLerbDetailAll) {
	    this.eventLerbDetailAll = eventLerbDetailAll;
	  }

}
