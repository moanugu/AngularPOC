package com.uprr.lic.decert.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uprr.lic.dataaccess.decertification.model.LicenseGridDetail;
import com.uprr.lic.dataaccess.decertification.model.SuspendEmployeePageDetail;
import com.uprr.lic.dataaccess.decertification.model.SuspensionGridDetail;
import com.uprr.lic.dataaccess.decertification.services.interfaces.IDecertificationService;
import com.uprr.lic.dataaccess.masters.model.ReasonBean;
import com.uprr.lic.dataaccess.masters.service.IReasonService;
import com.uprr.lic.dataaccess.transactions.EqmsTransactions;
import com.uprr.lic.util.FeedbackMessageConstant;

@Service("suspendUnsuspendService")
public class SuspendUnsuspendService implements ISuspendUnsuspendService{
	@Autowired
	private IDecertificationService decertificationService;
	
	
	public String checkEmplToAdd(String employeeId){
		String isSuccess="true";

		if(employeeId == null) {
          
            return FeedbackMessageConstant.EMPLOYEE_NAME_ID_REQD;
          }
		else if( !decertificationService.isValidEmployee(employeeId)){
			
			 return FeedbackMessageConstant.NO_RECORDS_FOR_EMPLOYEE;
		}
		else if( decertificationService.getLicenseGridList(employeeId).isEmpty()){
			
			 return FeedbackMessageConstant.NO_LICENSE_NO_SUSPEND;
		}
		else if( decertificationService.isEmployeeDecertified(employeeId)){
			 
			 return FeedbackMessageConstant.EMPLOYEE_DECERTIFIED;
		}
		else if(decertificationService.isRevocationConfirmedForEmployee(employeeId)){
			
			 return FeedbackMessageConstant.CONFIRM_REVOCATION_INITIATED;
		}
		else if(decertificationService.isEmployeePresentInAnyEvent(employeeId)){
			 
			 return FeedbackMessageConstant.EMPLOYEE_PRESENT_IN_ANY_EVENT;
		}
		else 
			return isSuccess;
	 }

	public List<LicenseGridDetail> getLicenseGridList(String employeeID) {
		return decertificationService.getLicenseGridList(employeeID);
	}
	public Boolean isRevocationConfirmedForEmployee(final String employeeID) {
	    return decertificationService.isRevocationConfirmedForEmployee(employeeID);
	  }
	public Boolean isEmployeeDecertified(final String employeeID){
		return decertificationService.isEmployeeDecertified(employeeID);
	}
	public Boolean isEmployeePresentInAnyEvent(final String employeeID){
		return decertificationService.isEmployeePresentInAnyEvent(employeeID);
	}
	
	public Boolean isEmployeeSuspended(final String employeeID) {
		return decertificationService.isEmployeeSuspended(employeeID);
	}
	
	public Boolean insertEmployeeSuspensionDetails(String employeeId,String comments,String loggedInEmpl){
		return decertificationService.insertEmployeeSuspensionDetails(employeeId,comments,loggedInEmpl);
	}
	
	@EqmsTransactions
	public Boolean updateEmployeeSuspensionDetails(String employeeId,String comments,String loggedInEmpl) {
		return decertificationService.updateEmployeeSuspensionDetails(employeeId,comments,loggedInEmpl);
	}
	 
}
