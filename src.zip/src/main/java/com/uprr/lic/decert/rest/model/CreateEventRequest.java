/**
 * Classname        : CreateEventRequest.java
 * Description      : This is used as a Bean for Decert Create/Update/Update Lerb Event. 
 * author           : Tech Mahindra
 * Date of creation : 2013
 * 
 * Change History
 * ------------------------------------------------------------  
 * Date        Changed By    Description
 * ------------------------------------------------------------  
 * 08/31/2017  xsat671       Modified for SS_QC#9361
 * ------------------------------------------------------------  
 * 
 * Copyright notice : "Copyright UPRR 2008"
 */
package com.uprr.lic.decert.rest.model;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import com.uprr.lic.dataaccess.decertification.model.EventDocumentGridDetail;
import com.uprr.lic.dataaccess.decertification.model.EventEmployeeDetail;
import com.uprr.lic.dataaccess.decertification.model.EventLerbDetail;
import com.uprr.lic.dataaccess.decertification.model.EventLocationDetail;
import com.uprr.lic.dataaccess.decertification.model.OtherDetail;
import com.uprr.lic.dataaccess.decertification.model.RDTResponseBean;
import com.uprr.lic.dataaccess.decertification.model.RestSpeedAndConRegBean;
import com.uprr.lic.dataaccess.decertification.model.SignalDetailsBean;
import com.uprr.lic.dataaccess.decertification.model.TrainDetail;
import com.uprr.lic.util.DDChoice;

public class CreateEventRequest {

	private DDChoice typeOfEventAll;
	private DDChoice evntDesc;
	private TrainDetail trainDetail;
	private EventLocationDetail locationDetail;
	private OtherDetail otherDetail;
	private EventEmployeeDetail employeeDropDown;
	private SignalDetailsBean signalDetailsBean = new SignalDetailsBean();
	private RDTResponseBean rdtResponseBean;

	private Integer mgrCmntId;
	private Integer evntDtlId;
	private Integer svcUnitNbr;

	private String eventDate;
	private Calendar eventDateCalendar;
	private Calendar crtnDate;

	private RestSpeedAndConRegBean restSpeedAndConRegBean = new RestSpeedAndConRegBean();

	private String mngrComments;
	private String mngrDescOfIncd;
	private String eventTime;
	private String respMngr;
	private String firstAlcoholEvent;
	private String firstDrugEvent;
	private String popupFlag;
	private String typeAuthQuestion;
	private String signalQuestion;
	private String typeAuthTWCQuestion;
	private String evntEntrdLate;
	private String crtnEmplId;
	private String evntSourceSystem;
	private String rdtEventID;
	private String violationTypeCode;
	private String rdtEmplPosition;
	private String evntStatusFlag;
	private String eventDescriptionValue;
	private String oldEvntType = null;
	private String wasDrugAAlco = null;
//	private String userId;
	private String mngrCmntLabel;
	private String mngrCmntLabel1;
	private String mngrComments1;
	private String callCirc7;
	private String drugNAlcoholEvent;

	private List<EventDocumentGridDetail> documentList;
	private List<EventEmployeeDetail> eventEmployeeAll = new ArrayList<EventEmployeeDetail>(); // To
	private List<EventEmployeeDetail> deletedEmployeeAll = new ArrayList<EventEmployeeDetail>();
	private List<EventLerbDetail> eventLerbDetailAll = new ArrayList<EventLerbDetail>();
	private List<String> selectedPopup;
	private List<EventEmployeeDetail> hfrEmplList = new ArrayList<EventEmployeeDetail>();
	private List<String> resultOfEventAll;
	private List<String> licToUnsuspend = new ArrayList<String>();

	private Boolean eventSubmitted = false;
	private Boolean isDecert = false;
	private Boolean isDrugAlcoholRegulation = false;
	private Boolean isLerbUser = false;
	private Boolean suspendFlag = false;
	private Boolean engRegulation = false;
	private Boolean conLicOnly = false;
	private Boolean isPopup = false;
	private Boolean isAfterNewDate = false;
	private Boolean isOtherEvnt = false;
	private Boolean isLerbAction = false;
	private Boolean isMitigateInvalidCloseFlag = false;
	private Boolean isUpdate = false;
	private Boolean isEmpUnsuspended = false;
	private Boolean checkFlag = false;
	private Boolean isDcrtEvntCreated = false;
	private Boolean isMitigate = false;
	private Boolean firAlco = false;
	private Boolean firDrug = false;
	
  // SS_QC#9361 changes start
  private String dateOfKnowledge;

  /**
   * @return the dateOfKnwldge
   */
  public String getDateOfKnowledge() {
    return dateOfKnowledge;
  }

  /**
   * @param dateOfKnwldge
   *          the dateOfKnwldge to set
   */
  public void setDateOfKnowledge(String dateOfKnowledge) {
    this.dateOfKnowledge = dateOfKnowledge;
  }
  // SS_QC#9361 changes end

  public DDChoice getTypeOfEventAll() {
		return typeOfEventAll;
	}

	public void setTypeOfEventAll(DDChoice typeOfEventAll) {
		this.typeOfEventAll = typeOfEventAll;
	}

	public DDChoice getEvntDesc() {
		return evntDesc;
	}

	public void setEvntDesc(DDChoice evntDesc) {
		this.evntDesc = evntDesc;
	}

	public TrainDetail getTrainDetail() {
		return trainDetail;
	}

	public void setTrainDetail(TrainDetail trainDetail) {
		this.trainDetail = trainDetail;
	}

	public EventLocationDetail getLocationDetail() {
		return locationDetail;
	}

	public void setLocationDetail(EventLocationDetail locationDetail) {
		this.locationDetail = locationDetail;
	}

	public OtherDetail getOtherDetail() {
		return otherDetail;
	}

	public void setOtherDetail(OtherDetail otherDetail) {
		this.otherDetail = otherDetail;
	}

	public EventEmployeeDetail getEmployeeDropDown() {
		return employeeDropDown;
	}

	public void setEmployeeDropDown(EventEmployeeDetail employeeDropDown) {
		this.employeeDropDown = employeeDropDown;
	}

	public SignalDetailsBean getSignalDetailsBean() {
		return signalDetailsBean;
	}

	public void setSignalDetailsBean(SignalDetailsBean signalDetailsBean) {
		this.signalDetailsBean = signalDetailsBean;
	}

	public RDTResponseBean getRdtResponseBean() {
		return rdtResponseBean;
	}

	public void setRdtResponseBean(RDTResponseBean rdtResponseBean) {
		this.rdtResponseBean = rdtResponseBean;
	}

	public Integer getMgrCmntId() {
		return mgrCmntId;
	}

	public void setMgrCmntId(Integer mgrCmntId) {
		this.mgrCmntId = mgrCmntId;
	}

	public Integer getEvntDtlId() {
		return evntDtlId;
	}

	public void setEvntDtlId(Integer evntDtlId) {
		this.evntDtlId = evntDtlId;
	}

	public Integer getSvcUnitNbr() {
		return svcUnitNbr;
	}

	public void setSvcUnitNbr(Integer svcUnitNbr) {
		this.svcUnitNbr = svcUnitNbr;
	}

	public String getEventDate() {
		return eventDate;
	}

	public void setEventDate(String eventDate) {
		this.eventDate = eventDate;
	}

	public Calendar getEventDateCalendar() {
		return eventDateCalendar;
	}

	public void setEventDateCalendar(Calendar eventDateCalendar) {
		this.eventDateCalendar = eventDateCalendar;
	}

	public Calendar getCrtnDate() {
		return crtnDate;
	}

	public void setCrtnDate(Calendar crtnDate) {
		this.crtnDate = crtnDate;
	}

	public RestSpeedAndConRegBean getRestSpeedAndConRegBean() {
		return restSpeedAndConRegBean;
	}

	public void setRestSpeedAndConRegBean(RestSpeedAndConRegBean restSpeedAndConRegBean) {
		this.restSpeedAndConRegBean = restSpeedAndConRegBean;
	}

	public String getMngrComments() {
		return mngrComments;
	}

	public void setMngrComments(String mngrComments) {
		this.mngrComments = mngrComments;
	}

	public String getMngrDescOfIncd() {
		return mngrDescOfIncd;
	}

	public void setMngrDescOfIncd(String mngrDescOfIncd) {
		this.mngrDescOfIncd = mngrDescOfIncd;
	}

	public String getEventTime() {
		return eventTime;
	}

	public void setEventTime(String eventTime) {
		this.eventTime = eventTime;
	}

	public String getRespMngr() {
		return respMngr;
	}

	public void setRespMngr(String respMngr) {
		this.respMngr = respMngr;
	}

	public String getFirstAlcoholEvent() {
		return firstAlcoholEvent;
	}

	public void setFirstAlcoholEvent(String firstAlcoholEvent) {
		this.firstAlcoholEvent = firstAlcoholEvent;
	}

	public String getFirstDrugEvent() {
		return firstDrugEvent;
	}

	public void setFirstDrugEvent(String firstDrugEvent) {
		this.firstDrugEvent = firstDrugEvent;
	}

	public String getPopupFlag() {
		return popupFlag;
	}

	public void setPopupFlag(String popupFlag) {
		this.popupFlag = popupFlag;
	}

	public String getTypeAuthQuestion() {
		return typeAuthQuestion;
	}

	public void setTypeAuthQuestion(String typeAuthQuestion) {
		this.typeAuthQuestion = typeAuthQuestion;
	}

	public String getSignalQuestion() {
		return signalQuestion;
	}

	public void setSignalQuestion(String signalQuestion) {
		this.signalQuestion = signalQuestion;
	}

	public String getTypeAuthTWCQuestion() {
		return typeAuthTWCQuestion;
	}

	public void setTypeAuthTWCQuestion(String typeAuthTWCQuestion) {
		this.typeAuthTWCQuestion = typeAuthTWCQuestion;
	}

	public String getEvntEntrdLate() {
		return evntEntrdLate;
	}

	public void setEvntEntrdLate(String evntEntrdLate) {
		this.evntEntrdLate = evntEntrdLate;
	}

	public String getCrtnEmplId() {
		return crtnEmplId;
	}

	public void setCrtnEmplId(String crtnEmplId) {
		this.crtnEmplId = crtnEmplId;
	}

	public String getEvntSourceSystem() {
		return evntSourceSystem;
	}

	public void setEvntSourceSystem(String evntSourceSystem) {
		this.evntSourceSystem = evntSourceSystem;
	}

	public String getRdtEventID() {
		return rdtEventID;
	}

	public void setRdtEventID(String rdtEventID) {
		this.rdtEventID = rdtEventID;
	}

	public String getViolationTypeCode() {
		return violationTypeCode;
	}

	public void setViolationTypeCode(String violationTypeCode) {
		this.violationTypeCode = violationTypeCode;
	}

	public String getRdtEmplPosition() {
		return rdtEmplPosition;
	}

	public void setRdtEmplPosition(String rdtEmplPosition) {
		this.rdtEmplPosition = rdtEmplPosition;
	}

	public String getEvntStatusFlag() {
		return evntStatusFlag;
	}

	public void setEvntStatusFlag(String evntStatusFlag) {
		this.evntStatusFlag = evntStatusFlag;
	}

	public String getEventDescriptionValue() {
		return eventDescriptionValue;
	}

	public void setEventDescriptionValue(String eventDescriptionValue) {
		this.eventDescriptionValue = eventDescriptionValue;
	}

	public String getOldEvntType() {
		return oldEvntType;
	}

	public void setOldEvntType(String oldEvntType) {
		this.oldEvntType = oldEvntType;
	}

	public String getWasDrugAAlco() {
		return wasDrugAAlco;
	}

	public void setWasDrugAAlco(String wasDrugAAlco) {
		this.wasDrugAAlco = wasDrugAAlco;
	}

//	public String getUserId() {
//		return userId;
//	}
//
//	public void setUserId(String userId) {
//		this.userId = userId;
//	}

	public String getMngrCmntLabel() {
		return mngrCmntLabel;
	}

	public void setMngrCmntLabel(String mngrCmntLabel) {
		this.mngrCmntLabel = mngrCmntLabel;
	}

	public String getMngrCmntLabel1() {
		return mngrCmntLabel1;
	}

	public void setMngrCmntLabel1(String mngrCmntLabel1) {
		this.mngrCmntLabel1 = mngrCmntLabel1;
	}

	public String getMngrComments1() {
		return mngrComments1;
	}

	public void setMngrComments1(String mngrComments1) {
		this.mngrComments1 = mngrComments1;
	}

	public String getCallCirc7() {
		return callCirc7;
	}

	public void setCallCirc7(String callCirc7) {
		this.callCirc7 = callCirc7;
	}

	public String getDrugNAlcoholEvent() {
		return drugNAlcoholEvent;
	}

	public void setDrugNAlcoholEvent(String drugNAlcoholEvent) {
		this.drugNAlcoholEvent = drugNAlcoholEvent;
	}

	public List<EventDocumentGridDetail> getDocumentList() {
		return documentList;
	}

	public void setDocumentList(List<EventDocumentGridDetail> documentList) {
		this.documentList = documentList;
	}

	public List<EventEmployeeDetail> getEventEmployeeAll() {
		return eventEmployeeAll;
	}

	public void setEventEmployeeAll(List<EventEmployeeDetail> eventEmployeeAll) {
		this.eventEmployeeAll = eventEmployeeAll;
	}

	public List<EventEmployeeDetail> getDeletedEmployeeAll() {
		return deletedEmployeeAll;
	}

	public void setDeletedEmployeeAll(List<EventEmployeeDetail> deletedEmployeeAll) {
		this.deletedEmployeeAll = deletedEmployeeAll;
	}

	public List<EventLerbDetail> getEventLerbDetailAll() {
		return eventLerbDetailAll;
	}

	public void setEventLerbDetailAll(List<EventLerbDetail> eventLerbDetailAll) {
		this.eventLerbDetailAll = eventLerbDetailAll;
	}

	public List<String> getSelectedPopup() {
		return selectedPopup;
	}

	public void setSelectedPopup(List<String> selectedPopup) {
		this.selectedPopup = selectedPopup;
	}

	public List<EventEmployeeDetail> getHfrEmplList() {
		return hfrEmplList;
	}

	public void setHfrEmplList(List<EventEmployeeDetail> hfrEmplList) {
		this.hfrEmplList = hfrEmplList;
	}

	public List<String> getResultOfEventAll() {
		return resultOfEventAll;
	}

	public void setResultOfEventAll(List<String> resultOfEventAll) {
		this.resultOfEventAll = resultOfEventAll;
	}

	public List<String> getLicToUnsuspend() {
		return licToUnsuspend;
	}

	public void setLicToUnsuspend(List<String> licToUnsuspend) {
		this.licToUnsuspend = licToUnsuspend;
	}

	public Boolean getEventSubmitted() {
		return eventSubmitted;
	}

	public void setEventSubmitted(Boolean eventSubmitted) {
		this.eventSubmitted = eventSubmitted;
	}

	public Boolean getIsDecert() {
		return isDecert;
	}

	public void setIsDecert(Boolean isDecert) {
		this.isDecert = isDecert;
	}

	public Boolean getIsDrugAlcoholRegulation() {
		return isDrugAlcoholRegulation;
	}

	public void setIsDrugAlcoholRegulation(Boolean isDrugAlcoholRegulation) {
		this.isDrugAlcoholRegulation = isDrugAlcoholRegulation;
	}

	public Boolean getIsLerbUser() {
		return isLerbUser;
	}

	public void setIsLerbUser(Boolean isLerbUser) {
		this.isLerbUser = isLerbUser;
	}

	public Boolean getSuspendFlag() {
		return suspendFlag;
	}

	public void setSuspendFlag(Boolean suspendFlag) {
		this.suspendFlag = suspendFlag;
	}

	public Boolean getEngRegulation() {
		return engRegulation;
	}

	public void setEngRegulation(Boolean engRegulation) {
		this.engRegulation = engRegulation;
	}

	public Boolean getConLicOnly() {
		return conLicOnly;
	}

	public void setConLicOnly(Boolean conLicOnly) {
		this.conLicOnly = conLicOnly;
	}

	public Boolean getIsPopup() {
		return isPopup;
	}

	public void setIsPopup(Boolean isPopup) {
		this.isPopup = isPopup;
	}

	public Boolean getIsAfterNewDate() {
		return isAfterNewDate;
	}

	public void setIsAfterNewDate(Boolean isAfterNewDate) {
		this.isAfterNewDate = isAfterNewDate;
	}

	public Boolean getIsOtherEvnt() {
		return isOtherEvnt;
	}

	public void setIsOtherEvnt(Boolean isOtherEvnt) {
		this.isOtherEvnt = isOtherEvnt;
	}

	public Boolean getIsLerbAction() {
		return isLerbAction;
	}

	public void setIsLerbAction(Boolean isLerbAction) {
		this.isLerbAction = isLerbAction;
	}

	public Boolean getIsMitigateInvalidCloseFlag() {
		return isMitigateInvalidCloseFlag;
	}

	public void setIsMitigateInvalidCloseFlag(Boolean isMitigateInvalidCloseFlag) {
		this.isMitigateInvalidCloseFlag = isMitigateInvalidCloseFlag;
	}

	public Boolean getIsUpdate() {
		return isUpdate;
	}

	public void setIsUpdate(Boolean isUpdate) {
		this.isUpdate = isUpdate;
	}

	public Boolean getIsEmpUnsuspended() {
		return isEmpUnsuspended;
	}

	public void setIsEmpUnsuspended(Boolean isEmpUnsuspended) {
		this.isEmpUnsuspended = isEmpUnsuspended;
	}

	public Boolean getCheckFlag() {
		return checkFlag;
	}

	public void setCheckFlag(Boolean checkFlag) {
		this.checkFlag = checkFlag;
	}

	public Boolean getIsDcrtEvntCreated() {
		return isDcrtEvntCreated;
	}

	public void setIsDcrtEvntCreated(Boolean isDcrtEvntCreated) {
		this.isDcrtEvntCreated = isDcrtEvntCreated;
	}

	public Boolean getIsMitigate() {
		return isMitigate;
	}

	public void setIsMitigate(Boolean isMitigate) {
		this.isMitigate = isMitigate;
	}

	public Boolean getFirAlco() {
		return firAlco;
	}

	public void setFirAlco(Boolean firAlco) {
		this.firAlco = firAlco;
	}

	public Boolean getFirDrug() {
		return firDrug;
	}

	public void setFirDrug(Boolean firDrug) {
		this.firDrug = firDrug;
	}

}
