package com.uprr.lic.decert.jms.rdt;

/**
 * Class Name	  : RDTMessageConverter
 * Description	: To convert message in to corresponding java POJO. 
 * Author		    : Tech Mahindra LTD.
 * Created On	: Aug 17, 2015
 *
 * Change History
 * ------------------------------------------------------------  
 * Date           Changed By        Description
 * ------------------------------------------------------------  
 * Aug-17-2015    xsat803            Created for REQ#588.
 * Oct-15-2015    xsat794            Modified for REQ#588 Part-B
 * Nov-18-2015    xsat803            Modified for REQ#588 Phase1 Part B.
 * Dec-30-2015    XSAT156            Code Refactored for REQ#588.
 * Apr-12-20156   xsat803            Modified for QC#5196
 * 03-Feb-2017    xsat737            Modified for SS_QC#7958:Generic exceptions replaced with EqmException for Sonar fix
 * ------------------------------------------------------------   
 *
 * Copyright notice : "Copyright UPRR 2015"
 */

import java.util.Calendar;
import java.util.Date;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.support.converter.MessageConversionException;
import org.springframework.jms.support.converter.MessageConverter;

import com.up.www.services.eqmsRdtIntegration.x10.EapDetailsType;
import com.up.www.services.eqmsRdtIntegration.x10.EapStatusType;
import com.up.www.services.eqmsRdtIntegration.x10.EmployeeDetails;
import com.up.www.services.eqmsRdtIntegration.x10.EmployeePositionType;
import com.up.www.services.eqmsRdtIntegration.x10.EqmsRdtIntegrationRequestDocument;
import com.up.www.services.eqmsRdtIntegration.x10.EqmsRdtIntegrationRequestType;
import com.up.www.services.eqmsRdtIntegration.x10.EventResultType;
import com.up.www.services.eqmsRdtIntegration.x10.EventStatusType;
import com.up.www.services.eqmsRdtIntegration.x10.FirstAlcoholPositiveType;
import com.up.www.services.eqmsRdtIntegration.x10.FirstDrugPositveType;
import com.up.www.services.eqmsRdtIntegration.x10.ServiceUnitType;
import com.up.www.services.eqmsRdtIntegration.x10.SourceSystemType;
import com.up.www.services.eqmsRdtIntegration.x10.ViolationDetailsType;
import com.up.www.services.eqmsRdtIntegration.x10.ViolationType;
import com.uprr.lic.dataaccess.common.dao.mapper.DecertificationMapper;
import com.uprr.lic.dataaccess.decertification.model.RDTRequestBean;
import com.uprr.lic.dataaccess.decertification.model.RDTResponseBean;
import com.uprr.lic.dataaccess.decertification.services.interfaces.IDecertificationService;
import com.uprr.lic.dataaccess.decertification.util.DecertificationUtil;
import com.uprr.lic.exception.EqmException;
import com.uprr.lic.util.DateUtil;
import com.uprr.lic.util.DecertificationApplicationConstant;
import com.uprr.lic.util.EqmsUtil;
import com.uprr.lic.util.Util;

/**
 * To convert message in to corresponding java POJO.
 * 
 * @author xsat803
 * @since Aug 17, 2015
 */
public class RDTMessageConvertor implements MessageConverter {
	private static final Logger LOGGER = LoggerFactory.getLogger(RDTMessageConvertor.class);

	@Autowired
	private IDecertificationService decertificationService;

	public RDTMessageConvertor() {
		super();
	}
	public RDTMessageConvertor(IDecertificationService decertificationService){
		this.decertificationService=decertificationService;
	}
	private static final String CLASSNAME = RDTMessageConvertor.class.getCanonicalName();

	/**
	 * This method is used to receive RDT message from request queue and start
	 * processing it.
	 * 
	 * @param arg0
	 * @return
	 * @throws JMSException
	 * @throws MessageConversionException
	 * @author xsat803
	 * @since Aug 17, 2015
	 */
	@Override
	public Object fromMessage(final Message message) throws JMSException, MessageConversionException {
		// EQMS-RDT integration switch ON/OFF flag
		final String onOfSwitchValue = decertificationService
				.getSystemParamValue(DecertificationApplicationConstant.SYSPARAM_RDT_ON_OFF_SWITCH);
		RDTRequestBean rdtRequestBean = null;
		if (null != onOfSwitchValue && onOfSwitchValue.equalsIgnoreCase(DecertificationApplicationConstant.STR_ON)) {
			final TextMessage textMessage = (TextMessage) message;
			rdtRequestBean = new RDTRequestBean();
			try {
				rdtRequestBean = getRDTRequestBean(textMessage.getText());
				rdtRequestBean.setCorrelationId(textMessage.getJMSCorrelationID());
			} catch (Exception exception) {
				LOGGER.error("Error in fromMessage(): " + exception);
			}
		}
		return rdtRequestBean;
	}

	@Override
	public Message toMessage(Object arg0, Session arg1) throws JMSException, MessageConversionException {
		return null;
	}

	/**
	 * To Parse request message and get the request bean
	 * 
	 * @param msgAsText
	 * @return
	 * @author xsat803
	 * @since Aug 20, 2015
	 */
	private final RDTRequestBean getRDTRequestBean(final String msgAsText) {
		String rdtSysInternalId = null;
		RDTResponseBean rdtResponseBean = null;
		final RDTRequestBean rdtRequestBean = new RDTRequestBean();
		EqmsRdtIntegrationRequestType rdtRequestType = null;
		try {
			// Store the Message in RDT request bean
			rdtRequestBean.setRequestXMLMessage(msgAsText);
			final EqmsRdtIntegrationRequestDocument rdtRequestDocument = EqmsRdtIntegrationRequestDocument.Factory
					.parse(msgAsText);
			// Check if it is valid then proceed.
			final boolean isValid = rdtRequestDocument.validate();
			rdtRequestType = rdtRequestDocument.getEqmsRdtIntegrationRequest();
			if (null != rdtRequestType) {
				// Populate RDT basic details in RDT request bean object
				rdtSysInternalId = getRDTBasicDetails(rdtRequestBean, rdtRequestType);
			}
			if (isValid && rdtRequestType != null) {
				final EventStatusType.Enum eventStatus = rdtRequestType.getEventStatus();
				if (null != eventStatus && !DecertificationApplicationConstant.BLANK_STRING.equals(eventStatus)) {
					rdtRequestBean.setEventStatus(eventStatus.toString());
				}
				// Employee Details
				final EmployeeDetails emplDtls = rdtRequestType.getEmployeeDetails();
				if (null != emplDtls) {
					// validating and setting employee id
					final String emplId = emplDtls.getEmployeeId();
					rdtRequestBean.setEmplId(emplId);
					// Perform all the validation of RDT message and populate
					// values in RDT request bean accordingly.
					rdtResponseBean = isVaildEmployee(emplId)
							? performValidationOnRDTMsg(rdtRequestBean, rdtRequestType) : new RDTResponseBean();
					// If RDT response is null that means no error find in RDT
					// message and all validation have been passed.
					if (rdtResponseBean == null) {
						// set Event Result
						setRDTEvntResult(rdtRequestBean, rdtRequestType);
						// Ftx Event, Event Recorder, Blue Flag
						setOtherDetails(rdtRequestBean, rdtRequestType);
						// Set Employee details
						rdtResponseBean = setEmployeeDetails(rdtRequestBean, rdtResponseBean, rdtSysInternalId,
								emplDtls);
					}
				}
			} else {
				rdtResponseBean = getRespBeanParsingError(rdtRequestType, rdtRequestBean);
			}
			// Store RDT request message into EQM_MSG_SENT table.
			insertRDTMsgIntoEqmMsgSent(rdtRequestBean);

		} catch (final Exception exception) {
			rdtResponseBean = getRespBeanParsingError(rdtRequestType, rdtRequestBean);// QC#5196
		}
		// set RDT response object
		rdtRequestBean.setRdtResponseBean(rdtResponseBean);
		return rdtRequestBean;
	}

	/**
	 * To RDT Basic details
	 *
	 * @param rdtRequestBean
	 * @param rdtRequestType
	 * @return
	 * @author xsat803
	 * @since Sep 14, 2015 Modified for REQ#588 Phase 1 Part B, QC#5196
	 */
	private String getRDTBasicDetails(final RDTRequestBean rdtRequestBean,
			final EqmsRdtIntegrationRequestType rdtRequestType) {
		// set source system
		final SourceSystemType.Enum sourceSystem = rdtRequestType.getSourceSystem();
		if (null != sourceSystem && !DecertificationApplicationConstant.BLANK_STRING.equals(sourceSystem)) {
			rdtRequestBean.setSourceSystem(sourceSystem.toString());
		}
		// set system date time
		final Calendar sysDateTime = rdtRequestType.getSystemDateTime();
		if (null != sysDateTime && !DecertificationApplicationConstant.BLANK_STRING.equals(sysDateTime)) {
			rdtRequestBean.setSysDateTime(sysDateTime);
		}
		// set RDT system internal id(collection id)
		final String rdtSysInternalId = rdtRequestType.getRdtSystemInternalId();
		if (null != rdtSysInternalId && !DecertificationApplicationConstant.BLANK_STRING.equals(rdtSysInternalId)) {
			rdtRequestBean.setRdtSysIntId(rdtSysInternalId);
		}
		// set event id. REQ#588 Phase 1 Part B start
		final String eqmsEvntId = rdtRequestType.getEqmsEventId();
		if (null != eqmsEvntId && !DecertificationApplicationConstant.BLANK_STRING.equals(eqmsEvntId)) {
			rdtRequestBean.setEqmsEvntId(eqmsEvntId); // REQ#588 Phase 1 Part B
														// start End
		}
		// set employee id, QC#5196
		final String emplId = rdtRequestType.getEmployeeDetails().getEmployeeId();
		if (null != emplId && !DecertificationApplicationConstant.BLANK_STRING.equals(emplId)) {
			rdtRequestBean.setEmplId(emplId); // REQ#588 Phase 1 Part B start
												// End
		}
		return rdtSysInternalId;
	}

	/**
	 * This method is used to set Other details like Ftx event, Event Recorder,
	 * Blue flag.
	 * 
	 * @param rdtRequestBean
	 * @param rdtRequestType
	 * @author XSAT803
	 * @since Aug 31, 2015
	 */
	private void setOtherDetails(final RDTRequestBean rdtRequestBean,
			final EqmsRdtIntegrationRequestType rdtRequestType) {
		final boolean isFtxEvent = rdtRequestType.getFtxEvent();
		if (!DecertificationApplicationConstant.BLANK_STRING.equals(isFtxEvent)) {
			rdtRequestBean.setFtxEvent(isFtxEvent);
		}
		final boolean isEventRecorder = rdtRequestType.getEventRecorder();
		if (!DecertificationApplicationConstant.BLANK_STRING.equals(isEventRecorder)) {
			rdtRequestBean.setEventRecorder(isEventRecorder);
		}
		final boolean isBlueFlag = rdtRequestType.getBlueFlag();
		if (!DecertificationApplicationConstant.BLANK_STRING.equals(isBlueFlag)) {
			rdtRequestBean.setBlueFlag(isBlueFlag);
		}
	}

	/**
	 * To set Service unit
	 * 
	 * @param rdtSysInternalId
	 * @param rdtResponseBean
	 * @param rdtRequestBean
	 * @param parsingErrors
	 * @param rdtRequestType
	 * @return
	 * @author XSAT803
	 * @since Aug 31, 2015
	 */
	private boolean isServiceUnitValid(final RDTRequestBean rdtRequestBean,
			final EqmsRdtIntegrationRequestType rdtRequestType) {
		boolean isValidSVCUnitExist = false;
		try {
			final ServiceUnitType.Enum svcUnitCode = rdtRequestType.getEventServiceUnit();
			if (null != svcUnitCode && !DecertificationApplicationConstant.BLANK_STRING.equals(svcUnitCode)) {
				isValidSVCUnitExist = decertificationService.populateSVCUnitDetails(rdtRequestBean,
						svcUnitCode.toString());
			}
		} catch (Exception exception) {
			isValidSVCUnitExist = false;
		}
		return isValidSVCUnitExist;
	}

	/**
	 * To set employee details
	 * 
	 * @param rdtRequestBean
	 * @param emplId
	 * @param rdtResponseBean
	 * @param rdtSysInternalId
	 * @param parsingErrors
	 * @param emplDet
	 * @author XSAT803
	 * @since Aug 31, 2015
	 */
	private RDTResponseBean setEmployeeDetails(final RDTRequestBean rdtRequestBean, RDTResponseBean rdtResponseBean,
			final String rdtSysInternalId, final EmployeeDetails emplDet) {
		// Violation Details
		final ViolationDetailsType violationDet = emplDet.getViolationDetails();
		if (null != violationDet) {
			// Violation Date
			final Calendar violationDate = violationDet.getViolationDate();
			if (null != violationDate && !DecertificationApplicationConstant.BLANK_STRING.equals(violationDate)) {
				if (DecertificationUtil.isValidDate(violationDate.getTime())) {
					rdtRequestBean.setViolationDate(violationDate);
					// Violation Time
					final String violationTime = violationDet.getViolationTime();
					if (null != violationTime
							&& !DecertificationApplicationConstant.BLANK_STRING.equals(violationTime)) {
						if (EqmsUtil.isValidTime(violationTime)) {
							rdtRequestBean.setViolationTime(violationTime);
							// Violation Type
							final ViolationType.Enum violationType = violationDet.getViolationType();
							if (null != violationType
									&& !DecertificationApplicationConstant.BLANK_STRING.equals(violationType)) {
								rdtRequestBean.setViolationTypeCode(violationType.toString());
							}
							// Is First Alcohol Positive
							final FirstAlcoholPositiveType.Enum fstAlcoholPositive = violationDet
									.getFirstAlcoholPositive();
							if (null != fstAlcoholPositive
									&& !DecertificationApplicationConstant.BLANK_STRING.equals(fstAlcoholPositive)) {
								rdtRequestBean.setFirstAlcoholPositive(fstAlcoholPositive.toString());
							}
							// Is First Drug Positive
							final FirstDrugPositveType.Enum fstDrugPositive = violationDet.getFirstDrugPositive();
							if (null != fstDrugPositive
									&& !DecertificationApplicationConstant.BLANK_STRING.equals(fstDrugPositive)) {
								rdtRequestBean.setFirstDrugPositive(fstDrugPositive.toString());
							}
							final EapDetailsType eapDetType = emplDet.getEapDetails();
							if (null != eapDetType) {
								final EapStatusType.Enum eapCompleted = eapDetType.getEapCompleted();
								// EAP Complete
								if (null != eapCompleted
										&& !DecertificationApplicationConstant.BLANK_STRING.equals(eapCompleted)) {
									rdtRequestBean.setEapCompleted(eapCompleted.toString());
								}
								// EAP Date
								final Calendar eapDate = eapDetType.getEapDate();
								if (null != eapDate
										&& !DecertificationApplicationConstant.BLANK_STRING.equals(eapDate)) {
									if (DecertificationUtil.isValidDate(eapDate.getTime())) {
										rdtRequestBean.setEapDate(eapDate);
									} else {
										rdtResponseBean = getErrorResponseBean(rdtRequestBean,
												DecertificationApplicationConstant.INVALID_EAP_DATE,
												DecertificationApplicationConstant.INVALID_EAP_DATE_DESC);
									}
								}
							}
							final EmployeePositionType.Enum emplPos = emplDet.getEmployeePosition();
							if (null != emplPos && !DecertificationApplicationConstant.BLANK_STRING.equals(emplPos)) {
								rdtRequestBean.setEmplPosition(emplPos.toString());
							} else {
								rdtResponseBean = getErrorResponseBean(rdtRequestBean,
										DecertificationApplicationConstant.INVALID_EMPL_POSITION,
										DecertificationApplicationConstant.INVALID_EMPL_POSITION_DESC);
							}
						} else {
							rdtResponseBean = getErrorResponseBean(rdtRequestBean,
									DecertificationApplicationConstant.INVALID_EVENT_TIME,
									DecertificationApplicationConstant.INVALID_EVENT_TIME_DESC);
						}
					}
				} else {
					rdtResponseBean = getErrorResponseBean(rdtRequestBean,
							DecertificationApplicationConstant.INVALID_EVENT_DATE,
							DecertificationApplicationConstant.INVALID_EVENT_DATE_DESC);
				}
			}
		}

		return rdtResponseBean;
	}

	// /**
	// * To set data to response object
	// *
	// * @param rdtSysInternalId
	// * @return RDTResponseBean
	// * @author xsat803
	// * @since Aug 21, 2015
	// */
	// private RDTResponseBean getResponseBean(String emplId, final String
	// rdtSysInternalId, final String errorType,
	// final String errorDesc, final String prcessStatus) {
	// final RDTResponseBean rdtResponseBean = new RDTResponseBean();
	// rdtResponseBean.setSourceSystem(DecertificationApplicationConstant.SOURCE_SYSTEM_EQMS);
	// rdtResponseBean.setRdtSysIntId(rdtSysInternalId);
	// rdtResponseBean.setEqmsEvntId(null);
	// rdtResponseBean.setEmployeeId(emplId);
	// rdtResponseBean.setProcessStatus(prcessStatus);
	// if (null != errorType && null != errorDesc) {
	// rdtResponseBean.setErrorType(errorType);
	// rdtResponseBean.setErrorDesc(errorDesc);
	// }
	// rdtResponseBean.setSysDateTime(Calendar.getInstance());
	// return rdtResponseBean;
	// }

	//
	// /**
	// * This method is used to prepare RDT error response for XML Parsing
	// error.
	// *
	// * @param rdtRequestBean
	// * @return
	// * @author xsat156
	// * @since Dec 29, 2015
	// */
	// private RDTResponseBean (final RDTRequestBean rdtRequestBean) {
	// final RDTResponseBean rdtResponseBean = new RDTResponseBean();
	// // Set common error Response bean details.
	// setCommonErrorRespBeanDtls(rdtResponseBean, rdtRequestBean);
	//
	// rdtResponseBean.setProcessStatus(DecertificationApplicationConstant.ERROR);
	// rdtResponseBean.setErrorType(DecertificationApplicationConstant.PARSING_ERROR);
	// rdtResponseBean.setErrorDesc(DecertificationApplicationConstant.PARSING_ERROR_DESC);
	// rdtResponseBean.setSysDateTime(Calendar.getInstance());
	// return rdtResponseBean;
	// }

	/**
	 * This method is used to set common Error Response bean details like RDT
	 * system ID, employee id etc.
	 *
	 * @param rdtResponseBean
	 * @param rdtRequestBean
	 * @author xsat156
	 * @since Dec 29, 2015
	 */
	private void setCommonErrorRespBeanDtls(final RDTResponseBean rdtResponseBean,
			final RDTRequestBean rdtRequestBean) {
		rdtResponseBean.setSourceSystem(DecertificationApplicationConstant.SOURCE_SYSTEM_EQMS);
		rdtResponseBean.setRdtSysIntId(rdtRequestBean.getRdtSysIntId());
		rdtResponseBean.setEqmsEvntId(rdtRequestBean.getEqmsEvntId());
		rdtResponseBean.setEmployeeId(rdtRequestBean.getEmplId());
	}

	/**
	 * This method is used to check whether employee id is valid or not.
	 *
	 * @param emplId
	 * @return
	 * @author xsat156
	 * @since Dec 30, 2015
	 */
	private boolean isVaildEmployee(final String emplId) {
		boolean isEmplIDValid = false;
		if (null != emplId && !DecertificationApplicationConstant.BLANK_STRING.equals(emplId)) {
			isEmplIDValid = true;
		}
		return isEmplIDValid;
	}

	/**
	 * This method is used to perform RDT message validation like Employee id
	 * validation, Service unit, Event status.
	 *
	 * @param rdtRequestBean
	 * @param rdtRequestType
	 * @return
	 * @author xsat156
	 * @since Dec 30, 2015 Modified for QC#5196
	 */
	private RDTResponseBean performValidationOnRDTMsg(final RDTRequestBean rdtRequestBean,
			final EqmsRdtIntegrationRequestType rdtRequestType) {
		RDTResponseBean rdtResponseBean = null;
		final String emplId = rdtRequestBean.getEmplId();
		if (!isValidEmployeeId(emplId)) {
			// get Invalid Employee Error ResponseBean
			// Added as it is mandatory tag in rdt response, in cases where
			// employee id is invalid
			rdtRequestBean.setEmplId(DecertificationApplicationConstant.INVALID_EMPLOYEE_ID);
			rdtResponseBean = getErrorResponseBean(rdtRequestBean, DecertificationApplicationConstant.INVALID_EMPL_ID,
					DecertificationApplicationConstant.INVALID_EMPL_ID_DESC);
		} else if (!decertificationService.isValidEmployee(emplId)) {
			// get EmplId does Not Exits Error RespBean
			rdtResponseBean = getErrorResponseBean(rdtRequestBean,
					DecertificationApplicationConstant.EMPL_ID_NOT_EXISTS,
					DecertificationApplicationConstant.EMPL_ID_NOT_EXISTS_DESC);
		} else if (!isTEYEmployee(emplId)) {
			// get Invalid SvcUnit Error RespBean
			rdtResponseBean = getErrorResponseBean(rdtRequestBean, DecertificationApplicationConstant.NOT_TEY_EMPLOYEE,
					DecertificationApplicationConstant.NOT_TEY_EMPLOYEE_DESC);// QC#5196
		} else if (!isServiceUnitValid(rdtRequestBean, rdtRequestType)) {
			// get Invalid SvcUnit Error RespBean
			rdtResponseBean = getErrorResponseBean(rdtRequestBean, DecertificationApplicationConstant.INVALID_SVC_UNIT,
					DecertificationApplicationConstant.INVALID_SVC_UNIT_DESC);
		} else if (!isViolationTimeValid(rdtRequestType)) {
			// get Invalid SvcUnit Error RespBean
			rdtResponseBean = getErrorResponseBean(rdtRequestBean,
					DecertificationApplicationConstant.INVALID_EVENT_TIME,
					DecertificationApplicationConstant.INVALID_EVENT_TIME_DESC);// QC#5196
		}
		return rdtResponseBean;
	}

	/**
	 * This method is used to insert RDT message in EQM_MSG_SENT table.
	 *
	 * @param rdtRequestBean
	 * @throws EqmException
	 * @author xsat156
	 * @since Dec 30, 2015
	 */
	private void insertRDTMsgIntoEqmMsgSent(final RDTRequestBean rdtRequestBean) throws EqmException {
		final Integer primaryKeyRDTEqmMsgSentId = decertificationService.insertRDTMsgIntoEqmMsgSent(rdtRequestBean);
		rdtRequestBean.setPrimaryKeyRDTEqmMsgSentId(primaryKeyRDTEqmMsgSentId);
	}

	/**
	 * This method is used to set Event result.
	 *
	 * @param rdtRequestBean
	 * @param rdtRequestType
	 * @author xsat156
	 * @since Dec 30, 2015
	 */
	private void setRDTEvntResult(final RDTRequestBean rdtRequestBean,
			final EqmsRdtIntegrationRequestType rdtRequestType) {
		// Event Result
		final EventResultType.Enum eventResult = rdtRequestType.getEventResult();
		if (null != eventResult && !DecertificationApplicationConstant.BLANK_STRING.equals(eventResult)) {
			rdtRequestBean.setEventResult(eventResult.toString());
		}
	}

	/*
	 * It is used to test the our local messages. If you want to test it, just
	 * un-comment the main() method & modify the message as per scenario.
	 */

	/*
	 * @SuppressWarnings("unused") public static void main(final String[] args)
	 * {  try { final
	 * ClassPathXmlApplicationContext classPathXmlAppContext = new
	 * ClassPathXmlApplicationContext(new String[] {
	 * "classpath:ApplicationContext.xml",
	 * "classpath:FteApplicationContext.xml",
	 * "classpath:FtxApplicationContext.xml",
	 * "classpath:WorkQueueApplicationContext.xml",
	 * "classpath:EDRApplicationContext.xml",
	 * "classpath:ThrcApplicationContext.xml",
	 * "classpath:BaseRepositoryApplicationContext.xml",
	 * "classpath:BitServiceApplicationContext.xml",
	 * "classpath:BitModelApplicationContext.xml",
	 * "classpath:BitFactoryApplicationContext.xml",
	 * "classpath:BitRepositoryApplicationContext.xml",
	 * "classpath:scoreBitIntegrationConfig.xml",
	 * "classpath:ScoreApplicationContext.xml",
	 * "classpath:LDApplicationContext.xml",
	 * "classpath:HibernateApplicationContext.xml",
	 * "classpath:ConnectionPoolDataSource.xml",
	 * "classpath:EqmPerformanceLoggerApplicationContext.xml",
	 * "classpath:ExternalJdbcTemplatesApplicationContext.xml",
	 * "classpath:xmf.xml", "classpath:jms-service-config.xml",
	 * "classpath:xmf-service-config_for_eqms.xml",
	 * "classpath:spring-security.xml" }); //classpath:EQMSConfig-dev.properties
	 * RDTMessageConvertor rdtMsgConv = new RDTMessageConvertor(); //String msg
	 * =
	 * "<soap:Envelope xmlns:soap='http://schemas.xmlsoap.org/soap/envelope/'><soap:Header xmlns:eeb='http://events.www.uprr.com/1.0' xmlns:wsa='http://www.w3.org/2005/08/addressing'>"
	 * + //
	 * "<wsa:Action>http://events.www.uprr.com/subscriber/receiveNotification</wsa:Action><wsa:MessageID>ed7fd0f7-c6ff-45b1-b6db-48cf8a2d4075</wsa:MessageID>"
	 * + //
	 * "<wsa:From><wsa:Address>cn=dddm001,ou=uprr,o=up</wsa:Address></wsa:From><wsa:To>cn=deqm999,ou=uprr,o=up.sub</wsa:To>"
	 * + //
	 * "<wsa:RelatesTo>ea0db54b-1c29-4d45-92d0-fc961644e534</wsa:RelatesTo><wsa:Metadata><eeb:compressionType>nonCompressed</eeb:compressionType></wsa:Metadata></soap:Header>"
	 * +
	 * //"<soap:Body><wsnb:Notify xmlns:wsnb='http://docs.oasis-open.org/wsn/b-2'><wsnb:NotificationMessage>"
	 * + //
	 * "<wsnb:Topic Dialect='http://docs.oasis-open.org/wsn/t-1/TopicExpression/Simple'>person/discipline-level-updated/1.0</wsnb:Topic>"
	 * + //
	 * "<wsnb:Message><discipline-level-updated xmlns:ns2=\"http://services.www.uprr.com/person/common-1_0\" xmlns=\"http://events.www.up.com/person/discipline-level-updated-1_0\">"
	 * + String msg1=
	 * "<p:eqms-rdt-integration-request xmlns:p=\"http://services.www.up.com/eqms-rdt-integration/1.0\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:schemaLocation=\"http://services.www.up.com/eqms-rdt-integration/1.0 eqms-rdt-integration-1.0.xsd \">"
	 * +"<p:source-system>EQMS</p:source-system>"
	 * +"<p:system-dateTime>2001-12-31T12:00:00</p:system-dateTime>"
	 * +"<p:rdt-system-internal-id>123</p:rdt-system-internal-id>"
	 * +"<p:event-status>NEW</p:event-status>" +"<p:employee-details>"
	 * +"<p:employee-id>0412265</p:employee-id>"
	 * +"<p:employee-position>EN</p:employee-position>" +"<p:violation-details>"
	 * +"<p:violation-date>2015-07-01</p:violation-date>"
	 * +"<p:violation-time>12:30</p:violation-time>"
	 * +"<p:violation-type>FRA_ALC_ABV_THLD</p:violation-type>"
	 * +"<p:first-drug-positive>Y</p:first-drug-positive>"
	 * +"<p:first-alcohol-positive>Y</p:first-alcohol-positive>"
	 * +"</p:violation-details>" +"<p:eap-details>"
	 * +"<p:eap-completed>Y</p:eap-completed>" +"<p:eap-date></p:eap-date>"
	 * +"</p:eap-details>" +"</p:employee-details>"
	 * +"<p:event-result>Collision</p:event-result>"
	 * +"<p:event-service-unit>TC</p:event-service-unit>"
	 * +"<p:ftx-event>false</p:ftx-event>"
	 * +"<p:event-recorder>false</p:event-recorder>"
	 * +"<p:blue-flag>false</p:blue-flag>" +"</p:eqms-rdt-integration-request>";
	 * //</wsnb:Message></wsnb:NotificationMessage></wsnb:Notify>
	 * </soap:Body></soap:Envelope>"; RDTRequestBean rdtReqBean =
	 * rdtMsgConv.getRDTRequestBean(msg1);
	 *   // RDTDelegate rdtDelegate =
	 * (RDTDelegate)classPathXmlAppContext.getBean("RDTDelegate"); //
	 * rdtDelegate.procesRdtRequest(rdtReqBean); } catch (Exception e) {
	 * e.printStackTrace(); } }
	 */

	/**
	 * This method is used to prepare RDT error response bean based on the
	 * different error type and error description
	 * 
	 * @param rdtRequestBean
	 * @param prcessStatus
	 * @param errorType
	 * @param errorDesc
	 * @return
	 * @author xsat803
	 * @since Apr 6, 2016. Added for QC#5196
	 */
	private RDTResponseBean getErrorResponseBean(final RDTRequestBean rdtRequestBean, final String errorType,
			final String errorDesc) {
		final RDTResponseBean rdtResponseBean = new RDTResponseBean();
		// Set common error Response bean details.
		setCommonErrorRespBeanDtls(rdtResponseBean, rdtRequestBean);
		rdtResponseBean.setProcessStatus(DecertificationApplicationConstant.ERROR);
		rdtResponseBean.setErrorType(errorType);
		rdtResponseBean.setErrorDesc(errorDesc);
		rdtResponseBean.setSysDateTime(Calendar.getInstance());
		return rdtResponseBean;
	}

	/**
	 * To get specific error response for different parsing issue.
	 * 
	 * @param rdtRequestType
	 * @param rdtRequestBean
	 * @return
	 * @author xsat803
	 * @since Apr 6, 2016 Added for QC#5196
	 */
	private RDTResponseBean getRespBeanParsingError(final EqmsRdtIntegrationRequestType rdtRequestType,
			RDTRequestBean rdtRequestBean) {
		String errorType = null;
		RDTResponseBean responseBean = null;
		try {
			responseBean = performValidationOnRDTMsg(rdtRequestBean, rdtRequestType);
			if (responseBean == null) {
				errorType = DecertificationApplicationConstant.INVALID_EVENT_STATUS;
				rdtRequestType.getEventStatus();
				errorType = DecertificationApplicationConstant.INVALID_SVC_UNIT;
				rdtRequestType.getEventServiceUnit();
				if (null != rdtRequestType.getEmployeeDetails()) {
					errorType = DecertificationApplicationConstant.INVALID_EMPL_ID;
					rdtRequestType.getEmployeeDetails().getEmployeeId();

					errorType = DecertificationApplicationConstant.INVALID_EMPL_POSITION;
					rdtRequestType.getEmployeeDetails().getEmployeePosition();

					if (null != rdtRequestType.getEmployeeDetails().getViolationDetails()) {
						errorType = DecertificationApplicationConstant.INVALID_EVENT_DATE;
						rdtRequestType.getEmployeeDetails().getViolationDetails().getViolationDate();

						errorType = DecertificationApplicationConstant.INVALID_EVENT_TIME;
						rdtRequestType.getEmployeeDetails().getViolationDetails().getViolationTime();

						errorType = DecertificationApplicationConstant.INVALID_VIOLATION_TYPE;
						rdtRequestType.getEmployeeDetails().getViolationDetails().getViolationType();
					}
					if (null != rdtRequestType.getEmployeeDetails().getEapDetails()) {
						errorType = DecertificationApplicationConstant.INVALID_EAP_DATE;
						rdtRequestType.getEmployeeDetails().getEapDetails().getEapDate();
					}
				}
			}
		} catch (Exception e) {
			if (errorType.equals(DecertificationApplicationConstant.INVALID_EMPL_ID)) {
				responseBean = getErrorResponseBean(rdtRequestBean, DecertificationApplicationConstant.INVALID_EMPL_ID,
						DecertificationApplicationConstant.INVALID_EMPL_ID_DESC);
			} else if (errorType.equals(DecertificationApplicationConstant.INVALID_EVENT_STATUS)) {
				responseBean = getErrorResponseBean(rdtRequestBean,
						DecertificationApplicationConstant.INVALID_EVENT_STATUS,
						DecertificationApplicationConstant.INVALID_EVENT_STATUS_DESC);
			} else if (errorType.equals(DecertificationApplicationConstant.INVALID_SVC_UNIT)) {
				responseBean = getErrorResponseBean(rdtRequestBean, DecertificationApplicationConstant.INVALID_SVC_UNIT,
						DecertificationApplicationConstant.INVALID_SVC_UNIT_DESC);
			} else if (errorType.equals(DecertificationApplicationConstant.INVALID_EMPL_POSITION)) {
				responseBean = getErrorResponseBean(rdtRequestBean,
						DecertificationApplicationConstant.INVALID_EMPL_POSITION,
						DecertificationApplicationConstant.INVALID_EMPL_POSITION_DESC);
			} else if (errorType.equals(DecertificationApplicationConstant.INVALID_EVENT_DATE)) {
				responseBean = getErrorResponseBean(rdtRequestBean,
						DecertificationApplicationConstant.INVALID_EVENT_DATE,
						DecertificationApplicationConstant.INVALID_EVENT_DATE_DESC);
			} else if (errorType.equals(DecertificationApplicationConstant.INVALID_EVENT_TIME)) {
				responseBean = getErrorResponseBean(rdtRequestBean,
						DecertificationApplicationConstant.INVALID_EVENT_TIME,
						DecertificationApplicationConstant.INVALID_EVENT_TIME_DESC);
			} else if (errorType.equals(DecertificationApplicationConstant.INVALID_VIOLATION_TYPE)) {
				responseBean = getErrorResponseBean(rdtRequestBean,
						DecertificationApplicationConstant.INVALID_VIOLATION_TYPE,
						DecertificationApplicationConstant.INVALID_VIOLATION_TYPE_DESC);
			} else if (errorType.equals(DecertificationApplicationConstant.INVALID_EAP_DATE)) {
				responseBean = getErrorResponseBean(rdtRequestBean, DecertificationApplicationConstant.INVALID_EAP_DATE,
						DecertificationApplicationConstant.INVALID_EAP_DATE_DESC);
			} else {
				responseBean = getErrorResponseBean(rdtRequestBean, DecertificationApplicationConstant.PARSING_ERROR,
						DecertificationApplicationConstant.PARSING_ERROR_DESC);
			}
		}
		return responseBean;
	}

	/**
	 * To validate and set violation time
	 * 
	 * @param rdtSysInternalId
	 * @param rdtResponseBean
	 * @param rdtRequestBean
	 * @param parsingErrors
	 * @param rdtRequestType
	 * @return
	 * @author XSAT803
	 * @since Aug 31, 2015
	 */
	private boolean isViolationTimeValid(final EqmsRdtIntegrationRequestType rdtRequestType) {
		boolean isValidTime = false;
		try {
			final String violationTime = rdtRequestType.getEmployeeDetails().getViolationDetails().getViolationTime();
			if (null != violationTime && !DecertificationApplicationConstant.BLANK_STRING.equals(violationTime)) {
				isValidTime = EqmsUtil.isValidTime(violationTime);
			}
		} catch (Exception exception) {
			LOGGER.error("UNABLE TO PARSE VIOLATION TIME");
		}
		return isValidTime;
	}

	/**
	 * To validate if employee is TEY employee
	 * 
	 * @param rdtRequestType
	 * @return
	 * @author xsat803
	 * @since Apr 13, 2016
	 */
	private boolean isTEYEmployee(final String emplId) {
		boolean isTey = false;
		try {
			if (emplId != null) {
				isTey = decertificationService.isTEYEmployee(emplId);
			}
		} catch (final Exception exception) {
			LOGGER.error("Exception while validating if employee job code is TEY" + exception);
		}
		return isTey;
	}

	/**
	 * To validate if employee id is valid
	 * 
	 * @param aEmplId
	 * @return
	 * @author xsat803
	 * @since Apr 20, 2016, QC#5196
	 * 
	 */
	private boolean isValidEmployeeId(final String emplId) {
		boolean isvalid = false;
		if ((emplId != null) && Util.isEmployeeIdEntered(emplId) && (emplId.length() == 7)) {
			isvalid = true;
		}
		return isvalid;
	}

	public static boolean isValidDate(final Date evntDate) {
		boolean isValid = false;
		final Calendar todayDate = DecertificationMapper.removeSecondsFromDate(Calendar.getInstance());
		final Calendar calEvntDate = DecertificationMapper.removeSecondsFromDate(DateUtil.getDateAsCalendar(evntDate));
		if (calEvntDate.compareTo(todayDate) <= 0) {
			isValid = true;
		}
		return isValid;
	}
}