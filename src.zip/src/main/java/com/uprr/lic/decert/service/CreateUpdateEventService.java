/**
 * CLASSNAME    : CreateUpdateEventService
 * Description  : 
 * author   : Tech Mahindra LTD.
 * Date of creation :
 *
 * Change History
 * ------------------------------------------------------------  
 *   Date          Changed By        Description
 * ------------------------------------------------------------  
 *  11/Jul/2017     xsat794         Modified for SS_QC_9129
 *  23/Aug/2017     xsat794         Modified for SS_QC_9357
 *  01/Sep/2017     xsat671         Modified for SS_QC#9361
 *  ----------------------------------------------------------
 *  **/
package com.uprr.lic.decert.service;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.uprr.lic.auth.EQMSUserBean;
import com.uprr.lic.auth.EQMSUserSession;
import com.uprr.lic.dataaccess.common.dao.mapper.DecertificationMapper;
import com.uprr.lic.dataaccess.common.model.DecertDDChoice;
import com.uprr.lic.dataaccess.common.model.EqmGisMpLoc;
import com.uprr.lic.dataaccess.decertification.model.CreateEventDetail;
import com.uprr.lic.dataaccess.decertification.model.EmployeeDetailPopupDetail;
import com.uprr.lic.dataaccess.decertification.model.EventDescBean;
import com.uprr.lic.dataaccess.decertification.model.EventEmployeeDetail;
import com.uprr.lic.dataaccess.decertification.model.EventLerbDetail;
import com.uprr.lic.dataaccess.decertification.model.FaxSuspensionDetail;
import com.uprr.lic.dataaccess.decertification.model.TrainDetail;
import com.uprr.lic.dataaccess.decertification.services.interfaces.IDecertificationService;
import com.uprr.lic.dataaccess.decertification.util.DecertificationUtil;
import com.uprr.lic.dataaccess.fte.model.Train;
import com.uprr.lic.dataaccess.masters.service.IReasonService;
import com.uprr.lic.dataaccess.masters.service.ISysParamService;
import com.uprr.lic.decert.rest.model.CreateEventRequest;
import com.uprr.lic.decert.rest.model.DropdownChoice;
import com.uprr.lic.decert.rest.model.EmployeeDetailResponse;
import com.uprr.lic.decert.rest.model.EventDescDetail;
import com.uprr.lic.decert.rest.model.EventEmployeeResponse;
import com.uprr.lic.decert.rest.model.TrainDetailResponse;
import com.uprr.lic.doss.put.DossPutServiceClient;
import com.uprr.lic.doss.put.DossPutServiceClientXmfImpl;
import com.uprr.lic.exception.EqmDaoException;
import com.uprr.lic.util.DDChoice;
import com.uprr.lic.util.DateUtil;
import com.uprr.lic.util.DecertificationApplicationConstant;
import com.uprr.lic.util.EQMSResnConstant;
import com.uprr.lic.util.SysParamBean;
import com.uprr.lic.util.SysParmConstants;
import com.uprr.lic.util.Util;
import com.uprr.netcontrol.frontend.client.xmf.XmfClientInvoker;

@Service("createUpdateEventService")
public class CreateUpdateEventService implements ICreateUpdateEventService {

  @Autowired
  private IDecertificationService decertificationService;

  @Autowired
  private IReasonService reasonService;

  @Autowired
  private ISysParamService sysParamService;

  @Autowired
  EQMSUserSession eqmsUserSession;

  @Autowired
  @Qualifier("dossPutXmfClientInvoker")
  XmfClientInvoker dosPutInvoker;

  @Autowired
  private EQMSUserSession session;

  private boolean validateEmployees = true;

  String wanrningMessage;

  String reasonForNotUpdatingEmployeeDetails;// Added for SS_QC_9129

  /*
   * @Override public Map<String, Integer> getSysParmLerbAction(){ Map<String, Integer>
   * ResultOfLerbAction=decertificationService.getSysParmLerbAction(); return ResultOfLerbAction; //return
   * createdropDownforlerb(ResultOfLerbAction); }
   */

  @Override
  public List<DropdownChoice> getSysParmLerbAction() {

    Map<String, Integer> ResultOfLerbAction = decertificationService.getSysParmLerbAction();
    // return ResultOfLerbAction;
    return createdropDownforlerb(ResultOfLerbAction);

  }

  @Override
  public List<String> getResultOfEventList() {
    List<String> ResultOfEventList = decertificationService.getResultOfEventList();
    return ResultOfEventList;
  }

  @Override
  public List<DropdownChoice> getEventTypeList() {

    final List<DDChoice> typeOfEventList = new ArrayList<DDChoice>();
    typeOfEventList.add(new DDChoice(1, "Decertification"));

    if (session.getUser().getRoleSet().contains(9) || session.getUser().getRoleSet().contains(10)
        || session.getUser().getRoleSet().contains(11)) {
      typeOfEventList.add(new DDChoice(2, "Other"));
    }
    return createDropDownChoiceListResponse(typeOfEventList);
  }

  @Override
  public List<String> getSignalTerritoryList() {
    List<String> SignalTerritoryList = decertificationService.getSigTtyList();
    return SignalTerritoryList;
  }

  @Override
  public List<String> getTypeOfTrackList() {
    List<String> TypeOfTrackList = decertificationService.getTypeOfTrackList();
    return TypeOfTrackList;

  }

  @Override
  public List<DropdownChoice> getRailRoadList() {
    Map<String, String> RailRoadList = decertificationService.getRailRoadList();
    return convertMapToDDChoice(RailRoadList);
  }

  @Override
  public List<String> getTypeofAuthorityList() {
    List<String> TypeofAuthorityList = decertificationService.getAuthorityList();
    return TypeofAuthorityList;
  }

  @Override
  public List<EventDescDetail> getEventDescriptionList() {
    List<EventDescBean> EventDescriptionList = decertificationService
        .getMngrCmnts(DecertificationApplicationConstant.EVENT_TYPE_ID_DECERTIFICATION);
    return createEventDescDetail(EventDescriptionList);
  }

  @Override
  public List<DropdownChoice> getWeatherList() {
    List<DDChoice> WeatherList = decertificationService.getWeatherList();
    return createDropDownChoiceListResponse(WeatherList);
  }

  @Override
  public List<DropdownChoice> getVisibilityList() {
    List<DDChoice> VisibilityList = decertificationService.getVisibilityList();
    return createDropDownChoiceListResponse(VisibilityList);
  }

  @Override
  public List<String> getOperationList() {
    List<String> OperationList = decertificationService.getOperationList();
    return OperationList;
  }

  @Override
  public List<String> getGradeList() {
    List<String> GradeList = decertificationService.getGradeList();
    return GradeList;
  }

  @Override
  public List<String> getCurvatureList() {
    List<String> CurvatureList = decertificationService.getCurvatureList();
    return CurvatureList;
  }

  @Override
  public List<String> getCrewTypeList() {
    List<String> CrewTypeList = decertificationService.getCrewTypeList();
    return CrewTypeList;
  }

  @Override
  public List<DropdownChoice> getPositionList() {
    List<DDChoice> PositionList = decertificationService.getPositionList(false);
    return createDropDownChoiceListResponse(PositionList);
  }

  @Override
  public List<String> getLicensedPositionList() {
    List<String> LicensedPositionList = decertificationService.getLicensedPositionList();
    return LicensedPositionList;
  }

  @Override
  public List<String> getDirectionList() {
    List<String> DirectionList = decertificationService.getDirectionList();
    return DirectionList;
  }

  @Override
  public List<String> getLastJobBrefList() {
    List<String> LastJobBrefList = decertificationService.getLastJobBrefList();
    return LastJobBrefList;
  }

  @Override
  public List<DropdownChoice> getDecertRegulationList(String position) {
    List<DecertDDChoice> DecertRegulationList = decertificationService.getDecertRegulationList(position);
    return createDecertDropDownChoiceListResponse(DecertRegulationList);
  }

  @Override
  public List<DropdownChoice> getOtherRegulationList() {
    List<DecertDDChoice> OtherRegulationList = decertificationService.getOtherRegulationList();
    return createDecertDropDownChoiceListResponse(OtherRegulationList);
  }

  @Override
  public List<String> getSuspendedList() {
    List<String> SuspendedList = decertificationService.getSuspendedList();
    return SuspendedList;
  }

  @Override
  public Collection<DropdownChoice> getSubDivision(String svcUnitName) {
    Map<String, DDChoice> mapOfSubDiv = decertificationService.getSubDivisionMapFromLocationMasterView(svcUnitName);
    return createDropDownChoiceListResponse(mapOfSubDiv.values());
  }

  @Override
  public EmployeeDetailResponse getEmployeeDetailsByID(String employeeId) {
    EmployeeDetailPopupDetail employeeDetails = decertificationService.getEmployeeDetailsByID(employeeId);
    return createEmployeeDetailPopupDetail(employeeDetails);
  }

  @Override
  public Boolean insertEvent(MultipartHttpServletRequest multipartRequest) {

    DossPutServiceClient dossPutClient = new DossPutServiceClientXmfImpl(dosPutInvoker);

    boolean inesertStaus = false;
    try {

      CreateEventRequest request = new ObjectMapper().readValue(multipartRequest.getParameter("createEventDetail"),
          CreateEventRequest.class);
      Map<String, List<MultipartFile>> fileMap = multipartRequest.getMultiFileMap();
      List<EventLerbDetail> lerbDetailList = request.getEventLerbDetailAll();
      List<MultipartFile> documents = new ArrayList<>();
      List<MultipartFile> lerbDocuments = new ArrayList<>();
      if (null != fileMap && fileMap.size() > 0) {
        for (Map.Entry<String, List<MultipartFile>> entry : fileMap.entrySet()) {
          if (entry.getKey().contains("createUpdate")) {
            for (MultipartFile multipartFile : entry.getValue()) {
              documents.add(multipartFile);
            }
          } else if (lerbDetailList != null) {
            for (int index = 0; index < lerbDetailList.size(); index++) {
              EventLerbDetail lerbDetail = lerbDetailList.get(index);
              if (entry.getKey().contains("lerb" + index)) {
                for (MultipartFile multipartFile : entry.getValue()) {
                  lerbDocuments.add(multipartFile);
                }
                lerbDetail.setDocuments(lerbDocuments);
              }
            }
          }
        }
      }
      EQMSUserBean eqmsUserBean = eqmsUserSession.getUser();
      inesertStaus = decertificationService.insertEventDetails(createEventRequest(request), eqmsUserBean.getEmplId(),
          /* null, */reasonService.getAllReason(), dossPutClient, documents);

    } catch (Exception e) {
      e.printStackTrace();
    }
    return inesertStaus;
  }

  @Override
  public Boolean updateEvent(MultipartHttpServletRequest multipartRequest) {
    DossPutServiceClient dossPutClient = new DossPutServiceClientXmfImpl(dosPutInvoker);

    boolean updateStatus = false;
    try {

      CreateEventRequest request = new ObjectMapper().readValue(multipartRequest.getParameter("createEventDetail"),
          CreateEventRequest.class);

      Map<String, List<MultipartFile>> fileMap = multipartRequest.getMultiFileMap();
      List<EventLerbDetail> lerbDetailList = request.getEventLerbDetailAll();
      List<MultipartFile> documents = new ArrayList<>();
      List<MultipartFile> lerbDocuments = new ArrayList<>();
      if (null != fileMap && fileMap.size() > 0) {
        for (Map.Entry<String, List<MultipartFile>> entry : fileMap.entrySet()) {
          if (entry.getKey().contains("createUpdate")) {
            for (MultipartFile multipartFile : entry.getValue()) {
              documents.add(multipartFile);
            }
          } else if (lerbDetailList != null) {
            for (int index = 0; index < lerbDetailList.size(); index++) {
              EventLerbDetail lerbDetail = lerbDetailList.get(index);
              if (entry.getKey().contains("lerb" + index)) {
                for (MultipartFile multipartFile : entry.getValue()) {
                  lerbDocuments.add(multipartFile);
                }
                lerbDetail.setDocuments(lerbDocuments);
              }
            }
          }
        }
      }
      EQMSUserBean eqmsUserBean = eqmsUserSession.getUser();
      updateStatus = decertificationService.updateEventDetails(createEventRequest(request), eqmsUserBean.getEmplId(),
          dossPutClient, reasonService.getAllReason(), documents);
    } catch (Exception e) {
      e.printStackTrace();
    }
    return updateStatus;
  }

  @Override
  public CreateEventRequest getEventDetails(Integer eventDetailID) {
    CreateEventDetail eventDeatils = decertificationService.getCreateEventBeanByEvntDtlId(eventDetailID, null, null,
        null, null);
    return createEventDetailResponse(eventDeatils);
  }

  // Convertion of Models
  /**
   * Convert List of dropDownchoice List for ALL API
   * 
   * @param dropDownChoiceList
   * @return
   */

  // vikas code for convert map to dropdownchoice

  private List<DropdownChoice> createdropDownforlerb(Map<String, Integer> lerbMapList) {
    List<DropdownChoice> dropdownChoiceLerbList = new ArrayList<>();
    Iterator it = lerbMapList.entrySet().iterator();
    while (it.hasNext()) {
      Map.Entry pair = (Map.Entry) it.next();
      DropdownChoice dropdownChoiceResponse = new DropdownChoice();
      dropdownChoiceResponse.setIntKey((Integer) pair.getValue());
      // dropdownChoiceResponse.setValue((String) pair.getKey());
      dropdownChoiceResponse.setStrKey((String) pair.getKey());
      dropdownChoiceLerbList.add(dropdownChoiceResponse);
    }
    return dropdownChoiceLerbList;
  }

  private List<DropdownChoice> createDropDownChoiceListResponse(List<DDChoice> dropDownChoiceList) {
    List<DropdownChoice> dropdownChoiceResponseList = new ArrayList<>();
    if (dropDownChoiceList != null) {
      for (DDChoice objDropdownChoice : dropDownChoiceList) {
        DropdownChoice dropdownChoiceResponse = new DropdownChoice();
        dropdownChoiceResponse.setIntKey(objDropdownChoice.getIntKey());
        dropdownChoiceResponse.setStrKey(objDropdownChoice.getStrKey());
        dropdownChoiceResponse.setValue(objDropdownChoice.getValue());
        dropdownChoiceResponseList.add(dropdownChoiceResponse);
      }
    }
    return dropdownChoiceResponseList;
  }

  /**
   * Convert List of dropDownchoice List for ALL API
   * 
   * @param dropDownChoiceList
   * @return
   */
  private List<DropdownChoice> createDecertDropDownChoiceListResponse(List<DecertDDChoice> dropDownChoiceList) {
    List<DropdownChoice> dropdownChoiceResponseList = new ArrayList<>();
    if (dropDownChoiceList != null) {
      for (DecertDDChoice objDropdownChoice : dropDownChoiceList) {
        DropdownChoice dropdownChoiceResponse = new DropdownChoice();
        dropdownChoiceResponse.setIntKey(objDropdownChoice.getIntKey());
        dropdownChoiceResponse.setStrKey(objDropdownChoice.getStrKey());
        dropdownChoiceResponse.setValue(objDropdownChoice.getValue());
        dropdownChoiceResponseList.add(dropdownChoiceResponse);
      }
    }
    return dropdownChoiceResponseList;
  }

  /**
   * Convert CreateEventDetail to CreateEventRequest
   * 
   * @param createEventRequest
   * @return
   */
  private CreateEventDetail createEventRequest(CreateEventRequest objCreateEventDetail) {
    CreateEventDetail objCreateEventRequest = new CreateEventDetail();
    objCreateEventRequest.setEvntDtlId(objCreateEventDetail.getEvntDtlId());
    objCreateEventRequest.setDocumentList(objCreateEventDetail.getDocumentList());
    objCreateEventRequest.setEventSubmitted(objCreateEventDetail.getEventSubmitted());
    objCreateEventRequest.setDecert(objCreateEventDetail.getIsDecert());
    objCreateEventRequest.setDrugAlcoholRegulation(objCreateEventDetail.getIsDrugAlcoholRegulation());
    objCreateEventRequest.setEventDateCalendar(
        setEvntDateCalendar(objCreateEventDetail.getEventDate(), objCreateEventDetail.getEventTime()));// Modified for
                                                                                                       // SS_QC_9357
    objCreateEventRequest.setTypeOfEventAll(objCreateEventDetail.getTypeOfEventAll());
    // objCreateEventRequest.setEventDate(DateUtil.convertStringToDate(objCreateEventDetail.getEventDate()));
    objCreateEventRequest.setEventDate(DateUtil.getDateFromString(objCreateEventDetail.getEventDate()));
    objCreateEventRequest.setEventTime(objCreateEventDetail.getEventTime());
    objCreateEventRequest.setResultOfEventAll(objCreateEventDetail.getResultOfEventAll());
    objCreateEventRequest.setMngrDescOfIncd(objCreateEventDetail.getMngrDescOfIncd());
    objCreateEventRequest.setMngrComments(objCreateEventDetail.getMngrComments());
    objCreateEventRequest.setRespMngr(objCreateEventDetail.getRespMngr());
    objCreateEventRequest.setFirstAlcoholEvent(objCreateEventDetail.getFirstAlcoholEvent());
    objCreateEventRequest.setFirstDrugEvent(objCreateEventDetail.getFirstDrugEvent());
    objCreateEventRequest.setFirAlco(objCreateEventDetail.getFirAlco());
    objCreateEventRequest.setFirDrug(objCreateEventDetail.getFirDrug());
    objCreateEventRequest.setEvntDesc(objCreateEventDetail.getEvntDesc());
    objCreateEventRequest.setMngrCmntLabel(objCreateEventDetail.getMngrCmntLabel());
    objCreateEventRequest.setMngrCmntLabel1(objCreateEventDetail.getMngrCmntLabel1());
    objCreateEventRequest.setMngrComments1(objCreateEventDetail.getMngrComments1());
    objCreateEventRequest.setMgrCmntId(objCreateEventDetail.getMgrCmntId());
    objCreateEventRequest.setTrainDetail(objCreateEventDetail.getTrainDetail());
    objCreateEventRequest.setLocationDetail(objCreateEventDetail.getLocationDetail());
    objCreateEventRequest.setOtherDetail(objCreateEventDetail.getOtherDetail());
    objCreateEventRequest.setEventEmployeeAll(objCreateEventDetail.getEventEmployeeAll());
    objCreateEventRequest.setDeletedEmployeeAll(objCreateEventDetail.getDeletedEmployeeAll());
    objCreateEventRequest.setCallCirc7(objCreateEventDetail.getCallCirc7());
    objCreateEventRequest.setEventLerbDetailAll(objCreateEventDetail.getEventLerbDetailAll());
    objCreateEventRequest.setEmployeeDropDown(objCreateEventDetail.getEmployeeDropDown());
    objCreateEventRequest.setLerbUser(objCreateEventDetail.getIsLerbUser());
    objCreateEventRequest.setDrugNAlcoholEvent(objCreateEventDetail.getDrugNAlcoholEvent());
    objCreateEventRequest.setSuspendFlag(objCreateEventDetail.getSuspendFlag());
    objCreateEventRequest.setEngRegulation(objCreateEventDetail.getEngRegulation());
    objCreateEventRequest.setConLicOnly(objCreateEventDetail.getConLicOnly());
    objCreateEventRequest.setSvcUnitNbr(objCreateEventDetail.getSvcUnitNbr());
    objCreateEventRequest.setSignalDetailsBean(objCreateEventDetail.getSignalDetailsBean());
    objCreateEventRequest.setPopup(objCreateEventDetail.getIsPopup());
    // objCreateEventRequest.setAfterNewDate(
    // objCreateEventDetail.isAfterNewDate( ) ) ;
    objCreateEventRequest.setOtherEvnt(objCreateEventDetail.getIsOtherEvnt());
    objCreateEventRequest.setLerbAction(objCreateEventDetail.getIsLerbAction());
    objCreateEventRequest.setMitigateInvalidCloseFlag(objCreateEventDetail.getIsMitigateInvalidCloseFlag());
    objCreateEventRequest.setUpdate(objCreateEventDetail.getIsUpdate());
    objCreateEventRequest.setRestSpeedAndConRegBean(objCreateEventDetail.getRestSpeedAndConRegBean());
    // objCreateEventRequest.setPopup( objCreateEventDetail.getPopupFlag( )
    // ) ;
    objCreateEventRequest.settypeAuthQuestion(objCreateEventDetail.getTypeAuthQuestion());
    objCreateEventRequest.setSignalQuestion(objCreateEventDetail.getSignalQuestion());
    objCreateEventRequest.setTypeAuthTWCQuestion(objCreateEventDetail.getTypeAuthTWCQuestion());
    objCreateEventRequest.setSelectedPopup(objCreateEventDetail.getSelectedPopup());
    objCreateEventRequest.setEmpUnsuspended(objCreateEventDetail.getIsEmpUnsuspended());
    objCreateEventRequest.setCrtnEmplId(eqmsUserSession.getUser().getEmplId());
    objCreateEventRequest.setCrtnDate(objCreateEventDetail.getCrtnDate());
    objCreateEventRequest.setEvntEntrdLate(objCreateEventDetail.getEvntEntrdLate());
    objCreateEventRequest.setCheckFlag(objCreateEventDetail.getCheckFlag());
    objCreateEventRequest.setDcrtEvntCreated(objCreateEventDetail.getIsDcrtEvntCreated());
    objCreateEventRequest.setHfrEmplList(objCreateEventDetail.getHfrEmplList());
    objCreateEventRequest.setLicToUnsuspend(objCreateEventDetail.getLicToUnsuspend());
    objCreateEventRequest.setEvntSourceSystem(objCreateEventDetail.getEvntSourceSystem());
    objCreateEventRequest.setRdtEventID(objCreateEventDetail.getRdtEventID());
    objCreateEventRequest.setViolationTypeCode(objCreateEventDetail.getViolationTypeCode());
    objCreateEventRequest.setRdtEmplPosition(objCreateEventDetail.getRdtEmplPosition());
    objCreateEventRequest.setRdtResponseBean(objCreateEventDetail.getRdtResponseBean());
    objCreateEventRequest.setEvntStatusFlag(objCreateEventDetail.getEvntStatusFlag());
    objCreateEventRequest.setEventDescriptionValue(objCreateEventDetail.getEventDescriptionValue());
    objCreateEventRequest.setOldEvntType(objCreateEventDetail.getOldEvntType());
    objCreateEventRequest.setWasDrugAAlco(objCreateEventDetail.getWasDrugAAlco());
    objCreateEventRequest.setMitigate(objCreateEventDetail.getIsMitigate());
    // Added for SS_QC#9361
    objCreateEventRequest.setDateOfKnowledge(
        DateUtil.ignoreTime(DateUtil.convertDateTimeStringToCalendar(objCreateEventDetail.getDateOfKnowledge())));
    return objCreateEventRequest;
  }

  /**
   * Convert CreateEventDetail to CreateEventRequest
   * 
   * @param createEventRequest
   * @return
   */
  private TrainDetail trainRequest(TrainDetailResponse objTrainRequestRequest) {
    TrainDetail objTrainRequest = new TrainDetail();
    objTrainRequestRequest.setTrainKey(objTrainRequest.getTrainKey());
    objTrainRequestRequest.setTrainSymbol(objTrainRequest.getTrainSymbol());
    objTrainRequestRequest.setSymbol(objTrainRequest.getSymbol());
    objTrainRequestRequest.setTrainSection(objTrainRequest.getTrainSection());
    objTrainRequestRequest.setLoads(objTrainRequest.getLoads());
    objTrainRequestRequest.setEmpties(objTrainRequest.getEmpties());
    objTrainRequestRequest.setTonnages(objTrainRequest.getTonnages());
    objTrainRequestRequest.setLength(objTrainRequest.getLength());
    objTrainRequestRequest.setMaxAuthorisedSpeed(objTrainRequest.getMaxAuthorisedSpeed());
    objTrainRequestRequest.setSpeedTimeOfIncident(objTrainRequest.getSpeedTimeOfIncident());
    objTrainRequestRequest.setOriginDate(objTrainRequest.getOriginDate());
    objTrainRequestRequest.setTrainDay(objTrainRequest.getTrainDay());
    objTrainRequestRequest.setEventEmployeeList(objTrainRequest.getEventEmployeeList());
    objTrainRequestRequest.setPreviosTrainSymbol(objTrainRequest.getPreviosTrainSymbol());
    objTrainRequestRequest.setTrainId(objTrainRequest.getTrainId());
    objTrainRequestRequest.setTrainDate(objTrainRequest.getTrainDate());
    return objTrainRequest;
  }

  /**
   * Convert EmployeeDetailPopupDetail to EmployeeDetailResponse
   * 
   * @param employeePopUpDetails
   * @return
   */
  private EmployeeDetailResponse createEmployeeDetailPopupDetail(EmployeeDetailPopupDetail employeePopUpDetails) {
    EmployeeDetailResponse objEmployeeDetailPopupResponse = new EmployeeDetailResponse();
    objEmployeeDetailPopupResponse.setEmployeeID(employeePopUpDetails.getEmployeeID());
    objEmployeeDetailPopupResponse.setEmployeeName(employeePopUpDetails.getEmployeeName());
    objEmployeeDetailPopupResponse.setRegion(employeePopUpDetails.getRegion());
    objEmployeeDetailPopupResponse.setServiceUnit(employeePopUpDetails.getServiceUnit());
    objEmployeeDetailPopupResponse.setYearsInCraft(employeePopUpDetails.getYearsInCraft());
    objEmployeeDetailPopupResponse.setHireDate(employeePopUpDetails.getHireDate());
    objEmployeeDetailPopupResponse.setLastStopTestDate(employeePopUpDetails.getLastStopTestDate());
    objEmployeeDetailPopupResponse.setConductorDate(employeePopUpDetails.getConductorDate());
    objEmployeeDetailPopupResponse.setTripsOnTerritory(employeePopUpDetails.getTripsOnTerritory());
    objEmployeeDetailPopupResponse.setLicenseAll(employeePopUpDetails.getLicenseAll());
    return objEmployeeDetailPopupResponse;
  }

  /**
   * Convert EventDetailsResponse to CreateEventDetail
   * 
   * @param createEventRequest
   * @return
   */
  private CreateEventRequest createEventDetailResponse(CreateEventDetail objCreateEventDetail) {

    CreateEventRequest objEventResponse = new CreateEventRequest();
    if (objCreateEventDetail == null) {
      return objEventResponse;
    }

    objEventResponse.setTypeOfEventAll(objCreateEventDetail.getTypeOfEventAll());
    objEventResponse.setEvntDesc(objCreateEventDetail.getEvntDesc());
    objEventResponse.setTrainDetail(objCreateEventDetail.getTrainDetail());
    objEventResponse.setLocationDetail(objCreateEventDetail.getLocationDetail());
    objEventResponse.setOtherDetail(objCreateEventDetail.getOtherDetail());
    objEventResponse.setEmployeeDropDown(objCreateEventDetail.getEmployeeDropDown());
    objEventResponse.setSignalDetailsBean(objCreateEventDetail.getSignalDetailsBean());
    objEventResponse.setRdtResponseBean(objCreateEventDetail.getRdtResponseBean());
    objEventResponse.setMgrCmntId(objCreateEventDetail.getMgrCmntId());
    objEventResponse.setEvntDtlId(objCreateEventDetail.getEvntDtlId());
    objEventResponse.setSvcUnitNbr(objCreateEventDetail.getSvcUnitNbr());
    objEventResponse.setEventDate(DateUtil.getDateAsString(objCreateEventDetail.getEventDate()));
    objEventResponse.setEventDateCalendar(objCreateEventDetail.getEventDateCalendar());
    objEventResponse.setCrtnDate(objCreateEventDetail.getCrtnDate());
    objEventResponse.setRestSpeedAndConRegBean(objCreateEventDetail.getRestSpeedAndConRegBean());
    objEventResponse.setMngrComments(objCreateEventDetail.getMngrComments());
    objEventResponse.setMngrDescOfIncd(objCreateEventDetail.getMngrDescOfIncd());
    objEventResponse.setEventTime(objCreateEventDetail.getEventTime());
    objEventResponse.setRespMngr(objCreateEventDetail.getRespMngr());
    objEventResponse.setFirstAlcoholEvent(objCreateEventDetail.getFirstAlcoholEvent());
    objEventResponse.setFirstDrugEvent(objCreateEventDetail.getFirstDrugEvent());
    objEventResponse.setIsPopup(objCreateEventDetail.isPopup());
    objEventResponse.setTypeAuthQuestion(objCreateEventDetail.gettypeAuthQuestion());
    objEventResponse.setSignalQuestion(objCreateEventDetail.getSignalQuestion());
    objEventResponse.setTypeAuthTWCQuestion(objCreateEventDetail.getTypeAuthTWCQuestion());
    objEventResponse.setEvntEntrdLate(objCreateEventDetail.getEvntEntrdLate());
    objEventResponse.setCrtnEmplId(eqmsUserSession.getUser().getEmplId());
    objEventResponse.setEvntSourceSystem(objCreateEventDetail.getEvntSourceSystem());
    objEventResponse.setRdtEventID(objCreateEventDetail.getRdtEventID());
    objEventResponse.setViolationTypeCode(objCreateEventDetail.getViolationTypeCode());
    objEventResponse.setRdtEmplPosition(objCreateEventDetail.getRdtEmplPosition());
    objEventResponse.setEvntStatusFlag(objCreateEventDetail.getEvntStatusFlag());
    objEventResponse.setEventDescriptionValue(objCreateEventDetail.getEventDescriptionValue());
    objEventResponse.setOldEvntType(objCreateEventDetail.getOldEvntType());
    objEventResponse.setWasDrugAAlco(objCreateEventDetail.getWasDrugAAlco());
    // objEventResponse.setUserId( objCreateEventDetail.getUserId( ) ) ;
    objEventResponse.setMngrCmntLabel(objCreateEventDetail.getMngrCmntLabel());
    objEventResponse.setMngrCmntLabel1(objCreateEventDetail.getMngrCmntLabel1());
    objEventResponse.setMngrComments1(objCreateEventDetail.getMngrComments1());
    objEventResponse.setCallCirc7(objCreateEventDetail.getCallCirc7());
    objEventResponse.setDrugNAlcoholEvent(objCreateEventDetail.getDrugNAlcoholEvent());
    objEventResponse.setDocumentList(objCreateEventDetail.getDocumentList());
    objEventResponse.setEventEmployeeAll(objCreateEventDetail.getEventEmployeeAll());
    objEventResponse.setDeletedEmployeeAll(objCreateEventDetail.getDeletedEmployeeAll());
    objEventResponse.setEventLerbDetailAll(objCreateEventDetail.getEventLerbDetailAll());
    objEventResponse.setSelectedPopup(objCreateEventDetail.getSelectedPopup());
    objEventResponse.setHfrEmplList(objCreateEventDetail.getHfrEmplList());
    objEventResponse.setResultOfEventAll(objCreateEventDetail.getResultOfEventAll());
    objEventResponse.setLicToUnsuspend(objCreateEventDetail.getLicToUnsuspend());
    objEventResponse.setEventSubmitted(objCreateEventDetail.isEventSubmitted());
    objEventResponse.setIsDecert(objCreateEventDetail.isDecert());
    objEventResponse.setIsDrugAlcoholRegulation(objCreateEventDetail.isDrugAlcoholRegulation());
    objEventResponse.setIsLerbUser(objCreateEventDetail.isLerbUser());
    objEventResponse.setSuspendFlag(objCreateEventDetail.isSuspendFlag());
    objEventResponse.setEngRegulation(objCreateEventDetail.isEngRegulation());
    objEventResponse.setConLicOnly(objCreateEventDetail.isConLicOnly());
    objEventResponse.setIsPopup(objCreateEventDetail.isPopup());
    // objEventResponse.setIsAfterNewDate( objCreateEventDetail. ) ;
    objEventResponse.setIsOtherEvnt(objCreateEventDetail.isOtherEvnt());
    objEventResponse.setIsLerbAction(objCreateEventDetail.isLerbAction());
    objEventResponse.setIsMitigateInvalidCloseFlag(objCreateEventDetail.isMitigateInvalidCloseFlag());
    objEventResponse.setIsUpdate(objCreateEventDetail.isUpdate());
    objEventResponse.setIsEmpUnsuspended(objCreateEventDetail.isEmpUnsuspended());
    objEventResponse.setCheckFlag(objCreateEventDetail.isCheckFlag());
    objEventResponse.setIsDcrtEvntCreated(objCreateEventDetail.isDcrtEvntCreated());
    objEventResponse.setIsMitigate(objCreateEventDetail.isMitigate());
    objEventResponse.setFirAlco(objCreateEventDetail.getFirAlco());
    objEventResponse.setFirDrug(objCreateEventDetail.getFirDrug());
    // SS_QC#9361 changes start
    if (null != objCreateEventDetail.getDateOfKnowledge()) {
      objEventResponse.setDateOfKnowledge(DateUtil.getDateAsString(objCreateEventDetail.getDateOfKnowledge()));
    }
    // SS_QC#9361 changes end
    return objEventResponse;

  }

  /**
   * Convert EventDescBean to EventDescDetail
   * 
   * @param createEventDescDetail
   * @return
   */
  private List<EventDescDetail> createEventDescDetail(List<EventDescBean> objEventDescriptionDetail) {
    List<EventDescDetail> objEventDescDetailResponse = new ArrayList<>();
    if (objEventDescriptionDetail != null) {
      for (EventDescBean objResponse : objEventDescriptionDetail) {
        EventDescDetail eventDescriptionResponse = new EventDescDetail();
        DDChoice evntDesc = new DDChoice();
        evntDesc.setIntKey(objResponse.getEvntDescId());
        evntDesc.setValue(objResponse.getEvntDescName());
        eventDescriptionResponse.setEvntDesc(evntDesc);
        eventDescriptionResponse.setMngrCmnts(objResponse.getMngrCmnts());
        objEventDescDetailResponse.add(eventDescriptionResponse);
      }
    }
    return objEventDescDetailResponse;
  }

  @Override
  public Map<Integer, List<DecertDDChoice>> getPrimRulesForEvntDate(String eventStrDate) {
    Calendar calendar = Calendar.getInstance();
    try {
      Date eventDate = DateUtil.getDateFromString(eventStrDate);
      calendar.setTime(eventDate);
    } catch (EqmDaoException exception) {
      exception.getStackTrace();
    }
    return decertificationService.getPrimRulesForEvntDate(calendar);
  }

  @Override
  public Map<String, List<DecertDDChoice>> getRegulations() {
    return decertificationService.getRegulations();
  }

  /**
   * Convert List of dropDownchoice List for ALL API
   * 
   * @param dropDownChoiceList
   * @return
   */
  private Collection<DropdownChoice> createDropDownChoiceListResponse(Collection<DDChoice> dropDownChoiceList) {
    Collection<DropdownChoice> dropdownChoiceResponseList = new ArrayList<>();
    if (dropDownChoiceList != null) {
      for (DDChoice objDropdownChoice : dropDownChoiceList) {
        DropdownChoice dropdownChoiceResponse = new DropdownChoice();
        dropdownChoiceResponse.setIntKey(objDropdownChoice.getIntKey());
        dropdownChoiceResponse.setStrKey(objDropdownChoice.getStrKey());
        dropdownChoiceResponse.setValue(objDropdownChoice.getValue());
        dropdownChoiceResponseList.add(dropdownChoiceResponse);
      }
    }
    return dropdownChoiceResponseList;
  }

  @Autowired
  public boolean getConductorVisibFlag() {
    boolean condVisibFlag = false;
    Map<String, SysParamBean> mapSysParm = sysParamService.getAllSystemParameter();
    final SysParamBean sysParamBean = mapSysParm.get("DECERT_CON_LIC_VISIBILITY");
    if (sysParamBean != null
        && sysParamBean.getParmValu().equalsIgnoreCase(DecertificationApplicationConstant.STR_ON)) {
      condVisibFlag = true;
    }
    return condVisibFlag;
  }

  /**
   * Convert CreateEventDetail to CreateEventRequest
   * 
   * @param createEventRequest
   * @return
   */
  private EventEmployeeResponse createEventEmployeeResponse(EventEmployeeDetail objEventEmployeeRequest) {
    EventEmployeeResponse objEmployeeResponse = new EventEmployeeResponse();
    objEmployeeResponse.setOnDutyDate(DateUtil.getDateAsString(objEventEmployeeRequest.getDateOnDuty()));
    return objEmployeeResponse;
  }

  private List<DropdownChoice> convertMapToDDChoice(Map<String, String> mapObject) {
    List<DropdownChoice> dropdownChoiceResponseList = new ArrayList();
    if (mapObject != null) {
      for (Map.Entry<String, String> entry : mapObject.entrySet()) {
        DropdownChoice dropdownChoiceResponse = new DropdownChoice();
        // dropdownChoiceResponse.setIntKey(ObjResponse.);
        dropdownChoiceResponse.setStrKey(entry.getKey());
        dropdownChoiceResponse.setValue(entry.getValue());
        dropdownChoiceResponseList.add(dropdownChoiceResponse);
      }
    }
    return dropdownChoiceResponseList;
  }

  /*
   * private boolean updatelerbAssignedTo(FaxSuspensionDetail faxSuspensionDetail){
   * decertificationService.reassignWorkItemForLerb(faxSuspensionDetail.getEventId(),
   * faxSuspensionDetail.getEmployeeID(), faxSuspensionDetail.getServiceUnitNumber(), EQMSResnConstant.RESN_LERB_ACTION,
   * faxSuspensionDetail.getLerbAssignedTo(), faxSuspensionDetail.getLoggedinUserID()); return true; }
   */

  @Override
  public boolean updatelerbAssignedTo(FaxSuspensionDetail faxSuspensionDetail) {
    faxSuspensionDetail.setLoggedinUserID(eqmsUserSession.getUser().getEmplId());
    decertificationService.reassignWorkItemForLerb(faxSuspensionDetail.getEventId(),
        faxSuspensionDetail.getEmployeeID(), faxSuspensionDetail.getServiceUnitNumber(),
        EQMSResnConstant.RESN_LERB_ACTION, faxSuspensionDetail.getLerbAssignedTo(),
        faxSuspensionDetail.getLoggedinUserID());
    return true;
  }

  public boolean isValidEmployee(String employeeId) {
    return decertificationService.isValidEmployee(employeeId);

  }

  @Override
  public List<EqmGisMpLoc> getServiceUnitBySubdvsnMp(String subDvsn, String milePost) {
    return decertificationService.getServiceUnitBySubdvsnMp(subDvsn, milePost);
  }

  @Override
  public Map<String, HashSet<EventEmployeeDetail>> getCrewData(String section, String symbol, String day,
      String eventDate) {
    Date eveDate = DateUtil.getDateInstanceFromStringDate(eventDate);
    return decertificationService.getCrewDataInfo(section, symbol, day, eveDate);
  }

  @Override
  public boolean validateHowLongOperating(CreateEventRequest request, boolean condVisibFlag) throws EqmDaoException {

    if (!DecertificationMapper.validateHowLongOperating(createEventRequest(request),
        sysParamService.getAllSystemParameter().get(SysParmConstants.DECERT_NEW_ATTRIBUTE_DATE_1))) {

      return false;
    }

    if (!areAllEmployeesInEQMS(request)) {
      return false;
    }

    if (condVisibFlag) {
      if (!checkEmplPosAtTimeOfEvnt(request.getEventEmployeeAll())) {
        return false;
      }
    }

    if (!validateEmployeeSuspension(request, condVisibFlag)) {
      return false;
    }

    return true;
  }

  private boolean checkEmplPosAtTimeOfEvnt(List<EventEmployeeDetail> eventEmplDetailList) {

    final Map<String, SysParamBean> sysParmMap = sysParamService.getAllSystemParameter();
    boolean isConPos = true;
    final List<String> conEmplId = new ArrayList<String>();
    final List<String> engEmplId = new ArrayList<String>();
    if (null != eventEmplDetailList && !eventEmplDetailList.isEmpty()) {
      /*
       * List<String> tempEmplIdList = new ArrayList<String>();
       * DecertificationUtil.getEmplIdListForConPos(tempEmplIdList, eventEmplDetailList);
       */
      for (final EventEmployeeDetail evntEmplDtlObj : eventEmplDetailList) {
        final String emplId = evntEmplDtlObj.getEmployeeID();
        String emplPos = evntEmplDtlObj.getStrPosition();
        if (null == emplPos) {
          final DDChoice ddChoice = evntEmplDtlObj.getPosition();
          if (null != ddChoice) {
            emplPos = ddChoice.getStrKey();
          }
        }
        if (null != evntEmplDtlObj.getActualPosOnTrain()
            && !"".equalsIgnoreCase(evntEmplDtlObj.getActualPosOnTrain())) {
          if (DecertificationApplicationConstant.RCO_CON.equalsIgnoreCase(emplPos)
              || DecertificationApplicationConstant.CON.equalsIgnoreCase(emplPos)) {
            if (!DecertificationUtil.getConductorPosList(sysParmMap.get(SysParmConstants.CONDUCTOR_POSITION_LIST))
                .contains(evntEmplDtlObj.getActualPosOnTrain())) {
              conEmplId.add(emplId);
            }
          } else {
            if (DecertificationUtil.getConductorPosList(sysParmMap.get(SysParmConstants.CONDUCTOR_POSITION_LIST))
                .contains(evntEmplDtlObj.getActualPosOnTrain())) {
              engEmplId.add(emplId);
            }
          }
        }
      }
      if (!conEmplId.isEmpty()) {
        String wanrningMessage = "Event cannot be entered because Employee ID(s): " + Util.listAppender(conEmplId, ",")
            + " were not working as a conductor when the event was occurred.";
        isConPos = false;
        throw new EqmDaoException(wanrningMessage);
      }
      if (!engEmplId.isEmpty()) {
        String wanrningMessage = "Event cannot be entered because Employee ID(s): " + Util.listAppender(conEmplId, ",")
            + " were not working as a engineer when the event was occurred.";
        isConPos = false;
        throw new EqmDaoException(wanrningMessage);
      }
    }
    return isConPos;
  }

  private boolean validateEmployeeSuspension(CreateEventRequest eventRequest, boolean condVisibFlag)
      throws EqmDaoException {

    boolean validate = true;
    validateEmployees = true;
    final boolean flagValue = checkStatus(eventRequest);
    if (flagValue && eventRequest.getIsLerbAction()) {
      final int NUM_OF_UNSUSPENDED_EMPLOYEES = validateEmployees(eventRequest, condVisibFlag);
      if (DecertificationApplicationConstant.EVENT_STATUS_OPEN.equalsIgnoreCase(eventRequest.getEvntStatusFlag())) {

        if (NUM_OF_UNSUSPENDED_EMPLOYEES == eventRequest.getEventEmployeeAll().size()) {
          // -- No suspended employee.
          validate = false;
          String wanrningMessage = "Atleast one employee should be suspended to submit the event.";
          throw new EqmDaoException(wanrningMessage);
        }
      }
    } else if (!eventRequest.getIsLerbAction()) {
      // SS_QC_9129 changes start(Single employee reinstate issue)
      if (eventRequest.getIsUpdate()) {
        reasonForNotUpdatingEmployeeDetails = checkIfEmployeeDetailsCanBeUpdated(eventRequest.getEvntDtlId(),
            eventRequest.getEvntStatusFlag());
        final int NUM_OF_UNSUSPENDED_EMPLOYEES = validateEmployees(eventRequest, condVisibFlag);
        if (reasonForNotUpdatingEmployeeDetails == null) {
          if (NUM_OF_UNSUSPENDED_EMPLOYEES == eventRequest.getEventEmployeeAll().size()) {
            validate = false;
            String wanrningMessage = "Atleast one employee should be suspended to submit the event.";
            throw new EqmDaoException(wanrningMessage);
          }
        }
      } else {
        final int NUM_OF_UNSUSPENDED_EMPLOYEES = validateEmployees(eventRequest, condVisibFlag);
        if (NUM_OF_UNSUSPENDED_EMPLOYEES == eventRequest.getEventEmployeeAll().size()) {
          validate = false;
          String wanrningMessage = "Atleast one employee should be suspended to submit the event.";
          throw new EqmDaoException(wanrningMessage);
        }
        // SS_QC_9129 changes end
      }
    }
    if (!validateEmployees) {
      validate = false;
    }
    return validate;
  }

  private int validateEmployees(CreateEventRequest eventRequest, boolean condVisibFlag) throws EqmDaoException {
    int result = 0; // -- to hold the number of unsuspended employees.

    for (final EventEmployeeDetail employee : eventRequest.getEventEmployeeAll()) {
      if ((employee.getSuspended() != null)
          && employee.getSuspended().equalsIgnoreCase(DecertificationApplicationConstant.YES)) {

        if (null != employee.getStrPosition()) {

          if (!condVisibFlag && DecertificationApplicationConstant.CON.equalsIgnoreCase(employee.getStrPosition())) {
            String wanrningMessage = "Conductor License of employee: " + employee.getEmployeeID()
                + " cannot be suspended. Hence event cannot be entered.";
            result += 1;
            validateEmployees = false;
            throw new EqmDaoException(wanrningMessage);
          } else if (!decertificationService.isLicensedEmployee(employee.getEmployeeID(),
              DateUtil.convertDateTimeStringToCalendar(eventRequest.getEventDate()), employee.getStrPosition())) {
            String wanrningMessage = "Employee with ID " + employee.getEmployeeID()
                + " doesn't posess valid license. Hence cannot be suspended.";
            result += 1;
            validateEmployees = false;
            throw new EqmDaoException(wanrningMessage);
          }
        } else {
          String wanrningMessage = "Position selected for employee with ID " + employee.getEmployeeID()
              + " is not a licensed position. Hence cannot be suspended.";
          result += 1;
          validateEmployees = false;
          throw new EqmDaoException(wanrningMessage);
        }

      } else if ((employee.getSuspended() != null)
          && employee.getSuspended().equalsIgnoreCase(DecertificationApplicationConstant.NO)) {
        result += 1;
      } else {
        String wanrningMessage = "The Suspension Value For Employee Not Selected";
        validateEmployees = false;
        throw new EqmDaoException(wanrningMessage);
      }
    }
    return result;
  }

  private boolean areAllEmployeesInEQMS(CreateEventRequest request) throws EqmDaoException {

    boolean areAllEmployeesInEQMS = true;

    for (final EventEmployeeDetail employee : request.getEventEmployeeAll()) {
      if (!employee.isValidEmployee()) {
        areAllEmployeesInEQMS = false;
        String wanrningMessage = "Employee with ID: " + employee.getEmployeeID() + " is not present in EQMS system.";
        throw new EqmDaoException(wanrningMessage);
      }
    }

    return areAllEmployeesInEQMS;
  }

  @Override
  public Map<String, SysParamBean> getSystemParam() {
    Map<String, SysParamBean> systemParam = sysParamService.getAllSystemParameter();
    return systemParam;
  }

  @Override
  public List<DecertDDChoice> getSignalMasterData() {
    return decertificationService.getSignalMasterData();
  }

  @Override
  public String checkIfEmployeeDetailsCanBeUpdated(Integer eventDetailId, String eventStatus) {
    try {
      if (DecertificationApplicationConstant.EVENT_STATUS_MITIGATE.equalsIgnoreCase(eventStatus)) {
        return "* Employee details cannot be updated because event has been mitigated.";
      } else if (DecertificationApplicationConstant.EVENT_STATUS_CLOSED.equalsIgnoreCase(eventStatus)) {
        return "* Employee details cannot be updated because event has been closed.";
      } else if (DecertificationApplicationConstant.EVENT_STATUS_INVALID.equalsIgnoreCase(eventStatus)) {
        return "* Employee details cannot be updated because event has been marked invalid.";
      } else if (decertificationService.isAnyEmployeeReinstated(eventDetailId)) {
        return "* Employee details cannot be updated because one or more employees in this event are reinstated.";
      } else if (decertificationService.isAnyEmployeeOfEventDecertified(eventDetailId)) {
        return "* Employee details cannot be updated because one or more employees in this event are decertified.";
      } else if (decertificationService.isRevocationConfirmed(eventDetailId, null)) {
        return "* Employee details cannot be updated because one or more employees in this event have their revocation confirmed.";
      }

    } catch (final EqmDaoException e) {

    } catch (final Exception e) {

    }
    return null;
  }

  @Override
  public List<Train> getTrainDetails(String trnSection, String trnSymbol, String trnDay) {
    return decertificationService.getTrainDetailsView(trnSection, trnSymbol, trnDay, null, null);
  }

  @SuppressWarnings("unchecked")
  @Override
  public List<TrainDetail> getTrainDetail(String trainSection, String trainSymbol, String trainDay, String eventDate) {
    String trainId = (trainSection + trainSymbol + trainDay);
    Object[] trainInfo = { trainSection, trainSymbol, trainDay };
    return (List<TrainDetail>) decertificationService.getTrainDetail(trainInfo, trainId,
        DateUtil.convertDateTimeStringToCalendar(eventDate));
  }

  @Override
  public boolean validateMilePostSvcUntAndSubDv(Integer milePost, Integer svcUnitNbr, String subDvsn) {
    return decertificationService.validateMilePostSvcUntAndSubDv(milePost, svcUnitNbr, subDvsn);
  }

  /**
   * Classname / Method Name : UpdateLerbEventEmployeeDetailsPage/checkStatus()
   * 
   * @return Description : This method is used to allow user to enter the lerb event if there is no suspended employee
   */
  private boolean checkStatus(CreateEventRequest eventRequest) {
    boolean retVal = false;
    int count = 0;
    if (null != eventRequest.getEventEmployeeAll() && !eventRequest.getEventEmployeeAll().isEmpty()) {
      for (final EventEmployeeDetail employee : eventRequest.getEventEmployeeAll()) {
        if ((employee.getSuspended() != null)
            && employee.getSuspended().equalsIgnoreCase(DecertificationApplicationConstant.NO)) {
          count++;
        }
      }
      if (!(count == eventRequest.getEventEmployeeAll().size())) {
        retVal = true;
      }
    }
    return retVal;
  }

  public Map<String, String> sendHFRReport(final CreateEventRequest createEventDetail) {

    Map<String, String> hfrRptMap = new HashMap<>();
    final DDChoice typeOfEvent = createEventDetail.getTypeOfEventAll();
    // Step 1: Event is Decertification event then verify whether Track is Main and Decert event created successfully.
    if (DecertificationApplicationConstant.EVENT_TYPE_DECERTIFICATION.equalsIgnoreCase(typeOfEvent.getValue())
        && (createEventDetail.getLocationDetail() != null && DecertificationApplicationConstant.MAIN_TRACK
            .equalsIgnoreCase(createEventDetail.getLocationDetail().getTypeOfTrack()))) {
      // Set employee id list in Create event bean and return comma separated email-id as request parameter to HFR
      // Report
      final String commaSeparateEmplID = decertificationService
          .populateEvntEmplListForHFR(createEventRequest(createEventDetail), sysParamService.getAllSystemParameter());
      // Generate the email content for Human Factor Report.
      final String mailContent = decertificationService.emailContentForHFR(createEventRequest(createEventDetail));
      hfrRptMap.put("commaSeparateEmplID", commaSeparateEmplID);
      hfrRptMap.put("mailContent", mailContent);
      /*
       * if (commaSeparateEmplID != null && mailContent != null) { target.appendJavascript("javascript:callHFRReport('"
       * + commaSeparateEmplID + "'" + EQMSConstant.COMMA + "'" + mailContent + "');"); } } else { LOGGER.info(
       * "Entered Decertification event is not conducted on Stop violation rule. " + CLASS_NAME); }
       */
    }
    return hfrRptMap;
  }

  /**
   * To set EvntDateCalendar in create bean for email content
   *
   * @param evntDate
   * @param evntTime
   * @return Calendar
   * @author xsat794
   * @since Aug 23, 2017 Added for SS_QC_9357
   */
  private Calendar setEvntDateCalendar(String evntDate, String evntTime) {
    final Calendar evntDateCalendar = Calendar.getInstance();
    final Date eventDate = DateUtil.getDateFromString(evntDate);
    final String eventTime = evntTime;
    evntDateCalendar.setTime(eventDate);
    final String time[] = eventTime.split(":");

    if (time != null && time[0] != null) {
      evntDateCalendar.set(Calendar.HOUR_OF_DAY, Integer.parseInt(time[0]));
    }
    if (time != null && time[1] != null) {
      evntDateCalendar.set(Calendar.MINUTE, Integer.parseInt(time[1]));
    }
    return evntDateCalendar;
  }
}
