package com.uprr.lic.decert.restcontroller;

import java.io.IOException;
import java.io.OutputStream;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;
import javax.xml.parsers.ParserConfigurationException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.xml.sax.SAXException;

import com.itextpdf.text.DocumentException;
import com.uprr.lic.dataaccess.common.model.CmtsEmplBasedMsgs;
import com.uprr.lic.dataaccess.common.model.EqmEmplCmntDtls;
import com.uprr.lic.dataaccess.decertification.model.ApproveRejectRemedialPageDetail;
import com.uprr.lic.dataaccess.decertification.model.MitigateEventDetail;
import com.uprr.lic.decert.rest.model.DecertifyLicenseDetailResponse;
import com.uprr.lic.decert.rest.model.DecertifyLicenseDetailRestRequest;
import com.uprr.lic.decert.rest.model.DropdownChoice;
import com.uprr.lic.decert.rest.model.EAPRequest;
import com.uprr.lic.decert.rest.model.EmployeeDetails;
import com.uprr.lic.decert.rest.model.EmployeeIncidentDetailResponse;
import com.uprr.lic.decert.rest.model.EmployeeOffenceDetails;
import com.uprr.lic.decert.rest.model.EmployeeOffenceDetailsRequest;
import com.uprr.lic.decert.rest.model.EmployeeViewIncidentPopupResponse;
import com.uprr.lic.decert.rest.model.EventDetailsResponse;
import com.uprr.lic.decert.rest.model.EventDocumentDetail;
import com.uprr.lic.decert.rest.model.EventEmployeeResponse;
import com.uprr.lic.decert.rest.model.EventIncidentHistoryResponse;
import com.uprr.lic.decert.rest.model.EventLerbDetailResponse;
import com.uprr.lic.decert.rest.model.FaxRemedialDetailRequest;
import com.uprr.lic.decert.rest.model.IncidentHistoryDeleteCommentDetails;
import com.uprr.lic.decert.rest.model.LicenseDetailResponse;
import com.uprr.lic.decert.rest.model.ReceivedDocumentRequest;
import com.uprr.lic.decert.rest.model.RemedialTrainingDetails;
import com.uprr.lic.decert.rest.model.SearchEventResponse;
import com.uprr.lic.decert.rest.model.ValidEmployeeDetailsForEap;
import com.uprr.lic.decert.service.IAdministrationService;
import com.uprr.lic.exception.EqmDaoException;
import com.uprr.lic.util.DateUtil;
import com.uprr.netcontrol.frontend.client.xmf.XmfClientInvoker;

@Controller
public class AdministrationController {

  Logger LOGGER = LoggerFactory.getLogger(AdministrationController.class);

  @Autowired
  private IAdministrationService adminService;

  @Autowired
  @Qualifier("dossGetXmfClientInvoker")
  XmfClientInvoker dossGetInvoker;

  @RequestMapping(method = RequestMethod.POST, value = "/getEventIncidentHistory/{eventDetailId}")
  @ResponseBody
  public List<EventIncidentHistoryResponse> getEventIncidentHistory(@PathVariable Integer eventDetailId) {
    return adminService.getEventIncidentHistory(eventDetailId);
  }

  @RequestMapping(method = RequestMethod.POST, value = "/getEmployeeDetails")
  @ResponseBody
  public List<EventEmployeeResponse> getEmployeeDetails(@RequestBody SearchEventResponse searchEventRequest) {
    return adminService.getEmployeeDetails(searchEventRequest);
  }

  @RequestMapping(method = RequestMethod.POST, value = "/getEventDetails")
  @ResponseBody
  public EventDetailsResponse getEventDetail(@RequestBody SearchEventResponse searchEventRequest) {
    return adminService.getEventDetails(searchEventRequest);
  }

  @RequestMapping(method = RequestMethod.GET, value = "/getLerbDetails/{eventId}/{employeeID}")
  @ResponseBody
  public List<EventLerbDetailResponse> getEventLerbDetails(@PathVariable Integer eventId,
      @PathVariable String employeeID) {
	  //SS_QC_10239 changes start
	  if(employeeID != null && (employeeID.equals("null") || employeeID.isEmpty())) {
		  employeeID = null;
	  }  //SS_QC_10239 changes end
    return adminService.getEventLerbDetails(eventId, employeeID);
  }

  @RequestMapping(method = RequestMethod.GET, value = "/getLicenseDetails/{employeeID}")
  @ResponseBody
  public List<LicenseDetailResponse> getLicenseDetailList(@PathVariable String employeeID) {
    return adminService.getLicenseDetailList(employeeID);
  }

  @RequestMapping(method = RequestMethod.GET, value = "/getRevocationPeriods")
  @ResponseBody
  public List<DropdownChoice> getRevocationPeriodList() {
    return adminService.getRevocationPeriodList();
  }

  @RequestMapping(method = RequestMethod.GET, value = "/getDocumentListByType/{eventID}/{eventTypeID}/{employeeID}")
  @ResponseBody
  public List<DropdownChoice> getDocumentListByType(@PathVariable("eventID") Integer eventID,
      @PathVariable("eventTypeID") Integer eventTypeID, @PathVariable("employeeID") String employeeID) {
    return adminService.getDocumentListByType(eventID, eventTypeID, employeeID);
  }

  @RequestMapping(method = RequestMethod.POST, value = "/updateReceivedDocument")
  @ResponseBody
  public String updateReceivedDocument(@RequestBody ReceivedDocumentRequest receivedDocuments) {
    String receivedDocumentMessage = adminService.updateReceivedDocument(receivedDocuments);
    return receivedDocumentMessage;
  }

  @RequestMapping(method = RequestMethod.POST, value = "/getDecertifyLicenseDetails")
  @ResponseBody
  public DecertifyLicenseDetailResponse getDecertifyLicenseDetails(
      @RequestBody DecertifyLicenseDetailRestRequest decertifyLicenseRequestDetail) throws Exception {
    return adminService.getDecertifyLicenseDetails(decertifyLicenseRequestDetail);
  }

  @RequestMapping(method = RequestMethod.POST, value = "/decertifyEmployee")
  @ResponseBody
  public boolean decertifyEmployee(@RequestBody DecertifyLicenseDetailRestRequest details) throws Exception {
    return adminService.decertifyEmployee(details);
  }

  /**
   * saveCommentsForEmployee
   * 
   * @param eventID
   * @param eventTypeID
   * @param employeeID
   * @return
   */
  @RequestMapping(method = RequestMethod.POST, value = "/updateEmployeeComment")
  @ResponseBody
  public boolean updateEmployeeComment(@RequestBody EmployeeDetails employeeCommentRequest) {
    return adminService.updateEmployeeComment(employeeCommentRequest);
  }

  /**
   * Set received document
   * 
   * @param eventID
   * @param eventTypeID
   * @param employeeID
   * @return
   */
  @RequestMapping(method = RequestMethod.POST, value = "/updateRemedialTrainingDetails/{serviceUnitNumber}")
  @ResponseBody
  public boolean updateRemedialTrainingDetails(@RequestBody FaxRemedialDetailRequest faxRemediaDetailRequest,
      @PathVariable("serviceUnitNumber") Integer serviceUnitNumber) {
    return adminService.updateRemedialTrainingDetails(faxRemediaDetailRequest, serviceUnitNumber);
  }

  @RequestMapping(method = RequestMethod.POST, value = "/getReinstateDate/{decline}")
  @ResponseBody
  public String getDefaultReinstateDate(@PathVariable boolean decline, @RequestBody EmployeeDetails employeeDetails) {
    return adminService.getReinstateDate(decline, employeeDetails);
  }

  @RequestMapping(method = RequestMethod.POST, value = "/declineReinstateEmployee")
  @ResponseBody
  public boolean declineReinstateEmployee(@RequestBody EmployeeDetails employeeDetails) {
    return adminService.declineReinstateEmployee(employeeDetails);
  }

  @RequestMapping(method = RequestMethod.POST, value = "/reinstateEmployee")
  @ResponseBody
  public Map<String, Boolean> reinstateEmployee(@RequestBody EmployeeDetails employeeDetails) {
    return adminService.reinstateEmployee(employeeDetails);
  }

  @RequestMapping(method = RequestMethod.POST, value = "/mitigateEmployee")
  @ResponseBody
  public boolean mitigateEmployee(MultipartHttpServletRequest request) {
    return adminService.mitigateEmployee(request);
  }

  @RequestMapping(method = RequestMethod.POST, value = "/verifyDisciplineEntry")
  @ResponseBody
  public String verifyMapsEntry(@RequestBody EmployeeDetails employeeDetails) throws EqmDaoException {
    return adminService.verifyMapsEntry(employeeDetails);
  }

  @RequestMapping(method = RequestMethod.POST, value = "/updateEAPDetails")
  @ResponseBody
  public boolean updateEAPDetails(@RequestBody EAPRequest eapRequest) throws Exception {
    return adminService.updateEAPDetails(eapRequest);
  }

  @RequestMapping(method = RequestMethod.GET, value = "/getIncidentHistoryList/{eventDetailID}/{employeeID}")
  @ResponseBody
  public List<EventIncidentHistoryResponse> getIncidentHistoryList(@PathVariable("eventDetailID") Integer eventDetailID,
      @PathVariable("employeeID") String employeeID) {
    return adminService.getIncidentHistoryList(eventDetailID, employeeID);
  }

  @RequestMapping(method = RequestMethod.GET, value = "/isDecertifyWorkItemPresent/{employeeID}/{eventDetailID}", headers = "Accept=application/json")
  @ResponseBody
  public Map<String, Integer> isDecertifyWorkItemPresent(@PathVariable("employeeID") String employeeID,
      @PathVariable("eventDetailID") Integer eventDetailID) {
    Integer workItemId = adminService.isDecertifyWorkItemPresent(eventDetailID, employeeID);
    Map<String, Integer> statusMap = new HashMap<String, Integer>();
    statusMap.put("workItem", workItemId);
    return statusMap;
  }

  @RequestMapping(method = RequestMethod.GET, value = "/checkRemedialTrainingStatus/{employeeID}/{eventDetailID}")
  @ResponseBody
  public Boolean checkRemedialTrainingInitiatedOrApproved(@PathVariable("employeeID") String employeeID,
      @PathVariable("eventDetailID") Integer eventDetailID) {
    return adminService.checkRemedialTrainingInitiatedOrApproved(employeeID, eventDetailID, null);
  }

  @RequestMapping(method = RequestMethod.GET, value = "/isFaxSuspensionDocumentRecieved/{eventDetailID}/{employeeID}")
  @ResponseBody
  public Boolean isFaxSuspensionDocumentRecieved(@PathVariable("eventDetailID") Integer eventDetailID,
      @PathVariable("employeeID") String employeeID) {
    return adminService.isFaxSuspensionReceived(eventDetailID, employeeID);
  }

  @RequestMapping(method = RequestMethod.GET, value = "/employeeStatus/{employeeID}/{eventDetailID}")
  @ResponseBody
  public String employeeStatus(@PathVariable("employeeID") String employeeID,
      @PathVariable("eventDetailID") Integer eventDetailID) {
    return adminService.employeeStatus(employeeID, eventDetailID);
  }

  @RequestMapping(method = RequestMethod.GET, value = "/isEmployeeAlreadyReinstated/{employeeID}/{eventDetailID}")
  @ResponseBody
  public Boolean isEmployeeAlreadyReinstated(@PathVariable("employeeID") String employeeID,
      @PathVariable("eventDetailID") Integer eventDetailID) {
    return adminService.isEmployeeAlreadyReinstated(employeeID, eventDetailID);
  }

  @RequestMapping(method = RequestMethod.GET, value = "/isReinstateWorkItemPresent/{employeeID}/{eventDetailID}")
  @ResponseBody
  public Map<String, Integer> isReinstateWorkItemPresent(@PathVariable("employeeID") String employeeID,
      @PathVariable("eventDetailID") Integer eventDetailID) {
    Integer workItem = adminService.isReinstateWorkItemPresent(eventDetailID, employeeID);
    Map<String, Integer> renWorkItemId = new HashMap<>();
    renWorkItemId.put("WorkItemId", workItem);
    return renWorkItemId;
  }

  @RequestMapping(method = RequestMethod.POST, value = "/checkRuleExamForReinstate")
  @ResponseBody
  public Boolean checkRuleExamForReinstate(@RequestBody EmployeeDetails employeeDetails) {
    return adminService.checkRuleExamForReinstate(employeeDetails.getEmployeeId(),
        DateUtil.getDateAsCalendar(DateUtil.getDateFromString(employeeDetails.getEventDate())));
  }

  @RequestMapping(method = RequestMethod.POST, value = "/workItemForUnaval")
  @ResponseBody
  public void createWorkItemForUnavalExam(@RequestBody EmployeeDetails employeeDetails) {
    Calendar eventDate = DateUtil.getDateAsCalendar(DateUtil.getDateFromString(employeeDetails.getEventDate()));
    adminService.createWorkItemForUnavalExam(employeeDetails.getEmployeeId(), eventDate,
        employeeDetails.getEventDetailId());
  }

  @RequestMapping(method = RequestMethod.POST, value = "/getEmployeeViewIncident")
  @ResponseBody
  public EmployeeViewIncidentPopupResponse getEmployeeViewIncidentDetails(
      @RequestBody EmployeeDetails employeeDetails) {
    return adminService.getEmployeeViewIncidentPopupDetail(employeeDetails.getEmployeeId(),
        employeeDetails.getEventDetailId(), employeeDetails.getEventTypeId());
  }

  @RequestMapping(method = RequestMethod.GET, value = "/isRemedialTrainingInitiated/{employeeID}/{eventDetailID}")
  @ResponseBody
  public Boolean isRemedialTrainingInitiated(@PathVariable("employeeID") String employeeID,
      @PathVariable("eventDetailID") Integer eventDetailID) {
    return adminService.checkRemedialTrainingInitiated(employeeID, eventDetailID, null);
  }

  @RequestMapping(method = RequestMethod.GET, value = "/getDecertAndRemedialInformation/{employeeID}/{eventDetailID}")
  @ResponseBody
  public EmployeeIncidentDetailResponse getDecertAndRemedialInformation(@PathVariable("employeeID") String employeeID,
      @PathVariable("eventDetailID") Integer eventDetailID) {
    return adminService.getDecertAndRemedialInformation(employeeID, eventDetailID);
  }

  @RequestMapping(method = RequestMethod.GET, value = "/calculateRegulationFlag/{employeeID}/{eventDetailID}")
  @ResponseBody
  public String calculateRegulationFlag(@PathVariable("employeeID") String employeeID,
      @PathVariable("eventDetailID") Integer eventDetailID) {
    return adminService.calculateRegulationflag(eventDetailID, employeeID);
  }

  @RequestMapping(method = RequestMethod.GET, value = "/calculateOffenceCount/{employeeID}/{eventDetailID}")
  @ResponseBody
  public String calculateOffenceCount(@PathVariable("employeeID") String employeeID,
      @PathVariable("eventDetailID") Integer eventDetailID) {
    return adminService.calculateOffenceCountForReinstateDate(eventDetailID, employeeID).toString();
  }

  @RequestMapping(method = RequestMethod.POST, value = "/getEmployeeOffenceDetails")
  @ResponseBody
  public EmployeeOffenceDetails getEmployeeOffenceDetails(
      @RequestBody EmployeeOffenceDetailsRequest employeeOffenceDetails) {
    return adminService.getEmployeeOffenceDetails(employeeOffenceDetails);
  }

  @RequestMapping(method = RequestMethod.POST, value = "/approveRemedialTraining")
  @ResponseBody
  public boolean approveRemedialTraining(@RequestBody RemedialTrainingDetails remedialTrainingDetails) {
    return adminService.approveRemedialTraining(remedialTrainingDetails);
  }

  @RequestMapping(method = RequestMethod.POST, value = "/rejectRemedialTraining")
  @ResponseBody
  public boolean rejectRemedialTraining(@RequestBody RemedialTrainingDetails remedialTrainingDetails) {
    return adminService.rejectRemedialTraining(remedialTrainingDetails);
  }

  @RequestMapping(method = RequestMethod.POST, value = "/performCommentDeleteOperation")
  @ResponseBody
  public boolean performCommentDeleteOperation(
      @RequestBody IncidentHistoryDeleteCommentDetails incidentHistoryDeleteCommentDetails) {
    return adminService.performCommentDeleteOperation(incidentHistoryDeleteCommentDetails);
  }

  @RequestMapping(method = RequestMethod.POST, value = "/getDocumentDetails")
  @ResponseBody
  public List<EventDocumentDetail> getDocumentDetails(@RequestBody SearchEventResponse searchEventRequest) {
    return adminService.getDocumentDetails(searchEventRequest);
  }

  /*
   * @RequestMapping(method = RequestMethod.GET, value = "/generatePdf")
   * @ResponseBody private byte[] generatePdf(@RequestParam(value = "gufnId") String gufnId,
   * @RequestParam(value = "mimeType") String mimeType, HttpServletResponse response) throws DocumentException {
   * response.setContentType("application/" + mimeType); response.setHeader("Content-Disposition",
   * "inline;filename=abc"); OutputStream responseOutputStream = null; System.err.println("application/"+mimeType);
   * byte[] byteOutput = null; try { byteOutput = adminService.generatePdf(gufnId); responseOutputStream =
   * response.getOutputStream(); if(null!= byteOutput){ response.setContentLength(byteOutput.length);
   * responseOutputStream.write(byteOutput); }else{ responseOutputStream.write(
   * "Error While getting Document, Please Try after some time".getBytes()); } } catch
   * (com.lowagie.text.DocumentException | ParserConfigurationException | SAXException | IOException e) { LOGGER.error(
   * "Failed at Admin controller generatePdf ", e); } return byteOutput; }
   */

  @RequestMapping(method = RequestMethod.GET, value = "/getApproveRejectRemedialPagedetails/{employeeID}/{eventDetailID}")
  @ResponseBody
  public ApproveRejectRemedialPageDetail getApproveRejectRemedialPagedetails(
      @PathVariable("employeeID") String employeeID, @PathVariable("eventDetailID") Integer eventDetailID) {
    return adminService.getApproveRejectRemedialPagedetails(employeeID, eventDetailID);
  }

  @RequestMapping(method = RequestMethod.GET, value = "/checkValidEmployeeForEapComplete/{employeeID}/{eventDetailID}")
  @ResponseBody
  public ValidEmployeeDetailsForEap checkValidEmployeeForEapComplete(@PathVariable("employeeID") String employeeID,
      @PathVariable("eventDetailID") Integer eventDetailID) {
    return adminService.isEAPCompleteForEmployee(employeeID, eventDetailID);
  }

  @RequestMapping(method = RequestMethod.GET, value = "/verifyMapsWorkItemId/{employeeID}/{eventDetailID}")
  @ResponseBody
  public Map<String, Integer> getVerifyMapsWorkItemId(@PathVariable("employeeID") String employeeID,
      @PathVariable("eventDetailID") Integer eventDetailID) {
    Map<String, Integer> workItemMap = new HashMap<>();
    Integer workItemIdForMaps = adminService.getVerifyMapsWorkItemId(eventDetailID, employeeID);
    workItemMap.put("workItemIdForMap", workItemIdForMaps);
    return workItemMap;
  }

  @RequestMapping(method = RequestMethod.GET, value = "/getEmployeeEventCommentDetails/{employeeID}/{eventDetailID}")
  @ResponseBody
  public EqmEmplCmntDtls getEmployeeEventCommentDetails(@PathVariable("employeeID") String employeeID,
      @PathVariable("eventDetailID") Integer eventDetailID) {
    return adminService.getEmployeeEventCommentDetails(eventDetailID, employeeID);
  }

  @RequestMapping(method = RequestMethod.GET, value = "/getMitigateEventBeanByEvntDtlId/{eventDetailID}")
  @ResponseBody
  public MitigateEventDetail getMitigateEventBeanByEvntDtlId(@PathVariable("eventDetailID") Integer eventDetailID) {
    return adminService.getMitigateEventBeanByEvntDtlId(eventDetailID);
  }

  @RequestMapping(method = RequestMethod.GET, value = "/generatePdf")
  @ResponseBody
  private void generatePdf(@RequestParam(value = "gufnId") String gufnId,
      @RequestParam(value = "mimeType") String mimeType, @RequestParam(value = "fileName") String fileName,
      HttpServletResponse response) throws DocumentException {
    if (mimeType.equalsIgnoreCase("xls") || mimeType.equalsIgnoreCase("xlsx")) {
      response.setContentType("application/ms-excel");
    } else {
      response.setContentType("application/" + mimeType);
    }
    response.setHeader("Content-Disposition", "inline;filename=" + fileName);

    OutputStream responseOutputStream = null;
    System.err.println("application/" + mimeType);

    byte[] byteOutput = null;
    try {
      byteOutput = adminService.generatePdf(gufnId);

      responseOutputStream = response.getOutputStream();
      if (null != byteOutput) {
        responseOutputStream.write(byteOutput);
      } else {
        responseOutputStream.write("Error While getting Document, Please Try after some time".getBytes());
      }
    } catch (com.lowagie.text.DocumentException | ParserConfigurationException | SAXException | IOException e) {
      LOGGER.error("Failed at Admin controller generatePdf ", e);
    }
  }

  // eventdocumentdetails for DRO closeout link
  @RequestMapping(method = RequestMethod.GET, value = "/getEventDocumentGridBean/{eventDetailID}")
  @ResponseBody
  public List<EventDocumentDetail> getEventDocumentGridBean(@PathVariable("eventDetailID")
  final Integer eventId) {
    return adminService.getEventDocumentGridBean(eventId, false);

  }

  // duplicating this method because in this API we dont have lerb flag
  // eventdocumentdetails for DRO closeout link
  @RequestMapping(method = RequestMethod.GET, value = "/getEventDocumentGridBean/{eventDetailID}/{isLerb}")
  @ResponseBody
  public List<EventDocumentDetail> getEventDocumentGridBean(@PathVariable("eventDetailID")
  final Integer eventId, @PathVariable("isLerb")
  final boolean isLerb) {
    // boolean isLerbFlag = Boolean.parseBoolean(isLerb);
    return adminService.getEventDocumentGridBean(eventId, isLerb);

  }
// SS_QC#9262 changes start
  /**
   * This method is used to employee based cmts messages details.
   *
   * @param emplId
   * @return List<CmtsEmplBasedMsgs>
   * @author xsat671
   * @since Sep 11, 2017.
   * Added for SS_QC#9262
   */
  @RequestMapping(method = RequestMethod.GET, value = "/getEmplStatusDetailsList/{employeeID}")
  @ResponseBody
  public List<CmtsEmplBasedMsgs> getEmplStatusDetailsList(@PathVariable("employeeID") String employeeID) {
    return adminService.getEmplStatusDetailsList(employeeID);
  }
//SS_QC#9262 changes end
}
