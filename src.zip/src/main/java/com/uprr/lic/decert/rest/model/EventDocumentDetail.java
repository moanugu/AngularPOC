/**
 * Classname    : EventDocumentGridDetail
 * Description  : 
 * author       : Tech Mahindra
 * Date of creation : 
 *
 * Change History
 * ------------------------------------------------------------  
 *   Date  Changed By    Description
 * ------------------------------------------------------------  
 *  22-Jan-2015   xsat494       Modified for Req 652
 *  
 * ------------------------------------------------------------  
 *
 * Copyright notice : "Copyright UPRR 2008"
 */
package com.uprr.lic.decert.rest.model;

public class EventDocumentDetail {

	private String fileName;
	private Integer docID;
	private String docKey;
	private String mimeType;
	private String lerbUpload;
	private byte[] datFileByteArray;

	public EventDocumentDetail() {
		super();
	}

	/**
	 * @return the fileName
	 */
	public String getFileName() {
		return fileName;
	}

	/**
	 * @param name
	 *            the fileName to set
	 */
	public void setFileName(final String name) {
		fileName = name;
	}

	public EventDocumentDetail(final String name) {
		super();
		fileName = name;
	}

	public Integer getDocID() {
		return docID;
	}

	public void setDocID(Integer docid) {
		docID = docid;
	}

	public String getDocKey() {
		return docKey;
	}

	public void setDocKey(String key) {
		docKey = key;
	}

	public String getMimeType() {
		return mimeType;
	}

	public void setMimeType(String type) {
		mimeType = type;
	}

	public String getLerbUpload() {
		return lerbUpload;
	}

	public void setLerbUpload(String lerbUpload) {
		this.lerbUpload = lerbUpload;
	}

	/**
	 * @return the datFileByteArray
	 */
	public byte[] getDatFileByteArray() {
		return datFileByteArray;
	}

	/**
	 * @param datFileByteArray
	 *            the datFileByteArray to set
	 */
	public void setDatFileByteArray(byte[] datFileByteArray) {
		this.datFileByteArray = datFileByteArray;
	}

}
