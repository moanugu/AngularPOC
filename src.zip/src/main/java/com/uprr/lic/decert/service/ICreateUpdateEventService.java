package com.uprr.lic.decert.service;

import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.uprr.lic.dataaccess.common.model.DecertDDChoice;
import com.uprr.lic.dataaccess.common.model.EqmGisMpLoc;
import com.uprr.lic.dataaccess.decertification.model.EventEmployeeDetail;
import com.uprr.lic.dataaccess.decertification.model.FaxSuspensionDetail;
import com.uprr.lic.dataaccess.decertification.model.TrainDetail;
import com.uprr.lic.dataaccess.fte.model.Train;
import com.uprr.lic.decert.rest.model.CreateEventRequest;
import com.uprr.lic.decert.rest.model.DropdownChoice;
import com.uprr.lic.decert.rest.model.EmployeeDetailResponse;
import com.uprr.lic.decert.rest.model.EventDescDetail;
import com.uprr.lic.util.SysParamBean;

public interface ICreateUpdateEventService {
	
	
	List<String> getResultOfEventList();
		
	List<DropdownChoice> getEventTypeList();
	
	List<EventDescDetail> getEventDescriptionList();
	
	
	List<String> getSignalTerritoryList();
	
	List<String> getTypeOfTrackList();
	
	List<DropdownChoice> getRailRoadList();
	
	List<String> getTypeofAuthorityList();
	
	List<DropdownChoice> getWeatherList();
	
	List<DropdownChoice> getVisibilityList();
	
	List<String> getOperationList();
	
	List<String> getGradeList();
	
	List<String> getCurvatureList();
	
	List<String> getCrewTypeList();
	
	EmployeeDetailResponse getEmployeeDetailsByID(String employeeId);
	
	List<DropdownChoice> getPositionList();
	
	List<String> getLicensedPositionList();
	
	List<String> getDirectionList();
	
	List<String> getLastJobBrefList();
	
	List<DropdownChoice> getDecertRegulationList(String position);
	
	List<DropdownChoice> getOtherRegulationList();
	
	List<String> getSuspendedList();
	
	Collection<DropdownChoice> getSubDivision(String svcUnitName);
	
	CreateEventRequest getEventDetails(Integer eventDetailID);

	Boolean insertEvent(MultipartHttpServletRequest  multipartRequest);

	Boolean updateEvent(MultipartHttpServletRequest  multipartRequest);


	// vikas code for getlerbaction
	List<DropdownChoice> getSysParmLerbAction();

	 Map<Integer,List<DecertDDChoice>> getPrimRulesForEvntDate(String eventDate) ;
	 Map<String, List<DecertDDChoice>> getRegulations();
	 boolean getConductorVisibFlag();
	 boolean updatelerbAssignedTo(FaxSuspensionDetail faxSuspensionDetail);
	 boolean isValidEmployee(String employeeId);

	List<EqmGisMpLoc> getServiceUnitBySubdvsnMp(String subDvsn, String milePost);

	Map<String, HashSet<EventEmployeeDetail>> getCrewData(String section, String symbol, String day, String eveDate);

	boolean validateHowLongOperating(CreateEventRequest createEventRequest,boolean condVisibFlag);
	
	Map<String, SysParamBean> getSystemParam();


	List<DecertDDChoice> getSignalMasterData();

	String checkIfEmployeeDetailsCanBeUpdated(Integer eventDetailId,String eventStatus);
	
	List<Train> getTrainDetails(String trnSection, String trnSymbol,String trnDay);
	
	List<TrainDetail> getTrainDetail(String section, String symbol, String day, String eveDate);
	
	public boolean validateMilePostSvcUntAndSubDv(final Integer milePost, final Integer svcUnitNbr, 
		      final String subDvsn);
	
	public Map<String, String> sendHFRReport(final CreateEventRequest createEventDetail);
}
