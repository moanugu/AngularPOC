package com.uprr.lic.decert.rest.model;

import java.util.Date;

public class DecertifyLicenseDetailResponse {

	private Integer eventDetailID;

	private Integer evntRvkeDtlsId;

	private String employeeID;

	private String employeeName;

	private DropdownChoice region;

	private DropdownChoice serviceUnit;

	private DropdownChoice typeOfEvent;

	private String regulation;

	private String eventDate;

	private String eventDateTime; 

	private String onDutyDateTime; 

	private String responsibleManager;

	private String responsibleManageId;

	private String resultOfEvent;

	private Date effectiveDate;

	private String effectiveDateStr;

	private String eapRequired;

	private DropdownChoice revocationPeriod;

	private String numberOfDays;

	private String eapCompleteDate;
	
	/* private List<LicenseDetailResponse> licenseDetailAll;

	 private List<EmployeeIncidentHistory> incidentDetailAll;

  
	 */
	private Date reinstateDate;

	private Integer workItemID;

	private String offcCount;

	private String regFlag;

	private String radioGroup = "No"; 

	private Date lastOnDutyDateTimeDate;

	private String lastOnDutyDateTime;

	private String eventRecorder;

	private String lastOnDutyDateTimeLabel;

	private String emplStatus;

	private String workHistoryLink;

	private String disciplineHistoryLink;

	private String jobHistoryLink;

	public Integer getEventDetailID() {
		return eventDetailID;
	}

	public void setEventDetailID(Integer eventDetailID) {
		this.eventDetailID = eventDetailID;
	}

	public Integer getEvntRvkeDtlsId() {
		return evntRvkeDtlsId;
	}

	public void setEvntRvkeDtlsId(Integer evntRvkeDtlsId) {
		this.evntRvkeDtlsId = evntRvkeDtlsId;
	}

	public String getEmployeeID() {
		return employeeID;
	}

	public void setEmployeeID(String employeeID) {
		this.employeeID = employeeID;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public DropdownChoice getRegion() {
		return region;
	}

	public void setRegion(DropdownChoice region) {
		this.region = region;
	}

	public DropdownChoice getServiceUnit() {
		return serviceUnit;
	}

	public void setServiceUnit(DropdownChoice serviceUnit) {
		this.serviceUnit = serviceUnit;
	}

	public DropdownChoice getTypeOfEvent() {
		return typeOfEvent;
	}

	public void setTypeOfEvent(DropdownChoice typeOfEvent) {
		this.typeOfEvent = typeOfEvent;
	}

	public String getRegulation() {
		return regulation;
	}

	public void setRegulation(String regulation) {
		this.regulation = regulation;
	}

	public String getEventDate() {
		return eventDate;
	}

	public void setEventDate(String eventDate) {
		this.eventDate = eventDate;
	}

	public String getEventDateTime() {
		return eventDateTime;
	}

	public void setEventDateTime(String eventDateTime) {
		this.eventDateTime = eventDateTime;
	}

	public String getOnDutyDateTime() {
		return onDutyDateTime;
	}

	public void setOnDutyDateTime(String onDutyDateTime) {
		this.onDutyDateTime = onDutyDateTime;
	}

	public String getResponsibleManager() {
		return responsibleManager;
	}

	public void setResponsibleManager(String responsibleManager) {
		this.responsibleManager = responsibleManager;
	}

	public String getResponsibleManageId() {
		return responsibleManageId;
	}

	public void setResponsibleManageId(String responsibleManageId) {
		this.responsibleManageId = responsibleManageId;
	}

	public String getResultOfEvent() {
		return resultOfEvent;
	}

	public void setResultOfEvent(String resultOfEvent) {
		this.resultOfEvent = resultOfEvent;
	}

	public Date getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public String getEffectiveDateStr() {
		return effectiveDateStr;
	}

	public void setEffectiveDateStr(String effectiveDateStr) {
		this.effectiveDateStr = effectiveDateStr;
	}

	public String getEapRequired() {
		return eapRequired;
	}

	public void setEapRequired(String eapRequired) {
		this.eapRequired = eapRequired;
	}

	public DropdownChoice getRevocationPeriod() {
		return revocationPeriod;
	}

	public void setRevocationPeriod(DropdownChoice revocationPeriod) {
		this.revocationPeriod = revocationPeriod;
	}

	public String getNumberOfDays() {
		return numberOfDays;
	}

	public void setNumberOfDays(String numberOfDays) {
		this.numberOfDays = numberOfDays;
	}

	public String getEapCompleteDate() {
		return eapCompleteDate;
	}

	public void setEapCompleteDate(String eapCompleteDate) {
		this.eapCompleteDate = eapCompleteDate;
	}

	public Date getReinstateDate() {
		return reinstateDate;
	}

	public void setReinstateDate(Date reinstateDate) {
		this.reinstateDate = reinstateDate;
	}

	public Integer getWorkItemID() {
		return workItemID;
	}

	public void setWorkItemID(Integer workItemID) {
		this.workItemID = workItemID;
	}

	public String getOffcCount() {
		return offcCount;
	}

	public void setOffcCount(String offcCount) {
		this.offcCount = offcCount;
	}

	public String getRegFlag() {
		return regFlag;
	}

	public void setRegFlag(String regFlag) {
		this.regFlag = regFlag;
	}

	public String getRadioGroup() {
		return radioGroup;
	}

	public void setRadioGroup(String radioGroup) {
		this.radioGroup = radioGroup;
	}

	public Date getLastOnDutyDateTimeDate() {
		return lastOnDutyDateTimeDate;
	}

	public void setLastOnDutyDateTimeDate(Date lastOnDutyDateTimeDate) {
		this.lastOnDutyDateTimeDate = lastOnDutyDateTimeDate;
	}

	public String getLastOnDutyDateTime() {
		return lastOnDutyDateTime;
	}

	public void setLastOnDutyDateTime(String lastOnDutyDateTime) {
		this.lastOnDutyDateTime = lastOnDutyDateTime;
	}

	public String getEventRecorder() {
		return eventRecorder;
	}

	public void setEventRecorder(String eventRecorder) {
		this.eventRecorder = eventRecorder;
	}

	public String getLastOnDutyDateTimeLabel() {
		return lastOnDutyDateTimeLabel;
	}

	public void setLastOnDutyDateTimeLabel(String lastOnDutyDateTimeLabel) {
		this.lastOnDutyDateTimeLabel = lastOnDutyDateTimeLabel;
	}

	public String getEmplStatus() {
		return emplStatus;
	}

	public void setEmplStatus(String emplStatus) {
		this.emplStatus = emplStatus;
	}
	
	public String getWorkHistoryLink() {
		return workHistoryLink;
	}

	public void setWorkHistoryLink(String workHistoryLink) {
		this.workHistoryLink = workHistoryLink;
	}

	public String getDisciplineHistoryLink() {
		return disciplineHistoryLink;
	}

	public void setDisciplineHistoryLink(String disciplineHistoryLink) {
		this.disciplineHistoryLink = disciplineHistoryLink;
	}

	public String getJobHistoryLink() {
		return jobHistoryLink;
	}

	public void setJobHistoryLink(String jobHistoryLink) {
		this.jobHistoryLink = jobHistoryLink;
	}
}
