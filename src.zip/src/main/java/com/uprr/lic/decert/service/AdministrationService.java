package com.uprr.lic.decert.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.xmlbeans.XmlException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.xml.sax.SAXException;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.lowagie.text.DocumentException;
import com.uprr.lic.auth.EQMSUserBean;
import com.uprr.lic.auth.EQMSUserSession;
import com.uprr.lic.dataaccess.Licensing.model.QualificationDetail;
import com.uprr.lic.dataaccess.common.model.CmtsEmplBasedMsgs;
import com.uprr.lic.dataaccess.common.model.EqmEmplCmntDtls;
import com.uprr.lic.dataaccess.common.model.EqmSysParm;
import com.uprr.lic.dataaccess.common.model.Rules;
import com.uprr.lic.dataaccess.decertification.model.ApproveRejectRemedialPageDetail;
import com.uprr.lic.dataaccess.decertification.model.DecertifyLicenseRequestDetail;
import com.uprr.lic.dataaccess.decertification.model.EAPDatePopupDetail;
import com.uprr.lic.dataaccess.decertification.model.EmployeeIncidentDetail;
import com.uprr.lic.dataaccess.decertification.model.EmployeeIncidentHistory;
import com.uprr.lic.dataaccess.decertification.model.EmployeeViewIncidentPopupDetail;
import com.uprr.lic.dataaccess.decertification.model.EventDetailDecertifyOpenDetail;
import com.uprr.lic.dataaccess.decertification.model.EventDocumentGridDetail;
import com.uprr.lic.dataaccess.decertification.model.EventEmployeeDetail;
import com.uprr.lic.dataaccess.decertification.model.EventIncidentHistory;
import com.uprr.lic.dataaccess.decertification.model.EventLerbDetail;
import com.uprr.lic.dataaccess.decertification.model.FaxRemedialDetail;
import com.uprr.lic.dataaccess.decertification.model.IncidentHistory;
import com.uprr.lic.dataaccess.decertification.model.LicenseGridDetail;
import com.uprr.lic.dataaccess.decertification.model.MitigateEventDetail;
import com.uprr.lic.dataaccess.decertification.model.SearchEventGridDetail;
import com.uprr.lic.dataaccess.decertification.services.interfaces.IDecertificationService;
import com.uprr.lic.dataaccess.masters.model.ReasonBean;
import com.uprr.lic.dataaccess.masters.service.IReasonService;
import com.uprr.lic.dataaccess.masters.service.ISysParamService;
import com.uprr.lic.decert.rest.model.DecertifyLicenseDetailResponse;
import com.uprr.lic.decert.rest.model.DecertifyLicenseDetailRestRequest;
import com.uprr.lic.decert.rest.model.DropdownChoice;
import com.uprr.lic.decert.rest.model.EAPRequest;
import com.uprr.lic.decert.rest.model.EmployeeDetails;
import com.uprr.lic.decert.rest.model.EmployeeIncidentDetailResponse;
import com.uprr.lic.decert.rest.model.EmployeeOffenceDetails;
import com.uprr.lic.decert.rest.model.EmployeeOffenceDetailsRequest;
import com.uprr.lic.decert.rest.model.EmployeeViewIncidentPopupResponse;
import com.uprr.lic.decert.rest.model.EventDetailsResponse;
import com.uprr.lic.decert.rest.model.EventDocumentDetail;
import com.uprr.lic.decert.rest.model.EventEmployeeResponse;
import com.uprr.lic.decert.rest.model.EventIncidentHistoryResponse;
import com.uprr.lic.decert.rest.model.EventLerbDetailResponse;
import com.uprr.lic.decert.rest.model.FaxRemedialDetailRequest;
import com.uprr.lic.decert.rest.model.IncidentHistoryDeleteCommentDetails;
import com.uprr.lic.decert.rest.model.LicenseDetailResponse;
import com.uprr.lic.decert.rest.model.MitigateEventDetailRequest;
import com.uprr.lic.decert.rest.model.ReceivedDocumentRequest;
import com.uprr.lic.decert.rest.model.RemedialTrainingDetails;
import com.uprr.lic.decert.rest.model.SearchEventResponse;
import com.uprr.lic.decert.rest.model.ValidEmployeeDetailsForEap;
import com.uprr.lic.doss.get.DossGetServiceClientXmfImpl;
import com.uprr.lic.doss.get.domain.DossGetServiceResponse;
import com.uprr.lic.doss.put.DossPutServiceClient;
import com.uprr.lic.doss.put.DossPutServiceClientXmfImpl;
import com.uprr.lic.exception.EqmDaoException;
import com.uprr.lic.externalservice.xmf.service.EmailNotificationService;
import com.uprr.lic.externalservice.xmf.service.QualificationService;
import com.uprr.lic.util.DDChoice;
import com.uprr.lic.util.DateUtil;
import com.uprr.lic.util.DecertificationApplicationConstant;
import com.uprr.netcontrol.frontend.client.xmf.XmfClientInvoker;

@Service("administrationService")
public class AdministrationService implements IAdministrationService {
	
	private static final Logger logger = LoggerFactory.getLogger(AdministrationService.class);

  @Autowired
  private IDecertificationService decertificationService;

  @Autowired
  private IReasonService reasonServiceImpl;

  @Autowired
  EQMSUserSession eqmsUserSession;

  @Autowired
  @Qualifier("dossPutXmfClientInvoker")
  XmfClientInvoker dosPutInvoker;

  @Autowired
  @Qualifier("dossGetXmfClientInvoker")
  XmfClientInvoker dossGetInvoker;

  @Autowired
  private ISysParamService sysParamService;

  @Autowired
  @Qualifier("secureInvokerEqm")
  XmfClientInvoker secureInvokerEqm;

  @Autowired
  private EmailNotificationService emailNotificationService;

  @Override
  public EventDetailsResponse getEventDetails(SearchEventResponse searchEventrequest) {
    return createEventDetailsresponse(
        decertificationService.getEventDetail(createEmployeeDetailsRequest(searchEventrequest)));
  }

  @Override
  public List<EventIncidentHistoryResponse> getEventIncidentHistory(Integer eventDetailId) {
    List<EventIncidentHistory> eventIncidentHistory = decertificationService.getEventIncidentHistory(eventDetailId);
    return createEventHistroryResponse(eventIncidentHistory);
  }

  @Override
  public List<EventEmployeeResponse> getEmployeeDetails(SearchEventResponse eventRequest) {
    SearchEventGridDetail request = createEmployeeDetailsRequest(eventRequest);
    List<EventEmployeeDetail> daoResponse = decertificationService.getEmployeeDetailGrid(request);
    return createEmployeeDetailsResponse(daoResponse);
  }

  @Override
  public List<EventLerbDetailResponse> getEventLerbDetails(Integer eventId, String employeeID) {
    List<EventLerbDetail> eventLerbDetailList = decertificationService.getLerbGridList(eventId, employeeID);
    return createEventLerbDetailsResponse(eventLerbDetailList);
  }

  @Override
  public List<DropdownChoice> getRevocationPeriodList() {
    List<DDChoice> RevocationPeriodList = decertificationService.getRevocationPeriodList();
    return createDropDownChoiceListResponse(RevocationPeriodList);
  }

  @Override
  public List<LicenseDetailResponse> getLicenseDetailList(String employeeID) {
    List<LicenseGridDetail> licenseGridDetailList = decertificationService.getLicenseDetailList(employeeID);
    return createLicenseDetailList(licenseGridDetailList);
  }

  @Override
  public List<DropdownChoice> getDocumentListByType(Integer eventID, Integer eventTypeID, String employeeID) {

    return createDropDownChoiceListResponse(
        decertificationService.getDocumentListByType(eventID, eventTypeID, employeeID));
  }

  public List<EventIncidentHistoryResponse> getIncidentHistoryList(final Integer eventDetailID,
      final String employeeID) {
    final List<EmployeeIncidentHistory> incidentList = decertificationService.getIncidentHistoryList(eventDetailID,
        employeeID);
    return createEmployeeHistroryResponse(incidentList);
  }

  @Override
  public String updateReceivedDocument(ReceivedDocumentRequest receivedDocumentRequest) {
    EQMSUserBean eqmsUserBean = eqmsUserSession.getUser();
    DDChoice ddChoice = createDDChoiceRequest(receivedDocumentRequest.getDocumentType());
    String receivedDocumentMessage = decertificationService.setReceivedDocument(receivedDocumentRequest.getEmployeeID(),
        receivedDocumentRequest.getEvntDtlId(), ddChoice, eqmsUserBean.getEmplId(),
        receivedDocumentRequest.getAssignedManager(), receivedDocumentRequest.getReasonId(),
        receivedDocumentRequest.getServiceUnitNbr());
    return receivedDocumentMessage;
  }

  private EventDetailsResponse createEventDetailsresponse(
      EventDetailDecertifyOpenDetail objEventDetailDecertifyOpenDetail) {
    EventDetailsResponse objResponse = new EventDetailsResponse();
    objResponse.setTypeOfEvent(objEventDetailDecertifyOpenDetail.getTypeOfEvent());
    objResponse.setRegulation(objEventDetailDecertifyOpenDetail.getRegulation());
    objResponse.setOccurredOn(objEventDetailDecertifyOpenDetail.getOccurredOn());
    objResponse.setRespMngr(objEventDetailDecertifyOpenDetail.getRespMngr());
    objResponse.setResultOfEventAll(objEventDetailDecertifyOpenDetail.getResultOfEventAll());
    objResponse.setResultOfEvent(objEventDetailDecertifyOpenDetail.getResultOfEvent());
    objResponse.setMngrDescOfIncd(objEventDetailDecertifyOpenDetail.getMngrDescOfIncd());
    objResponse.setMngrComments(objEventDetailDecertifyOpenDetail.getMngrComments());
    objResponse.setTrainDetail(objEventDetailDecertifyOpenDetail.getTrainDetail());
    objResponse.setLocationDetail(objEventDetailDecertifyOpenDetail.getLocationDetail());
    objResponse.setOtherDetail(objEventDetailDecertifyOpenDetail.getOtherDetail());
    objResponse.setEventDocumentGridBean(objEventDetailDecertifyOpenDetail.getEventDocumentGridBean());
    objResponse.setEventEmployeeAll(objEventDetailDecertifyOpenDetail.getEventEmployeeAll());
    objResponse.setEventTime(objEventDetailDecertifyOpenDetail.getEventTime());
    objResponse.setReasonID(objEventDetailDecertifyOpenDetail.getReasonID());
    objResponse.setDocketNumber(objEventDetailDecertifyOpenDetail.getDocketNumber());
    objResponse.setResponseType(objEventDetailDecertifyOpenDetail.getResponseType());
    objResponse.setEvntSrc(objEventDetailDecertifyOpenDetail.getEvntSrc());
    objResponse.setEvntDescrptn(objEventDetailDecertifyOpenDetail.getEvntDescrptn());
    objResponse.setReasonID(objEventDetailDecertifyOpenDetail.getReasonID());
    return objResponse;
  }

  private List<EventEmployeeResponse> createEmployeeDetailsResponse(List<EventEmployeeDetail> daoResponseList) {
    List<EventEmployeeResponse> eventEmployeeResponseList = new ArrayList<>();

    for (EventEmployeeDetail objEventEmployeeResponse : daoResponseList) {
      EventEmployeeResponse objResponse = new EventEmployeeResponse();
      objResponse.setEmplEvntDtlsId(objEventEmployeeResponse.getEmplEvntDtlsId());
      objResponse.setEmployeeID(objEventEmployeeResponse.getEmployeeID());
      objResponse.setEmployeeName(objEventEmployeeResponse.getEmployeeName());
      objResponse.setPosition(createDropDownChoiceResponse(objEventEmployeeResponse.getPosition()));
      objResponse.setDateOnDuty(objEventEmployeeResponse.getDateOnDuty());
      objResponse.setTimeOnDuty(objEventEmployeeResponse.getTimeOnDuty());
      objResponse.setHrsOnDuty(objEventEmployeeResponse.getHrsOnDuty());
      objResponse.setPreviosRest(objEventEmployeeResponse.getPreviosRest());
      objResponse.setDirection(objEventEmployeeResponse.getDirection());
      objResponse.setLastJobBref(objEventEmployeeResponse.getLastJobBref());
      objResponse.setSuspended(objEventEmployeeResponse.getSuspended());
      objResponse.setEmplStatFlag(objEventEmployeeResponse.getEmplStatFlag());
      objResponse.setStatusDate(objEventEmployeeResponse.getStatusDate());
      objResponse.setAssignedManager(objEventEmployeeResponse.getAssignedManager());
      objResponse.setStatus(objEventEmployeeResponse.getStatus());
      objResponse.setCallCirc7(objEventEmployeeResponse.getCallCirc7());
      objResponse.setCallCirc7WithDateOnDutyTime(objEventEmployeeResponse.getCallCirc7WithDateOnDutyTime());
      objResponse.setValidEmployee(objEventEmployeeResponse.isValidEmployee());
      objResponse.setActualPosSeq(objEventEmployeeResponse.getActualPosSeq());
      objResponse.setCnvtJobTypePosSeq(objEventEmployeeResponse.getCnvtJobTypePosSeq());
      objResponse.setJobType(objEventEmployeeResponse.getJobType());
      objResponse.setIncidentHistory(objEventEmployeeResponse.getIncidentHistory());
      objResponse.setAssignedManagersvcunit(objEventEmployeeResponse.getAssignedManagersvcunit());
      objResponse.setNameIdDisplay(objEventEmployeeResponse.getNameIdDisplay());
      objResponse.setEmployeePosition(objEventEmployeeResponse.getEmployeePosition());
      objResponse.setOnDutyDate(objEventEmployeeResponse.getOnDutyDate());
      objResponse.setRegulation(objEventEmployeeResponse.getRegulation());
      objResponse.setStrPosition(objEventEmployeeResponse.getStrPosition());
      objResponse.setStrRegulation(objEventEmployeeResponse.getStrRegulation());
      objResponse.setFirstDAndAEvent(objEventEmployeeResponse.getFirstDAndAEvent());
      objResponse.setActualPosOnTrain(objEventEmployeeResponse.getActualPosOnTrain());
      objResponse.setPrevValueFirstAlcoAEvent(objEventEmployeeResponse.getPrevValueFirstAlcoAEvent());
      objResponse.setMonthYears(objEventEmployeeResponse.getMonthYears());
      objResponse.setEmplCirc7(objEventEmployeeResponse.getEmplCirc7());
      objResponse.setEmplBoardName(objEventEmployeeResponse.getEmplBoardName());
      objResponse.setRuleNbr(objEventEmployeeResponse.getRuleNbr());
      objResponse.setPrimaryRules(objEventEmployeeResponse.getPrimaryRules());
      objResponse.setReceivedDocType(objEventEmployeeResponse.getReceivedDocType());
      objResponse.setPrevValueFirstDAndAEvent(objEventEmployeeResponse.getPrevValueFirstDAndAEvent());
      objResponse.setFirstAlcoholEvent(objEventEmployeeResponse.getFirstAlcoholEvent());
      objResponse.setOldRegulation(objEventEmployeeResponse.getOldRegulation());

      eventEmployeeResponseList.add(objResponse);
    }
    return eventEmployeeResponseList;
  }

  private DropdownChoice createDropDownChoiceResponse(DDChoice position) {
    DropdownChoice dropdownChoice = new DropdownChoice();
    if (position != null) {
      dropdownChoice.setIntKey(position.getIntKey());
      dropdownChoice.setStrKey(position.getStrKey());
      dropdownChoice.setValue(position.getValue());
    }
    return dropdownChoice;
  }

  private DDChoice createDDChoiceResponse(DropdownChoice dropdownChoice) {
    DDChoice ddChoice = new DDChoice();
    if (dropdownChoice != null) {
      ddChoice.setIntKey(dropdownChoice.getIntKey());
      ddChoice.setStrKey(dropdownChoice.getStrKey());
      ddChoice.setValue(dropdownChoice.getValue());
    }
    return ddChoice;
  }

  private SearchEventGridDetail createEmployeeDetailsRequest(SearchEventResponse objSearchEventResponse) {
    SearchEventGridDetail objRequest = new SearchEventGridDetail();
    objRequest.setServiceUnit(objSearchEventResponse.getServiceUnit());
    objRequest.setServiceUnitNbr(objSearchEventResponse.getServiceUnitNbr());
    objRequest.setEventDate(objSearchEventResponse.getEventDate());
    objRequest.setTypeOfEventAndRegulation(objSearchEventResponse.getTypeOfEventAndRegulation());
    objRequest.setEventStatus(objSearchEventResponse.getEventStatus());
    objRequest.setResponsibleManager(objSearchEventResponse.getResponsibleManager());
    objRequest.setResponsibleManagerID(objSearchEventResponse.getResponsibleManagerID());
    objRequest.setEmployeeID(objSearchEventResponse.getEmployeeID());
    objRequest.setEmployeePositionAndName(objSearchEventResponse.getEmployeePositionAndName());
    objRequest.setEmployeeStatus(objSearchEventResponse.getEmployeeStatus());
    objRequest.setDate(objSearchEventResponse.getDate());
    objRequest.setEventDetailID(objSearchEventResponse.getEventDetailID());
    objRequest.setEventTypeID(objSearchEventResponse.getEventTypeID());
    objRequest.setCreationEmployeeID(objSearchEventResponse.getCreationEmployeeID());
    objRequest.setEmployeeDetailsGroup(objSearchEventResponse.getEmployeeDetailsGroup());
    objRequest.setResponsibleManagerSvcUnit(objSearchEventResponse.getResponsibleManagerSvcUnit());
    objRequest.setEvntSrc(objSearchEventResponse.getEvntSrc());
    objRequest.setRegulation(objSearchEventResponse.getRegulation());

    return objRequest;
  }

  private List<EventIncidentHistoryResponse> createEventHistroryResponse(
      List<EventIncidentHistory> eventIncidentHistoryList) {
    List<EventIncidentHistoryResponse> eventIncidentHistoryResponses = new ArrayList<>();
    for (IncidentHistory objIncidentHistory : eventIncidentHistoryList) {
      EventIncidentHistoryResponse objResponse = new EventIncidentHistoryResponse();
      objResponse.setAction(objIncidentHistory.getAction());
      objResponse.setDate(objIncidentHistory.getDate());
      objResponse.setActionTakenBy(objIncidentHistory.getActionTakenBy());
      objResponse.setComments(objIncidentHistory.getComments());
      objResponse.setEvntDtlId(objIncidentHistory.getEvntDtlId());
      objResponse.setReasonId(objIncidentHistory.getReasonId());
      objResponse.setEmployeeId(objIncidentHistory.getEmployeeId());
      objResponse.setEmplCmntDtlsId(objIncidentHistory.getEmplCmntDtlsId());

      eventIncidentHistoryResponses.add(objResponse);
    }
    return eventIncidentHistoryResponses;
  }

  private List<EventIncidentHistoryResponse> createEmployeeHistroryResponse(
      List<EmployeeIncidentHistory> eventIncidentHistoryList) {
    List<EventIncidentHistoryResponse> eventIncidentHistoryResponses = new ArrayList<>();
    for (IncidentHistory objIncidentHistory : eventIncidentHistoryList) {
      EventIncidentHistoryResponse objResponse = new EventIncidentHistoryResponse();
      objResponse.setAction(objIncidentHistory.getAction());
      objResponse.setDate(objIncidentHistory.getDate());
      objResponse.setActionTakenBy(objIncidentHistory.getActionTakenBy());
      objResponse.setComments(objIncidentHistory.getComments());
      objResponse.setEvntDtlId(objIncidentHistory.getEvntDtlId());
      objResponse.setReasonId(objIncidentHistory.getReasonId());
      objResponse.setEmployeeId(objIncidentHistory.getEmployeeId());
      objResponse.setEmplCmntDtlsId(objIncidentHistory.getEmplCmntDtlsId());
      objResponse.setRemedialTrainingApproved(checkRemedialTrainingInitiatedOrApproved(
          objIncidentHistory.getEmployeeId(), objIncidentHistory.getEvntDtlId(), null));
      eventIncidentHistoryResponses.add(objResponse);
    }
    return eventIncidentHistoryResponses;
  }

  private List<EventLerbDetailResponse> createEventLerbDetailsResponse(List<EventLerbDetail> eventLerbDetailList) {
    List<EventLerbDetailResponse> eventLerbDetailResponses = new ArrayList<>();
    for (EventLerbDetail objEventLerbDetail : eventLerbDetailList) {
      EventLerbDetailResponse objResponse = new EventLerbDetailResponse();
      objResponse.setLerbDtlId(objEventLerbDetail.getLerbDtlId());
      objResponse.setEmployeeDropDown(objEventLerbDetail.getEmployeeDropDown());
      objResponse.setLerbAction(createDropDownChoiceResponse(objEventLerbDetail.getLerbAction()));
      objResponse.setDocketNumber(objEventLerbDetail.getDocketNumber());
      objResponse.setResponseType(objEventLerbDetail.getResponseType());
      objResponse.setDateReceived(objEventLerbDetail.getDateReceived());
      objResponse.setDueDate(objEventLerbDetail.getDueDate());
      objResponse.setLerbAssignedTo(objEventLerbDetail.getLerbAssignedTo());
      objResponse.setLerbComments(objEventLerbDetail.getLerbComments());
      objResponse.setEmployeeId(objEventLerbDetail.getEmployeeId());
      objResponse.setNameIdDisplay(objEventLerbDetail.getNameIdDisplay());
      objResponse.setDocumentList(createEventDocumentDetail(objEventLerbDetail.getDocumentList()));
      objResponse.setHideAtmtFlag(objEventLerbDetail.isHideAtmtFlag());
      eventLerbDetailResponses.add(objResponse);
    }
    return eventLerbDetailResponses;
  }

  private List<EventDocumentDetail> createEventDocumentDetail(
      List<EventDocumentGridDetail> eventDocumentGridDetailList) {
    List<EventDocumentDetail> eventDocumentDetailResponses = new ArrayList<>();

    if (eventDocumentGridDetailList != null) {
      for (EventDocumentGridDetail objEventDocumentGridDetail : eventDocumentGridDetailList) {
        EventDocumentDetail objEventDocumentDetail = new EventDocumentDetail();
        objEventDocumentDetail.setFileName(objEventDocumentGridDetail.getFileName());
        objEventDocumentDetail.setDocID(objEventDocumentGridDetail.getDocID());
        objEventDocumentDetail.setDocKey(objEventDocumentGridDetail.getDocKey());
        objEventDocumentDetail.setMimeType(objEventDocumentGridDetail.getMimeType());
        objEventDocumentDetail.setLerbUpload(objEventDocumentGridDetail.getLerbUpload());
        objEventDocumentDetail.setDatFileByteArray(objEventDocumentGridDetail.getDatFileByteArray());
        eventDocumentDetailResponses.add(objEventDocumentDetail);
      }
    }
    return eventDocumentDetailResponses;
  }

  private DDChoice createDDChoiceRequest(DropdownChoice dropdownChoice) {
    DDChoice ddChoice = new DDChoice();
    ddChoice.setIntKey(dropdownChoice.getIntKey());
    ddChoice.setStrKey(dropdownChoice.getStrKey());
    ddChoice.setValue(dropdownChoice.getValue());
    return ddChoice;
  }

  private List<LicenseDetailResponse> createLicenseDetailList(List<LicenseGridDetail> licenseGridDetailList) {
    List<LicenseDetailResponse> eventLicenseDetailList = new ArrayList<>();
    for (LicenseGridDetail objLicenseGridDetail : licenseGridDetailList) {
      LicenseDetailResponse objLicenseDetailResponse = new LicenseDetailResponse();
      objLicenseDetailResponse.setLicenseIssueDate(objLicenseGridDetail.getLicenseIssueDate());
      objLicenseDetailResponse.setLicenseExpirationDate(objLicenseGridDetail.getLicenseExpirationDate());
      objLicenseDetailResponse.setLastSkillRide(objLicenseGridDetail.getLastSkillRide());
      objLicenseDetailResponse.setSkillRideConductedBy(objLicenseGridDetail.getSkillRideConductedBy());
      objLicenseDetailResponse.setLicenseClassCode(objLicenseGridDetail.getLicenseClassCode());
      objLicenseDetailResponse.setCertFlag(objLicenseGridDetail.getCertFlag());
      objLicenseDetailResponse.setLicenseDtlID(objLicenseGridDetail.getLicenseDtlID());
      objLicenseDetailResponse.setCrtnDate(objLicenseGridDetail.getCrtnDate());
      objLicenseDetailResponse.setLicenseStartDate(objLicenseGridDetail.getLicenseStartDate());
      objLicenseDetailResponse.setJobType(objLicenseGridDetail.getJobType());
      objLicenseDetailResponse.setAssignedManager(objLicenseGridDetail.getAssignedManager());
      eventLicenseDetailList.add(objLicenseDetailResponse);
    }
    return eventLicenseDetailList;
  }

  /**
   * Convert List of dropDownchoice List for ALL API
   * 
   * @param dropDownChoiceList
   * @return
   */
  private List<DropdownChoice> createDropDownChoiceListResponse(List<DDChoice> dropDownChoiceList) {
    List<DropdownChoice> dropdownChoiceResponseList = new ArrayList<>();
    if (dropDownChoiceList != null) {
      for (DDChoice objDropdownChoice : dropDownChoiceList) {
        DropdownChoice dropdownChoiceResponse = new DropdownChoice();
        dropdownChoiceResponse.setIntKey(objDropdownChoice.getIntKey());
        dropdownChoiceResponse.setStrKey(objDropdownChoice.getStrKey());
        dropdownChoiceResponse.setValue(objDropdownChoice.getValue());
        dropdownChoiceResponseList.add(dropdownChoiceResponse);
      }
    }
    return dropdownChoiceResponseList;
  }

  @Override
  public DecertifyLicenseDetailResponse getDecertifyLicenseDetails(
      DecertifyLicenseDetailRestRequest decertifyLicenseDetailRestRequest) throws Exception {

    DecertifyLicenseRequestDetail decertifyLicenseRequestDetail = createDecertifyLicenseResponse(
        decertifyLicenseDetailRestRequest);
    try {
      decertifyLicenseRequestDetail = decertificationService.getDecertifyLicenseDetails(decertifyLicenseRequestDetail,
          false);

      decertifyLicenseRequestDetail = decertificationService.getRevocationDetails(decertifyLicenseRequestDetail);
      // Hard coded value for Last On Duty Date\Time label - REQ#597 Part 2.
      decertifyLicenseRequestDetail.setLastOnDutyDateTimeLabel(
          DecertificationApplicationConstant.DECERTIFY_LICENSE_REQUEST_LABEL_LAST_ON_DUTY_DATE_TIME);
      /* Code for Conductor Licensing(without LERB) */
      // Setting the Revocation period as system generated and
      if ((null != decertifyLicenseRequestDetail.getRevocationPeriod()
          && !DecertificationApplicationConstant.EVENT_TYPE_OTHER
              .equalsIgnoreCase(decertifyLicenseRequestDetail.getRevocationPeriod().getStrKey()))
          || (null != decertifyLicenseRequestDetail.getRevocationPeriod()
              && DecertificationApplicationConstant.EVENT_TYPE_OTHER
                  .equalsIgnoreCase(decertifyLicenseRequestDetail.getRevocationPeriod().getStrKey())
              && null != decertifyLicenseRequestDetail.getNumberOfDays())) {
        DDChoice choice = new DDChoice();
        choice.setStrKey(decertifyLicenseRequestDetail.getRevocationPeriod().getStrKey());
        choice.setValue(decertifyLicenseRequestDetail.getRevocationPeriod().getValue());
        decertifyLicenseRequestDetail.setRevocationPeriod(choice);

        /* Code ends for Conductor Licensing Changes(without LERB) */
      } else {
        DDChoice choice = new DDChoice();
        decertifyLicenseRequestDetail.setRevocationPeriod(choice);
      }

    } catch (EqmDaoException e) {
      // throw new EqmDaoException(e.getMessage());
    	logger.info(e.getMessage());//Added this code as we need not to through exception.
    } catch (final Exception e) {
       //throw new Exception(e.getMessage());
    	logger.info(e.getMessage());//Added this code as we need not to through exception.
    }
    return createDecertifyLicenseResponse(decertifyLicenseRequestDetail);
  }

  private DecertifyLicenseDetailResponse createDecertifyLicenseResponse(
      DecertifyLicenseRequestDetail objDecertifyLicenseRequestDetailResponse) {

    DecertifyLicenseDetailResponse objResponse = new DecertifyLicenseDetailResponse();
    objResponse.setEventDetailID(objDecertifyLicenseRequestDetailResponse.getEventDetailID());
    objResponse.setEvntRvkeDtlsId(objDecertifyLicenseRequestDetailResponse.getEvntRvkeDtlsId());
    objResponse.setEmployeeID(objDecertifyLicenseRequestDetailResponse.getEmployeeID());
    objResponse.setEmployeeName(objDecertifyLicenseRequestDetailResponse.getEmployeeName());
    objResponse.setRegulation(objDecertifyLicenseRequestDetailResponse.getRegulation());
    objResponse.setEventDate(objDecertifyLicenseRequestDetailResponse.getEventDate());
    objResponse.setEventDateTime(objDecertifyLicenseRequestDetailResponse.getEventDateTime());
    objResponse.setOnDutyDateTime(objDecertifyLicenseRequestDetailResponse.getOnDutyDateTime());
    objResponse.setResponsibleManager(objDecertifyLicenseRequestDetailResponse.getResponsibleManager());
    objResponse.setResponsibleManageId(objDecertifyLicenseRequestDetailResponse.getResponsibleManageId());
    objResponse.setResultOfEvent(objDecertifyLicenseRequestDetailResponse.getResultOfEvent());

    objResponse.setEffectiveDate(objDecertifyLicenseRequestDetailResponse.getEffectiveDate());
    objResponse.setEffectiveDateStr(objDecertifyLicenseRequestDetailResponse.getEffectiveDateStr());
    objResponse.setEapRequired(objDecertifyLicenseRequestDetailResponse.isEapRequired());
    objResponse.setRevocationPeriod(
        createDropDownChoiceResponse(objDecertifyLicenseRequestDetailResponse.getRevocationPeriod()));
    objResponse.setNumberOfDays(objDecertifyLicenseRequestDetailResponse.getNumberOfDays());
    objResponse.setEapCompleteDate(objDecertifyLicenseRequestDetailResponse.getEapCompleteDate());
    objResponse.setReinstateDate(objDecertifyLicenseRequestDetailResponse.getReinstateDate());
    objResponse.setWorkItemID(objDecertifyLicenseRequestDetailResponse.getWorkItemID());
    objResponse.setOffcCount(objDecertifyLicenseRequestDetailResponse.getOffcCount());
    objResponse.setRegFlag(objDecertifyLicenseRequestDetailResponse.getRegFlag());
    objResponse.setRadioGroup(objDecertifyLicenseRequestDetailResponse.getRadioGroup());
    objResponse.setLastOnDutyDateTimeDate(objDecertifyLicenseRequestDetailResponse.getLastOnDutyDateTimeDate());
    objResponse.setLastOnDutyDateTime(objDecertifyLicenseRequestDetailResponse.getLastOnDutyDateTime());
    objResponse.setEventRecorder(objDecertifyLicenseRequestDetailResponse.getEventRecorder());
    objResponse.setLastOnDutyDateTimeLabel(objDecertifyLicenseRequestDetailResponse.getLastOnDutyDateTimeLabel());
    objResponse.setEmplStatus(objDecertifyLicenseRequestDetailResponse.getEmplStatus());
    objResponse.setRegion(createDropDownChoiceResponse(objDecertifyLicenseRequestDetailResponse.getRegion()));
    objResponse.setTypeOfEvent(createDropDownChoiceResponse(objDecertifyLicenseRequestDetailResponse.getTypeOfEvent()));
    objResponse.setServiceUnit(createDropDownChoiceResponse(objDecertifyLicenseRequestDetailResponse.getServiceUnit()));
    objResponse.setDisciplineHistoryLink(objDecertifyLicenseRequestDetailResponse.getDisciplineHistoryLink());
    objResponse.setJobHistoryLink(objDecertifyLicenseRequestDetailResponse.getJobHistoryLink());
    objResponse.setWorkHistoryLink(objDecertifyLicenseRequestDetailResponse.getWorkHistoryLink());
    return objResponse;
  }

  private DecertifyLicenseRequestDetail createDecertifyLicenseResponse(
      DecertifyLicenseDetailRestRequest objDecertifyLicenseDetailRequest) {
    DecertifyLicenseRequestDetail objResponse = new DecertifyLicenseRequestDetail();
    objResponse.setEventDetailID(objDecertifyLicenseDetailRequest.getEventDetailID());
    objResponse.setEmployeeID(objDecertifyLicenseDetailRequest.getEmployeeID());
    objResponse.setEmployeeName(objDecertifyLicenseDetailRequest.getEmployeeName());
    objResponse.setWorkItemID(objDecertifyLicenseDetailRequest.getWorkItemID());
    objResponse.setRevocationPeriod(createDDChoiceResponse(objDecertifyLicenseDetailRequest.getRevocationPeriod()));
    objResponse.setEapRequired(objDecertifyLicenseDetailRequest.getEapRequired());
    objResponse.setEffectiveDate(DateUtil.getDateFromString(objDecertifyLicenseDetailRequest.getEffDate()));
    objResponse.setNumberOfDays(objDecertifyLicenseDetailRequest.getNoOfDays());
    objResponse.setEvntRvkeDtlsId(objDecertifyLicenseDetailRequest.getEvntRvkeDtlsId());
    objResponse.setRegion(createDDChoiceResponse(objDecertifyLicenseDetailRequest.getRegion()));
    objResponse.setServiceUnit(createDDChoiceResponse(objDecertifyLicenseDetailRequest.getServiceUnit()));
    objResponse.setTypeOfEvent(createDDChoiceResponse(objDecertifyLicenseDetailRequest.getTypeOfEvent()));
    objResponse.setRegulation(objDecertifyLicenseDetailRequest.getRegulation());
    objResponse.setEventDate(objDecertifyLicenseDetailRequest.getEventDate());
    objResponse.setEventDateTime(objDecertifyLicenseDetailRequest.getEventDateTime());
    objResponse.setOnDutyDateTime(objDecertifyLicenseDetailRequest.getOnDutyDateTime());
    objResponse.setResponsibleManager(objDecertifyLicenseDetailRequest.getResponsibleManager());
    objResponse.setResponsibleManageId(objDecertifyLicenseDetailRequest.getResponsibleManageId());
    objResponse.setResultOfEvent(objDecertifyLicenseDetailRequest.getResultOfEvent());
    objResponse.setEffectiveDateStr(objDecertifyLicenseDetailRequest.getEffectiveDateStr());
    objResponse.setEapCompleteDate(objDecertifyLicenseDetailRequest.getEapCompleteDate());
    /* objResponse.setIncidentDetailAll( objDecertifyLicenseDetailRequest.getIncidentDetailAll( ) ) ; */
    objResponse.setLicenseDetailAll(objDecertifyLicenseDetailRequest.getLicenseDetailAll());
    objResponse.setReinstateDate(objDecertifyLicenseDetailRequest.getReinstateDate());
    objResponse.setOffcCount(objDecertifyLicenseDetailRequest.getOffcCount());
    objResponse.setRegFlag(objDecertifyLicenseDetailRequest.getRegFlag());
    objResponse.setRadioGroup(objDecertifyLicenseDetailRequest.getRadioGroup());
    objResponse.setLastOnDutyDateTimeDate(objDecertifyLicenseDetailRequest.getLastOnDutyDateTimeDate());
    objResponse.setLastOnDutyDateTime(objDecertifyLicenseDetailRequest.getLastOnDutyDateTime());
    objResponse.setEventRecorder(objDecertifyLicenseDetailRequest.getEventRecorder());
    objResponse.setLastOnDutyDateTimeLabel(objDecertifyLicenseDetailRequest.getLastOnDutyDateTimeLabel());
    objResponse.setEmplStatus(objDecertifyLicenseDetailRequest.getEmplStatus());
    objResponse.setDisciplineHistoryLink(objDecertifyLicenseDetailRequest.getDisciplineHistoryLink());
    objResponse.setDisciplineHistoryLink(objDecertifyLicenseDetailRequest.getJobHistoryLink());
    objResponse.setDisciplineHistoryLink(objDecertifyLicenseDetailRequest.getWorkHistoryLink());
    return objResponse;
  }

  @Override
  public boolean decertifyEmployee(DecertifyLicenseDetailRestRequest details) throws Exception {
    EQMSUserBean eqmsUserBean = eqmsUserSession.getUser();
    return decertificationService.decertifyEmployee(createDecertifyLicenseResponse(details), eqmsUserBean.getEmplId(),
        details.isLerbAction(), reasonServiceImpl.getAllReason());
  }

  /**
   * UpdateCommentsForEmployee
   * 
   * @param eventID
   * @param eventTypeID
   * @param employeeID
   * @return
   */
  @Override
  public boolean updateEmployeeComment(@RequestBody EmployeeDetails employeeDetails) {

    EQMSUserBean eqmsUserBean = eqmsUserSession.getUser();

    boolean additionalCommentStatus = false;

    if (employeeDetails.getEmployeeHistoryData() != null) {
      EventIncidentHistoryResponse incidentHistory = employeeDetails.getEmployeeHistoryData();
      additionalCommentStatus = decertificationService.addAdditionalCommentsForEmployee(incidentHistory.getEvntDtlId(),
          incidentHistory.getReasonId(), incidentHistory.getEmployeeId(), employeeDetails.getComments(),
          eqmsUserBean.getEmplId(), incidentHistory.getEmplCmntDtlsId());
    } else {
      additionalCommentStatus = decertificationService.addAdditionalCommentsForEmployee(
          employeeDetails.getEventDetailId(), employeeDetails.getResnId(), employeeDetails.getEmployeeId(),
          employeeDetails.getComments(), eqmsUserBean.getEmplId(), employeeDetails.getEmplCmntDtlId());
    }

    return additionalCommentStatus;
  }

  @Override
  public boolean updateRemedialTrainingDetails(FaxRemedialDetailRequest faxRemediaDetailRequest,
      Integer serviceUnitNumber) {
    EQMSUserBean eqmsUserBean = eqmsUserSession.getUser();
    boolean remedialStatus = decertificationService.setRemedialTrainingDetails(
        createFaxRemedialDetail(faxRemediaDetailRequest), serviceUnitNumber, eqmsUserBean.getEmplId());
    return remedialStatus;
  }

  private FaxRemedialDetail createFaxRemedialDetail(FaxRemedialDetailRequest objFaxRemedialDetail) {
    FaxRemedialDetail faxRemedialDetail = new FaxRemedialDetail();
    faxRemedialDetail.setEmployeeID(objFaxRemedialDetail.getEmployeeID());
    faxRemedialDetail.setEmployeeName(objFaxRemedialDetail.getEmployeeName());
    Date remedialDate = DateUtil.getDateInstanceFromStringDate(objFaxRemedialDetail.getRemedialDate());
    faxRemedialDetail.setRemedialDate(remedialDate);
    faxRemedialDetail.setRemedialReceive(objFaxRemedialDetail.getRemedialReceive());
    faxRemedialDetail.setRemedialEffect(objFaxRemedialDetail.getRemedialEffect());
    faxRemedialDetail.setEventDetailID(objFaxRemedialDetail.getEventDetailID());
    faxRemedialDetail.setDcrtEmplStatID(objFaxRemedialDetail.getDcrtEmplStatID());
    faxRemedialDetail.setRespMgrId(objFaxRemedialDetail.getRespMgrId());
    return faxRemedialDetail;
  }

  @Override
  public String getReinstateDate(boolean decline, EmployeeDetails employeeDetails) {

    final String employeeId = employeeDetails.getEmployeeId();
    Integer eventDetailID = employeeDetails.getEventDetailId();
    Integer workItemIdReinstate = employeeDetails.getWorkItemId();
    Integer serviceUnitNbr = employeeDetails.getServiceUnitNbr();

    String defaultDate = decertificationService.getDefaultReinstateDate(decline, employeeId, eventDetailID,
        workItemIdReinstate, serviceUnitNbr);

    return defaultDate;
  }

  @Override
  public boolean declineReinstateEmployee(EmployeeDetails employeeDetails) {

    final String employeeId = employeeDetails.getEmployeeId();
    final Integer eventDetailID = employeeDetails.getEventDetailId();
    final Integer workItemIdReinstate = employeeDetails.getWorkItemId();
    final Date reinstateWorkItemDate = DateUtil
        .getDateInstanceFromStringDate(employeeDetails.getReinstateWorkItemDate());
    EQMSUserBean eqmsUserBean = eqmsUserSession.getUser();
    boolean flag = decertificationService.declineReinstateEmployee(eventDetailID, employeeId, workItemIdReinstate,
        reinstateWorkItemDate, eqmsUserBean.getEmplId());
    return flag;
  }

  @Override
  public Map<String, Boolean> reinstateEmployee(EmployeeDetails employeeDetails) {

    final String reinstateEmployeeStatus = "reinstateEmployeeStatus";
    final String employeeAlreadyReinstated = "isEmployeeAlreadyReinstated";

    final String employeeId = employeeDetails.getEmployeeId();
    final Integer eventDetailID = employeeDetails.getEventDetailId();
    final Integer workItemIdReinstate = employeeDetails.getWorkItemId();
    final Date reinstateWorkItemDate = DateUtil
        .getDateInstanceFromStringDate(employeeDetails.getReinstateWorkItemDate());
    EQMSUserBean eqmsUserBean = eqmsUserSession.getUser();
    Map<String, Boolean> response = new HashMap<String, Boolean>();

    Calendar reinstateCalender = Calendar.getInstance();
    reinstateCalender.setTime(reinstateWorkItemDate);

    Map<Integer, ReasonBean> reason = reasonServiceImpl.getAllReason();

    boolean flag = decertificationService.reinstateEmployee(eventDetailID, employeeId, workItemIdReinstate,
        employeeDetails.getServiceUnitNbr(), eqmsUserBean.getEmplId(), reinstateCalender, reason);
    response.put(reinstateEmployeeStatus, flag);

    boolean isEmployeeAlreadyReinstated = decertificationService.isEmployeeAlreadyReinstated(employeeId, eventDetailID);
    response.put(employeeAlreadyReinstated, isEmployeeAlreadyReinstated);

    return response;
  }

  @Override
  public boolean mitigateEmployee(MultipartHttpServletRequest request) {

    try {

      MitigateEventDetailRequest eventDetailRequest = new ObjectMapper()
          .readValue(request.getParameter("eventDetailRequest"), MitigateEventDetailRequest.class);
      Map<String, List<MultipartFile>> fileMap = request.getMultiFileMap();

      List<MultipartFile> documents = new ArrayList<>();
      if (null != fileMap && fileMap.size() > 0) {
        for (Map.Entry<String, List<MultipartFile>> entry : fileMap.entrySet()) {
          for (MultipartFile multipartFile : entry.getValue()) {
            documents.add(multipartFile);
          }
        }
      }

      EQMSUserBean eqmsUserBean = eqmsUserSession.getUser();
      DossPutServiceClient dossPutClient = new DossPutServiceClientXmfImpl(dosPutInvoker);
      return decertificationService.mitigateEmployee(eventDetailRequest.getEmployeeId(),
          eventDetailRequest.getComment(), eventDetailRequest.getEventDetailId(), eqmsUserBean.getEmplId(),
          reasonServiceImpl.getAllReason(), eventDetailRequest.getTypeOfEventAndRegulation(),
          eventDetailRequest.isUnsuspendEmpl(), dossPutClient, documents);

    } catch (Exception e) {
      e.printStackTrace();
    }
    return false;
  }

  @Override
  public Integer isDecertifyWorkItemPresent(Integer evntDtlId, String employeeID) {
    Integer response = decertificationService.isDecertifyWorkItemPresent(evntDtlId, employeeID);
    return response;
  }

  @Override
  public String verifyMapsEntry(@RequestBody EmployeeDetails employeeDetails) throws EqmDaoException {

    Integer workItemIdVerifyDiciplineEntry = null;
    EQMSUserBean eqmsUserBean = eqmsUserSession.getUser();
    Set<Integer> roleSet = eqmsUserBean.getRoleSet();

    workItemIdVerifyDiciplineEntry = decertificationService
        .isVerifyDisciplineWorkItemPresent(employeeDetails.getEventDetailId(), employeeDetails.getEmployeeId());

    EqmEmplCmntDtls eqmEmplCmntDtls = decertificationService.getEmplCmntDtls(employeeDetails.getEventDetailId(),
        employeeDetails.getEmployeeId());

    if (null != eqmEmplCmntDtls) {
      return "MAPS Entry was already verified by " + eqmEmplCmntDtls.getCrtnEmplId() + " on "
          + eqmEmplCmntDtls.getCrtnDate().getTime();
    }

    if (workItemIdVerifyDiciplineEntry == null) {
      return "MAPS Entry cannot be Verified";
    }

    boolean verifyDisciplineEntry = decertificationService.verifyDisciplineEntry(employeeDetails.getEventDetailId(),
        workItemIdVerifyDiciplineEntry, employeeDetails.getEmployeeId(), eqmsUserBean.getEmplId(), roleSet,
        employeeDetails.getEventType());

    if (verifyDisciplineEntry) {
      return "MAPS Entry has been made.";
    } else {
      throw new EqmDaoException("DB error");
    }
  }

  @Override
  public boolean updateEAPDetails(EAPRequest eapRequest) throws EqmDaoException {
    EQMSUserBean eqmsUserBean = eqmsUserSession.getUser();
    EAPDatePopupDetail eapDatePopupBean = new EAPDatePopupDetail();
    eapDatePopupBean.setEapDate(DateUtil.getDateFromString(eapRequest.getEapDate()));

    SearchEventGridDetail searchEventGridDetail = createEmployeeDetailsRequest(eapRequest.getSearchEventDetails());

    return decertificationService.setEapComplete(eapRequest.getEmployeeId(), searchEventGridDetail, eapDatePopupBean,
        eqmsUserBean.getEmplId());

    /*
     * boolean checkEAPCompleteFlag = decertificationService.isEAPCompleteForEmployee(eapRequest.getEmployeeId(),
     * searchEventGridDetail.getEventDetailID()); boolean eapCompleteInitiatedCheckFlag = decertificationService
     * .checkEapAlreadyInitiated(eapRequest.getEmployeeId(), searchEventGridDetail.getEventDetailID()); if
     * (checkEAPCompleteFlag) { // -- CHECKS IF EAP IS ALREADY INITIATED if (eapCompleteInitiatedCheckFlag) { //
     * m_feedbackPanel.warn(FeedbackMessageConstant.EVENT_DETAILS_PAGE_028); } else { } } else { //
     * m_feedbackPanel.warn(FeedbackMessageConstant.EVENT_DETAILS_PAGE_007); } return false;
     */
  }

  @Override
  public boolean checkRemedialTrainingInitiatedOrApproved(String employeeID, Integer evntDtlId,
      Integer dcrtEmplStatId) {
    return decertificationService.checkRemedialTrainingInitiatedOrApproved(employeeID, evntDtlId, dcrtEmplStatId);
  }

  @Override
  public boolean isFaxSuspensionReceived(Integer eventDetailID, String employeeID) {
    return decertificationService.isFaxSuspensionReceived(eventDetailID, employeeID);
  }

  @Override
  public String employeeStatus(String employeeID, Integer evntDtlId) {
    return decertificationService.employeeStatus(employeeID, evntDtlId);
  }

  @Override
  public boolean isEmployeeAlreadyReinstated(String employeeID, Integer evntDtlId) {
    return decertificationService.isEmployeeAlreadyReinstated(employeeID, evntDtlId);
  }

  @Override
  public Integer isReinstateWorkItemPresent(Integer evntDtlId, String employeeId) {
    return decertificationService.isReinstateWorkItemPresent(evntDtlId, employeeId);
  }

  @Override
  public boolean checkRuleExamForReinstate(String emplId, Calendar evntDate) {
    return decertificationService.checkRuleExamForReinstate(emplId, evntDate);
  }

  @Override
  public void createWorkItemForUnavalExam(String emplId, Calendar evntDate, Integer evntId) {
    EQMSUserBean eqmsUserBean = eqmsUserSession.getUser();
    decertificationService.createWorkItemForUnavalExam(emplId, evntDate, evntId, eqmsUserBean.getEmplId());
  }

  @Override
  public EmployeeViewIncidentPopupResponse getEmployeeViewIncidentPopupDetail(String employeeID, Integer eventDetailID,
      Integer eventTypeID) {
    EmployeeViewIncidentPopupDetail employeeViewData = decertificationService
        .getEmployeeViewIncidentPopupDetail(employeeID, eventDetailID, eventTypeID);
    return createEmployeeViewIncidentResponse(employeeViewData);
  }

  private EmployeeViewIncidentPopupResponse createEmployeeViewIncidentResponse(
      EmployeeViewIncidentPopupDetail employeeViewData) {
    EmployeeViewIncidentPopupResponse viewIncidentResponseObj = new EmployeeViewIncidentPopupResponse();
    viewIncidentResponseObj.setEmployeeID(employeeViewData.getEmployeeID());
    viewIncidentResponseObj.setEmployeeName(employeeViewData.getEmployeeName());
    viewIncidentResponseObj.setRegion(employeeViewData.getRegion());
    viewIncidentResponseObj.setYearsInCraft(employeeViewData.getYearsInCraft());
    viewIncidentResponseObj.setHireDate(employeeViewData.getHireDate());
    viewIncidentResponseObj.setDateOnDuty(employeeViewData.getDateOnDuty());
    viewIncidentResponseObj.setTimeOnDuty(employeeViewData.getTimeOnDuty());
    viewIncidentResponseObj.setHoursOnDuty(employeeViewData.getHoursOnDuty());
    viewIncidentResponseObj.setPreviousRest(employeeViewData.getPreviousRest());
    viewIncidentResponseObj.setLastStopTest(employeeViewData.getLastStopTest());
    viewIncidentResponseObj.setConductorDate(setConductorDateFromService(employeeViewData));
    viewIncidentResponseObj.setServiceUnit(employeeViewData.getServiceUnit());
    viewIncidentResponseObj.setIsFirstDrugPositive(employeeViewData.getIsFirstDrugPositive());
    viewIncidentResponseObj.setIsFirstAlcoholPositive(employeeViewData.getIsFirstAlcoholPositive());
    viewIncidentResponseObj.setPrimRuleDesc(employeeViewData.getPrimRuleDesc());
    return viewIncidentResponseObj;
  }

  @Override
  public boolean checkRemedialTrainingInitiated(String employeeID, Integer evntDtlId, Integer dcrtEmplStatId) {
    return decertificationService.checkRemedialTrainingInitiated(employeeID, evntDtlId, dcrtEmplStatId);
  }

  @Override
  public EmployeeIncidentDetailResponse getDecertAndRemedialInformation(String employeeId, Integer eventDetailsId) {
    EmployeeIncidentDetail employeeDetails = decertificationService.getDecertAndRemedialInformation(employeeId,
        eventDetailsId);
    return createEmployeeIncidentResponse(employeeDetails);
  }

  private EmployeeIncidentDetailResponse createEmployeeIncidentResponse(EmployeeIncidentDetail employeeDetails) {
    EmployeeIncidentDetailResponse employeeIncidentResponseObj = new EmployeeIncidentDetailResponse();
    employeeIncidentResponseObj.setEffectiveDate(employeeDetails.getEffectiveDate());
    employeeIncidentResponseObj.setRevocationLength(employeeDetails.getRevocationLength());
    employeeIncidentResponseObj.setNoOfDays(employeeDetails.getNoOfDays());
    employeeIncidentResponseObj.setEapDate(employeeDetails.getEapDate());
    employeeIncidentResponseObj.setEapRequired(employeeDetails.getEapRequired());
    employeeIncidentResponseObj.setFtxEvent(employeeDetails.getFtxEvent());
    employeeIncidentResponseObj.setEvntDate(employeeDetails.getEvntDate());
    employeeIncidentResponseObj.setReinstateDate(employeeDetails.getReinstateDate());
    employeeIncidentResponseObj.setOffcNbr(employeeDetails.getOffcNbr());
    employeeIncidentResponseObj.setRegFlag(employeeDetails.getRegFlag());
    employeeIncidentResponseObj.setEmployeeStatus(employeeDetails.getEmplStat());
    employeeIncidentResponseObj.setRemedialDetailList(employeeDetails.getRemedialDetailList());
    return employeeIncidentResponseObj;
  }

  @Override
  public String calculateRegulationflag(Integer eventDtlId, String employeeId) {
    return decertificationService.calculateRegulationflag(eventDtlId, employeeId);
  }

  @Override
  public Integer calculateOffenceCountForReinstateDate(Integer eventDtlId, String employeeID) {
    return decertificationService.calculateOffenceCountForReinstateDate(eventDtlId, employeeID);
  }

  @Override
  public EmployeeOffenceDetails getEmployeeOffenceDetails(EmployeeOffenceDetailsRequest employeeOffenceDetails) {
    EmployeeOffenceDetails incidentDetail = new EmployeeOffenceDetails();
    String trackCode = decertificationService.calculatetrackType(employeeOffenceDetails.getEventDetailId());
    String noOffnInOneYear = decertificationService.calculateNoOffenceInOneYear(employeeOffenceDetails.getEventDate(),
        employeeOffenceDetails.getRegulationFlag(), employeeOffenceDetails.getEmployeeId());
    Integer conOffnCount = decertificationService.calculateConOffnCnt(employeeOffenceDetails.getEmployeeId(),
        employeeOffenceDetails.getRegulationFlag(), employeeOffenceDetails.getEventDetailId());

    incidentDetail.setTrackCode(trackCode);
    incidentDetail.setNoOffnInOneYear(noOffnInOneYear);
    incidentDetail.setConOffnCount(conOffnCount);
    return incidentDetail;
  }

  @Override
  public boolean approveRemedialTraining(RemedialTrainingDetails remedialTrainingDetails) {

    EQMSUserBean eqmsUserBean = eqmsUserSession.getUser();
    Integer eventDetailId = remedialTrainingDetails.getEventDetailId();
    String employeeId = remedialTrainingDetails.getEmployeeId();
    Date reinstateWorkItemDate = remedialTrainingDetails.getReinstateDate();
    String comments = remedialTrainingDetails.getComments();
    boolean eapReqdAndCompleted = remedialTrainingDetails.getEapReqdAndCompleted();
    Integer serviceUnitNbr = remedialTrainingDetails.getServiceUnitNumber();
    String respMngrId = remedialTrainingDetails.getResponsibleManagerId();
    String crtnId = eqmsUserBean.getEmplId();
    Integer workItemId = remedialTrainingDetails.getWorkItemId();

    return decertificationService.approveRemedialTraining(eventDetailId, employeeId, reinstateWorkItemDate, comments,
        eapReqdAndCompleted, serviceUnitNbr, respMngrId, crtnId, workItemId);
  }

  @Override
  public boolean rejectRemedialTraining(RemedialTrainingDetails remedialTrainingDetails) {
    EQMSUserBean eqmsUserBean = eqmsUserSession.getUser();
    Integer eventDetailId = remedialTrainingDetails.getEventDetailId();
    String employeeId = remedialTrainingDetails.getEmployeeId();
    String comments = remedialTrainingDetails.getComments();
    Integer serviceUnitNbr = remedialTrainingDetails.getServiceUnitNumber();
    String crtnId = eqmsUserBean.getEmplId();
    Integer workItemId = remedialTrainingDetails.getWorkItemId();
    return decertificationService.rejectRemedialTraining(eventDetailId, employeeId, comments, crtnId, workItemId,
        serviceUnitNbr);
  }

  @Override
  public boolean performCommentDeleteOperation(
      IncidentHistoryDeleteCommentDetails incidentHistoryDeleteCommentDetails) {
    IncidentHistory incidentHIstory = incidentHistoryDeleteCommentDetails.getIncidentHistory();
    String loggedInUserId = eqmsUserSession.getUser().getEmplId();
    boolean suspCmntFlag = incidentHistoryDeleteCommentDetails.isSuspDocFlag();
    boolean onlyCmntDeleteFlag = incidentHistoryDeleteCommentDetails.isOnlyCmntDeleteFlag();

    boolean susDocFlag = incidentHistoryDeleteCommentDetails.isSuspDocFlag();
    String subjectMail = incidentHistoryDeleteCommentDetails.getIncidentHistory().getComments();
    String employeeId = incidentHistoryDeleteCommentDetails.getEmployeeId();
    String employeeName = incidentHistoryDeleteCommentDetails.getEmployeeName();

    boolean isSuccess = decertificationService.performCommentDeleteOperation(incidentHIstory, loggedInUserId,
        suspCmntFlag, onlyCmntDeleteFlag);

    if (isSuccess) {
      sendMailToAssgnMngr(susDocFlag, subjectMail, employeeId, employeeName);
    }

    return isSuccess;
  }

  protected void sendMailToAssgnMngr(boolean susDocFlag, String subjectMail, String employeeID, String employeeName) {
    StringBuffer subjectOfEmail = new StringBuffer();
    StringBuffer contentOfEmail = new StringBuffer();
    List<String> assignMngrList = decertificationService.getAsgnMngrList(employeeID);
    if (null == assignMngrList || assignMngrList.isEmpty()) {
      assignMngrList = new ArrayList<String>();
    }
    EqmSysParm emailIdOfEQMSGrp = sysParamService.getSystemParamValue(DecertificationApplicationConstant.EQMS_GROUP);// getMap().get(DecertificationApplicationConstant.EQMS_GROUP);
    List<String> emplID = new ArrayList<>();

    if (null != emailIdOfEQMSGrp) {
      /*
       * emplID = new String[assignMngrList.size() + 1]; emplID[assignMngrList.size()] = new String("EQMS@UP.COM");
       */
      emplID.add(assignMngrList.size(), "EQMS@UP.COM");
    }
    /*
     * emplID = new String[assignMngrList.size() + 1]; emplID[assignMngrList.size()] = new String("EQMS@UP.COM");
     */

    if (!assignMngrList.isEmpty()) {
      for (int i = 0; i < assignMngrList.size(); i++) {
        // emplID[i] = new String(assignMngrList.get(i));
        emplID.add(assignMngrList.get(i));
      }
    }
    String date = getSysDate();

    if (susDocFlag) {
      subjectOfEmail.append(DecertificationApplicationConstant.SUBJECT_OF_EMAIL_DELETE);
    } else {
      subjectOfEmail.append(subjectMail);
    }

    subjectOfEmail.append(DecertificationApplicationConstant.LEFT_PARENTHESIS);
    subjectOfEmail.append(DecertificationApplicationConstant.MAIL_EMPLOYEE_ID).append(employeeID);
    subjectOfEmail.append(DecertificationApplicationConstant.RIGHT_PARENTHESIS);
    contentOfEmail.append(DecertificationApplicationConstant.MAIL_EMPLOYEE_ID).append(employeeID);
    contentOfEmail.append("<br>");
    contentOfEmail.append(DecertificationApplicationConstant.MAIL_EMPLOYEE_NAME).append(employeeName);
    contentOfEmail.append("<br>");

    if (susDocFlag) {
      contentOfEmail.append(DecertificationApplicationConstant.ACTION)
          .append(DecertificationApplicationConstant.SUBJECT_OF_EMAIL_DELETE);
    } else {
      contentOfEmail.append(DecertificationApplicationConstant.ACTION).append(subjectMail);
    }

    contentOfEmail.append("<br>");
    contentOfEmail.append(DecertificationApplicationConstant.SYSDATE).append(date);
    emailNotificationService.sendEmailNotification(emplID, null, null, subjectOfEmail.toString(),
        contentOfEmail.toString(), EmailNotificationService.EQMS_EMAIL_DESCRIPTION);
    // service.sendEmailNotification(emplID, contentOfEmail.toString(), subjectOfEmail.toString());
  }

  private String getSysDate() {
    Date date = DateUtil.getTodaysDate();
    String sysDate = DateUtil.getDateMMDDYYYY(DateUtil.getDateAsCalendar(date));
    return sysDate;
  }

  @Override
  public List<EventDocumentDetail> getDocumentDetails(SearchEventResponse eventRequest) {
    SearchEventGridDetail request = createEmployeeDetailsRequest(eventRequest);
    List<EventDocumentGridDetail> daoResponse = decertificationService.getDocumentDetails(request);
    if (null == daoResponse) {
      return null;
    }
    return createEventDocumentDetailsResponse(daoResponse);
  }

  private List<EventDocumentDetail> createEventDocumentDetailsResponse(List<EventDocumentGridDetail> daoResponseList) {
    List<EventDocumentDetail> eventEventDocumentDetailList = new ArrayList<>();

    if (daoResponseList == null) {
      return eventEventDocumentDetailList;
    }

    for (EventDocumentGridDetail objEventDocumentResponse : daoResponseList) {
      EventDocumentDetail eventDocument = new EventDocumentDetail();
      eventDocument.setDocID(objEventDocumentResponse.getDocID());
      eventDocument.setDocKey(objEventDocumentResponse.getDocKey());
      eventDocument.setFileName(objEventDocumentResponse.getFileName());
      eventDocument.setLerbUpload(objEventDocumentResponse.getLerbUpload());
      eventDocument.setMimeType(objEventDocumentResponse.getMimeType());
      eventDocument.setDatFileByteArray(objEventDocumentResponse.getDatFileByteArray());
      eventEventDocumentDetailList.add(eventDocument);
    }
    return eventEventDocumentDetailList;
  }

  @Override
  public byte[] generatePdf(String gufn)
      throws ParserConfigurationException, SAXException, IOException, DocumentException {
    DossGetServiceResponse serviceResponse = getDocumentsXmfServices(gufn);
    byte[] byteArray = serviceResponse.getByteDocumentData();
    /*
     * ByteArrayOutputStream temp = new ByteArrayOutputStream(); Document document = new Document(PageSize.A4); PdfCopy
     * writer = new PdfCopy(document, temp); PdfReader pdfReader = null; document.open(); if (byteArray != null &&
     * byteArray.length != 0) { pdfReader = new PdfReader(byteArray); merge(writer, pdfReader, document); }
     * document.close();
     */

    return byteArray;
  }

  /*
   * public void merge(PdfCopy pdfWriter, PdfReader reader, Document document) throws DocumentException, IOException {
   * int count = 0; int number = 0; number = reader.getNumberOfPages(); // we retrieve the size of the first page while
   * (count < number) { document.newPage(); count++; pdfWriter.addPage(pdfWriter.getImportedPage(reader, count)); } }
   * public ByteArrayOutputStream getPdf(String gunf) throws DocumentException, ParserConfigurationException,
   * SAXException, IOException { ByteArrayOutputStream baos = new ByteArrayOutputStream(); Document doc = new
   * Document(PageSize.A4); // step 2: create a writer that listens to the document PdfWriter writer =
   * PdfWriter.getInstance(doc, baos); doc.open(); // step 3: we create a parser and set the document handler SAXParser
   * parser = SAXParserFactory.newInstance().newSAXParser(); CustomTagHandler cth = new CustomTagHandler(doc, writer,
   * customMap); ByteArrayInputStream bais = new ByteArrayInputStream(gunf.getBytes()); // step 4: we parse the document
   * parser.parse(bais, cth); writer.flush(); doc.close(); return baos; }
   */

  public DossGetServiceResponse getDocumentsXmfServices(String gufnId) {
    DossGetServiceClientXmfImpl client = new DossGetServiceClientXmfImpl(dossGetInvoker);
    DossGetServiceResponse dossGetServiceResponse = null;
    try {
      dossGetServiceResponse = client.getDataDocumentAsByteArray(gufnId);
    } catch (XmlException e) {
      // TODO code for send mail
      e.printStackTrace();
    }
    return dossGetServiceResponse;
  }

  @Override
  public ApproveRejectRemedialPageDetail getApproveRejectRemedialPagedetails(String employeeId,
      Integer eventDetailsId) {
    return decertificationService.getApproveRejectRemedialPagedetails(employeeId, eventDetailsId);
  }

  @Override
  public ValidEmployeeDetailsForEap isEAPCompleteForEmployee(String employeeID, Integer eventDetailID) {
    boolean checkEAPCompleteFlag = decertificationService.isEAPCompleteForEmployee(employeeID, eventDetailID);
    boolean eapCompleteInitiatedCheckFlag = decertificationService.checkEapAlreadyInitiated(employeeID, eventDetailID);
    ValidEmployeeDetailsForEap validEmployeeDetailsForEap = new ValidEmployeeDetailsForEap();
    validEmployeeDetailsForEap.setEapAlreadyCompleted(checkEAPCompleteFlag);
    validEmployeeDetailsForEap.setEapInitiated(eapCompleteInitiatedCheckFlag);
    return validEmployeeDetailsForEap;
  }

  @Override
  public Integer getVerifyMapsWorkItemId(Integer eventDetailID, String employeeID) {
    return decertificationService.isVerifyDisciplineWorkItemPresent(eventDetailID, employeeID);
  }

  @Override
  public EqmEmplCmntDtls getEmployeeEventCommentDetails(Integer eventDetailID, String employeeID) {
    return decertificationService.getEmplCmntDtls(eventDetailID, employeeID);
  }

  public MitigateEventDetail getMitigateEventBeanByEvntDtlId(Integer eventDetailID) {

    return decertificationService.getMitigateEventBeanByEvntDtlId(eventDetailID);

  }

  public List<EventDocumentDetail> getEventDocumentGridBean(final Integer eventDetailID, final boolean lerbFlag) {
    List<EventDocumentGridDetail> daoResponse = decertificationService.getEventDocumentGridBean(eventDetailID,
        lerbFlag);
    return createEventDocumentDetailsResponse(daoResponse);
  }

  private String setConductorDateFromService(EmployeeViewIncidentPopupDetail employeeViewIncidentPopupDetail) {
    Rules rules = null;
    String conductorDate = null;
    QualificationService qualificationService = new QualificationService(secureInvokerEqm);
    if (DecertificationApplicationConstant.HYPHEN_STRING.equals(employeeViewIncidentPopupDetail.getConductorDate())) {
      EqmSysParm sysParamBean = sysParamService.getSystemParamValue(DecertificationApplicationConstant.PINS_CODE_RCO);
      String sysParamValue = sysParamBean.getParmValu();

      String employeeId = employeeViewIncidentPopupDetail.getEmployeeID();
      QualificationDetail details = qualificationService.getTestQualificationDetails(employeeId, sysParamValue, true,sysParamService.getAllSystemParameter());

      if ((details != null) && (details.getRules() != null)) {
        rules = new Rules();
		// Modified for Denial of Certification bundled QCs(SS_QC#5120)
        rules.setRulesDate(DateUtil.getCalendarAsString(details.getRules().getExamDate()));
        rules.setRulesResult(details.getRules().getRsltFlag());
        rules.setRulesScore(details.getRules().getExamScorNbr());
      }

      if ((rules != null) && (rules.getRulesDate() != null) && (null != rules.getRulesResult())
          && (rules.getRulesScore() != null)) {
		// Modified for Denial of Certification bundled QCs(SS_QC#5120)	  
        conductorDate = rules.getRulesDate();
        return conductorDate;
      }
    }
    return employeeViewIncidentPopupDetail.getConductorDate();

  }

  // SS_QC#9262 changes start
  /**
   * This method is used to employee based cmts messages details.
   *
   * @param emplId
   * @return List<CmtsEmplBasedMsgs>
   * @author xsat671
   * @since Sep 11, 2017.
   * Added for SS_QC#9262
   */
  @Override
  public List<CmtsEmplBasedMsgs> getEmplStatusDetailsList(final String emplId) {
    return decertificationService.getEmplStatusDetailsList(emplId);
  }
  // SS_QC#9262 changes end
}
