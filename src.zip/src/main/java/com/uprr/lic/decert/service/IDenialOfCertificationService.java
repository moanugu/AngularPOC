package com.uprr.lic.decert.service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.velocity.exception.MethodInvocationException;
import org.apache.velocity.exception.ParseErrorException;
import org.apache.velocity.exception.ResourceNotFoundException;
import org.springframework.web.multipart.MultipartFile;
import org.xml.sax.SAXException;

import com.uprr.lic.dataaccess.common.model.DenialPdfPageDetails;
import com.uprr.lic.dataaccess.decertification.model.DenialEmployeeDetail;
import com.uprr.lic.dataaccess.decertification.model.DenyLicenseRequestDetail;
import com.uprr.lic.dataaccess.decertification.model.EventDocumentGridDetail;
import com.uprr.lic.dataaccess.decertification.model.SkillEvaluationAndEventRecorderSummaryDetails;
import com.uprr.lic.util.DDChoice;

public interface IDenialOfCertificationService {

  public List<DDChoice> getRegualtionsForDenial();

  public DenialEmployeeDetail getDenialDetailsForSkill(final String emplId);

  public DenialEmployeeDetail getDenialDetailsForRules(final String emplId);

  public SkillEvaluationAndEventRecorderSummaryDetails getSkillAndRecorderSummaryDetail(final String employeeId,
      final Integer evntEmplSeq);

  public String validateIfAllowToCreateAnEvent(final String employeeId, final Integer regulationSelected, final String emplPos);
  
  public boolean initiateDenialOfCertification(final String employeeId, final Integer regulationSelected, final String emplPos);
  
  public String rejectDenialOfCertification(String employeeId,
      Integer eventDetailId, Integer workItemId, Integer resnId);
  
  public String goBackToRebuttal(String employeeId,
      Integer eventDetailId, Integer workItemId, Integer resnId);

  public DenialEmployeeDetail getDenyLicenseRequestPageDetails(final String emplId, final Integer resnId);

boolean hasLicenseDeniedSuccessfully(DenyLicenseRequestDetail denyLicenseRequestDetail);

 public ByteArrayOutputStream generatePdf(DenialPdfPageDetails denialPageDetails)throws ParserConfigurationException, SAXException, IOException, ResourceNotFoundException, ParseErrorException, MethodInvocationException, Exception ;
	
	public  String  getComments(Integer workItemId);
	
	public String uploadFile(final List<MultipartFile> documents,final  String emplID,final String oprnCode, final Integer workItemId, final String emplPos) throws IOException;
	
	public List<String> getEmplLcnsDtls(String employeeId);
	
	public byte[] downloadFormFromFileNet(String employeeId,Integer eventDetailId, String denyOprnCode, OutputStream responseOutputStream);
	
	public List<EventDocumentGridDetail> getRebuttalDocDetails(final Integer eventDetailID, final String rebuttalOprnCode);
	
	public byte[] downloadFormUsingGuid(final String guid);
	
	public Map<String,String> getEqmEmplDtlsFromWorkItemId(final Integer workItemId);

	 /**
   * This method is used to return loggedInUser Name
   *
   * @return String
   * @author xsat671
   * @since Jul 11, 2017. Added for Denial of Certification bundled QCs(SS_QC#5120
   */
  public Map<String,String> getLoggedInUserNameAndEmplId();

}
