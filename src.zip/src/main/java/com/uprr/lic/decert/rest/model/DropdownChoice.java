package com.uprr.lic.decert.rest.model;

public class DropdownChoice {

	private Integer intKey;

	private String strKey;

	private String value;

	public Integer getIntKey() {
		return intKey;
	}

	/**
	 * @param intKey
	 *            the intKey to set
	 */
	public void setIntKey(final Integer intKey) {
		this.intKey = intKey;
	}

	/**
	 * @return the strKey
	 */
	public String getStrKey() {
		return strKey;
	}

	/**
	 * @param strKey
	 *            the strKey to set
	 */
	public void setStrKey(final String strKey) {
		this.strKey = strKey;
	}

	/**
	 * @return the value
	 */
	public String getValue() {
		return value;
	}

	/**
	 * @param value
	 *            the value to set
	 */
	public void setValue(final String value) {
		this.value = value;
	}

}
