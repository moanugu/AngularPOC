package com.uprr.lic.decert.service;

import java.io.IOException;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.ParserConfigurationException;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.xml.sax.SAXException;

import com.lowagie.text.DocumentException;
import com.uprr.lic.dataaccess.common.model.CmtsEmplBasedMsgs;
import com.uprr.lic.dataaccess.common.model.EqmEmplCmntDtls;
import com.uprr.lic.dataaccess.decertification.model.ApproveRejectRemedialPageDetail;
import com.uprr.lic.dataaccess.decertification.model.MitigateEventDetail;
import com.uprr.lic.decert.rest.model.DecertifyLicenseDetailResponse;
import com.uprr.lic.decert.rest.model.DecertifyLicenseDetailRestRequest;
import com.uprr.lic.decert.rest.model.DropdownChoice;
import com.uprr.lic.decert.rest.model.EAPRequest;
import com.uprr.lic.decert.rest.model.EmployeeDetails;
import com.uprr.lic.decert.rest.model.EmployeeIncidentDetailResponse;
import com.uprr.lic.decert.rest.model.EmployeeOffenceDetails;
import com.uprr.lic.decert.rest.model.EmployeeOffenceDetailsRequest;
import com.uprr.lic.decert.rest.model.EmployeeViewIncidentPopupResponse;
import com.uprr.lic.decert.rest.model.EventDetailsResponse;
import com.uprr.lic.decert.rest.model.EventDocumentDetail;
import com.uprr.lic.decert.rest.model.EventEmployeeResponse;
import com.uprr.lic.decert.rest.model.EventIncidentHistoryResponse;
import com.uprr.lic.decert.rest.model.EventLerbDetailResponse;
import com.uprr.lic.decert.rest.model.FaxRemedialDetailRequest;
import com.uprr.lic.decert.rest.model.IncidentHistoryDeleteCommentDetails;
import com.uprr.lic.decert.rest.model.LicenseDetailResponse;
import com.uprr.lic.decert.rest.model.ReceivedDocumentRequest;
import com.uprr.lic.decert.rest.model.RemedialTrainingDetails;
import com.uprr.lic.decert.rest.model.SearchEventResponse;
import com.uprr.lic.decert.rest.model.ValidEmployeeDetailsForEap;
import com.uprr.lic.exception.EqmDaoException;

public interface IAdministrationService {
	
	EventDetailsResponse getEventDetails(SearchEventResponse searchEventrequest);

	List<EventIncidentHistoryResponse> getEventIncidentHistory(Integer eventDetailId);

	List<EventEmployeeResponse> getEmployeeDetails(SearchEventResponse searchEventRequest);
	
	List<EventLerbDetailResponse> getEventLerbDetails(Integer eventId, String employeeID);
	
	List<DropdownChoice> getRevocationPeriodList();
	List<LicenseDetailResponse> getLicenseDetailList(String employeeID);

	List<DropdownChoice> getDocumentListByType(Integer eventID, Integer eventTypeID, String employeeID);

	String updateReceivedDocument(ReceivedDocumentRequest receivedDocumentRequest);
	
	DecertifyLicenseDetailResponse getDecertifyLicenseDetails(DecertifyLicenseDetailRestRequest decertifyLicenseRequestDetail) throws Exception;
	
	boolean decertifyEmployee(DecertifyLicenseDetailRestRequest details) throws Exception;

	boolean updateEmployeeComment(@RequestBody EmployeeDetails employeeDetails);
	
	
	boolean updateRemedialTrainingDetails(FaxRemedialDetailRequest faxRemediaDetailRequest, Integer serviceUnitNumber);

	/**
	 * Get Default reinstate date
	 * @param decline
	 * @param employeeDetails
	 * @return
	 */
	String getReinstateDate(boolean decline, EmployeeDetails employeeDetails);

	boolean declineReinstateEmployee(EmployeeDetails employeeDetails);

	Map<String, Boolean> reinstateEmployee(EmployeeDetails employeeDetails) ;
	boolean mitigateEmployee(MultipartHttpServletRequest multipartHttpServletRequest);

	
	List<EventIncidentHistoryResponse> getIncidentHistoryList(Integer eventDetailID, String employeeID);
	
	Integer isDecertifyWorkItemPresent(Integer evntDtlId, String employeeID);

	
	String verifyMapsEntry(EmployeeDetails employeeDetails)
			throws EqmDaoException;
	
	boolean updateEAPDetails(EAPRequest eapRequest)
			throws EqmDaoException;
	
	boolean checkRemedialTrainingInitiatedOrApproved(final String employeeID, final Integer evntDtlId,
		      final Integer dcrtEmplStatId);
 
	boolean isFaxSuspensionReceived(Integer evntDtlId, String employeeID) ;
	
	String employeeStatus(String employeeID, Integer evntDtlId);
	
	boolean isEmployeeAlreadyReinstated(String employeeID, Integer evntDtlId);
	
	Integer isReinstateWorkItemPresent(Integer evntDtlId,String employeeId);
	
	boolean checkRuleExamForReinstate(String emplId, Calendar evntDate);
	
	void createWorkItemForUnavalExam(String emplId, Calendar evntDate, Integer evntId);
	
	EmployeeViewIncidentPopupResponse getEmployeeViewIncidentPopupDetail(String employeeID, Integer eventDetailID,
		      Integer eventTypeID);
	boolean checkRemedialTrainingInitiated(final String employeeID, final Integer evntDtlId,
		      final Integer dcrtEmplStatId);
	
	EmployeeIncidentDetailResponse getDecertAndRemedialInformation(final String employeeId, 
		      final Integer eventDetailsId);
	
	String calculateRegulationflag(Integer eventDtlId, String employeeId);
	
	Integer calculateOffenceCountForReinstateDate(Integer eventDtlId, String employeeID);
	
	EmployeeOffenceDetails getEmployeeOffenceDetails(EmployeeOffenceDetailsRequest employeeOffenceDetails);
	
	boolean approveRemedialTraining(RemedialTrainingDetails remedialTrainingDetails);
	
	boolean rejectRemedialTraining(RemedialTrainingDetails remedialTrainingDetails);
	
	boolean performCommentDeleteOperation(IncidentHistoryDeleteCommentDetails incidentHistoryDeleteCommentDetails);
	
	List<EventDocumentDetail> getDocumentDetails(SearchEventResponse eventRequest);
	
	byte[] generatePdf(String gufn)  throws DocumentException, ParserConfigurationException, SAXException, IOException, DocumentException  ;

	public ApproveRejectRemedialPageDetail getApproveRejectRemedialPagedetails(String employeeId,
		      Integer eventDetailsId);
	
	public ValidEmployeeDetailsForEap isEAPCompleteForEmployee(final String employeeID, final Integer eventDetailID);
	
	//public VerifyMapsDetails VerifyMapsDetails(final String employeeID, final Integer eventDetailID);
	public Integer getVerifyMapsWorkItemId(Integer eventDetailID, String employeeID);
	
	public EqmEmplCmntDtls getEmployeeEventCommentDetails(Integer eventDetailID, String employeeID);
	public MitigateEventDetail getMitigateEventBeanByEvntDtlId(final Integer evntDtlId) ;
	public List<EventDocumentDetail> getEventDocumentGridBean(final Integer eventId,final boolean lerbFlag);
	
	// Added for SS_QC#9262
	public List<CmtsEmplBasedMsgs> getEmplStatusDetailsList(final String emplId);
}
