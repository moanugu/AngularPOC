package com.uprr.lic.decert.rest.model;

public class EAPRequest {

	private String  employeeId;
	private String firstDAndAEvent;
	private SearchEventResponse searchEventDetails;
//	private String userId;
	private String eapDate;
	public String getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	public String getFirstDAndAEvent() {
		return firstDAndAEvent;
	}
	public void setFirstDAndAEvent(String firstDAndAEvent) {
		this.firstDAndAEvent = firstDAndAEvent;
	}
	public SearchEventResponse getSearchEventDetails() {
		return searchEventDetails;
	}
	public void setSearchEventDetails(SearchEventResponse searchEventDetails) {
		this.searchEventDetails = searchEventDetails;
	}
//	public String getUserId() {
//		return userId;
//	}
//	public void setUserId(String userId) {
//		this.userId = userId;
//	}
	public String getEapDate() {
		return eapDate;
	}
	
	public void setEapDate(String eapDate) {
		this.eapDate = eapDate;
	}
}
