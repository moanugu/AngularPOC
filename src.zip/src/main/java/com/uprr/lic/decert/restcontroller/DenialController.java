/**
 * Description  : This class is backend controller for all the denial flow..
 * ClassName    : DenialController
 * author       : Tech Mahindra Ltd
 * Created on : Jun 2017
 *
 * Change History
 * ------------------------------------------------------------  
 * Date          Changed By      Description
 * ------------------------------------------------------------  
 * 05-Jun-2017    xsat794       Added for Denial of Certification bundled QCs(SS_QC#5120)
 * ------------------------------------------------------------  
 *
 * Copyright notice : "Copyright UPRR 2017"
 */
package com.uprr.lic.decert.restcontroller;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.velocity.exception.MethodInvocationException;
import org.apache.velocity.exception.ParseErrorException;
import org.apache.velocity.exception.ResourceNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.lowagie.text.DocumentException;
import com.uprr.lic.dataaccess.common.model.DenialPdfPageDetails;
import com.uprr.lic.dataaccess.decertification.model.DenialEmployeeDetail;
import com.uprr.lic.dataaccess.decertification.model.DenyLicenseRequestDetail;
import com.uprr.lic.dataaccess.decertification.model.EventDocumentGridDetail;
import com.uprr.lic.dataaccess.decertification.model.SkillEvaluationAndEventRecorderSummaryDetails;
import com.uprr.lic.decert.service.IDenialOfCertificationService;
import com.uprr.lic.util.DDChoice;

@Controller
public class DenialController {

  @Autowired
  private IDenialOfCertificationService denialOfCertificationService;
  /**
   * 
   * This method is used to get regulations 
   *
   * @return List<DDChoice>
   * @author xsat794
   * @since Jul 5, 2017
   * Added for Denial of Certification bundled QCs(SS_QC#5120)
   */
  @RequestMapping(method = RequestMethod.GET, value = "/getRegualtionsForDenial")
  @ResponseBody
  public List<DDChoice> getEventTypeList() {
    return denialOfCertificationService.getRegualtionsForDenial();
  }
  /**
   * 
   * To get employee details for skill
   *
   * @param employeeId
   * @return DenialEmployeeDetail
   * @author xsat794
   * @since Jul 5, 2017
   * Added for Denial of Certification bundled QCs(SS_QC#5120)
   */
  @RequestMapping(method = RequestMethod.GET, value = "/getDenyDetailsForSkill/{employeeId}")
  @ResponseBody
  public DenialEmployeeDetail getDenialEmployeeDetailsForSkill(@PathVariable String employeeId) {
    return denialOfCertificationService.getDenialDetailsForSkill(employeeId);
  }
  /**
   * 
   * To get employee details for rules
   *
   * @param employeeId
   * @return DenialEmployeeDetail
   * @author xsat794
   * @since Jul 5, 2017
   * Added for Denial of Certification bundled QCs(SS_QC#5120)
   */
  @RequestMapping(method = RequestMethod.GET, value = "/getDenyDetailsForRules/{employeeId}")
  @ResponseBody
  public DenialEmployeeDetail getDenialEmployeeDetailsForRules(@PathVariable String employeeId) {
    return denialOfCertificationService.getDenialDetailsForRules(employeeId);
  }
  /**
   * 
   * To get skill and recorder summary
   *
   * @param employeeId
   * @param evntEmplSeq
   * @return SkillEvaluationAndEventRecorderSummaryDetails
   * @author xsat794
   * @since Jul 5, 2017
   * Added for Denial of Certification bundled QCs(SS_QC#5120)
   */
  @RequestMapping(method = RequestMethod.GET, value = "/getSkillAndRecorderSummaryDetail/{employeeId}/{evntEmplSeq}")
  @ResponseBody
  public SkillEvaluationAndEventRecorderSummaryDetails getSkillAndRecorderSummaryDetail(@PathVariable String employeeId,
      @PathVariable Integer evntEmplSeq) {
    return denialOfCertificationService.getSkillAndRecorderSummaryDetail(employeeId, evntEmplSeq);
  }
  /**
   * 
   * To check the conditions for creation of event
   *
   * @param employeeId
   * @param regulationSelected
   * @return String
   * @author xsat794
   * @since Jul 5, 2017
   * Added for Denial of Certification bundled QCs(SS_QC#5120)
   */
  @RequestMapping(method = RequestMethod.GET, value = "/validateIfAllowToCreateAnEvent/{employeeId}/{regulationSelected}/{emplPos}")
  @ResponseBody
  public String validateIfAllowToCreateAnEvent(@PathVariable String employeeId,
      @PathVariable Integer regulationSelected, @PathVariable String emplPos) {
    return denialOfCertificationService.validateIfAllowToCreateAnEvent(employeeId, regulationSelected, emplPos);
  }
  /**
   * 
   * This method is used to initiate denial of certification
   *
   * @param employeeId
   * @param regulationSelected
   * @param emplPos
   * @return boolean
   * @author xsat794
   * @since Jul 5, 2017
   * Added for Denial of Certification bundled QCs(SS_QC#5120)
   */
  @RequestMapping(method = RequestMethod.POST, value = "/initiateDenialOfCertification/{employeeId}/{regulationSelected}/{emplPos}")
  @ResponseBody
  public boolean initiateDenialOfCertification(@PathVariable String employeeId,
      @PathVariable Integer regulationSelected, @PathVariable String emplPos) {
    return denialOfCertificationService.initiateDenialOfCertification(employeeId, regulationSelected, emplPos);
  }
  /**
   * 
   * This method is used to reject denial of certification
   *
   * @param employeeId
   * @param eventDetailId
   * @param workItemId
   * @param resnId
   * @return String
   * @author xsat794
   * @since Jul 5, 2017
   * Added for Denial of Certification bundled QCs(SS_QC#5120)
   */
  @RequestMapping(method = RequestMethod.POST, value = "/rejectDenialOfCertification/{employeeId}/{eventDetailId}/{workItemId}/{resnId}")
  @ResponseBody
  public String rejectDenialOfCertification(@PathVariable String employeeId,
      @PathVariable Integer eventDetailId, @PathVariable Integer workItemId, @PathVariable Integer resnId) {
    return denialOfCertificationService.rejectDenialOfCertification(employeeId, eventDetailId, workItemId, resnId);
  }
  /**
   * 
   * This method is used for go back to rebuttal process
   *
   * @param employeeId
   * @param eventDetailId
   * @param workItemId
   * @param resnId
   * @return String
   * @author xsat794
   * @since Jul 5, 2017
   * Added for Denial of Certification bundled QCs(SS_QC#5120)
   */
  @RequestMapping(method = RequestMethod.POST, value = "/goBackToRebuttal/{employeeId}/{eventDetailId}/{workItemId}/{resnId}")
  @ResponseBody
  public String goBackToRebuttal(@PathVariable String employeeId,
      @PathVariable Integer eventDetailId, @PathVariable Integer workItemId, @PathVariable Integer resnId) {
    return denialOfCertificationService.goBackToRebuttal(employeeId, eventDetailId, workItemId, resnId);
  }
  /**
   * 
   * This method gets the data for DenyLicenseRequestPage
   *
   * @param employeeId
   * @param resnId
   * @return DenialEmployeeDetail
   * @author xsat794
   * @since Jul 5, 2017
   * Added for Denial of Certification bundled QCs(SS_QC#5120)
   */
  @RequestMapping(method = RequestMethod.GET, value = "/getDenyLicenseRequestPageDetails/{employeeId}/{resnId}")
  @ResponseBody
  public DenialEmployeeDetail getDenyLicenseRequestPageDetails(@PathVariable String employeeId, @PathVariable Integer resnId) {
    return denialOfCertificationService.getDenyLicenseRequestPageDetails(employeeId, resnId);
  }
  /**
   * 
   * Method to check if license is denied successfully
   *
   * @param denyLicenseRequestDetail
   * @return boolean
   * @author xsat794
   * @since Jul 5, 2017
   * Added for Denial of Certification bundled QCs(SS_QC#5120)
   */
@RequestMapping(method = RequestMethod.POST, value = "/hasLicenseDeniedSuccessfully")
  @ResponseBody
  public boolean hasLicenseDeniedSuccessfully(@RequestBody DenyLicenseRequestDetail denyLicenseRequestDetail){
    return denialOfCertificationService.hasLicenseDeniedSuccessfully(denyLicenseRequestDetail);
    
  }
	/**
	 * 
	 * This method is used to generate the PDF for all the form work items
	 *
	 * @param request
	 * @param response
	 * @throws ResourceNotFoundException
	 * @throws ParseErrorException
	 * @throws MethodInvocationException
	 * @throws Exception
	 * @author xsat794
	 * @since Jul 5, 2017
	 * Added for Denial of Certification bundled QCs(SS_QC#5120)
	 */
	@RequestMapping(method = RequestMethod.POST, value="/submitDenialForm")
	@ResponseBody
  public ResponseEntity<byte[]> submitDenialForm(@RequestBody DenialPdfPageDetails denialPageDetails,
      HttpServletResponse response)
      throws ResourceNotFoundException, ParseErrorException, MethodInvocationException, Exception {
    HttpHeaders headers = new HttpHeaders();
    headers.setContentType(MediaType.parseMediaType("application/pdf"));
    String filename = "output.pdf";
    headers.setContentDispositionFormData(filename, filename);
    headers.setCacheControl("must-revalidate, post-check=0, pre-check=0");
    ByteArrayOutputStream baos = denialOfCertificationService.generatePdf(denialPageDetails);
    byte[] byteOutput = null;
    byteOutput = baos.toByteArray();
    OutputStream responseOutputStream = response.getOutputStream();
    if (null != byteOutput) {
      responseOutputStream.write(byteOutput);
    } else {
      responseOutputStream.write("Error While getting Document, Please Try after some time".getBytes());
      return new ResponseEntity<byte[]>(HttpStatus.EXPECTATION_FAILED);
    }
    return new ResponseEntity<byte[]>(byteOutput, headers, HttpStatus.OK);
  }
	
/**
 * 
 * This method is used to get form description.
 *
 * @param workItemId
 * @return List<String>
 * @author xsat794
 * @since Jul 5, 2017
 * Added for Denial of Certification bundled QCs(SS_QC#5120)
 */
@RequestMapping(method = RequestMethod.GET, value="/getComments/{workItemId}")
@ResponseBody
	public List<String> getComments(@PathVariable("workItemId") Integer workItemId){
		List<String>cmntsList= new ArrayList<String>();
		String cmnts = denialOfCertificationService.getComments(workItemId);
		if(cmnts!=null){
			 StringTokenizer st = new StringTokenizer(cmnts,"&");  
			 while(st.hasMoreTokens()){
				 cmntsList.add(st.nextToken());
			 }
		}
		return cmntsList;
	
	}
/**
 * 
 * This method is used to upload the files for rebuttal approve
 *
 * @param multipartRequest
 * @return boolean
 * @throws IOException
 * @author xsat794
 * @since Jul 5, 2017
 * Added for Denial of Certification bundled QCs(SS_QC#5120)
 */
@RequestMapping(method = RequestMethod.POST, value="/uploadFile")
@ResponseBody
	public Boolean uploadFile(MultipartHttpServletRequest multipartRequest)
			throws IOException {
		String emplID = multipartRequest.getParameter("emplID");
		String oprnCode = multipartRequest.getParameter("oprnCode");
		String workItemId = multipartRequest.getParameter("workItemId");
		String emplPos = multipartRequest.getParameter("emplPos");
		Map<String, List<MultipartFile>> fileMap = multipartRequest
				.getMultiFileMap();

		List<MultipartFile> documents = new ArrayList<>();

		if (null != fileMap && fileMap.size() > 0) {
			for (Map.Entry<String, List<MultipartFile>> entry : fileMap
					.entrySet()) {
				if (entry.getKey().contains("fileUpload")) {	
					for (MultipartFile multipartFile : entry.getValue()) {
						documents.add(multipartFile);
					}
				}
			}
		}

		Boolean isUploadComplete =false;
		String gufnId = denialOfCertificationService.uploadFile(documents, emplID,oprnCode, Integer.parseInt(workItemId), emplPos);
		if (gufnId != null) {
			isUploadComplete=true;
		}
		return isUploadComplete;
	}

/**
 * This method is used to get employee licenses
 *
 * @param employeeID
 * @return List<String>
 * @author xsat794
 * @since Jul 5, 2017
 * Added for Denial of Certification bundled QCs(SS_QC#5120)
 */
@RequestMapping(method = RequestMethod.GET, value="/getLcnsDtls/{employeeID}")
@ResponseBody
public List<String> getEmplLcnsDtls(@PathVariable("employeeID") String employeeID){
	return denialOfCertificationService.getEmplLcnsDtls(employeeID);
}

/**
 * This method is used to download files from filenet service
 *
 * @param employeeId
 * @param eventDetailId
 * @param denyOprnCode
 * @param response
 * @throws DocumentException
 * @author xsat794
 * @since Jul 5, 2017
 * Added for Denial of Certification bundled QCs(SS_QC#5120)
 */
@RequestMapping(method = RequestMethod.GET, value = "/downloadFileFromFileNet")
@ResponseBody
  public void downloadFileFromFileNet(@RequestParam(value = "employeeId") String employeeId, @RequestParam(value = "eventDetailId") Integer eventDetailId,
      @RequestParam(value = "denyOprnCode") String denyOprnCode, HttpServletResponse response) throws DocumentException {
    byte[] byteOutput = null;
    OutputStream responseOutputStream = null;
    HttpHeaders  headers = new HttpHeaders();
    headers.setContentType(MediaType.parseMediaType("application/pdf"));
    String filename = "output.pdf";
    headers.setContentDispositionFormData(filename, filename);
    headers.setCacheControl("must-revalidate, post-check=0, pre-check=0");
    response.setContentType("application/pdf");
    response.setHeader("Content-Disposition", "inline;filename=denialForm");
    try {
      responseOutputStream = response.getOutputStream();
      byteOutput = denialOfCertificationService.downloadFormFromFileNet(employeeId, eventDetailId, denyOprnCode,responseOutputStream);
      if (null == byteOutput) {
        responseOutputStream.write("Error While getting Document, Please Try after some time".getBytes());
      } 
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  /**
   * This method is to get the documents for rebuttal.
   *
   * @param eventDetailID
   * @param rebuttalOprnCode
   * @return List<EventDocumentGridDetail>
   * @author xsat794
   * @since Jul 5, 2017
   * Added for Denial of Certification bundled QCs(SS_QC#5120)
   */
  @RequestMapping(method = RequestMethod.GET, value = "/getRebuttalDocDetails/{eventDetailID}/{rebuttalOprnCode}")
  @ResponseBody
  public List<EventDocumentGridDetail> getRebuttalDocDetails(@PathVariable
  final Integer eventDetailID,@PathVariable final String rebuttalOprnCode) {
    return denialOfCertificationService.getRebuttalDocDetails(eventDetailID,rebuttalOprnCode);

  }
  /**
   * To get the documents for rebuttal on click of view.
   *
   * @param gufnId
   * @param mimeType
   * @param fileName
   * @param response
   * @author xsat794
   * @since Jul 5, 2017
   * Added for Denial of Certification bundled QCs(SS_QC#5120)
   */
  @RequestMapping(method = RequestMethod.GET, value = "/getRebuttalDocs")
  @ResponseBody
  private void getRebuttalDocs(@RequestParam(value = "gufnId") String gufnId,
      @RequestParam(value = "mimeType") String mimeType, @RequestParam(value = "fileName") String fileName, HttpServletRequest request, HttpServletResponse response) throws IOException {
    OutputStream responseOutputStream = null; 
    if (mimeType.equalsIgnoreCase("xls") || mimeType.equalsIgnoreCase("xlsx")) {
      response.setContentType("application/ms-excel");
    } else {
      response.setContentType("application/" + mimeType);
    }
    response.setHeader("Content-Disposition", "inline;filename=" + fileName);
      byte[] byteOutput = null;
      try {
        byteOutput = denialOfCertificationService.downloadFormUsingGuid(gufnId);
          responseOutputStream = response.getOutputStream(); 
          if(null!= byteOutput){ 
          responseOutputStream.write(byteOutput); 
          }else{
          responseOutputStream.write("Error While getting Document, Please Try after some time".getBytes());
          }
      } catch (IOException e) {
        e.printStackTrace();
      }
    }
  /**
   * This method is to employee Details.
   *
   * @param eventDetailID
   * @param rebuttalOprnCode
   * @return List<EventDocumentGridDetail>
   * @author xsat794
   * @since Jul 5, 2017
   * Added for Denial of Certification bundled QCs(SS_QC#5120)
   */
  @RequestMapping(method = RequestMethod.GET, value = "/getEqmEmplDtlsFromWorkItemId/{workItemId}")
  @ResponseBody
  public Map<String,String> getEqmEmplDtlsFromWorkItemId(@PathVariable final Integer workItemId) {
    return denialOfCertificationService.getEqmEmplDtlsFromWorkItemId(workItemId);
  }
  
  /**
   * This method is used to get logged in user name and id
   *
   * @return Map<String,String>
   * @author xsat671
   * @since Jul 27, 2017
   * Added for Denial of Certification bundled QCs(SS_QC#5120)
   */
  @RequestMapping(method = RequestMethod.GET, value = "/getLoggedInUserNameAndEmplId")
  @ResponseBody
  public Map<String,String> getLoggedInUserNameAndEmplId() {
    return denialOfCertificationService.getLoggedInUserNameAndEmplId();
  }
}
