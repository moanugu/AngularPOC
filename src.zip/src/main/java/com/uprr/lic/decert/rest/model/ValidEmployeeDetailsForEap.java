package com.uprr.lic.decert.rest.model;

public class ValidEmployeeDetailsForEap {
	private boolean isEapAlreadyCompleted;
	private boolean isEapInitiated;
	public boolean isEapAlreadyCompleted() {
		return isEapAlreadyCompleted;
	}
	public void setEapAlreadyCompleted(boolean isEapAlreadyCompleted) {
		this.isEapAlreadyCompleted = isEapAlreadyCompleted;
	}
	public boolean isEapInitiated() {
		return isEapInitiated;
	}
	public void setEapInitiated(boolean isEapInitiated) {
		this.isEapInitiated = isEapInitiated;
	}
	
}
