package com.uprr.lic.decert.rest.model;

public class EmployeeViewIncidentPopupResponse {
	
	protected String employeeID;

	  protected String employeeName;

	  protected String region;

	  protected String yearsInCraft;

	  protected String hireDate;

	  protected String dateOnDuty;

	  protected String timeOnDuty;

	  protected String hoursOnDuty;

	  protected String previousRest;

	  protected String lastStopTest;

	  protected String conductorDate;

	  protected String serviceUnit;
	  
	  protected String isFirstDrugPositive; 
	  
	  protected String isFirstAlcoholPositive;
	  
	  protected String primRuleDesc;

	public String getEmployeeID() {
		return employeeID;
	}

	public void setEmployeeID(String employeeID) {
		this.employeeID = employeeID;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getYearsInCraft() {
		return yearsInCraft;
	}

	public void setYearsInCraft(String yearsInCraft) {
		this.yearsInCraft = yearsInCraft;
	}

	public String getHireDate() {
		return hireDate;
	}

	public void setHireDate(String hireDate) {
		this.hireDate = hireDate;
	}

	public String getDateOnDuty() {
		return dateOnDuty;
	}

	public void setDateOnDuty(String dateOnDuty) {
		this.dateOnDuty = dateOnDuty;
	}

	public String getTimeOnDuty() {
		return timeOnDuty;
	}

	public void setTimeOnDuty(String timeOnDuty) {
		this.timeOnDuty = timeOnDuty;
	}

	public String getHoursOnDuty() {
		return hoursOnDuty;
	}

	public void setHoursOnDuty(String hoursOnDuty) {
		this.hoursOnDuty = hoursOnDuty;
	}

	public String getPreviousRest() {
		return previousRest;
	}

	public void setPreviousRest(String previousRest) {
		this.previousRest = previousRest;
	}

	public String getLastStopTest() {
		return lastStopTest;
	}

	public void setLastStopTest(String lastStopTest) {
		this.lastStopTest = lastStopTest;
	}

	public String getConductorDate() {
		return conductorDate;
	}

	public void setConductorDate(String conductorDate) {
		this.conductorDate = conductorDate;
	}

	public String getServiceUnit() {
		return serviceUnit;
	}

	public void setServiceUnit(String serviceUnit) {
		this.serviceUnit = serviceUnit;
	}

	public String getIsFirstDrugPositive() {
		return isFirstDrugPositive;
	}

	public void setIsFirstDrugPositive(String isFirstDrugPositive) {
		this.isFirstDrugPositive = isFirstDrugPositive;
	}

	public String getIsFirstAlcoholPositive() {
		return isFirstAlcoholPositive;
	}

	public void setIsFirstAlcoholPositive(String isFirstAlcoholPositive) {
		this.isFirstAlcoholPositive = isFirstAlcoholPositive;
	}

	public String getPrimRuleDesc() {
		return primRuleDesc;
	}

	public void setPrimRuleDesc(String primRuleDesc) {
		this.primRuleDesc = primRuleDesc;
	} 

}
