package com.uprr.lic.decert.rest.model;

public class DesignateResponse {
	
	private boolean isDesignateSuccess;
	
	//Added for SS_Qc#9622:Start
	private boolean isManagerNotAssigned;

	public boolean isDesignateSuccess() {
		return isDesignateSuccess;
	}

	public void setDesignateSuccess(boolean isDesignateSuccess) {
		this.isDesignateSuccess = isDesignateSuccess;
	}

	public boolean isManagerNotAssigned() {
		return isManagerNotAssigned;
	}

	public void setManagerNotAssigned(boolean isManagerNotAssigned) {
		this.isManagerNotAssigned = isManagerNotAssigned;
	}
	
	

}
