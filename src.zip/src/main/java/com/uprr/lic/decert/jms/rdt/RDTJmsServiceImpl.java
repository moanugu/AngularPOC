/**
 * Class Name   : RDTJmsServiceImpl
 * Description  : 
 * Created By   : Tech Mahindra Ltd.
 * Created On   : 
 *
 * Change History
 * ------------------------------------------------------------  
 *   Date       Changed By     Description
 * ------------------------------------------------------------  
 * 25-Sep-2017   xsat794         Modified for SS_QC_9263
 * ------------------------------------------------------------  
 *  Copyright notice : "Copyright UPRR 2008"
 */
package com.uprr.lic.decert.jms.rdt;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;

import org.apache.xmlbeans.XmlOptions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;

import com.up.www.services.eqmsRdtIntegration.x10.EqmsRdtIntegrationReplyDocument;
import com.up.www.services.eqmsRdtIntegration.x10.EqmsRdtIntegrationReplyType;
import com.up.www.services.eqmsRdtIntegration.x10.ErrorType;
import com.up.www.services.eqmsRdtIntegration.x10.ProcessResultType;
import com.up.www.services.eqmsRdtIntegration.x10.ProcessResultType.ErrorMessage;
import com.up.www.services.eqmsRdtIntegration.x10.ProcessStatusType;
import com.up.www.services.eqmsRdtIntegration.x10.SourceSystemType;
import com.uprr.lic.dataaccess.common.model.DecertDDChoice;
import com.uprr.lic.dataaccess.common.model.EqmEmplDtls;
import com.uprr.lic.dataaccess.common.model.EqmSvcUnit;
import com.uprr.lic.dataaccess.components.common.service.IAuthDao;
import com.uprr.lic.dataaccess.decertification.model.CreateEventDetail;
import com.uprr.lic.dataaccess.decertification.model.EAPDatePopupDetail;
import com.uprr.lic.dataaccess.decertification.model.EqmDcrtVltnRegMpng;
import com.uprr.lic.dataaccess.decertification.model.EventEmployeeDetail;
import com.uprr.lic.dataaccess.decertification.model.EventLocationDetail;
import com.uprr.lic.dataaccess.decertification.model.OtherDetail;
import com.uprr.lic.dataaccess.decertification.model.RDTEmailBean;
import com.uprr.lic.dataaccess.decertification.model.RDTRequestBean;
import com.uprr.lic.dataaccess.decertification.model.RDTResponseBean;
import com.uprr.lic.dataaccess.decertification.model.SearchEventGridDetail;
import com.uprr.lic.dataaccess.decertification.services.interfaces.IDecertificationService;
import com.uprr.lic.dataaccess.masters.service.IReasonService;
import com.uprr.lic.exception.DossException;
import com.uprr.lic.exception.EqmException;
import com.uprr.lic.util.DDChoice;
import com.uprr.lic.util.DecertificationApplicationConstant;
import com.uprr.lic.util.EQMSConstant;

public class RDTJmsServiceImpl implements RDTService {
  
  private final Logger JMS_LOG = LoggerFactory.getLogger("JMS");
  private IDecertificationService decertService;

  private IAuthDao eqmsDao;

  private IReasonService reasonService;

  private JmsTemplate rdtJmsTemplate;

  public RDTJmsServiceImpl(IDecertificationService decertService, IAuthDao eqmsDao, IReasonService reasonService,
      JmsTemplate rdtJmsTemplate) {
    super();
    this.decertService = decertService;
    this.eqmsDao = eqmsDao;
    this.reasonService = reasonService;
    this.rdtJmsTemplate = rdtJmsTemplate;
  }

  private static final Logger LOGGER = LoggerFactory.getLogger(RDTJmsServiceImpl.class);

  private static final String CLASSNAME = RDTJmsServiceImpl.class.getCanonicalName();

  private boolean isRDTEvntProcess = false;

  // private RDTResponseBean rdtResponseBean; //QC#5196 //commented for
  // SS_QC_5196 issue fix

  /**
   * To service all RDT request and as per request type decide the method call.
   * 
   * @param rdtRequestBean
   * @author XSAT803
   * @since Aug 26, 2015 Modified for REQ#588 Phase 1 Part B, QC#5196, QC#5196 issue fix
   */
  public void processRdtRequest(final RDTRequestBean rdtRequestBean) {
    JMS_LOG.debug("processRdtRequest start");
    if (null != rdtRequestBean) {
      RDTResponseBean rdtResponseBean = rdtRequestBean.getRdtResponseBean(); // QC#5196
      // issue
      // fix
      CreateEventDetail createEventBean = new CreateEventDetail();
      try {
        if (null == rdtResponseBean) {
          final String emplId = rdtRequestBean.getEmplId();
          final Calendar eventDate = rdtRequestBean.getViolationDate();
          final String emplPosition = rdtRequestBean.getEmplPosition();
          // Check if employee has valid license or not.
          final boolean isEmplLicensed = decertService.isLicensedEmployee(emplId, eventDate, emplPosition);
          if (isEmplLicensed) {
            // Perform the RDT operation based on RDT Event status.
            isRDTEvntProcess = false;
            createEventBean = checkAndProcessRDTEvntStatus(rdtRequestBean, createEventBean, rdtResponseBean);// QC#5196
                                                                                                             // issue
                                                                                                             // fix
            /*
             * Set get RDT response bean based on RDT operation status if all business validation works otherwise
             * retrieve error response through RDT request bean object.
             */
            rdtResponseBean = isRDTEvntProcess ? getSuccessResponseBean(rdtRequestBean, createEventBean)
                : rdtRequestBean.getRdtResponseBean(); // QC#5196
            // issue
            // fix
          } else {
            rdtResponseBean = getErrorResponseBean(rdtRequestBean, createEventBean,
                DecertificationApplicationConstant.LICENSE_NOT_VALID,
                DecertificationApplicationConstant.LICENSE_NOT_VALID_DESC); // QC#5196
          }
        }
      } catch (DataAccessException exception) {
        rdtResponseBean = getErrorResponseBean(rdtRequestBean, createEventBean,
            DecertificationApplicationConstant.INTERNAL_ERROR, DecertificationApplicationConstant.INTERNAL_ERROR_DESC);
        LOGGER.error("DossException | DataAccessException exception : processRdtRequest(.) method " + exception);
      } catch (final EqmException exception) {
        rdtResponseBean = getErrorResponseBean(rdtRequestBean, createEventBean,
            DecertificationApplicationConstant.INTERNAL_ERROR, DecertificationApplicationConstant.INTERNAL_ERROR_DESC);
        LOGGER.error("Exception : processRdtRequest(.) method :" + exception);
      }
      // Update EQMS response in EQM_MSG_SENT table and send EQMS response
      // to RDT queue.
      sendEQMSResponseToRDT(rdtRequestBean, rdtResponseBean);
      // Notify RDT event email notification for Create/Update/Cancel etc.
      notifyRDTEmailNotification(rdtRequestBean, rdtResponseBean);
    }
    JMS_LOG.debug("processRdtRequest Exit");
  }

  /**
   * This method is used to process RDT message as per RDT Event status like, New, Update, Cancel and Mark Invalid.
   *
   * @param rdtRequestBean
   * @param createEventBean
   * @return
   * @throws DossException
   * @author xsat156
   * @since Dec 29, 2015, QC#5196, QC#5196 issue fix
   */
  private CreateEventDetail checkAndProcessRDTEvntStatus(final RDTRequestBean rdtRequestBean,
      CreateEventDetail createEventBean, RDTResponseBean rdtResponseBean) throws EqmException {// QC#5196
    // issue
    // fix
    final Calendar eventDate = rdtRequestBean.getViolationDate();
    final String eventStatus = rdtRequestBean.getEventStatus();
    final String emplId = rdtRequestBean.getEmplId();
    Integer evntId = null;// Modified for REQ#588 Phase 1 Part B. Start
    if (null != rdtRequestBean.getEqmsEvntId()) {
      evntId = Integer.valueOf(rdtRequestBean.getEqmsEvntId());
    }
    switch (eventStatus) {
      // New RDT Event creation request
      case DecertificationApplicationConstant.RDT_EVENT_STATUS_NEW:
        createEventBean = decertService.getCreateEventBeanByEvntDtlId(null, rdtRequestBean.getRdtSysIntId(), eventDate,
            rdtRequestBean.getViolationTime(), emplId);
        if (null == createEventBean) {
          createEventBean = new CreateEventDetail();
          isRDTEvntProcess = insertRDTEvent(rdtRequestBean, createEventBean);
        } else {
          rdtResponseBean = getErrorResponseBean(rdtRequestBean, createEventBean,
              DecertificationApplicationConstant.EVENT_ALREADY_EXIST,
              DecertificationApplicationConstant.EVENT_ALREADY_EXIST_DESC); // QC#5196
          rdtRequestBean.setRdtResponseBean(rdtResponseBean);// QC#5196
          // issue
          // fix.
        }
        break;
      // Update RDT Event request
      case DecertificationApplicationConstant.RDT_EVENT_STATUS_UPDATE:
        createEventBean = decertService.getCreateEventBeanByEvntDtlId(evntId, rdtRequestBean.getRdtSysIntId(),
            eventDate, rdtRequestBean.getViolationTime(), emplId);
        isRDTEvntProcess = updateRDTEvent(rdtRequestBean, createEventBean);
        break;
      // Mark Invalid RDT Event request
      case DecertificationApplicationConstant.RDT_EVENT_STATUS_MARK_INVALID:
        createEventBean = decertService.getCreateEventBeanByEvntDtlId(evntId, rdtRequestBean.getRdtSysIntId(),
            eventDate, rdtRequestBean.getViolationTime(), emplId);
        isRDTEvntProcess = markInvalidRDTEvent(rdtRequestBean, createEventBean); // QC#5196
        break;
      // Cancel RDT Event request
      case DecertificationApplicationConstant.RDT_EVENT_STATUS_CANCEL:
        createEventBean = decertService.getCreateEventBeanByEvntDtlId(evntId, rdtRequestBean.getRdtSysIntId(),
            eventDate, rdtRequestBean.getViolationTime(), emplId);
        isRDTEvntProcess = cancelRDTEvent(rdtRequestBean, createEventBean); // QC#5196
        break;
      default:
    }
    return createEventBean;
  }

  /**
   * This method is used to process Cancel RDT events as per violation type codes.
   * 
   * @param rdtRequestBean
   * @param createEventBean
   * @return
   * @author xsat803
   * @since Nov 23, 2015 Added for REQ#588 Phase 1 Part B Modified for REQ#588 Phase 2 part 1 QC#5196, QC#5196 issue fix
   *        Modified For SS_QC#6526
   *        Modified for SS_QC_9263
   */
  private boolean cancelRDTEvent(RDTRequestBean rdtRequestBean, CreateEventDetail createEventBean) {
    boolean isEvntCanceled = false;
    final String eventStatus = createEventBean.getEvntStatusFlag();
    if (eventStatus != null && !DecertificationApplicationConstant.FLAG_M.equalsIgnoreCase(eventStatus)
        && !DecertificationApplicationConstant.FLAG_I.equalsIgnoreCase(eventStatus)
        && !DecertificationApplicationConstant.FLAG_L.equalsIgnoreCase(eventStatus)) {
      // Get violation type code
      final String violationTypeCode = rdtRequestBean.getViolationTypeCode();
      switch (violationTypeCode) {
        case DecertificationApplicationConstant.FRA_ALC_ABV_THLD:
          // Process RDT cancel Event for FRA Alcohol Above Threshold
          // Violation type.
          isEvntCanceled = cancelRDTDecertEvent(createEventBean);
          break;
        case DecertificationApplicationConstant.FRA_DRUG:
          // Update RDT message details for FRA Drug Violation type.
          isEvntCanceled = cancelRDTDecertEvent(createEventBean);
          break;
        case DecertificationApplicationConstant.FRA_RFSL:
          // Update RDT message details for FRA Refusal Violation type.
          isEvntCanceled = cancelRDTDecertEvent(createEventBean);
          break;

        // Start : Added For SS_QC#6526
        case DecertificationApplicationConstant.UP_AUTH_RFSL_RDT:// Added
          // for
          // Req#588
          // hase
          // 2(B)

          isEvntCanceled = cancelRDTDecertEvent(createEventBean);
          break;

        case DecertificationApplicationConstant.UP_AUTH_CWKR_RFL_RDT:// Added
          // for
          // Req#588
          // hase
          // 2(B)

          isEvntCanceled = cancelRDTDecertEvent(createEventBean);
          break;

        case DecertificationApplicationConstant.FRA_CWKR_RFL_RDT:// Added
          // for
          // Req#588
          // hase
          // 2(B)

          isEvntCanceled = cancelRDTDecertEvent(createEventBean);
          break;
        case DecertificationApplicationConstant.UP_AUTH_RDT:// Added for
          // Req#588 hase
          // 2(B)

          isEvntCanceled = cancelRDTDecertEvent(createEventBean);
          break;

        case DecertificationApplicationConstant.FRA_ALC_BLW_THLD_RDT:// Added
          // for
          // Req#588
          // hase
          // 2(B)

          isEvntCanceled = cancelRDTDecertEvent(createEventBean);
          break;
        // End : Added For SS_QC#6526
          //Added for SS_QC_9263
        case DecertificationApplicationConstant.UP_RETURN_TO_WORK_RDT:
          isEvntCanceled = cancelRDTDecertEvent(createEventBean);
          break;
        default:
      }
    } else {
      // QC#5196 issue fix changes start
      final RDTResponseBean rdtResponseBean = getErrorResponseBean(rdtRequestBean, createEventBean,
          DecertificationApplicationConstant.EVENT_CANNOT_BE_CANCELLED_MARKINVALID,
          DecertificationApplicationConstant.EVENT_CANNOT_BE_CANCELLED_MARKINVALID_DESC); // QC#5196
      rdtRequestBean.setRdtResponseBean(rdtResponseBean);// QC#5196 issue
      // fix.
    }
    // QC#5196 issue fix changes end
    return isEvntCanceled;
  }

  /**
   * To insert RDT event
   *
   * @param rdtRequestBean
   * @param createEventBean
   * @param emplId
   * @param eventDate
   * @param emplPosition
   * @return
   * @throws DossException
   * @author xsat803
   * @since Nov 18, 2015 Modified for REQ#588 Phase 1 Part B Modifed for QC#5196 issue fix
   */
  private boolean insertRDTEvent(final RDTRequestBean rdtRequestBean, final CreateEventDetail createEventBean)
      throws EqmException {
    boolean isuccess = false;
    final Calendar eventDate = rdtRequestBean.getViolationDate();
    final String emplPosition = rdtRequestBean.getEmplPosition();
    final String emplId = rdtRequestBean.getEmplId();
    // set Event source system as RDT
    createEventBean.setEvntSourceSystem(rdtRequestBean.getSourceSystem());
    // Set RDT Event ID
    createEventBean.setRdtEventID(rdtRequestBean.getRdtSysIntId());
    // Is Drug And Alcohol Event
    createEventBean.setDrugAlcoholRegulation(DecertificationApplicationConstant.BOOLEAN_TRUE);
    createEventBean.setDrugNAlcoholEvent(EQMSConstant.VALUE_YES);
    // Set Violation Type code.
    createEventBean.setViolationTypeCode(rdtRequestBean.getViolationTypeCode());
    // Set Employee position
    createEventBean.setRdtEmplPosition(emplPosition);
    // ---EVENT DETAILS
    // Event Date
    createEventBean.setEventDate(eventDate.getTime());
    // Event Time
    createEventBean.setEventTime(rdtRequestBean.getViolationTime());
    // Set Event Date and Time in bean.
    setEventDate(createEventBean);
    // Manager Comments
    setManagerComments(rdtRequestBean, createEventBean);
    // Is Drug and Alcohol
    createEventBean.setDrugAlcoholRegulation(DecertificationApplicationConstant.BOOLEAN_TRUE);
    // Result Of event
    final List<String> resultOfEvent = new ArrayList<String>();
    resultOfEvent.add(DecertificationApplicationConstant.RESULT_OF_EVENT_NONE);
    createEventBean.setResultOfEventAll(resultOfEvent);
    // Is suspended
    createEventBean.setSuspendFlag(DecertificationApplicationConstant.BOOLEAN_TRUE);
    // ---SETTING DECERT OTHER EVENT DETAILS
    setOtherDetails(rdtRequestBean, createEventBean);
    // SETTING lOCATION DETAILS
    setLocationDetails(rdtRequestBean, createEventBean);
    // Set responsible Manager details
    setRespManagerDtls(createEventBean, emplId);
    // Set Employee Event Details
    setEmployeeEventDetails(createEventBean, rdtRequestBean, emplId);
    // Set Response Bean
    createEventBean.setRdtResponseBean(rdtRequestBean.getRdtResponseBean());
    // setting manage comments for REQ#588 Part_B.
    final String eventDescription = createEventBean.getEventDescriptionValue();
    createEventBean.setMgrCmntId(setMgrCmntIdForRDtEvent(eventDescription));
    // Perform DB operation to create event

    try {
      isuccess = decertService.insertEventDetails(createEventBean, EQMSConstant.DEFAULT_EQMS_USER,
          reasonService.getAllReason(), null, null);
    } catch (DossException e) {
      isuccess = false;
      LOGGER.error("Unable to insert event details due to Doss client", e);
    }
    return isuccess;
  }

  /**
   * To update an RDT event for each Violation type.
   *
   * @param rdtRequestBean
   * @param createEventBean
   * @return
   * @throws DossException
   * @author xsat803
   * @since Nov 23, 2015 Added for REQ#588 Phase 1 Part B, QC#5196, QC#5196 issue fix Modified for SS_QC 6526
   * Modified for SS_QC_9263
   */
  private boolean updateRDTEvent(final RDTRequestBean rdtRequestBean, final CreateEventDetail createEventBean) {
    boolean isEvntUpdated = false;
    if (null != createEventBean && null != createEventBean.getEvntDtlId()) {
      // SS_QC 6526 changes start.
      // to get the value of old regulation
      String oldViolation = createEventBean.getEventEmployeeAll().get(0).getRegulation().getValue();
      createEventBean.getEventEmployeeAll().get(0).setOldRegulation(oldViolation);
      //Added for SS_QC_9080 changes Start
      String oldEvntType=createEventBean.getTypeOfEventAll().getValue();
      createEventBean.setOldEvntType(oldEvntType);
      //Added for SS_QC_9080 changes End
      // SS_QC 6526 changes end.
      switch (rdtRequestBean.getViolationTypeCode()) {
        case DecertificationApplicationConstant.FRA_ALC_ABV_THLD:
          // Update RDT message details for FRA Alcohol Above Threshold
          // Violation type.
          isEvntUpdated = updateDecertRDTEvent(rdtRequestBean, createEventBean);// QC#5196
          // issue
          // fix
          break;
        case DecertificationApplicationConstant.FRA_DRUG:
          // Update RDT message details for FRA Drug Violation type.
          isEvntUpdated = updateDecertRDTEvent(rdtRequestBean, createEventBean);// QC#5196
          // issue
          // fix
          break;
        case DecertificationApplicationConstant.FRA_RFSL:
          // Update RDT message details for FRA Refusal Violation type.
          isEvntUpdated = updateDecertRDTEvent(rdtRequestBean, createEventBean);// QC#5196
          // issue
          // fix
          // SS_QC 6526 changes start.
        case DecertificationApplicationConstant.UP_AUTH_RDT:
          isEvntUpdated = updateDecertRDTEvent(rdtRequestBean, createEventBean);
          break;
        case DecertificationApplicationConstant.FRA_CWKR_RFL_RDT:
          isEvntUpdated = updateDecertRDTEvent(rdtRequestBean, createEventBean);
          break;
        case DecertificationApplicationConstant.UP_AUTH_CWKR_RFL_RDT:
          isEvntUpdated = updateDecertRDTEvent(rdtRequestBean, createEventBean);
          break;
        case DecertificationApplicationConstant.UP_AUTH_RFSL_RDT:
          isEvntUpdated = updateDecertRDTEvent(rdtRequestBean, createEventBean);
          break;
        case DecertificationApplicationConstant.FRA_ALC_BLW_THLD_RDT:
          isEvntUpdated = updateDecertRDTEvent(rdtRequestBean, createEventBean);
          // SS_QC 6526 changes end.
          //SS_QC_9263 changes start
        case DecertificationApplicationConstant.UP_RETURN_TO_WORK_RDT:
          isEvntUpdated = updateDecertRDTEvent(rdtRequestBean, createEventBean);
          break;
        //SS_QC_9263 changes end
        default:
      }
    } else {
      final RDTResponseBean rdtResponseBean = getErrorResponseBean(rdtRequestBean, createEventBean, // QC#5196
          // issue
          // fix
          DecertificationApplicationConstant.EVENT_NOT_FOUND, DecertificationApplicationConstant.EVENT_NOT_FOUND_DESC);// QC#5196
      rdtRequestBean.setRdtResponseBean(rdtResponseBean);// QC#5196 issue
      // fix.
    }
    return isEvntUpdated;
  }

  /**
   * To Mark Invalid the RDT event
   *
   * @param rdtRequestBean
   * @param createEventBean
   * @return
   * @author xsat803
   * @since Nov 23, 2015 Added for REQ#588 Phase 1 Part B Modified for REQ#588 Phase 2 part 1, QC#5196 Modified for
   *        SS_QC 6526, QC#5196 issue fix,Modified for SS_QC_9263
   */
  private boolean markInvalidRDTEvent(final RDTRequestBean rdtRequestBean, final CreateEventDetail createEventBean) {
    boolean isEvntMarkedAsInvalid = false;
    RDTResponseBean rdtResponseBean = null;
    switch (rdtRequestBean.getViolationTypeCode()) {
      case DecertificationApplicationConstant.FRA_ALC_ABV_THLD:
        rdtResponseBean = getErrorResponseBean(rdtRequestBean, createEventBean, // QC#5196
            // issue
            // fix
            DecertificationApplicationConstant.MARK_INVALID_ERROR,
            DecertificationApplicationConstant.MARK_INVALID_ERROR_DESC); // QC#5196
        rdtRequestBean.setRdtResponseBean(rdtResponseBean);// QC#5196 issue
        // fix.
        break;
      case DecertificationApplicationConstant.FRA_RFSL:
          rdtResponseBean = getErrorResponseBean(rdtRequestBean, createEventBean, // QC#5196
              // issue
              // fix
              DecertificationApplicationConstant.MARK_INVALID_ERROR,
              DecertificationApplicationConstant.MARK_INVALID_ERROR_DESC); // QC#5196
          rdtRequestBean.setRdtResponseBean(rdtResponseBean);// QC#5196 issue
          // fix.
          break;
      case DecertificationApplicationConstant.FRA_DRUG:
        // Update RDT message details for FRA Drug Violation type.
        isEvntMarkedAsInvalid = markInvalidDecertEvents(rdtRequestBean, createEventBean);
        break;
      // SS_QC 6526 changes start.
      case DecertificationApplicationConstant.UP_AUTH_RFSL_RDT:// Added for
        // Req#588
        // hase 2(B)
        // Modified for REQ#588 Phase 2(B)
        isEvntMarkedAsInvalid = markInvalidDecertEvents(rdtRequestBean, createEventBean);
        break;

      case DecertificationApplicationConstant.UP_AUTH_CWKR_RFL_RDT:// Added
        // for
        // Req#588
        // hase
        // 2(B)
        // Modified for REQ#588 Phase 2(B)
        isEvntMarkedAsInvalid = markInvalidDecertEvents(rdtRequestBean, createEventBean);
        break;

      case DecertificationApplicationConstant.FRA_CWKR_RFL_RDT:// Added for
        // Req#588
        // hase 2(B)
        // Modified for REQ#588 Phase 2(B)
        isEvntMarkedAsInvalid = markInvalidDecertEvents(rdtRequestBean, createEventBean);
        break;

      case DecertificationApplicationConstant.UP_AUTH_RFSL:
        // Update RDT message details for FRA Refusal Violation type.
        isEvntMarkedAsInvalid = markInvalidDecertEvents(rdtRequestBean, createEventBean);
        break;

      case DecertificationApplicationConstant.UP_AUTH:
        // Update RDT message details for FRA Refusal Violation type.
        isEvntMarkedAsInvalid = markInvalidDecertEvents(rdtRequestBean, createEventBean);
        break;

      case DecertificationApplicationConstant.UP_AUTH_RDT:// Added for Req#588
        // hase 2(B)
        // Modified for REQ#588 Phase 2(B)
        isEvntMarkedAsInvalid = markInvalidDecertEvents(rdtRequestBean, createEventBean);
        break;

      case DecertificationApplicationConstant.FRA_ALC_BLW_THLD_RDT:// Added
        // for
        // Req#588
        // hase
        // 2(B)
        // Modified for REQ#588 Phase 2(B)
        isEvntMarkedAsInvalid = markInvalidDecertEvents(rdtRequestBean, createEventBean);
        break;
        //SS_QC_9263 changes start
      case DecertificationApplicationConstant.UP_RETURN_TO_WORK_RDT:
        isEvntMarkedAsInvalid = markInvalidDecertEvents(rdtRequestBean, createEventBean);
        break; 
       //SS_QC_9263 changes end
      default:
    }
    return isEvntMarkedAsInvalid;
  }

  /**
   * To mark Invalid RDT event.
   *
   * @param createEventBean
   * @return
   * @author xsat803
   * @since Mar 22, 2016 Added for REQ#588 Phase 2 part 1, Modified for REQ#588 Phase 2(B), QC#5196 issue fix
   */
  private boolean markInvalidDecertEvents(final RDTRequestBean rdtRequestBean,
      final CreateEventDetail createEventBean) {
    // boolean isEvntMarkedAsInvalid = false;
    String regulation = createEventBean.getViolationTypeCode();// ADDED FOR
    // REQ#588
    // PHASE
    // 2(B)
    final String eventStatus = createEventBean.getEvntStatusFlag();
    if (eventStatus != null && !DecertificationApplicationConstant.FLAG_C.equalsIgnoreCase(eventStatus)
        && !DecertificationApplicationConstant.FLAG_M.equalsIgnoreCase(eventStatus)
        && !DecertificationApplicationConstant.FLAG_I.equalsIgnoreCase(eventStatus)) {
      decertService.markInvalid(null, createEventBean.getEvntDtlId(), EQMSConstant.DEFAULT_EQMS_USER,
          reasonService.getAllReason(), DecertificationApplicationConstant.FLAG_I, regulation);
    } else {
      final RDTResponseBean rdtResponseBean = getErrorResponseBean(rdtRequestBean, createEventBean, // QC#5196
          // issue
          // fix
          DecertificationApplicationConstant.EVENT_CANNOT_BE_CANCELLED_MARKINVALID,
          DecertificationApplicationConstant.EVENT_CANNOT_BE_CANCELLED_MARKINVALID_DESC); // QC#5196
      rdtRequestBean.setRdtResponseBean(rdtResponseBean);// QC#5196 issue
      // fix.
    }
    return true;
  }

  /**
   * This method is used to set Regulation details
   *
   * @param rdtRequestBean
   * @param emplDtls
   * @param createEventBean
   * @author xsat156
   * @since Dec 29, 2015 Modfied for SS_QC 6526,SS_QC#6526 issue fix.
   * Modified for SS_QC_9129
   */
  private void setRegulationDetails(final RDTRequestBean rdtRequestBean, final EventEmployeeDetail emplDtls,
      final CreateEventDetail createEventBean) {
    final List<EqmDcrtVltnRegMpng> lstEqmDcrtVltnRegMpng = decertService.getRegualtionViolationDtls(
        rdtRequestBean.getViolationTypeCode(), null, null, rdtRequestBean.getEmplPosition());
    String eventStatus = rdtRequestBean.getEventStatus();// getting event
    // status.Added
    // for
    // SS_QC_6526
    String evntType = getCurrentEvntType(rdtRequestBean, createEventBean);// getting
    // type
    // of
    // event
    // Added
    // for
    // SS_QC_6526.
    if (DecertificationApplicationConstant.EVENT_STAT_NEW.equalsIgnoreCase(eventStatus)) {
      if (null != lstEqmDcrtVltnRegMpng && !lstEqmDcrtVltnRegMpng.isEmpty()) {
        // Regulation
        final DecertDDChoice ddChoiceRegulation = new DecertDDChoice();
        ddChoiceRegulation.setValue(lstEqmDcrtVltnRegMpng.get(0).getEqmEvntReg().getEvntReg());
        int evnrRegId = lstEqmDcrtVltnRegMpng.get(0).getEqmEvntReg().getEvntRegId();
        ddChoiceRegulation.setIntKey(evnrRegId);
        emplDtls.setRegulation(ddChoiceRegulation);
        // SS_QC 6526 changes start
        // --Event Details - Event Type
        final DDChoice typeOfEventAll = new DDChoice();
        typeOfEventAll.setValue(evntType);
        if (DecertificationApplicationConstant.EVENT_TYPE_DECERTIFICATION.equalsIgnoreCase(evntType)) {
          typeOfEventAll.setIntKey(DecertificationApplicationConstant.EVENT_TYPE_ID_DECERTIFICATION);
          createEventBean.setTypeOfEventAll(typeOfEventAll);
        } else if (DecertificationApplicationConstant.EVENT_TYPE_OTHER.equalsIgnoreCase(evntType)) {
          typeOfEventAll.setIntKey(DecertificationApplicationConstant.EVENT_TYPE_ID_OTHER);
          createEventBean.setTypeOfEventAll(typeOfEventAll);
        }
        // setting type of event.
        if (DecertificationApplicationConstant.EVENT_TYPE_DECERTIFICATION.equals(evntType)) {
          createEventBean.setDecert(DecertificationApplicationConstant.BOOLEAN_TRUE);
          //SS_QC_9129 changes start
          DecertDDChoice primaryRules = new DecertDDChoice();
          primaryRules=decertService.setPrimRuleForRdt(evnrRegId);
          emplDtls.setPrimaryRules(primaryRules);
        //SS_QC_9129 changes end
        } else if (DecertificationApplicationConstant.EVENT_TYPE_OTHER.equals(evntType)) {
          createEventBean.setOtherEvnt(DecertificationApplicationConstant.BOOLEAN_TRUE);
        }
      }
    }
    // Added for SS_QC 6526
    else if (DecertificationApplicationConstant.EVENT_TYPE_OTHER.equalsIgnoreCase(evntType)
        && eventStatus.equalsIgnoreCase(DecertificationApplicationConstant.EVENT_STATUS_UPDATE)) {
      boolean update = false;
      String oldViolation = createEventBean.getViolationTypeCode();
      String newViolation = rdtRequestBean.getViolationTypeCode();
      update = updateOtherEventRegulations(newViolation, oldViolation);
      if (update) {
        if (newViolation.equalsIgnoreCase(DecertificationApplicationConstant.FRA_ALC_ABV_THLD)
            || newViolation.equalsIgnoreCase(DecertificationApplicationConstant.FRA_DRUG)
            || newViolation.equalsIgnoreCase(DecertificationApplicationConstant.FRA_RFSL)) // SS_QC#6526
        // issue
        // fix.
        {
          createEventBean.setDecert(DecertificationApplicationConstant.BOOLEAN_TRUE);
          createEventBean.setOtherEvnt(DecertificationApplicationConstant.BOOLEAN_FALSE);
          createEventBean.setViolationTypeCode(rdtRequestBean.getViolationTypeCode());// SS_QC#6526
          // issue
          // fix.
          evntType = DecertificationApplicationConstant.EVENT_TYPE_DECERTIFICATION;
          final DecertDDChoice ddChoiceRegulation = new DecertDDChoice();
          ddChoiceRegulation.setValue(lstEqmDcrtVltnRegMpng.get(0).getEqmEvntReg().getEvntReg());
          int evnrRegId = lstEqmDcrtVltnRegMpng.get(0).getEqmEvntReg().getEvntRegId();
          ddChoiceRegulation.setIntKey(evnrRegId);
          emplDtls.setRegulation(ddChoiceRegulation);
          //SS_QC_9129 changes start
          DecertDDChoice primaryRules = new DecertDDChoice();
          primaryRules=decertService.setPrimRuleForRdt(evnrRegId);
          emplDtls.setPrimaryRules(primaryRules);
        //SS_QC_9129 changes end
          // --Event Details - Event Type
          final DDChoice typeOfEventAll = new DDChoice();
          typeOfEventAll.setValue(evntType);
          typeOfEventAll.setIntKey(DecertificationApplicationConstant.EVENT_TYPE_ID_DECERTIFICATION);
          createEventBean.setTypeOfEventAll(typeOfEventAll);
          createEventBean.setDrugNAlcoholEvent(DecertificationApplicationConstant.YES);
          setFirstDrugAndAlcoholDtls(emplDtls, rdtRequestBean, createEventBean);
          setManagerComments(rdtRequestBean, createEventBean);
          // SS_QC_6526 issue fix starts.
          final String eventDescription = createEventBean.getEventDescriptionValue();
          createEventBean.setMgrCmntId(setMgrCmntIdForRDtEvent(eventDescription));
          // SS_QC_6526 issue fix ends.
        } else {
          evntType = DecertificationApplicationConstant.EVENT_TYPE_OTHER;
          final DecertDDChoice ddChoiceRegulation = new DecertDDChoice();
          ddChoiceRegulation.setValue(lstEqmDcrtVltnRegMpng.get(0).getEqmEvntReg().getEvntReg());
          int evnrRegId = lstEqmDcrtVltnRegMpng.get(0).getEqmEvntReg().getEvntRegId();
          ddChoiceRegulation.setIntKey(evnrRegId);
          emplDtls.setRegulation(ddChoiceRegulation);
          final DDChoice typeOfEventAll = new DDChoice();
          typeOfEventAll.setValue(evntType);
          typeOfEventAll.setIntKey(DecertificationApplicationConstant.EVENT_TYPE_ID_OTHER);
          createEventBean.setTypeOfEventAll(typeOfEventAll);
          createEventBean.setViolationTypeCode(rdtRequestBean.getViolationTypeCode());// SS_QC#6526
          // issue
          // fix.
          setFirstDrugAndAlcoholDtls(emplDtls, rdtRequestBean, createEventBean);
          setManagerComments(rdtRequestBean, createEventBean);
        }
      }
    } else if (DecertificationApplicationConstant.EVENT_TYPE_DECERTIFICATION.equalsIgnoreCase(evntType)) {
      createEventBean.setDecert(true);
    }
    // SS_QC 6526 changes end.
  }

  /**
   * This method is used to set Decertification event location details.
   *
   * @param rdtRequestBean
   * @param createEventBean
   * @author XSAT803
   * @since Aug 26, 2015 Modified for REQ#588 Phase 1 Part B
   */
  private void setLocationDetails(final RDTRequestBean rdtRequestBean, CreateEventDetail createEventBean) {
    final EventLocationDetail locationDet = new EventLocationDetail();
    // REQ#599 Phase 1 Part B changes
    final EqmSvcUnit svcUnitDet = decertService.getSvcUnitDetail(rdtRequestBean.getEventSvcUnit(), null, null, null);
    // Region
    final DDChoice ddChoiceReg = new DDChoice();
    ddChoiceReg.setValue(svcUnitDet.getEqmReg().getRegName());
    ddChoiceReg.setIntKey(svcUnitDet.getEqmReg().getRegNbr());
    locationDet.setRegion(ddChoiceReg);
    // Service Unit
    final DDChoice ddChoiceSvcUnit = new DDChoice();
    ddChoiceSvcUnit.setValue(svcUnitDet.getSvcUnitName());
    ddChoiceSvcUnit.setIntKey(svcUnitDet.getSvcUnitNbr());
    locationDet.setServiceUnit(ddChoiceSvcUnit);
    createEventBean.setLocationDetail(locationDet);
    createEventBean.setSvcUnitNbr(svcUnitDet.getSvcUnitNbr());
  }

  /**
   * This method is used to set Decertification other event details.
   *
   * @param rdtRequestBean
   * @param createEventBean
   * @author XSAT803
   * @since Aug 26, 2015
   */
  private void setOtherDetails(final RDTRequestBean rdtRequestBean, final CreateEventDetail createEventBean) {
    OtherDetail otherDetails = new OtherDetail();
    // Is Blue Flag
    otherDetails.setBlueFlag(
        rdtRequestBean.isBlueFlag() ? DecertificationApplicationConstant.YES : DecertificationApplicationConstant.NO);
    // Is Ftx Event
    otherDetails.setFtxEvent(
        rdtRequestBean.isFtxEvent() ? DecertificationApplicationConstant.YES : DecertificationApplicationConstant.NO);
    // Is Event Recorder
    otherDetails.setEventRecorder(rdtRequestBean.isEventRecorder() ? DecertificationApplicationConstant.YES
        : DecertificationApplicationConstant.NO);
    createEventBean.setOtherDetail(otherDetails);
  }

  /**
   * To set Manager comments for Decertification event details.
   *
   * @param rdtRequestBean
   * @param createEventBean
   * @author XSAT803
   * @since Aug 26, 2015 Modified for REQ#588 Part_B., REQ#588 Phase 2 part 1 Modified for SS_QC 6526. Modified for
   *        REQ#588 code review comments.,Modified for SS_QC_9263
   */
  private void setManagerComments(final RDTRequestBean rdtRequestBean, final CreateEventDetail createEventBean) {
    Map<String, String> mgrCmnt = new HashMap<String, String>();
    List<Object> mgrCmntList = decertService.getMngrCmntsForRDT();
    if (mgrCmntList != null && !mgrCmntList.isEmpty()) {
      final Iterator<Object> objIterator = mgrCmntList.iterator();
      while (objIterator.hasNext()) {
        final Object[] cmnts = (Object[]) objIterator.next();
        mgrCmnt.put((String) cmnts[DecertificationApplicationConstant.INTEGER_1],
            (String) cmnts[DecertificationApplicationConstant.INTEGER_2]);
      }
    }

    if (DecertificationApplicationConstant.FRA_ALC_ABV_THLD.equals(rdtRequestBean.getViolationTypeCode())
        && DecertificationApplicationConstant.FLAG_Y.equals(rdtRequestBean.getFirstAlcoholPositive())) {
      createEventBean.setEventDescriptionValue(DecertificationApplicationConstant.FRA_ALCO_FIRST_VIOLATION);
      createEventBean.setMngrComments(mgrCmnt.get(createEventBean.getEventDescriptionValue()));
    } else if (DecertificationApplicationConstant.FRA_ALC_ABV_THLD.equals(rdtRequestBean.getViolationTypeCode())
        && DecertificationApplicationConstant.FLAG_N.equals(rdtRequestBean.getFirstAlcoholPositive())) {
      createEventBean.setEventDescriptionValue(DecertificationApplicationConstant.FRA_ALCO_MULTIPLE_VIOLATION);// Added
      createEventBean.setMngrComments(mgrCmnt.get(createEventBean.getEventDescriptionValue())); // for

    } else if (DecertificationApplicationConstant.FRA_DRUG.equals(rdtRequestBean.getViolationTypeCode())
        && DecertificationApplicationConstant.FLAG_Y.equals(rdtRequestBean.getFirstDrugPositive())) {
      createEventBean.setEventDescriptionValue(DecertificationApplicationConstant.FRA_DRUG_FIRST_VIOLATION);// Added
      // for
      createEventBean.setMngrComments(mgrCmnt.get(createEventBean.getEventDescriptionValue())); // REQ#588

    } else if (DecertificationApplicationConstant.FRA_DRUG.equals(rdtRequestBean.getViolationTypeCode())
        && DecertificationApplicationConstant.FLAG_N.equals(rdtRequestBean.getFirstDrugPositive())) {
      createEventBean.setEventDescriptionValue(DecertificationApplicationConstant.FRA_DRUG_MULTIPLE_VIOLATION);// Added
      createEventBean.setMngrComments(mgrCmnt.get(createEventBean.getEventDescriptionValue())); // for

    } else if (DecertificationApplicationConstant.FRA_RFSL.equals(rdtRequestBean.getViolationTypeCode())) {
      createEventBean.setEventDescriptionValue(DecertificationApplicationConstant.FRA_REFUSAL_VIOLATION);// Added
      // for
      createEventBean.setMngrComments(mgrCmnt.get(createEventBean.getEventDescriptionValue())); // REQ#588
      // Part_B
    } /*
       * else if (DecertificationApplicationConstant.FRA_RFSL.equals( rdtRequestBean.getViolationTypeCode()) &&
       * DecertificationApplicationConstant.FLAG_N.equals(rdtRequestBean. getFirstDrugPositive())) {
       * createEventBean.setMngrComments( DecertificationApplicationConstant. MGR_CMNTS_FRA_DRUG_SECOND_DRUG_VIOLATION);
       * createEventBean.setEventDescriptionValue( DecertificationApplicationConstant.FRA_DRUG_MULTIPLE_VIOLATION);/ /
       * Added }
       */
    // SS_QC 6526 changes start.
    else if (DecertificationApplicationConstant.UP_AUTH_RDT.equals(rdtRequestBean.getViolationTypeCode())) {
      createEventBean.setEventDescriptionValue(DecertificationApplicationConstant.UP_AUTH);
      createEventBean.setMngrComments(mgrCmnt.get(createEventBean.getEventDescriptionValue()));
    } else if (DecertificationApplicationConstant.FRA_ALC_BLW_THLD_RDT.equals(rdtRequestBean.getViolationTypeCode())) {
      createEventBean.setEventDescriptionValue(DecertificationApplicationConstant.FRA_ALC_BLW_THLD);
      createEventBean.setMngrComments(mgrCmnt.get(createEventBean.getEventDescriptionValue()));
    } else if (DecertificationApplicationConstant.FRA_CWKR_RFL_RDT.equals(rdtRequestBean.getViolationTypeCode())) {
      createEventBean.setEventDescriptionValue(DecertificationApplicationConstant.FRA_CWKR_RFL);
      createEventBean.setMngrComments(mgrCmnt.get(createEventBean.getEventDescriptionValue()));
    } else if (DecertificationApplicationConstant.UP_AUTH_CWKR_RFL_RDT.equals(rdtRequestBean.getViolationTypeCode())) {
      createEventBean.setEventDescriptionValue(DecertificationApplicationConstant.UP_AUTH_CWKR_RFL);
      createEventBean.setMngrComments(mgrCmnt.get(createEventBean.getEventDescriptionValue()));
    } else if (DecertificationApplicationConstant.UP_AUTH_RFSL_RDT.equals(rdtRequestBean.getViolationTypeCode())) {
      createEventBean.setEventDescriptionValue(DecertificationApplicationConstant.UP_AUTH_RFSL);
      createEventBean.setMngrComments(mgrCmnt.get(createEventBean.getEventDescriptionValue()));
    }// SS_QC 6526 changes end.
    //SS_QC_9263 changes start
    else if (DecertificationApplicationConstant.UP_RETURN_TO_WORK_RDT.equals(rdtRequestBean.getViolationTypeCode())) {
      createEventBean.setEventDescriptionValue(DecertificationApplicationConstant.UP_AUTH);
      createEventBean.setMngrComments(mgrCmnt.get(createEventBean.getEventDescriptionValue()));
    }
   //SS_QC_9263 changes end
  }

  /**
   * @return the decertService
   */
  public IDecertificationService getDecertService() {
    return decertService;
  }

  /**
   * @param decertService
   *          the decertService to set
   */
  public void setDecertService(IDecertificationService decertService) {
    this.decertService = decertService;
  }

  /**
   * @return the eqmsDao
   */
  public IAuthDao getEqmsDao() {
    return eqmsDao;
  }

  /**
   * @param eqmsDao
   *          the eqmsDao to set
   */
  public void setEqmsDao(IAuthDao eqmsDao) {
    this.eqmsDao = eqmsDao;
  }

  /**
   * @param reasonService
   *          the reasonService to set
   */
  public void setReasonService(final IReasonService reasonService) {
    this.reasonService = reasonService;
  }

  /**
   * This method is used to set Event date in CreateEventDetail Bean object.
   *
   * @param createEventBean
   * @author xsat156
   * @since Sep 6, 2015
   */
  private void setEventDate(final CreateEventDetail createEventBean) {
    final Calendar evntDateCalendar = Calendar.getInstance();
    final Date evntDate = createEventBean.getEventDate();
    final String evntTime = createEventBean.getEventTime();
    final String time[] = evntTime.split(":");
    evntDateCalendar.setTime(evntDate);
    if (time != null && time[0] != null) {
      evntDateCalendar.set(Calendar.HOUR_OF_DAY, Integer.parseInt(time[0]));
    }
    if (time != null && time[1] != null) {
      evntDateCalendar.set(Calendar.MINUTE, Integer.parseInt(time[1]));
    }
    createEventBean.setEventDateCalendar(evntDateCalendar);
  }

  /**
   * To send the response text from EQMS to RDT.
   * 
   * @param rdtResponseBean
   * @return
   * @author xsat803
   * @since Nov 24, 2015 Added for REQ#588
   */
  private boolean sendResponse(final RDTResponseBean rdtResponseBean) {
    boolean isRDTRespSend = false;
    try {
      final String responseXmlString = getResponseXmlString(rdtResponseBean);
      final String rdtSysIntId = rdtResponseBean.getRdtSysIntId();

      if (rdtJmsTemplate != null && rdtJmsTemplate != null) {
        rdtJmsTemplate.send(new MessageCreator() {
          public Message createMessage(Session session) throws JMSException {
            final Message responseMessage = (session).createTextMessage(responseXmlString);
            responseMessage.setJMSCorrelationID(rdtSysIntId);
            return responseMessage;
          }
        });
        isRDTRespSend = true;
      }
    } catch (final Exception ex) {
      LOGGER.error("EQMS_RDT: Error :sendResponse() :  Method :" + CLASSNAME);
    }
    return isRDTRespSend;
  }

  /**
   * This method is used to prepare response in order to send it to RDT team.
   * 
   * @param rdtResponseBean
   * @return
   * @throws Exception
   * @author xsat156
   * @since Sep 2, 2015 Modified for REQ#588 Phase 1 Part B
   */
  private final String getResponseXmlString(final RDTResponseBean rdtResponseBean) {
    String rdtResponseMsg = null;
    final EqmsRdtIntegrationReplyDocument rdtResponseDocument = EqmsRdtIntegrationReplyDocument.Factory.newInstance();
    final XmlOptions xmlOptions = new XmlOptions().setSaveNamespacesFirst().setUseDefaultNamespace();
    final EqmsRdtIntegrationReplyType rdtResponse = rdtResponseDocument.addNewEqmsRdtIntegrationReply();

    final ProcessResultType processResult = rdtResponse.addNewProcessResult();
    if (null != rdtResponseBean.getErrorDesc() && null != rdtResponseBean.getErrorType()) {
      final ErrorMessage errorMsg = processResult.addNewErrorMessage();
      errorMsg.setErrorType(getErrorMsg(rdtResponseBean.getErrorType()));
      errorMsg.setErrorDescription(rdtResponseBean.getErrorDesc());
      processResult.setErrorMessage(errorMsg);
    }
    if (null != rdtResponseBean.getProcessStatus()) {
      processResult
          .setProcessStatus((ProcessStatusType.SUCCESS.toString().equalsIgnoreCase(rdtResponseBean.getProcessStatus()))
              ? ProcessStatusType.SUCCESS : ProcessStatusType.ERROR);
      rdtResponse.setProcessResult(processResult);
    }
    if (null != rdtResponseBean.getEqmsEvntId()) {
      rdtResponse.setEqmsEventId(rdtResponseBean.getEqmsEvntId()); // REQ#588
      // Phase
      // 1
      // Part
      // B
    }
    if (null != rdtResponseBean.getRdtSysIntId()) {
      rdtResponse.setRdtSystemInternalId(rdtResponseBean.getRdtSysIntId());
    }
    if (null != rdtResponseBean.getSourceSystem()) {
      rdtResponse.setSourceSystem((SourceSystemType.EQMS.toString().equalsIgnoreCase(rdtResponseBean.getSourceSystem()))
          ? SourceSystemType.EQMS : SourceSystemType.RDT);
    }
    if (null != rdtResponseBean.getSysDateTime()) {
      rdtResponse.setSystemDateTime(rdtResponseBean.getSysDateTime());
    }
    if (null != rdtResponseBean.getEmployeeId()) {
      rdtResponse.setEmployeeId(rdtResponseBean.getEmployeeId()); // REQ#588
      // Phase
      // 1
      // Part
      // B
    }
    rdtResponseDocument.setEqmsRdtIntegrationReply(rdtResponse);
    try {
      if (rdtResponseDocument.validate(xmlOptions)) {
        rdtResponseMsg = rdtResponseDocument.xmlText(xmlOptions);
      } else {
        LOGGER.error("ERROR MESSAGE:: UNABLE TO CONVERT MESSAGE TO RESPONSE XML : INVALID XML BEAN OBJECT");
      }
    } catch (Exception exception) {
      LOGGER.error("Exception in getResponseXmlString() method " + exception);
    }

    return rdtResponseMsg;
  }

  /**
   * @return the rdtJmsTemplate
   */
  public JmsTemplate getRdtJmsTemplate() {
    return rdtJmsTemplate;
  }

  /**
   * @param rdtJmsTemplate
   *          the rdtJmsTemplate to set
   */
  public void setRdtJmsTemplate(JmsTemplate rdtJmsTemplate) {
    this.rdtJmsTemplate = rdtJmsTemplate;
  }

  /**
   * This method is used to prepare RDT success response bean details.
   * 
   * @param rdtSysInternalId
   * @return RDTResponseBean
   * @author xsat803
   * @since Aug 21, 2015 Modified for REQ#588 Phase 1 Part B, QC#5196, QC#5196 issue fix
   */
  private RDTResponseBean getSuccessResponseBean(final RDTRequestBean rdtRequestBean,
      final CreateEventDetail createEventBean) {
    final RDTResponseBean rdtResponseBean = new RDTResponseBean();// QC#5196
    // issue
    // fix
    rdtResponseBean.setSourceSystem(DecertificationApplicationConstant.SOURCE_SYSTEM_EQMS);
    rdtResponseBean.setRdtSysIntId(rdtRequestBean.getRdtSysIntId());
    if (null != createEventBean && null != createEventBean.getEvntDtlId()) {
      rdtResponseBean.setEqmsEvntId(createEventBean.getEvntDtlId().toString());
    } else if (null != rdtRequestBean && null != rdtRequestBean.getEqmsEvntId()) {
      rdtResponseBean.setEqmsEvntId(rdtRequestBean.getEqmsEvntId());
    }
    rdtResponseBean.setEmployeeId(rdtRequestBean.getEmplId());
    rdtResponseBean.setProcessStatus(DecertificationApplicationConstant.SUCCESS);
    rdtResponseBean.setSysDateTime(Calendar.getInstance());
    return rdtResponseBean;
  }

  /**
   * To get error messages
   *
   * @param errorType
   * @return
   * @author xsat803
   * @since Sep 10, 2015 Modified for QC#5196
   */
  private ErrorType.Enum getErrorMsg(final String errorType) {
    ErrorType.Enum errorStr = ErrorType.INTERNAL_ERROR;
    if (ErrorType.EMPL_ID_NOT_EXISTS.toString().endsWith(errorType)) {
      errorStr = ErrorType.EMPL_ID_NOT_EXISTS;
    } else if (ErrorType.INVALID_EMPL_ID.toString().endsWith(errorType)) {
      errorStr = ErrorType.INVALID_EMPL_ID;
    } else if (ErrorType.INVALID_EVENT_STATUS.toString().endsWith(errorType)) {
      errorStr = ErrorType.INVALID_EVENT_STATUS;
    } else if (ErrorType.INVALID_SVC_UNIT.toString().endsWith(errorType)) {
      errorStr = ErrorType.INVALID_SVC_UNIT;
    } else if (ErrorType.PARSING_ERROR.toString().endsWith(errorType)) {
      errorStr = ErrorType.PARSING_ERROR;
    } else if (ErrorType.INVALID_EVENT_DATE.toString().endsWith(errorType)) {
      errorStr = ErrorType.INVALID_EVENT_DATE;
    } else if (ErrorType.INTERNAL_ERROR.toString().endsWith(errorType)) {
      errorStr = ErrorType.INTERNAL_ERROR;
    } else if (ErrorType.INVALID_EVENT_TIME.toString().endsWith(errorType)) {
      errorStr = ErrorType.INVALID_EVENT_TIME;
    } else if (ErrorType.EVENT_ALREADY_EXIST.toString().endsWith(errorType)) {
      errorStr = ErrorType.EVENT_ALREADY_EXIST;
    } else if (ErrorType.EVENT_NOT_FOUND.toString().endsWith(errorType)) {
      errorStr = ErrorType.EVENT_NOT_FOUND;
    } else if (ErrorType.INVALID_EMPL_POSITION.toString().endsWith(errorType)) {
      errorStr = ErrorType.INVALID_EMPL_POSITION;
    } else if (ErrorType.INVALID_VIOLATION_TYPE.toString().endsWith(errorType)) {
      errorStr = ErrorType.INVALID_VIOLATION_TYPE;
    } else if (ErrorType.INVALID_EAP_DATE.toString().endsWith(errorType)) {
      errorStr = ErrorType.INVALID_EAP_DATE;
    } else if (ErrorType.MARK_INVALID_ERROR.toString().endsWith(errorType)) {
      errorStr = ErrorType.MARK_INVALID_ERROR;
    } else if (ErrorType.LICENSE_NOT_VALID.toString().endsWith(errorType)) {
      errorStr = ErrorType.LICENSE_NOT_VALID;
    } else if (ErrorType.EVENT_CANNOT_BE_CANCELLED_MARKINVALID.toString().endsWith(errorType)) {
      errorStr = ErrorType.EVENT_CANNOT_BE_CANCELLED_MARKINVALID;
    } else if (ErrorType.EVENT_CANNOT_BE_UPDATED.toString().endsWith(errorType)) {
      errorStr = ErrorType.EVENT_CANNOT_BE_UPDATED;
    } else if (ErrorType.NOT_TEY_EMPLOYEE.toString().endsWith(errorType)) {
      errorStr = ErrorType.NOT_TEY_EMPLOYEE;
    }
    return errorStr;
  }

  /**
   * To set the manager comment id in DCRT_OTH_EVNT_DTLS table
   *
   * @param eventDEscription
   * @return
   * @author xsat794
   * @since Dec 8, 2015
   */
  private Integer setMgrCmntIdForRDtEvent(final String eventDEscription) {
    final Integer mgrCmntId = decertService.setMgrCmntIdForRDTEvent(eventDEscription);
    return mgrCmntId;
  }

  /**
   * This method is used to set Responsible Manager Details.
   *
   * @param createEventBean
   * @param emplId
   * @author xsat156
   * @since Dec 29, 2015
   */
  private void setRespManagerDtls(final CreateEventDetail createEventBean, final String emplId) {
    final EqmEmplDtls primMgrlDtls = eqmsDao.getPrimaryManager(emplId);
    if (null != primMgrlDtls) {
      createEventBean.setRespMngr(primMgrlDtls.getEmplId());
    } else {
      final String respMgr = (decertService.getSUnitAdmin(createEventBean.getSvcUnitNbr())).getEmplId();
      createEventBean.setRespMngr(respMgr);
    }
  }

  /**
   * This method is used to set employee event detail in CreateEventDetail bean object.
   *
   * @param createEventBean
   * @param rdtRequestBean
   * @param emplId
   * @author xsat156
   * @since Dec 29, 2015
   */
  private void setEmployeeEventDetails(final CreateEventDetail createEventBean, final RDTRequestBean rdtRequestBean,
      final String emplId) {
    // ---SETTING EMPLOYEE DETAILS
    final List<EventEmployeeDetail> eventEmployeeAll = new ArrayList<EventEmployeeDetail>();
    final EventEmployeeDetail emplDtls = new EventEmployeeDetail();
    // Employee Id
    emplDtls.setEmployeeID(emplId);
    // Employee Name
    emplDtls.setEmployeeName(decertService.getEmployeeNameByEmployeeID(emplId));
    // Is Suspended
    emplDtls.setSuspended(DecertificationApplicationConstant.YES);
    // Position
    final Integer actualPosSeq = decertService.getPosSeqByPosCode(createEventBean.getRdtEmplPosition());
    emplDtls.setActualPosSeq(actualPosSeq);
    emplDtls.setStrPosition(createEventBean.getRdtEmplPosition());
    final DDChoice position = decertService.getConventionalPos(actualPosSeq);
    if (position != null) {
      position.setValue(String.valueOf(position.getIntKey()));
      emplDtls.setPosition(position);
      emplDtls.setCnvtJobTypePosSeq(position.getIntKey());
    }

    // Set Regulation Details for given violation and Position of employee
    setRegulationDetails(rdtRequestBean, emplDtls, createEventBean);
    // set First Drug and Alcohol events
    setFirstDrugAndAlcoholDtls(emplDtls, rdtRequestBean, createEventBean);
    // Add the employee details in Event Employee list.
    eventEmployeeAll.add(emplDtls);
    createEventBean.setEventEmployeeAll(eventEmployeeAll);
  }

  /**
   * This method is used to set First alcohol and Drug details.
   *
   * @param emplDtls
   * @param rdtRequestBean
   * @param createEventBean
   * @author xsat156
   * @since Dec 29, 2015
   */
  private void setFirstDrugAndAlcoholDtls(final EventEmployeeDetail emplDtls, final RDTRequestBean rdtRequestBean,
      final CreateEventDetail createEventBean) {
    // set First Drug and Alcohol events
    if (DecertificationApplicationConstant.FLAG_Y.equals(rdtRequestBean.getFirstDrugPositive())) {
      emplDtls.setFirstDAndAEvent(DecertificationApplicationConstant.TRUE_VALUE);
      createEventBean.setFirDrug(true);// setting the value in create
      // event bean.
    } else {
      emplDtls.setFirstDAndAEvent(DecertificationApplicationConstant.FALSE_VALUE);
    }
    if (DecertificationApplicationConstant.FLAG_Y.equals(rdtRequestBean.getFirstAlcoholPositive())) {
      emplDtls.setFirstAlcoholEvent(DecertificationApplicationConstant.TRUE_VALUE);
      createEventBean.setFirAlco(true);// setting the value in create
      // event bean.
    } else {
      emplDtls.setFirstAlcoholEvent(DecertificationApplicationConstant.FALSE_VALUE);
    }
  }

  /**
   * This method is used to prepare RDT error response bean details.
   *
   * @param rdtRequestBean
   * @param createEventBean
   * @return
   * @author xsat156
   * @since Dec 29, 2015, QC#5196, QC#5196 issue fix
   */
  private RDTResponseBean getErrorResponseBean(final RDTRequestBean rdtRequestBean,
      final CreateEventDetail createEventBean, final String errorType, final String errorDesc) {
    final RDTResponseBean rdtResponseBean = new RDTResponseBean();// QC#5196
    // issue
    // fix
    rdtResponseBean.setSourceSystem(DecertificationApplicationConstant.SOURCE_SYSTEM_EQMS);
    rdtResponseBean.setRdtSysIntId(rdtRequestBean.getRdtSysIntId());
    if (null != createEventBean && null != createEventBean.getEvntDtlId()) {
      rdtResponseBean.setEqmsEvntId(createEventBean.getEvntDtlId().toString());
    } else if (null != rdtRequestBean && null != rdtRequestBean.getEqmsEvntId()) {
      rdtResponseBean.setEqmsEvntId(rdtRequestBean.getEqmsEvntId());
    }
    rdtResponseBean.setEmployeeId(rdtRequestBean.getEmplId());
    rdtResponseBean.setProcessStatus(DecertificationApplicationConstant.ERROR);
    rdtResponseBean.setErrorType(null != errorType ? errorType : DecertificationApplicationConstant.INTERNAL_ERROR);
    rdtResponseBean
        .setErrorDesc(null != errorDesc ? errorDesc : DecertificationApplicationConstant.INTERNAL_ERROR_DESC);
    rdtResponseBean.setSysDateTime(Calendar.getInstance());
    return rdtResponseBean;
  }

  /**
   * This method is used to send EQMS response to RDT.
   *
   * @param rdtRequestBean
   * @param rdtResponseBean
   * @author xsat156
   * @since Dec 29, 2015
   */
  private void sendEQMSResponseToRDT(final RDTRequestBean rdtRequestBean, final RDTResponseBean rdtResponseBean) {
    final String responseMsg = getResponseXmlString(rdtResponseBean);
    if (null != responseMsg) {
      final boolean msgSentUpdated = decertService.updateRDTMsgIntoEqmMsgSent(responseMsg,
          rdtRequestBean.getPrimaryKeyRDTEqmMsgSentId());
      sendResponse(rdtResponseBean);
    }
  }

  /**
   * This method is used to notify and triggered RDT email notification.
   *
   * @param rdtRequestBean
   * @param rdtResponseBean
   * @author xsat156
   * @since Dec 29, 2015
   */
  private void notifyRDTEmailNotification(final RDTRequestBean rdtRequestBean, final RDTResponseBean rdtResponseBean) {
    final String responseMsg = getResponseXmlString(rdtResponseBean);
    final String requestMsg = rdtRequestBean.getRequestXMLMessage();// Added
    // for
    // REQ#588
    // Checking for the ERROR status.
    if (DecertificationApplicationConstant.ERROR.equalsIgnoreCase(rdtResponseBean.getProcessStatus())) {
      final RDTEmailBean rdtEmailNotification = new RDTEmailBean();
      // setting the values into bean.
      rdtEmailNotification.setRequestMsg(requestMsg);
      rdtEmailNotification.setResponseMsg(responseMsg);
      rdtEmailNotification.setEvntStatus(DecertificationApplicationConstant.EQMS_RDT_STATUS_REJECTED);
      // Trigger RDT email notification.
      decertService.sendEmailNotificationForRDTEvent(rdtEmailNotification);
    }
  }

  /**
   * This method is used to update RDT message details for FRA Alcohol Above Threshold Violation types.
   *
   * @param rdtRequestBean
   * @param createEventBean
   * @return
   * @throws DossException
   * @author xsat156
   * @since Dec 29, 2015, QC#5196, QC#5196 issue fix Modified for 6526.
   */
  private boolean updateDecertRDTEvent(final RDTRequestBean rdtRequestBean, final CreateEventDetail createEventBean) {
    boolean isEvntUpdated = false;
    boolean anyUpdate = false;
    boolean eapUpdate = false;
    final String emplId = rdtRequestBean.getEmplId();
    final Integer evntId = Integer.valueOf(rdtRequestBean.getEqmsEvntId());
    if (null != createEventBean.getEvntStatusFlag()
        && !DecertificationApplicationConstant.FLAG_C.equalsIgnoreCase(createEventBean.getEvntStatusFlag())
        && !DecertificationApplicationConstant.FLAG_M.equalsIgnoreCase(createEventBean.getEvntStatusFlag())
        && !DecertificationApplicationConstant.FLAG_I.equalsIgnoreCase(createEventBean.getEvntStatusFlag())
        && !DecertificationApplicationConstant.FLAG_L.equalsIgnoreCase(createEventBean.getEvntStatusFlag())) {

      final boolean isAnyEmplOfEvntDec = decertService.isAnyEmployeeOfEventDecertified(evntId);
      final boolean isRevoConf = decertService.isRevocationConfirmed(evntId, emplId);
      final boolean isAnyEmplReinstated = decertService.isAnyEmployeeReinstated(evntId);
      boolean update = false;// SS_QC#6526

      // Check and update Employee Position and regulation details.
      if (!isAnyEmplOfEvntDec && !isRevoConf && !isAnyEmplReinstated) {
        // SS_QC_6526 chnages start.
        if (!createEventBean.getEventEmployeeAll().get(0).getEmployeePosition()
            .equalsIgnoreCase(rdtRequestBean.getEmplPosition())
            || !createEventBean.getViolationTypeCode().equalsIgnoreCase(rdtRequestBean.getViolationTypeCode())) {
          // boolean update = false;commented For SS_QC#6526
          update = updateOtherEventRegulations(rdtRequestBean.getViolationTypeCode(),
              createEventBean.getViolationTypeCode());
          if (update || !createEventBean.getEventEmployeeAll().get(0).getEmployeePosition()
              .equalsIgnoreCase(rdtRequestBean.getEmplPosition())) {
            checkAndSetUpdatedEmplPosAndRegDtls(rdtRequestBean, createEventBean);
            anyUpdate = true;
          }
        }
        // SS_QC_6526 changes end.
      }
      // Check Service unit change details.
      if (!createEventBean.getSvcUnitNbr().equals(rdtRequestBean.getEventSvcUnit())) {
        setLocationDetails(rdtRequestBean, createEventBean);
        anyUpdate = true;
      }
      // Set Responsible Manager details.
      setRespManagerDtls(createEventBean, emplId);

      // Check and update EAP Details.
      if (!isAnyEmplReinstated) {
    	  String evntType = getCurrentEvntType(rdtRequestBean, createEventBean);
    	  if (DecertificationApplicationConstant.EVENT_TYPE_DECERTIFICATION.equalsIgnoreCase(evntType)) {
    	      createEventBean.setDecert(true);
    	    }
        eapUpdate = checkAndUpdateEAPDetails(rdtRequestBean, createEventBean);
        isEvntUpdated = eapUpdate;
      }
      if (anyUpdate && !eapUpdate) // modified for SS_QC_6526
      {
        try {
          isEvntUpdated = decertService.updateEventDetails(createEventBean, EQMSConstant.DEFAULT_EQMS_USER, null,
              reasonService.getAllReason(), null);
        } catch (DossException e) {
          LOGGER.error("Error updating updateEventDetails ", e);
        }
      } else {
        if (isAnyEmplOfEvntDec || isRevoConf || isAnyEmplReinstated) {
          final RDTResponseBean rdtResponseBean = getErrorResponseBean(rdtRequestBean, createEventBean, // QC#5196
              // issue
              // fix
              DecertificationApplicationConstant.EVENT_CANNOT_BE_UPDATED,
              DecertificationApplicationConstant.EVENT_CANNOT_BE_UPDATED_DESC);// QC#5196
          rdtRequestBean.setRdtResponseBean(rdtResponseBean);// QC#5196
          // issue
          // fix.
        } // Start : Added For SS_QC#6526
        if (!update) {
          final RDTResponseBean rdtResponseBean = getErrorResponseBean(rdtRequestBean, createEventBean, // QC#5196
              // issue
              // fix
              DecertificationApplicationConstant.EVENT_CANNOT_BE_UPDATED,
              DecertificationApplicationConstant.EVENT_VIOLATION_CANNOT_BE_UPDATED_DESC);// QC#5196
          rdtRequestBean.setRdtResponseBean(rdtResponseBean);// QC#5196
          // issue
          // fix.
        } // Ends : Added For SS_QC#6526
      }
    }
    return isEvntUpdated;
  }

  /**
   * This method is used to set updated employee position details and Regulation details as per RDT message.
   *
   * @param rdtRequestBean
   * @param createEventBean
   * @return
   * @author xsat156
   * @since Dec 29, 2015
   */
  private boolean checkAndSetUpdatedEmplPosAndRegDtls(final RDTRequestBean rdtRequestBean,
      final CreateEventDetail createEventBean) {
    boolean isEmplPosAndRegDtlsUpdate = false;
    // Position change check
    final EventEmployeeDetail emplDtls = createEventBean.getEventEmployeeAll() != null
        ? createEventBean.getEventEmployeeAll().get(0) : null;
    if (emplDtls != null && !emplDtls.getPosition().equals(rdtRequestBean.getEmplPosition())) {
      final Integer actualPosSeq = decertService.getPosSeqByPosCode(rdtRequestBean.getEmplPosition());
      emplDtls.setActualPosSeq(actualPosSeq);
      emplDtls.setStrPosition(createEventBean.getRdtEmplPosition());
      final DDChoice position = decertService.getConventionalPos(actualPosSeq);
      if (position != null) {
        position.setValue(String.valueOf(position.getIntKey()));
        emplDtls.setPosition(position);
        emplDtls.setCnvtJobTypePosSeq(position.getIntKey());
      }
      // Set regulation details as per updated Employee position details.
      setRegulationDetails(rdtRequestBean, emplDtls, createEventBean);
      isEmplPosAndRegDtlsUpdate = true;
    }
    return isEmplPosAndRegDtlsUpdate;
  }

  /**
   * This method is used to check EAP details change in RDT message if any then update EQM_DCRT_EMPL_STAT table with
   * details.
   *
   * @param rdtRequestBean
   * @return
   * @author xsat156
   * @since Dec 29, 2015, QC#5196, REQ#588 Phase 2 Part B, QC#5196 issue fix
   */
  private boolean checkAndUpdateEAPDetails(final RDTRequestBean rdtRequestBean,
      final CreateEventDetail createEventBean) {
    final Integer evntId = Integer.valueOf(rdtRequestBean.getEqmsEvntId());
    final String emplId = rdtRequestBean.getEmplId();
    boolean isEAPDtlsUpdated = false;
    // Set EAP Details
    if (null != rdtRequestBean.getEapDate() && null != evntId) {
      // Check if EAP is already initiated for an employee.
      boolean eapCompleted = decertService.checkEapAlreadyInitiated(emplId, evntId);
      if (!eapCompleted) {
        EAPDatePopupDetail eapDatePopupBean = new EAPDatePopupDetail();
        eapDatePopupBean.setEapDate(rdtRequestBean.getEapDate().getTime());
        eapDatePopupBean.setEmployeeID(emplId);
        decertService.setEapComplete(emplId, getSelectedEventObj(createEventBean), eapDatePopupBean,
            EQMSConstant.DEFAULT_EQMS_USER);// REQ#588 Phase 2 Part
        // B
        isEAPDtlsUpdated = true;
      } else {
        final RDTResponseBean rdtResponseBean = getErrorResponseBean(rdtRequestBean, createEventBean, // QC#5196
            // issue
            // fix
            DecertificationApplicationConstant.EAP_ALREADY_COMPLETED,
            DecertificationApplicationConstant.EAP_ALREADY_COMPLETED_DESC);// QC#5196
        rdtRequestBean.setRdtResponseBean(rdtResponseBean);// QC#5196
        // issue
        // fix.
      }
    }
    return isEAPDtlsUpdated;
  }

  /**
   * This method is used to Cancel FRA Alcohol Above Threshold Violation type RDT event.
   * 
   * @param createEventBean
   * @return
   * @author xsat156
   * @since Dec 29, 2015, SS_QC 6526(Creation of DAMUP work item),SS_QC#6526 Added For SS_QC#6656(RDT Cancel event-
   *        DAMUP getting created instead of DROLD)
   */
  private boolean cancelRDTDecertEvent(final CreateEventDetail createEventBean) {
    boolean isEvntCanceled = false;
    if (createEventBean.getEventEmployeeAll() != null && !createEventBean.getEventEmployeeAll().isEmpty()
        && createEventBean.getEventEmployeeAll().get(0) != null) {
      final DecertDDChoice ddChoiceRegulation = createEventBean.getEventEmployeeAll().get(0).getRegulation();

      // Start : Added For SS_QC#6526
      String commonKey = ddChoiceRegulation.getStrKey();
      if (commonKey == null) {
        commonKey = ddChoiceRegulation.getIntKey() != null ? String.valueOf(ddChoiceRegulation.getIntKey().intValue())
            : null;
      }
      // End : Added For SS_QC#6526

      // Start : Added For SS_QC#6656(RDT Cancel event- DAMUP getting created instead of DROLD)
      if (createEventBean.getTypeOfEventAll() != null && (createEventBean.getTypeOfEventAll().getIntKey() != null)
          && (createEventBean.getTypeOfEventAll().getIntKey()
              .intValue() == DecertificationApplicationConstant.EVENT_TYPE_ID_DECERTIFICATION.intValue())) {
        createEventBean.setDecert(true);
      } else {
        createEventBean.setDecert(false);
      }
      // Ends : Added For SS_QC#6656(RDT Cancel event- DAMUP getting created instead of DROLD)

      if (ddChoiceRegulation != null && commonKey != null && !commonKey.contains(// Added For SS_QC#6526
          DecertificationApplicationConstant.EVENT_REGULATION_DRUG_AND_ALCOHOL)) {
        isEvntCanceled = decertService.cancelEvent(null, getSelectedEventObj(createEventBean),
            EQMSConstant.DEFAULT_EQMS_USER, reasonService.getAllReason(), DecertificationApplicationConstant.FLAG_L);
      }
    }
    return isEvntCanceled;
  }

  /**
   * To get SearchEventGridDetail
   * 
   * @param createEventBean
   * @return
   * @author xsat803
   * @since Jun 22, 2016, REQ#588 Phase 2 Part B, SS_QC#6526
   */
  private SearchEventGridDetail getSelectedEventObj(CreateEventDetail createEventBean) {
    SearchEventGridDetail selectedEvent = new SearchEventGridDetail();// REQ#588
    // Phase
    // 2
    // Part
    // B
    // (Creation
    // of
    // DAMUP
    // work
    // item)
    selectedEvent.setEventDetailID(createEventBean.getEvntDtlId());
    selectedEvent
        .setEventTypeID(createEventBean.isDecert() ? DecertificationApplicationConstant.EVENT_TYPE_ID_DECERTIFICATION
            : DecertificationApplicationConstant.EVENT_TYPE_ID_OTHER);
    selectedEvent.setEmployeeID(createEventBean.getEventEmployeeAll().get(0).getEmployeeID());
    selectedEvent.setServiceUnitNbr(createEventBean.getSvcUnitNbr());
    // Start : Added For SS_QC#6526
    selectedEvent.setEvntSrc(createEventBean.getEvntSourceSystem());
    selectedEvent.setRegulation(createEventBean.getEventEmployeeAll().get(0).getRegulation().getValue());
    // End : Added For SS_QC#6526
    return selectedEvent;
  }

  /**
   * To check the condition for updateRDT event.
   *
   * @param newViolation
   * @param oldViolationType
   * @return
   * @author xsat794
   * @since Jun 13, 2016 Added for REQ#588 Phase 2 Part B
   */
  public static boolean updateOtherEventRegulations(String newViolation, String oldViolationType) {
    boolean update = false;
    if (oldViolationType.equalsIgnoreCase(DecertificationApplicationConstant.UP_AUTH_RDT)
        && !(newViolation.equalsIgnoreCase(DecertificationApplicationConstant.FRA_RFSL)
            || newViolation.equalsIgnoreCase(DecertificationApplicationConstant.FRA_DRUG))) {
      update = true;
    } else if (oldViolationType.contains(DecertificationApplicationConstant.FRA_ALC_BLW_THLD_RDT)// SS_QC#6526
        // issue
        // fix.
        && (newViolation.equalsIgnoreCase(DecertificationApplicationConstant.FRA_CWKR_RFL_RDT)
            || newViolation.equalsIgnoreCase(DecertificationApplicationConstant.FRA_DRUG))) {
      update = true;
    } else if (oldViolationType.equalsIgnoreCase(DecertificationApplicationConstant.FRA_CWKR_RFL_RDT)) {
      update = false;
    } else if (oldViolationType.equalsIgnoreCase(DecertificationApplicationConstant.UP_AUTH_CWKR_RFL_RDT)
        && newViolation.equalsIgnoreCase(DecertificationApplicationConstant.FRA_CWKR_RFL_RDT)) {
      update = true;
    } else if (oldViolationType.equalsIgnoreCase(DecertificationApplicationConstant.UP_AUTH_RFSL_RDT)
        && newViolation.equalsIgnoreCase(DecertificationApplicationConstant.FRA_RFSL)) {
      update = true;
    }
    return update;
  }

  /**
   * To get the current event type of the evnt.
   *
   * @param rdtRequestBean
   * @param createEventBean
   * @param eventStatus
   * @return
   * @author xsat794
   * @since Jul 12, 2016 Added for SS_QC_6526
   */
  private String getCurrentEvntType(final RDTRequestBean rdtRequestBean, final CreateEventDetail createEventBean) {
    String eventStatus = rdtRequestBean.getEventStatus();
    String evntType = null;
    if (DecertificationApplicationConstant.EVENT_STAT_NEW.equalsIgnoreCase(eventStatus)) {
      final List<EqmDcrtVltnRegMpng> lstEqmDcrtVltnRegMpng1 = decertService.getRegualtionViolationDtls(
          rdtRequestBean.getViolationTypeCode(), null, null, rdtRequestBean.getEmplPosition());

      evntType = lstEqmDcrtVltnRegMpng1.get(0).getEqmEvntType().getEvntType();
    }
    if (DecertificationApplicationConstant.RDT_EVENT_STATUS_UPDATE.equalsIgnoreCase(eventStatus)) {
      final List<EqmDcrtVltnRegMpng> lstEqmDcrtVltnRegMpng1 = decertService.getRegualtionViolationDtls(
          createEventBean.getViolationTypeCode(), null, null,
          createEventBean.getEventEmployeeAll().get(0).getEmployeePosition());

      evntType = lstEqmDcrtVltnRegMpng1.get(0).getEqmEvntType().getEvntType();
    }
    return evntType;
  }

}
