/**
 * Description  : 
 * ClassName    : DenialOfCertificationService
 * author       : Tech Mahindra Ltd
 * Created on : Jun 2017
 *
 * Change History
 * ------------------------------------------------------------  
 * Date          Changed By      Description
 * ------------------------------------------------------------  
 * 05-Jun-2017    xsat794       Added for Denial of Certification bundled QCs(SS_QC#5120)
 * ------------------------------------------------------------  
 *
 * Copyright notice : "Copyright UPRR 2017"
 */
package com.uprr.lic.decert.service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.velocity.exception.MethodInvocationException;
import org.apache.velocity.exception.ParseErrorException;
import org.apache.velocity.exception.ResourceNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.uprr.lic.auth.EQMSUserBean;
import com.uprr.lic.auth.EQMSUserSession;
import com.uprr.lic.dataaccess.Licensing.model.SkillRide;
import com.uprr.lic.dataaccess.common.model.DenialPdfPageDetails;
import com.uprr.lic.dataaccess.common.model.Rules;
import com.uprr.lic.dataaccess.decertification.model.CategoryInformationDetail;
import com.uprr.lic.dataaccess.decertification.model.DenialEmployeeDetail;
import com.uprr.lic.dataaccess.decertification.model.DenyLicenseRequestDetail;
import com.uprr.lic.dataaccess.decertification.model.EventDocumentGridDetail;
import com.uprr.lic.dataaccess.decertification.model.LicenseGridDetail;
import com.uprr.lic.dataaccess.decertification.model.SkillEvaluationAndEventRecorderSummaryDetails;
import com.uprr.lic.dataaccess.decertification.services.interfaces.IDenyService;
import com.uprr.lic.dataaccess.decertification.util.DecertificationUtil;
import com.uprr.lic.util.DDChoice;
import com.uprr.lic.util.EQMSResnConstant;

@Service("denialOfCertificationService")
public class DenialOfCertificationService implements IDenialOfCertificationService {

  @Autowired
  private IDenyService denyService;
  
  @Autowired
  EQMSUserSession eqmsUserSession;
  /**
   * 
   * This method is used to get regulations 
   *
   * @return List<DDChoice>
   * @author xsat794
   * @since Jul 5, 2017
   * Added for Denial of Certification bundled QCs(SS_QC#5120)
   */
  @Override
  public List<DDChoice> getRegualtionsForDenial() {
    return DecertificationUtil.getRegulationListForChangeLicense();
  }
  /**
   * 
   * To get denial details for skill
   *
   * @param emplId
   * @return DenialEmployeeDetail
   * @author xsat794
   * @since Jul 5, 2017
   * Added for Denial of Certification bundled QCs(SS_QC#5120)
   */
  @Override
  public DenialEmployeeDetail getDenialDetailsForSkill(String emplId) {
    DenialEmployeeDetail denialEmployeeDetail = denyService.getEmployeeDetailsForDenialOfCertification(emplId);
    List<SkillRide> skillRidesList = denyService.getRecentFiveSkillRideListForEmployee(emplId);
    denialEmployeeDetail.setSkillRideList(skillRidesList);
    return denialEmployeeDetail;
  }
  /**
   * 
   * To get denial details for rule
   *
   * @param emplId
   * @return DenialEmployeeDetail
   * @author xsat794
   * @since Jul 5, 2017
   * Added for Denial of Certification bundled QCs(SS_QC#5120)
   */
  @Override
  public DenialEmployeeDetail getDenialDetailsForRules(String emplId) {
    DenialEmployeeDetail denialEmployeeDetail = denyService.getEmployeeDetailsForDenialOfCertification(emplId);
    List<LicenseGridDetail> licenseList = denyService.getLicenseGridList(emplId);
    denialEmployeeDetail.setLicenseAll(licenseList);
    List<Rules> ruleslList = denyService.getRulesGridDataForRules(emplId);
    denialEmployeeDetail.setRuleList(ruleslList);
    return denialEmployeeDetail;
  }
  /**
   * 
   * To get skill and recorder summary
   *
   * @param employeeId
   * @param evntEmplSeq
   * @return SkillEvaluationAndEventRecorderSummaryDetails
   * @author xsat794
   * @since Jul 5, 2017
   * Added for Denial of Certification bundled QCs(SS_QC#5120)
   */
  @Override
  public SkillEvaluationAndEventRecorderSummaryDetails getSkillAndRecorderSummaryDetail(String employeeId,
      Integer evntEmplSeq) {
    SkillEvaluationAndEventRecorderSummaryDetails summaryDetails = denyService
        .getSkillAndRecorderSummaryDetail(employeeId, evntEmplSeq);
    List<CategoryInformationDetail> categoryList = denyService.getSkillEvaltuationCateoryInformationList(employeeId,
        evntEmplSeq);
    summaryDetails.setCategoryInformationDetailsList(categoryList);
    return summaryDetails;
  }
  /**
   * 
   * To check the conditions for creation of event
   *
   * @param employeeId
   * @param regulationSelected
   * @param emplPos
   * @return String
   * @author xsat794
   * @since Jul 5, 2017
   * Added for Denial of Certification bundled QCs(SS_QC#5120)
   */
  @Override
  public String validateIfAllowToCreateAnEvent(final String employeeId, final Integer regulationSelected, final String emplPos) {
    String warningMsg = denyService.validateIfAllowToCreateAnEvent(employeeId, regulationSelected, emplPos);
    return warningMsg;
  }
  /**
   * 
   * This method is used to initiate denial of certification
   *
   * @param employeeId
   * @param regulationSelected
   * @param emplPos
   * @return boolean
   * @author xsat794
   * @since Jul 5, 2017
   * Added for Denial of Certification bundled QCs(SS_QC#5120)
   */
  @Override
  public boolean initiateDenialOfCertification(final String employeeId, final Integer regulationSelected, final String emplPos) {
    EQMSUserBean eqmsUserBean = eqmsUserSession.getUser();
    return denyService.initiateDenialOfCertification(employeeId, regulationSelected, eqmsUserBean.getEmplId(), emplPos);
  }
  /**
   * 
   * This method is used to reject denial of certification
   *
   * @param employeeId
   * @param eventDetailId
   * @param workItemId
   * @param resnId
   * @return String
   * @author xsat794
   * @since Jul 5, 2017
   * Added for Denial of Certification bundled QCs(SS_QC#5120)
   */
  @Override
  public String rejectDenialOfCertification(String employeeId, Integer eventDetailId, Integer workItemId, Integer resnId) {
    EQMSUserBean eqmsUserBean = eqmsUserSession.getUser();
    return denyService.rejectDenialOfCertification(employeeId, eventDetailId, workItemId, eqmsUserBean.getEmplId(), resnId);
  }
  /**
   * 
   * This method is used for go back to rebuttal process
   *
   * @param employeeId
   * @param eventDetailId
   * @param workItemId
   * @param resnId
   * @return String
   * @author xsat794
   * @since Jul 5, 2017
   * Added for Denial of Certification bundled QCs(SS_QC#5120)
   */
  @Override
  public String goBackToRebuttal(String employeeId, Integer eventDetailId, Integer workItemId,
      Integer resnId) {
    EQMSUserBean eqmsUserBean = eqmsUserSession.getUser();
    return denyService.goBackToRebuttal(employeeId, eventDetailId, workItemId,eqmsUserBean.getEmplId(), resnId);
  }
  /**
   * 
   * This method gets the data for DenyLicenseRequestPage
   *
   * @param emplId
   * @param resnId
   * @return DenialEmployeeDetail
   * @author xsat794
   * @since Jul 5, 2017
   * Added for Denial of Certification bundled QCs(SS_QC#5120)
   */
  @Override
  public DenialEmployeeDetail getDenyLicenseRequestPageDetails(String emplId, Integer resnId) {
    DenialEmployeeDetail denialEmployeeDetail = denyService.getEmployeeDetailsForDenialOfCertification(emplId);
    if(EQMSResnConstant.RESN_DENIAL_SKILLS.equals(resnId)){
      List<SkillRide> skillRidesList = denyService.getRecentFiveSkillRideListForEmployee(emplId);
      denialEmployeeDetail.setSkillRideList(skillRidesList);
    }else if(EQMSResnConstant.RESN_DENIAL_RULES.equals(resnId)){
      List<Rules> ruleslList = denyService.getRulesGridDataForRules(emplId);
      denialEmployeeDetail.setRuleList(ruleslList);
  }
    List<String> externalSystemsLinks=denyService.getExternalSystemLinks(emplId);
    denialEmployeeDetail.setExternalSystemsLinks(externalSystemsLinks);
    
    List<LicenseGridDetail> gridDetails=denyService.getLicenseGridList(emplId, false);
    denialEmployeeDetail.setLicenseAll(gridDetails);
  return denialEmployeeDetail;
}
/**
 * 
 * Method to check if license is denied successfully
 *
 * @param denyLicenseRequestDetail
 * @return boolean
 * @author xsat794
 * @since Jul 5, 2017
 * Added for Denial of Certification bundled QCs(SS_QC#5120)
 */
@Override
  public boolean hasLicenseDeniedSuccessfully(DenyLicenseRequestDetail denyLicenseRequestDetail) {
    EQMSUserBean eqmsUserBean = eqmsUserSession.getUser();
    return denyService.hasLicenseDeniedSuccessfully(denyLicenseRequestDetail, eqmsUserBean.getEmplId());
  }
 /**
  * 
  * This method is used to generate the PDF for all the form work items
  *
  * @param denialPageDetails
  * @return ByteArrayOutputStream
  * @throws ResourceNotFoundException
  * @throws ParseErrorException
  * @throws MethodInvocationException
  * @throws Exception
  * @author xsat794
  * @since Jul 5, 2017
  * Added for Denial of Certification bundled QCs(SS_QC#5120)
  */
public ByteArrayOutputStream generatePdf(DenialPdfPageDetails denialPageDetails)throws  ResourceNotFoundException, ParseErrorException, MethodInvocationException, Exception {
	EQMSUserBean eqmsUserBean = eqmsUserSession.getUser();
	  return denyService.generatePdf(denialPageDetails, eqmsUserBean.getEmplId());
  }

	/**
	 * 
	 * This method is used to get form description.
	 *
	 * @param workItemId
	 * @return String
	 * @author xsat794
	 * @since Jul 5, 2017
	 * Added for Denial of Certification bundled QCs(SS_QC#5120)
	 */
	public  String getComments(Integer workItemId){
		 return denyService.getComments(workItemId);
	}
	/**
	 * 
	 * This method is used to upload the files for rebuttal approve
	 *
	 * @param documents
	 * @param emplID
	 * @param oprnCode
	 * @param workItemId
	 * @return String
	 * @throws IOException
	 * @author xsat794
	 * @since Jul 5, 2017
	 * Added for Denial of Certification bundled QCs(SS_QC#5120)
	 */
	public String uploadFile(List<MultipartFile> documents,String emplID,String oprnCode, Integer workItemId, final String emplPos) throws IOException{
		EQMSUserBean eqmsUserBean = eqmsUserSession.getUser();
		return denyService.uploadFile(documents,emplID,eqmsUserBean.getEmplId(),oprnCode, workItemId, emplPos);
	}
	/**
	 * 
	 * This method is used to get employee licenses
	 *
	 * @param employeeId
	 * @return List<String>
	 * @author xsat794
	 * @since Jul 5, 2017
	 * Added for Denial of Certification bundled QCs(SS_QC#5120)
	 */
	public List<String> getEmplLcnsDtls(String employeeId){
		return denyService.getEmplLcnsDtls(employeeId);
	}
	/** 
	 * This method is used to download files from filenet service
	 * @param employeeId
	 * @param eventDetailId
	 * @param denyOprnCode
	 * @param responseOutputStream
	 * @return byte[]
	 * @author xsat794
	 * @since Jul 5, 2017
	 * Added for Denial of Certification bundled QCs(SS_QC#5120)
	 */

  @Override
  public byte[] downloadFormFromFileNet(String employeeId, Integer eventDetailId, String denyOprnCode,OutputStream responseOutputStream) {
    return denyService.downloadFormFromFileNet(employeeId, eventDetailId, denyOprnCode,responseOutputStream);
  }
  /**
   * 
   * This method is to get the documents for rebuttal.
   *
   * @param eventDetailID
   * @param rebuttalOprnCode
   * @return List<EventDocumentGridDetail>
   * @author xsat794
   * @since Jul 5, 2017
   * Added for Denial of Certification bundled QCs(SS_QC#5120)
   */
  @Override
  public List<EventDocumentGridDetail> getRebuttalDocDetails(Integer eventDetailID, final String rebuttalOprnCode) {
    return denyService.getRebuttalDocDetails(eventDetailID,rebuttalOprnCode);
  }
  /**
   * 
   * This method is used to download files from filenet service
   *
   * @param guid
   * @return byte[]
   * @author xsat794
   * @since Jul 5, 2017
   * Added for Denial of Certification bundled QCs(SS_QC#5120)
   */
  @Override
  public byte[] downloadFormUsingGuid(String guid) {
    return denyService.downloadFormUsingGuid(guid);
  }
  public Map<String,String> getEqmEmplDtlsFromWorkItemId(final Integer workItemId) {
    return denyService.getEqmEmplDtlsFromWorkItemId(workItemId);
  }
  /**
   * This method is used to return loggedInUser Name
   *
   * @return String
   * @author xsat671
   * @since Jul 11, 2017. Added for Denial of Certification bundled QCs(SS_QC#5120
   */
  @Override
  public Map<String,String> getLoggedInUserNameAndEmplId() {
    Map<String,String> emplNameAndIdMap=new HashMap<String, String>();
    EQMSUserBean eqmsUserBean = eqmsUserSession.getUser();
    emplNameAndIdMap.put(eqmsUserBean.getEmplId(), eqmsUserBean.getEmpName());
    return emplNameAndIdMap;
  }
}
