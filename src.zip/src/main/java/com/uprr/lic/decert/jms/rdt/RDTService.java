package com.uprr.lic.decert.jms.rdt;

import com.uprr.lic.dataaccess.decertification.model.RDTRequestBean;

public interface RDTService {
	public void processRdtRequest(final RDTRequestBean rdtRequestBean);
}
