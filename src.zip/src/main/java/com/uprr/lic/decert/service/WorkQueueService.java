
package com.uprr.lic.decert.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uprr.lic.dataaccess.decertification.model.WorkQueueLcnsDtl;
import com.uprr.lic.dataaccess.decertification.services.interfaces.IDecertificationService;
import com.uprr.lic.decert.jms.cmts.PendingRulesSender;

@Service("workqueueService")
public class WorkQueueService implements IWorkQueueService {

  @Autowired
  private IDecertificationService decertificationService;

  @Override
  public boolean updateWorkQueueDetailst(WorkQueueLcnsDtl workQueueLcnsDtl, PendingRulesSender pendingRulesSender) {
         boolean flagforapproval= decertificationService.sendLDMarkUpMsg(workQueueLcnsDtl, pendingRulesSender);
         return flagforapproval;
  }
  
 
  @Override
  public boolean updateWorkQueueDetailstForDAA(WorkQueueLcnsDtl workQueueLcnsDtl, PendingRulesSender pendingRulesSender) {
    decertificationService.closeEventOnDAMUPApprove(workQueueLcnsDtl.getEvntDtlId(),
       workQueueLcnsDtl.getLoggedInUserId());
    boolean flagforapproval=decertificationService.sendLDMarkUpMsg(workQueueLcnsDtl, pendingRulesSender);
    return flagforapproval;
  }

}
