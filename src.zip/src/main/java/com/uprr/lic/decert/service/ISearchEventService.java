package com.uprr.lic.decert.service;

import java.util.List;

import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.uprr.lic.auth.EQMSUserBean;
import com.uprr.lic.dataaccess.decertification.model.SearchEventGridDetail;
import com.uprr.lic.decert.rest.model.DropdownChoice;
import com.uprr.lic.decert.rest.model.EmployeeDetails;
import com.uprr.lic.decert.rest.model.SearchEventRequest;
import com.uprr.lic.decert.rest.model.SearchEventResponse;
import com.uprr.lic.exception.EqmDaoException;

public interface ISearchEventService {

  List<DropdownChoice> getRegionList();

  List<DropdownChoice> getTypeOfEvents();

  List<DropdownChoice> getServiceUnitsByRegion(Integer region);

  List<SearchEventResponse> searchEvents(SearchEventRequest details);

  boolean acceptMitigateEvent(MultipartHttpServletRequest multipartHttpServletRequest,
      Boolean isLerbAction);

  boolean updateComments(EmployeeDetails employeeDetails);

  String validateDROCloseout(EmployeeDetails employeeDetails) throws EqmDaoException;

  boolean submitDROCloseoutComments(EmployeeDetails employeeDetails);

  EQMSUserBean getUserDetail();

  String validateEventForUpdate(SearchEventGridDetail details) throws EqmDaoException;
  
  boolean updateResponsibleManager(EmployeeDetails employeeDetails);

  boolean getResponsibleManagerById(String updatedManagerId);

}
