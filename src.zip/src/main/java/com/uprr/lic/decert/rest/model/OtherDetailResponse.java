package com.uprr.lic.decert.rest.model;

import com.uprr.lic.util.DDChoice;

public class OtherDetailResponse {
	private long serialVersionUID;
	private Long eventOtherTrainId;
	private String crewType;
	private String operation;
	private DDChoice weather;
	private DDChoice visibility;
	private String vsblWthr;
	private String grade;
	private String curvature;
	private String eventRecorder;
	private String blueFlag;
	private String ftxEvent;

	public long getSerialVersionUID() {
		return serialVersionUID;
	}

	public void setSerialVersionUID(final long serialVersionUID) {
		this.serialVersionUID = serialVersionUID;
	}

	public Long getEventOtherTrainId() {
		return eventOtherTrainId;
	}

	public void setEventOtherTrainId(final Long eventOtherTrainId) {
		this.eventOtherTrainId = eventOtherTrainId;
	}

	public String getCrewType() {
		return crewType;
	}

	public void setCrewType(final String crewType) {
		this.crewType = crewType;
	}

	public String getOperation() {
		return operation;
	}

	public void setOperation(final String operation) {
		this.operation = operation;
	}

	public DDChoice getWeather() {
		return weather;
	}

	public void setWeather(final DDChoice weather) {
		this.weather = weather;
	}

	public DDChoice getVisibility() {
		return visibility;
	}

	public void setVisibility(final DDChoice visibility) {
		this.visibility = visibility;
	}

	public String getVsblWthr() {
		return vsblWthr;
	}

	public void setVsblWthr(final String vsblWthr) {
		this.vsblWthr = vsblWthr;
	}

	public String getGrade() {
		return grade;
	}

	public void setGrade(final String grade) {
		this.grade = grade;
	}

	public String getCurvature() {
		return curvature;
	}

	public void setCurvature(final String curvature) {
		this.curvature = curvature;
	}

	public String getEventRecorder() {
		return eventRecorder;
	}

	public void setEventRecorder(final String eventRecorder) {
		this.eventRecorder = eventRecorder;
	}

	public String getBlueFlag() {
		return blueFlag;
	}

	public void setBlueFlag(final String blueFlag) {
		this.blueFlag = blueFlag;
	}

	public String getFtxEvent() {
		return ftxEvent;
	}

	public void setFtxEvent(final String ftxEvent) {
		this.ftxEvent = ftxEvent;
	}
}
