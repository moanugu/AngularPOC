package com.uprr.lic.decert.rest.model;

import java.util.Date;

import com.uprr.lic.dataaccess.common.model.DecertDDChoice;
import com.uprr.lic.dataaccess.decertification.model.IncidentHistory;

public class EventEmployeeResponse {

	private Integer emplEvntDtlsId;

	private String employeeID; // To hold the Employee ID

	private String employeeName; // To hold the Employee Name

	private DropdownChoice position; // To hold the Position of the Employee at the
									// time of Incident
	private Date dateOnDuty; // To hold the Date on Duty

	private String timeOnDuty; // To hold the time on Duty

	private String hrsOnDuty; // To hold the Number of Hours on Duty

	private String previosRest; // To hold the Previos rest

	private String direction; // To hold the Employee's Direction

	private String lastJobBref; // To hold the Employee's Last Job Briefing

	private String suspended; // To hold the suspension flag data of the
								// Employee

	private String emplStatFlag; // To hold the Employee Status

	private String statusDate; // To hold the Employee Status Updated Date

	private String assignedManager; // To hold the Employee's Assigned Manager

	private String status;

	private String callCirc7;

	private String callCirc7WithDateOnDutyTime;

	private Boolean isValidEmployee = true;

	private Integer actualPosSeq; // To hold position code obtained from tera
									// data

	private Integer cnvtJobTypePosSeq;

	private String jobType;

	private IncidentHistory incidentHistory;

	private String assignedManagersvcunit; // To hold assigned manager service
												// unit for qc1220

	private String nameIdDisplay; // QC 1056 LERB

	private String employeePosition; // QC 1056 LERB - Added since position DD
										// choice is not giving strKey

	private String onDutyDate; // QC 1056 LERB

	private DecertDDChoice regulation;

	private String strPosition;

	private String strRegulation;

	private String firstDAndAEvent = "false"; // QC 991

	private String actualPosOnTrain; // Added For REQ#223.

	private String prevValueFirstAlcoAEvent = "false"; // Added for REQ#588
															// Part_B.

	private String monthYears;// Added For REQ#401

	private String emplCirc7; // Req#401-pt5

	private String emplBoardName; // Req#401-pt5

	private String ruleNbr; // QC#3720

	private DecertDDChoice primaryRules; // QC#3720

	/**
	 * To store name of document selected from Drop down
	 */
	private String receivedDocType;// added for REQ#597 Part I

	/**
	 * Variable used to store the value of "Is First Drug and Alcohol ?" before
	 * changing
	 */
	private String prevValueFirstDAndAEvent = "false"; // added for REQ#597
															// Part I

	private String firstAlcoholEvent = "false"; // REQ#588 Phase 1 Part B

	private String oldRegulation;// Added for SS_QC 6526

	// start:Req#401-pt5
	/**
	 * @return the emplCirc7
	 */
	public String getEmplCirc7() {
		return emplCirc7;
	}

	/**
	 * @param emplCirc7
	 *            the emplCirc7 to set
	 */
	public void setEmplCirc7(final String emplCirc7) {
		this.emplCirc7 = emplCirc7;
	}

	/**
	 * @return the emplBoardName
	 */
	public String getEmplBoardName() {
		return emplBoardName;
	}

	/**
	 * @param emplBoardName
	 *            the emplBoardName to set
	 */
	public void setEmplBoardName(final String emplBoardName) {
		this.emplBoardName = emplBoardName;
	}

	// end:Req#401-pt5
	public EventEmployeeResponse() {
		super();
	}

	public EventEmployeeResponse(final String employeeid) {
		super();
		employeeID = employeeid;
	}

	/**
	 * @return
	 */
	public String getEmployeeID() {
		return employeeID;
	}

	/**
	 * @param employeeID
	 */
	public void setEmployeeID(final String employeeID) {
		this.employeeID = employeeID;
	}

	/**
	 * @return
	 */
	public String getEmployeeName() {
		return employeeName;
	}

	/**
	 * @param employeeName
	 */
	public void setEmployeeName(final String employeeName) {
		this.employeeName = employeeName;
	}

	/**
	 * @return
	 */
	public DropdownChoice getPosition() {
		return position;
	}

	/**
	 * @param position
	 */
	public void setPosition(final DropdownChoice position) {
		this.position = position;
	}

	/**
	 * @return
	 */
	public Date getDateOnDuty() {
		return dateOnDuty;
	}

	/**
	 * @param dateOnDuty
	 */
	public void setDateOnDuty(final Date dateOnDuty) {
		this.dateOnDuty = dateOnDuty;
	}

	/**
	 * @return
	 */
	public String getTimeOnDuty() {
		return timeOnDuty;
	}

	/**
	 * @param timeOnDuty
	 */
	public void setTimeOnDuty(final String timeOnDuty) {
		this.timeOnDuty = timeOnDuty;
	}

	/**
	 * @return
	 */
	public String getHrsOnDuty() {
		return hrsOnDuty;
	}

	/**
	 * @param hrsOnDuty
	 */
	public void setHrsOnDuty(final String hrsOnDuty) {
		this.hrsOnDuty = hrsOnDuty;
	}

	/**
	 * @return
	 */
	public String getPreviosRest() {
		return previosRest;
	}

	/**
	 * @param previosRest
	 */
	public void setPreviosRest(final String previosRest) {
		this.previosRest = previosRest;
	}

	/**
	 * @return
	 */
	public String getDirection() {
		return direction;
	}

	/**
	 * @param direction
	 */
	public void setDirection(final String direction) {
		this.direction = direction;
	}

	/**
	 * @return
	 */
	public String getLastJobBref() {
		return lastJobBref;
	}

	/**
	 * @param lastJobBref
	 */
	public void setLastJobBref(final String lastJobBref) {
		this.lastJobBref = lastJobBref;
	}

	/**
	 * @return
	 */
	public String getSuspended() {
		return suspended;
	}

	/**
	 * @param suspended
	 */
	public void setSuspended(final String suspended) {
		this.suspended = suspended;
	}

	/**
	 * @return the m_emplStatFlag
	 */
	public String getEmplStatFlag() {
		return emplStatFlag;
	}

	/**
	 * @param statFlag
	 *            the m_emplStatFlag to set
	 */
	public void setEmplStatFlag(final String statFlag) {
		emplStatFlag = statFlag;
	}

	/**
	 * @return the m_statusDate
	 */
	public String getStatusDate() {
		return statusDate;
	}

	/**
	 * @param date
	 *            the m_statusDate to set
	 */
	public void setStatusDate(final String date) {
		statusDate = date;
	}

	/**
	 * @return the m_assignedManager
	 */
	public String getAssignedManager() {
		return assignedManager;
	}

	/**
	 * @param manager
	 *            the m_assignedManager to set
	 */
	public void setAssignedManager(final String manager) {
		assignedManager = manager;
	}

	/**
	 * @return the m_emplEvntDtlsId
	 */
	public Integer getEmplEvntDtlsId() {
		return emplEvntDtlsId;
	}

	/**
	 * @param emplEvntDtlsId
	 *            the m_emplEvntDtlsId to set
	 */
	public void setEmplEvntDtlsId(final Integer emplEvntDtlsId) {
		this.emplEvntDtlsId = emplEvntDtlsId;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status
	 *            the status to set
	 */
	public void setStatus(final String status) {
		this.status = status;
	}

	public String getCallCirc7() {
		return callCirc7;
	}

	public void setCallCirc7(final String crewCallCirc7) {
		callCirc7 = crewCallCirc7;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((employeeID == null) ? 0 : employeeID.hashCode());
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(final Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		final EventEmployeeResponse other = (EventEmployeeResponse) obj;
		if (employeeID == null) {
			if (other.employeeID != null) {
				return false;
			}
		} else if (!employeeID.equals(other.employeeID)) {
			return false;
		}
		return true;
	}

	public boolean isValidEmployee() {
		return isValidEmployee;
	}

	public void setValidEmployee(final boolean isValidEmployee) {
		this.isValidEmployee = isValidEmployee;
	}

	/**
	 * @return the callCirc7WithDateOnDutyTime
	 */
	public String getCallCirc7WithDateOnDutyTime() {
		return callCirc7WithDateOnDutyTime;
	}

	/**
	 * @param callCirc7WithDateOnDutyTime
	 *            the callCirc7WithDateOnDutyTime to set
	 */
	public void setCallCirc7WithDateOnDutyTime(final String callCirc7WithDateOnDutyTime) {
		this.callCirc7WithDateOnDutyTime = callCirc7WithDateOnDutyTime;
	}

	public Integer getActualPosSeq() {
		return actualPosSeq;
	}

	public void setActualPosSeq(final Integer actualPosSeq) {
		this.actualPosSeq = actualPosSeq;
	}

	public Integer getCnvtJobTypePosSeq() {
		return cnvtJobTypePosSeq;
	}

	public void setCnvtJobTypePosSeq(final Integer cnvtJobTypePosSeq) {
		this.cnvtJobTypePosSeq = cnvtJobTypePosSeq;
	}

	public IncidentHistory getIncidentHistory() {
		return incidentHistory;
	}

	public void setIncidentHistory(final IncidentHistory history) {
		incidentHistory = history;
	}

	public String getAssignedManagersvcunit() {
		return assignedManagersvcunit;
	}

	public void setAssignedManagersvcunit(final String assignedManagersvcunit) {
		this.assignedManagersvcunit = assignedManagersvcunit;
	}

	public String getJobType() {
		return jobType;
	}

	public void setJobType(final String jobType) {
		this.jobType = jobType;
	}

	public String getNameIdDisplay() {
		return nameIdDisplay;
	}

	public void setNameIdDisplay(final String nameIdDisplay) {
		this.nameIdDisplay = nameIdDisplay;
	}

	public String getEmployeePosition() {
		return employeePosition;
	}

	public void setEmployeePosition(final String employeePosition) {
		this.employeePosition = employeePosition;
	}

	public String getOnDutyDate() {
		return onDutyDate;
	}

	public void setOnDutyDate(final String onDutyDate) {
		this.onDutyDate = onDutyDate;
	}

	public DecertDDChoice getRegulation() {
		return regulation;
	}

	public void setRegulation(final DecertDDChoice regulation) {
		this.regulation = regulation;
	}

	public String getStrPosition() {
		return strPosition;
	}

	public void setStrPosition(final String strPosition) {
		this.strPosition = strPosition;
	}

	public String getStrRegulation() {
		return strRegulation;
	}

	public void setStrRegulation(final String strRegulation) {
		this.strRegulation = strRegulation;
	}

	public String getFirstDAndAEvent() {
		return firstDAndAEvent;
	}

	public void setFirstDAndAEvent(final String firstDAndAEvent) {
		this.firstDAndAEvent = firstDAndAEvent;
	}

	/**
	 * @return the actualPosOnTrain
	 */
	public String getActualPosOnTrain() {
		return actualPosOnTrain;
	}

	/**
	 * @param actualPosOnTrain
	 *            the actualPosOnTrain to set
	 */
	public void setActualPosOnTrain(final String actualPosOnTrain) {
		this.actualPosOnTrain = actualPosOnTrain;
	}

	/**
	 * @return the monthYears
	 */
	public String getMonthYears() {
		return monthYears;
	}

	/**
	 * @param monthYears
	 *            the monthYears to set
	 */
	public void setMonthYears(final String monthYears) {
		this.monthYears = monthYears;
	}

	/**
	 * @return the receivedDocType REQ#597 Part I
	 */
	public String getReceivedDocType() {
		return receivedDocType;
	}

	/**
	 * @param receivedDocType
	 *            the receivedDocType to set REQ#597 Part I
	 */
	public void setReceivedDocType(final String receivedDocType) {
		this.receivedDocType = receivedDocType;
	}

	/**
	 * @return the prevValueFirstDAndAEvent REQ#597 Part I
	 */
	public String getPrevValueFirstDAndAEvent() {
		return prevValueFirstDAndAEvent;
	}

	/**
	 * @param prevValueFirstDAndAEvent
	 *            the prevValueFirstDAndAEvent to set REQ#597 Part I
	 */
	public void setPrevValueFirstDAndAEvent(final String prevFirstDAndAEvent) {
		this.prevValueFirstDAndAEvent = prevFirstDAndAEvent;
	}

	// REQ#588 Phase 1 Part B start
	/**
	 * @return the prevValueFirstAlcoAEvent
	 */
	public String getPrevValueFirstAlcoAEvent() {
		return prevValueFirstAlcoAEvent;
	}

	/**
	 * @param prevValueFirstAlcoAEvent
	 *            the prevValueFirstAlcoAEvent to set
	 */
	public void setPrevValueFirstAlcoAEvent(String prevValueFirstAlcoAEvent) {
		this.prevValueFirstAlcoAEvent = prevValueFirstAlcoAEvent;
	}

	/**
	 * @return the firstAlcoholEvent
	 */
	public String getFirstAlcoholEvent() {
		return firstAlcoholEvent;
	}

	/**
	 * @param firstAlcoholEvent
	 *            the firstAlcoholEvent to set
	 */
	public void setFirstAlcoholEvent(String firstAlcoholEvent) {
		this.firstAlcoholEvent = firstAlcoholEvent;
	}// REQ#588 Phase 1 Part B end

	/**
	 * @return the ruleNbr
	 */
	public String getRuleNbr() { // QC#3720 start
		return ruleNbr;
	}

	/**
	 * @param ruleNbr
	 *            the ruleNbr to set
	 */
	public void setRuleNbr(String ruleNbr) {
		this.ruleNbr = ruleNbr;
	}

	/**
	 * @return the primaryRules
	 */
	public DecertDDChoice getPrimaryRules() {
		return primaryRules;
	}

	/**
	 * @param primaryRules
	 *            the primaryRules to set
	 */
	public void setPrimaryRules(DecertDDChoice primaryRules) {
		this.primaryRules = primaryRules;
	}// QC#3720 end

	// SS_QC 6526 changes start.
	/**
	 * @return the oldRegulation
	 */
	public String getOldRegulation() {
		return oldRegulation;
	}

	/**
	 * @param oldRegulation
	 *            the oldRegulation to set
	 */
	public void setOldRegulation(String oldRegulation) {
		this.oldRegulation = oldRegulation;
	}
	// SS_QC 6526 changes end.
}