package com.uprr.lic.decert.jms.rdt;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.uprr.lic.dataaccess.decertification.model.RDTRequestBean;

public class RDTDelegate {
	private RDTService rdtService;

	public RDTDelegate(RDTService rdtService) {
		this.rdtService = rdtService;
	}

	private static final Logger LOGGER = LoggerFactory.getLogger(RDTDelegate.class);

	public RDTService getRdtService() {
		return rdtService;
	}

	public void setRdtService(RDTService rdtService) {
		this.rdtService = rdtService;
	}

	public void processRdtRequest(final RDTRequestBean rdtRequestBean) {
		rdtService.processRdtRequest(rdtRequestBean);
	}

}
