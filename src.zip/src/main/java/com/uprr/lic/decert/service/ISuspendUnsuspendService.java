package com.uprr.lic.decert.service;

import java.util.List;

import com.uprr.lic.dataaccess.decertification.model.LicenseGridDetail;

public interface ISuspendUnsuspendService {
	
	String checkEmplToAdd(String employeeId);
	
	public  List<LicenseGridDetail> getLicenseGridList(String employeeID);
	
	public Boolean isRevocationConfirmedForEmployee(String employeeID);
	
	public Boolean isEmployeeDecertified(String employeeID);
	
	public Boolean isEmployeePresentInAnyEvent(String employeeID);
	
	public Boolean isEmployeeSuspended(String employeeID);
	
	public Boolean insertEmployeeSuspensionDetails(String employeeId,String comments,String loggedInEmpl);
	
	public Boolean updateEmployeeSuspensionDetails(String employeeId,String comments,String loggedInEmpl);
	
}
