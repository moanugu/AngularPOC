package com.uprr.lic.decert.restcontroller;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.xmlbeans.XmlException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.uprr.lic.auth.EQMSUserBean;
import com.uprr.lic.auth.EQMSUserSession;
import com.uprr.lic.dataaccess.decertification.model.SearchEventGridDetail;
import com.uprr.lic.decert.rest.constant.ControllerConstants;
import com.uprr.lic.decert.rest.model.DropdownChoice;
import com.uprr.lic.decert.rest.model.EmployeeDetails;
import com.uprr.lic.decert.rest.model.SearchEventRequest;
import com.uprr.lic.decert.rest.model.SearchEventResponse;
import com.uprr.lic.decert.service.ISearchEventService;
import com.uprr.lic.doss.get.DossGetServiceClientXmfImpl;
import com.uprr.lic.doss.get.domain.DossGetServiceResponse;
import com.uprr.lic.doss.put.DossPutServiceClient;
import com.uprr.lic.doss.put.DossPutServiceClientXmfImpl;
import com.uprr.lic.doss.put.domain.DossPutServiceRequest;
import com.uprr.lic.doss.put.domain.DossPutServiceResponse;
import com.uprr.lic.util.DateUtil;
import com.uprr.netcontrol.frontend.client.xmf.XmfClientInvoker;

@Controller
public class SearchEventController {

  private Logger LOGGER = LoggerFactory.getLogger(SearchEventController.class);

  @Autowired
  @Qualifier("eqmXmfClientInvoker")
  XmfClientInvoker invoker;

  @Autowired
  @Qualifier("dossGetXmfClientInvoker")
  XmfClientInvoker dosGetInvoker;

  @Autowired
  @Qualifier("dossPutXmfClientInvoker")
  XmfClientInvoker dosPutInvoker;

  @Autowired
  private ISearchEventService service;

  @Autowired
  EQMSUserSession session;

  @RequestMapping(value = ControllerConstants.GET_REGION_LIST, method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
  @ResponseBody
  public List<DropdownChoice> query(String symbol, String arrivalCirc7) {
    return service.getRegionList();
  }

  @RequestMapping(method = RequestMethod.GET, value = ControllerConstants.GET_TYPE_OF_EVENTS)
  @ResponseBody
  public List<DropdownChoice> getTypeOfEventListQuery() {
    return service.getTypeOfEvents();
  }

  @RequestMapping(method = RequestMethod.GET, value = ControllerConstants.GET_SERVICE_UNITS_BY_REGION)
  @ResponseBody
  public List<DropdownChoice> getServiceUnitsByRegionQuery(@PathVariable Integer region) {
    return service.getServiceUnitsByRegion(region);
  }

  @RequestMapping(method = RequestMethod.POST, value = ControllerConstants.GET_SEARCH_EVENTS)
  @ResponseBody
  public List<SearchEventResponse> searchEventsQuery(@RequestBody SearchEventRequest eventDetails) {

    Date fromDate = DateUtil.getDateInstanceFromStringDate(eventDetails.getEventFromDate());
    Date toDate = DateUtil.getDateInstanceFromStringDate(eventDetails.getEventToDate());
    eventDetails.setFromDate(fromDate);
    eventDetails.setToDate(toDate);
    session.getSessionMap().put("searchEventRequest", eventDetails);
    return service.searchEvents(eventDetails);
  }

  @RequestMapping(method = RequestMethod.POST, value = "/acceptMitigateEvent/{isLerbAction}")
  @ResponseBody
  public boolean acceptMitigateEvent(MultipartHttpServletRequest multipartRequest,
      @PathVariable("isLerbAction") Boolean isLerbAction) {
    return service.acceptMitigateEvent(multipartRequest, isLerbAction);

  }

  // Update Comment for mark invalid and cancel events
  @RequestMapping(method = RequestMethod.POST, value = "/updatedComments")
  @ResponseBody
  public boolean updatedComments(@RequestBody EmployeeDetails employeeDetails) {
    return service.updateComments(employeeDetails);
  }

  // Submit DROCloseout Comments
  @RequestMapping(method = RequestMethod.POST, value = "/dROCloseoutComment")
  @ResponseBody
  public boolean submitDROCloseoutComments(@RequestBody EmployeeDetails employeeDetails) {
    return service.submitDROCloseoutComments(employeeDetails);
  }

  // Validate DROCloseout Comments
  @RequestMapping(method = RequestMethod.POST, value = "/validateDROCloseout")
  @ResponseBody
  public String validateDROCloseout1(@RequestBody EmployeeDetails employeeDetails) {
    return service.validateDROCloseout(employeeDetails);
  }

  // Validate For Update
  @RequestMapping(method = RequestMethod.POST, value = "/validateEventForUpdate")
  @ResponseBody
  public String validateEventForUpdate(@RequestBody SearchEventGridDetail selectedEvent) {
    return service.validateEventForUpdate(selectedEvent);
  }

  @RequestMapping(method = RequestMethod.GET, value = "/getDocumentXmfServices")
  @ResponseBody
  public DossGetServiceResponse getDocumentsXmfServices(@RequestParam(value = "gufnId") String gufnId) {
    DossGetServiceClientXmfImpl client = new DossGetServiceClientXmfImpl(dosGetInvoker);
    DossGetServiceResponse dossGetServiceResponse = null;
    try {
      dossGetServiceResponse = client.getDataDocumentAsByteArray(gufnId);
    } catch (XmlException e) {
      e.printStackTrace();
    }
    return dossGetServiceResponse;
  }

  @RequestMapping(method = RequestMethod.POST, value = "/putDocumentXmfServices")
  @ResponseBody
  public String getDocumentsXmfServices(@RequestBody DossPutServiceRequest dossPutServiceRequest) {
    DossPutServiceClient client = new DossPutServiceClientXmfImpl(dosPutInvoker);
    DossPutServiceResponse dossGetServiceResponse = client.putDataDocumentAndGetGUFN(dossPutServiceRequest);
    return dossGetServiceResponse.getGufn();
  }

  @SuppressWarnings({ "unchecked", "rawtypes" })
  @RequestMapping(method = RequestMethod.GET, value = "/getUserDetail")
  @ResponseBody
  public Map getUserDetails() {
    Map userDetailsMap = new HashMap();
    EQMSUserBean userDetail = service.getUserDetail();
    if (userDetail != null) {
      userDetailsMap.put("roleSet", userDetail.getRoleSet());
      userDetailsMap.put("employeeId", userDetail.getEmplId());
      userDetailsMap.put("employeeName", userDetail.getEmpName());
    }
    return userDetailsMap;
  }

  // Update ResponsibleManager Details
  @RequestMapping(method = RequestMethod.POST, value = "/changeResponsibleManager")
  @ResponseBody
  public boolean updateResponsibleManager(@RequestBody EmployeeDetails employeeDetails) {
    return service.updateResponsibleManager(employeeDetails);
  }

  // Get ResponsibleManager By Id
  @RequestMapping(method = RequestMethod.POST, value = "/getResponsibleManagerById/{updatedManagerId}")
  @ResponseBody
  public boolean getResponsibleManagerById(@PathVariable("updatedManagerId") String updatedManagerId) {
    return service.getResponsibleManagerById(updatedManagerId);
  }

}
