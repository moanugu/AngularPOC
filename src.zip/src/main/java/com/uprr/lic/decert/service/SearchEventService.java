/**
 * Class Name   : SearchEventService
 * Description  : 
 * Created By   : Tech Mahindra Ltd.
 * Created On   : 
 *
 * Change History
 * ------------------------------------------------------------  
 *   Date       Changed By     Description
 * ------------------------------------------------------------  
 * 25-Sep-2017   xsat794         Modified for SS_QC_9263
 * ------------------------------------------------------------  
 *  Copyright notice : "Copyright UPRR 2008"
 */

package com.uprr.lic.decert.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.uprr.lic.auth.EQMSUserBean;
import com.uprr.lic.auth.EQMSUserSession;
import com.uprr.lic.dataaccess.common.dao.mapper.DecertificationMapper;
import com.uprr.lic.dataaccess.components.common.model.EqmsEmplRoleAreaBean;
import com.uprr.lic.dataaccess.decertification.model.MitigateEventDetail;
import com.uprr.lic.dataaccess.decertification.model.SearchEventDetail;
import com.uprr.lic.dataaccess.decertification.model.SearchEventGridDetail;
import com.uprr.lic.dataaccess.decertification.services.interfaces.IDecertificationService;
import com.uprr.lic.dataaccess.masters.service.IReasonService;
import com.uprr.lic.decert.rest.model.DropdownChoice;
import com.uprr.lic.decert.rest.model.EmployeeDetails;
import com.uprr.lic.decert.rest.model.MitigateEventDetailRequest;
import com.uprr.lic.decert.rest.model.SearchEventRequest;
import com.uprr.lic.decert.rest.model.SearchEventResponse;
import com.uprr.lic.doss.put.DossPutServiceClient;
import com.uprr.lic.doss.put.DossPutServiceClientXmfImpl;
import com.uprr.lic.exception.EqmDaoException;
import com.uprr.lic.util.DDChoice;
import com.uprr.lic.util.DecertificationApplicationConstant;
import com.uprr.lic.util.EQMSConstant;
import com.uprr.lic.util.FeedbackMessageConstant;
import com.uprr.netcontrol.frontend.client.xmf.XmfClientInvoker;

@Service("searchEventService")
public class SearchEventService implements ISearchEventService {

  Logger LOGGER = LoggerFactory.getLogger(SearchEventService.class);

  @Autowired
  IDecertificationService service;

  @Autowired
  private IReasonService reasonServiceImpl;

  @Autowired
  EQMSUserSession eqmsUserSession;

  @Autowired
  @Qualifier("dossPutXmfClientInvoker")
  XmfClientInvoker dosPutInvoker;

  @Override
  public List<DropdownChoice> getRegionList() {
    return getRegionList(service.getRegionList());
  }

  private List<DropdownChoice> getRegionList(List<DDChoice> regionListParam) {
    return fillResponse(regionListParam);
  }

  @Override
  public List<DropdownChoice> getTypeOfEvents() {
    return fillResponse(service.getTypeOfEventListForSearch());
  }

  @Override
  public List<DropdownChoice> getServiceUnitsByRegion(final Integer region) {
    return fillResponse(service.getServiceUnitListByRegion(region));
  }

  @Override
  public List<SearchEventResponse> searchEvents(final SearchEventRequest request) {
    final List<SearchEventGridDetail> searchEventListList = service
        .getSearchEventList(createSearchEventRequest(request));

    return createSearchResponse(searchEventListList);

  }

  private List<SearchEventResponse> createSearchResponse(final List<SearchEventGridDetail> searchEventListList) {
    final List<SearchEventResponse> responseList = new ArrayList<>();
    for (SearchEventGridDetail objSearchEventResponse : searchEventListList) {
      SearchEventResponse objResponse = new SearchEventResponse();
      objResponse.setServiceUnit(objSearchEventResponse.getServiceUnit());
      objResponse.setServiceUnitNbr(objSearchEventResponse.getServiceUnitNbr());
      objResponse.setEventDate(objSearchEventResponse.getEventDate());
      objResponse.setTypeOfEventAndRegulation(objSearchEventResponse.getTypeOfEventAndRegulation());
      objResponse.setEventStatus(objSearchEventResponse.getEventStatus());
      objResponse.setResponsibleManager(objSearchEventResponse.getResponsibleManager());
      objResponse.setResponsibleManagerID(objSearchEventResponse.getResponsibleManagerID());
      objResponse.setEmployeeID(objSearchEventResponse.getEmployeeID());
      objResponse.setEmployeePositionAndName(objSearchEventResponse.getEmployeePositionAndName());
      objResponse.setEmployeeStatus(objSearchEventResponse.getEmployeeStatus());
      objResponse.setDate(objSearchEventResponse.getDate());
      objResponse.setEventDetailID(objSearchEventResponse.getEventDetailID());
      objResponse.setEventTypeID(objSearchEventResponse.getEventTypeID());
      objResponse.setCreationEmployeeID(objSearchEventResponse.getCreationEmployeeID());
      objResponse.setEmployeeDetailsGroup(objSearchEventResponse.getEmployeeDetailsGroup());
      objResponse.setResponsibleManagerSvcUnit(objSearchEventResponse.getResponsibleManagerSvcUnit());
      objResponse.setEvntSrc(objSearchEventResponse.getEvntSrc());
      objResponse.setRegulation(objSearchEventResponse.getRegulation());
      objResponse.setEventDateOnly(objSearchEventResponse.getM_eventDateOnly());
      objResponse.setEventTime(objSearchEventResponse.getM_eventTime());
      responseList.add(objResponse);
    }
    return responseList;
  }

  private SearchEventDetail createSearchEventRequest(SearchEventRequest objSearchEventRequest) {
    SearchEventDetail objRequest = new SearchEventDetail();
    objRequest.setFromDate(objSearchEventRequest.getFromDate());
    objRequest.setToDate(objSearchEventRequest.getToDate());
    objRequest.setEmployeeID(objSearchEventRequest.getEmployeeID());
    objRequest.setResponsibleManagerID(objSearchEventRequest.getResponsibleManagerID());
    objRequest.setRegion(fillDropdownRequestValues(objSearchEventRequest.getRegion()));
    objRequest.setServiceUnit(fillDropdownRequestValues(objSearchEventRequest.getServiceUnit()));
    objRequest.setStatusOfEvent(fillDropdownRequestValues(objSearchEventRequest.getStatusOfEvent()));
    objRequest.setTypeOfEvent(fillDropdownRequestValues(objSearchEventRequest.getTypeOfEvent()));
    objRequest.setServiceUnitType(objSearchEventRequest.getServiceUnitType());
    objRequest.setViewPage(objSearchEventRequest.getIsViewPage());
    objRequest.setOtherEvent(objSearchEventRequest.getIsOtherEvent());
    objRequest.setAdminButton(objSearchEventRequest.getIsAdminButton());
    objRequest.setSearchEventGridDetailAll(objSearchEventRequest.getSearchEventGridDetailAll());
    objRequest.setLerbAction(objSearchEventRequest.getIsLerbAction());
    objRequest.setEvntSrc(fillDropdownRequestValues(objSearchEventRequest.getEvntSrc()));
    objRequest.setEventFromDate(objSearchEventRequest.getEventFromDate());
    objRequest.setEventToDate(objSearchEventRequest.getEventToDate());

    return objRequest;
  }

  private List<DropdownChoice> fillResponse(List<DDChoice> ddChoiceList) {

    List<DropdownChoice> dropdownChoiceList = new ArrayList<>();
    for (DDChoice objDDChoice : ddChoiceList) {
      DropdownChoice objResponse = new DropdownChoice();
      if (objDDChoice != null) {
        objResponse.setIntKey(objDDChoice.getIntKey());
        objResponse.setStrKey(objDDChoice.getStrKey());
        objResponse.setValue(objDDChoice.getValue());
        dropdownChoiceList.add(objResponse);
      }
    }
    return dropdownChoiceList;
  }

  private DDChoice fillDropdownRequestValues(DropdownChoice dropdownChoice) {

    DDChoice objRequest = null;
    if (dropdownChoice != null) {
      objRequest = new DDChoice();
      objRequest.setIntKey(dropdownChoice.getIntKey());
      objRequest.setStrKey(dropdownChoice.getStrKey());
      objRequest.setValue(dropdownChoice.getValue());
    }
    return objRequest;
  }

  @Override
  public boolean acceptMitigateEvent(MultipartHttpServletRequest multipartHttpServletRequest, Boolean isLerbAction) {
    try {
      MitigateEventDetailRequest eventDetailRequest = new ObjectMapper().readValue(
          multipartHttpServletRequest.getParameter("mitigateEventDetails"), MitigateEventDetailRequest.class);
      Map<String, List<MultipartFile>> fileMap = multipartHttpServletRequest.getMultiFileMap();

      List<MultipartFile> documents = new ArrayList<>();
      if (null != fileMap && fileMap.size() > 0) {
        for (Map.Entry<String, List<MultipartFile>> entry : fileMap.entrySet()) {
          for (MultipartFile multipartFile : entry.getValue()) {
            documents.add(multipartFile);
          }
        }
      }
      EQMSUserBean eqmsUserBean = eqmsUserSession.getUser();
      DossPutServiceClient dossPutClient = new DossPutServiceClientXmfImpl(dosPutInvoker);
      return service.acceptMitigateEvent(createMitigateEventDetailRequest(eventDetailRequest), eqmsUserBean.getEmplId(),
          isLerbAction, reasonServiceImpl.getAllReason(), documents, dossPutClient);

    } catch (Exception e) {
      LOGGER.error("acceptMitigateEvent failed : ", e);
    }
    return false;
  }

  private MitigateEventDetail createMitigateEventDetailRequest(
      MitigateEventDetailRequest objMitigateEventDetailRequest) {
    MitigateEventDetail objRequest = new MitigateEventDetail();
    objRequest.setEqmEvntDtlId(objMitigateEventDetailRequest.getEventDetailId());
    objRequest.setComment(objMitigateEventDetailRequest.getComment());
    objRequest.setRegulation(objMitigateEventDetailRequest.getRegulation());
    objRequest.setTypeOfEvent(objMitigateEventDetailRequest.getTypeOfEvent());
   // objRequest.setApplFlag(objMitigateEventDetailRequest.getMitgApplFlag());//Added for 8267
    return objRequest;
  }

  @Override
  public boolean updateComments(EmployeeDetails employeeDetails) {

    EQMSUserBean eqmsUserBean = eqmsUserSession.getUser();
    SearchEventGridDetail searchEventDetail = new SearchEventGridDetail();
    searchEventDetail.setEventDetailID(employeeDetails.getEventDetailId());
    searchEventDetail.setEventTypeID(employeeDetails.getEventTypeId());
    //SS_QC_9263 code changes start
    searchEventDetail.setTypeOfEventAndRegulation(employeeDetails.getEventAndRegulation());
    searchEventDetail.setEmployeeID(employeeDetails.getEmployeeId());
    searchEventDetail.setServiceUnitNbr(employeeDetails.getServiceUnitNbr());
    String[] eventAndRegulationSplit = employeeDetails.getEventAndRegulation().split("/");
    String regulation = eventAndRegulationSplit[1];
    if (employeeDetails.getEventType().equalsIgnoreCase(DecertificationApplicationConstant.FLAG_I)) {

      return service.markInvalid(employeeDetails.getComments(), employeeDetails.getEventDetailId(),
          eqmsUserBean.getEmplId(), reasonServiceImpl.getAllReason(), employeeDetails.getEventType(),
          regulation);
      //SS_QC_9263 code changes end
    } else if (employeeDetails.getEventType().equalsIgnoreCase(DecertificationApplicationConstant.FLAG_L)) {
      return service.cancelEvent(employeeDetails.getComments(), searchEventDetail, eqmsUserBean.getEmplId(),
          reasonServiceImpl.getAllReason(), employeeDetails.getEventType());
    }
    return false;
  }

  @Override
  public boolean submitDROCloseoutComments(EmployeeDetails employeeDetails) {
    EQMSUserBean eqmsUserBean = eqmsUserSession.getUser();
    Integer id = service.saveCmntsAndRemoveWI(employeeDetails.getEventDetailId(), eqmsUserBean.getEmplId(),
        employeeDetails.getComments());
    if (null != id) {
      return true;
    }
    return false;
  }

  @Override
  public String validateDROCloseout(EmployeeDetails employeeDetails) throws EqmDaoException {
	  EQMSUserBean eqmsUserBean = eqmsUserSession.getUser();
    if (!DecertificationApplicationConstant.EVENT_TYPE_ID_DECERTIFICATION.equals(employeeDetails.getEventTypeId())) {
    	return FeedbackMessageConstant.LERB_MESSAGE_017;
    } else if(checkServiceUnit(eqmsUserBean, employeeDetails.getServiceUnitNbr())){
    	return FeedbackMessageConstant.DRO_SVC_UNIT_MSG;
    }else if(!checkRoleForDROComments()){
    	return FeedbackMessageConstant.SEARCH_PAGE_DRO_PRIV_MSG;
    } else if (DecertificationMapper.getCloseEvntStatusList().contains(employeeDetails.getEventStatus())) {
      return "Event is already" + employeeDetails.getEventStatus() + ", 'so action cannot be performed.";
    } else if (service.isDROCmntsEntered(employeeDetails.getEventDetailId())) {
      return "DRO CloseOut Comments for the selected event is already entered.";
    } else if (!service.checkDROCmntsWI(employeeDetails.getEventDetailId())) {
      return FeedbackMessageConstant.EVENT_DETAILS_DRO_CMNTS;
    }
    return null;
  }
  
  /**
   * To check service unit of the logged manager.
   *
   * @author xsat128
   * @since Oct 17, 2013
   * Added For REQ#401-Part4.
   */
  private boolean checkServiceUnit(final EQMSUserBean eqmsUsrBean, final Integer evntSvcUnit){
	
    List<Integer> svcUnitList = new ArrayList<Integer>();
    Map<Integer, Set<EqmsEmplRoleAreaBean>> roleAreaMap = eqmsUsrBean.getEmplRoleAreaMap(); 
    if (eqmsUsrBean.getRoleSet().contains(EQMSConstant.ROLE_ID_SU_ADMIN)) {
      final Set<EqmsEmplRoleAreaBean> roleAreaSet = roleAreaMap.get(EQMSConstant.ROLE_ID_SU_ADMIN);
      getServiceUnitList(roleAreaSet, svcUnitList);
    }
    if(svcUnitList.contains(evntSvcUnit)){
      return false;
    }else{
      return true;
    }
  }
  
  private void getServiceUnitList(final Set<EqmsEmplRoleAreaBean> roleAreaSet, List<Integer> svcUnitList) {
	    for (final EqmsEmplRoleAreaBean roleAreaBean : roleAreaSet) {
	      svcUnitList.add(roleAreaBean.getSvcUnitNbr());
	    } 
	}
  
  private boolean checkRoleForDROComments() {
	  EQMSUserBean eqmsUserBean = eqmsUserSession.getUser();
	  boolean droCloseOut = false;
	    if (eqmsUserBean.getRoleSet().contains(EQMSConstant.SERVICE_UNIT_ADMIN_ROLE_ID)){
	      droCloseOut = true;
	    } 
	    return droCloseOut;
}

  @Override
  public EQMSUserBean getUserDetail() {
    EQMSUserBean eqmsUserBean = eqmsUserSession.getUser();
    return eqmsUserBean;
  }

  public String validateEventForUpdate(SearchEventGridDetail details) throws EqmDaoException {

    EQMSUserBean eqmsUserBean = eqmsUserSession.getUser();
    Set<Integer> roleSet = eqmsUserBean.getRoleSet();

    if (service.isAnyEmployeeReinstated(details.getEventDetailID())) {
      return "Event cannot be updated because one or more employees are reinstated.";
    } else if (service.isAnyEmployeeOfEventDecertified(details.getEventDetailID())) {
      return "Event cannot be updated because one or more employees are decertified.";
    } else if (service.isRevocationConfirmed(details.getEventDetailID(), null)) {
      return "Event cannot be updated because one or more employees have their revocation confirmed.";
    } else if ((roleSet != null) && (roleSet.size() == 1) && roleSet.contains(EQMSConstant.ROLE_ID_MANAGER)
        && !(eqmsUserBean.getEmplId().equalsIgnoreCase(details.getResponsibleManagerID()))) {
      return "Only the responsible manager can update this event.";
    }
    return null;
  }

  @Override
  public boolean updateResponsibleManager(EmployeeDetails employeeDetails) {
	  EQMSUserBean eqmsUserBean = eqmsUserSession.getUser();
    return service.changeRespManager(employeeDetails.getUpdatedManagerId(), employeeDetails.getEventDetailId(),
    		eqmsUserBean.getEmplId(), employeeDetails.getServiceUnitNbr());
  }

  @Override
  public boolean getResponsibleManagerById(String updatedManagerId) {  
    return service.getResponsibleManagerById(updatedManagerId);
  }

}
