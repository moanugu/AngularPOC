package com.uprr.lic.decert.rest.model;

import java.util.List;

import com.uprr.lic.dataaccess.decertification.model.EventEmployeeDetail;
import com.uprr.lic.util.DecertificationApplicationConstant;
import com.uprr.lic.util.Util;

public class EventLerbDetailResponse {

  
  private Integer lerbDtlId;

  protected EventEmployeeDetail employeeDropDown = new EventEmployeeDetail();

  protected DropdownChoice lerbAction;

  protected String docketNumber;

  protected String responseType;

  protected String dateReceived;

  protected String dueDate;
  
  protected String lerbAssignedTo;

  protected String lerbComments;

  protected String employeeId;
  
  protected String nameIdDisplay;

  protected List<EventDocumentDetail> documentList;
  
  //protected List<FileUpload> uploads = new ArrayList<FileUpload>();
  
  protected boolean hideAtmtFlag = false;
  
  public Integer getLerbDtlId() {
    return lerbDtlId;
  }

  public void setLerbDtlId(Integer lerbDtlId) {
    this.lerbDtlId = lerbDtlId;
  }

  public EventEmployeeDetail getEmployeeDropDown() {
    return employeeDropDown;
  }

  public void setEmployeeDropDown(EventEmployeeDetail employeeDropDown) {
    this.employeeDropDown = employeeDropDown;
  }

  public DropdownChoice getLerbAction() {
    return lerbAction;
  }

  public void setLerbAction(DropdownChoice lerbAction) {
    this.lerbAction = lerbAction;
  }

  public String getDocketNumber() {
    return docketNumber;
  }

  public void setDocketNumber(String docketNumber) {
    this.docketNumber = docketNumber;
  }

  public String getResponseType() {
    return responseType;
  }

  public void setResponseType(String responseType) {
    this.responseType = responseType;
  }

  public String getDateReceived() {
    return dateReceived;
  }

  public void setDateReceived(String dateReceived) {
    this.dateReceived = dateReceived;
  }

  public String getDueDate() {
    return dueDate;
  }

  public void setDueDate(String dueDate) {
    this.dueDate = dueDate;
  }

  public String getLerbComments() {
    return lerbComments;
  }

  public void setLerbComments(String lerbComments) {
    this.lerbComments = lerbComments;
  }

  public String getLerbAssignedTo() {
    return lerbAssignedTo;
  }

  public void setLerbAssignedTo(String lerbAssignedTo) {
    //added for QC 1056 II starts
    if (lerbAssignedTo == null || DecertificationApplicationConstant.BLANK_STRING.equalsIgnoreCase(lerbAssignedTo.trim())) {
      this.lerbAssignedTo = DecertificationApplicationConstant.BLANK_STRING;
    } else {
      this.lerbAssignedTo = Util.convertLookUpFormatToEmplID(lerbAssignedTo);
    }
  //added for QC 1056 II ends
  }

  public String getEmployeeId() {
    return employeeId;
  }

  public void setEmployeeId(String employeeId) {
    this.employeeId = employeeId;
  }

  public List<EventDocumentDetail> getDocumentList() {
    return documentList;
  }

  public void setDocumentList(List<EventDocumentDetail> documentList) {
    this.documentList = documentList;
  }

  public String getNameIdDisplay() {
    return nameIdDisplay;
  }

  public void setNameIdDisplay(String nameIdDisplay) {
    this.nameIdDisplay = nameIdDisplay;
  }

 /* public List<FileUpload> getUploads() {
    return uploads;
  }

  public void setUploads(List<FileUpload> uploads) {
    this.uploads = uploads;
  }*/

  public boolean isHideAtmtFlag() {
    return hideAtmtFlag;
  }

  public void setHideAtmtFlag(boolean hideAtmtFlag) {
    this.hideAtmtFlag = hideAtmtFlag;
  }
}
