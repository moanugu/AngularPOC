package com.uprr.lic.decert.service;

import org.springframework.web.bind.annotation.RequestBody;

import com.uprr.lic.dataaccess.decertification.model.WorkQueueLcnsDtl;
import com.uprr.lic.decert.jms.cmts.PendingRulesSender;

public interface IWorkQueueService {

  boolean updateWorkQueueDetailst(@RequestBody WorkQueueLcnsDtl workQueueLcnsDtl,
      PendingRulesSender pendingRulesSender);
 
  boolean updateWorkQueueDetailstForDAA(@RequestBody WorkQueueLcnsDtl workQueueLcnsDtl,
	      PendingRulesSender pendingRulesSender);

}
