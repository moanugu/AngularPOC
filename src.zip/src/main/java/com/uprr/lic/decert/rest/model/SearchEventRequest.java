package com.uprr.lic.decert.rest.model;

import java.util.Date;
import java.util.List;

public class SearchEventRequest {
	private Date fromDate;
	private Date toDate;
	private String employeeID;
	private String responsibleManagerID;
	private DropdownChoice region;
	private DropdownChoice serviceUnit;
	private DropdownChoice statusOfEvent;
	private DropdownChoice typeOfEvent;
	private String serviceUnitType;
	private boolean isViewPage;
	private boolean isOtherEvent;
	private boolean isAdminButton;
	private List searchEventGridDetailAll;
	private boolean isLerbAction;
	private DropdownChoice evntSrc;
	private String eventFromDate;
	private String eventToDate;

	public Date getFromDate() {
		return fromDate;
	}

	public void setFromDate(final Date fromDate) {
		this.fromDate = fromDate;
	}

	public Date getToDate() {
		return toDate;
	}

	public void setToDate(final Date toDate) {
		this.toDate = toDate;
	}

	public String getEmployeeID() {
		return employeeID;
	}

	public void setEmployeeID(final String employeeID) {
		this.employeeID = employeeID;
	}

	public String getResponsibleManagerID() {
		return responsibleManagerID;
	}

	public void setResponsibleManagerID(final String responsibleManagerID) {
		this.responsibleManagerID = responsibleManagerID;
	}

	public DropdownChoice getRegion() {
		return region;
	}

	public void setRegion(final DropdownChoice region) {
		this.region = region;
	}

	public DropdownChoice getServiceUnit() {
		return serviceUnit;
	}

	public void setServiceUnit(final DropdownChoice serviceUnit) {
		this.serviceUnit = serviceUnit;
	}

	public DropdownChoice getStatusOfEvent() {
		return statusOfEvent;
	}

	public void setStatusOfEvent(final DropdownChoice statusOfEvent) {
		this.statusOfEvent = statusOfEvent;
	}

	public DropdownChoice getTypeOfEvent() {
		return typeOfEvent;
	}

	public void setTypeOfEvent(final DropdownChoice typeOfEvent) {
		this.typeOfEvent = typeOfEvent;
	}

	public String getServiceUnitType() {
		return serviceUnitType;
	}

	public void setServiceUnitType(final String serviceUnitType) {
		this.serviceUnitType = serviceUnitType;
	}

	public boolean getIsViewPage() {
		return isViewPage;
	}

	public void setIsViewPage(final boolean isViewPage) {
		this.isViewPage = isViewPage;
	}

	public boolean getIsOtherEvent() {
		return isOtherEvent;
	}

	public void setIsOtherEvent(final boolean isOtherEvent) {
		this.isOtherEvent = isOtherEvent;
	}

	public boolean getIsAdminButton() {
		return isAdminButton;
	}

	public void setIsAdminButton(final boolean isAdminButton) {
		this.isAdminButton = isAdminButton;
	}

	public List getSearchEventGridDetailAll() {
		return searchEventGridDetailAll;
	}

	public void setSearchEventGridDetailAll(final List searchEventGridDetailAll) {
		this.searchEventGridDetailAll = searchEventGridDetailAll;
	}

	public boolean getIsLerbAction() {
		return isLerbAction;
	}

	public void setIsLerbAction(final boolean isLerbAction) {
		this.isLerbAction = isLerbAction;
	}

	public DropdownChoice getEvntSrc() {
		return evntSrc;
	}

	public void setEvntSrc(final DropdownChoice evntSrc) {
		this.evntSrc = evntSrc;
	}

	public String getEventFromDate() {
		return eventFromDate;
	}

	public void setEventFromDate(final String eventFromDate) {
		this.eventFromDate = eventFromDate;
	}

	public String getEventToDate() {
		return eventToDate;
	}

	public void setEventToDate(final String eventToDate) {
		this.eventToDate = eventToDate;
	}
}
