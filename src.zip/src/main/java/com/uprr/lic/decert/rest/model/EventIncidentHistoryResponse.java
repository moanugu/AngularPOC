package com.uprr.lic.decert.rest.model;

public class EventIncidentHistoryResponse {
	private String action;
	private String date;
	private String actionTakenBy;
	private String comments;
	private Integer evntDtlId;
	private Integer reasonId;
	private String employeeId;
	private Integer emplCmntDtlsId;
	private boolean isRemedialTrainingApproved;
	public String getAction() {
		return action;
	}

	public void setAction(final String action) {
		this.action = action;
	}

	public String getDate() {
		return date;
	}

	public void setDate(final String date) {
		this.date = date;
	}

	public String getActionTakenBy() {
		return actionTakenBy;
	}

	public void setActionTakenBy(final String actionTakenBy) {
		this.actionTakenBy = actionTakenBy;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(final String comments) {
		this.comments = comments;
	}

	public Integer getEvntDtlId() {
		return evntDtlId;
	}

	public void setEvntDtlId(final Integer evntDtlId) {
		this.evntDtlId = evntDtlId;
	}

	public Integer getReasonId() {
		return reasonId;
	}

	public void setReasonId(final Integer reasonId) {
		this.reasonId = reasonId;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(final String employeeId) {
		this.employeeId = employeeId;
	}

	public Integer getEmplCmntDtlsId() {
		return emplCmntDtlsId;
	}

	public void setEmplCmntDtlsId(final Integer emplCmntDtlsId) {
		this.emplCmntDtlsId = emplCmntDtlsId;
	}
	
	public boolean isRemedialTrainingApproved() {
		return isRemedialTrainingApproved;
	}
	
	public void setRemedialTrainingApproved(boolean isRemedialTrainingApproved) {
		this.isRemedialTrainingApproved = isRemedialTrainingApproved;
	}
}
