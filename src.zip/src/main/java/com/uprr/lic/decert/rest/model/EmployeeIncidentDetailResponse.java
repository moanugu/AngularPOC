package com.uprr.lic.decert.rest.model;

import java.util.Calendar;
import java.util.List;

import com.uprr.lic.dataaccess.decertification.model.RemedialTrainingDetail;

public class EmployeeIncidentDetailResponse {

	private String effectiveDate;

	private String revocationLength;

	private Integer noOfDays;

	private String eapDate;

	private String eapRequired;

	private String ftxEvent;

	private Calendar evntDate;

	private String offcNbr;

	private String regFlag;
	
	private String employeeStatus;
	
	private String reinstateDate;
	
	public String getReinstateDate() {
		return reinstateDate;
	}

	public void setReinstateDate(String reinstateDate) {
		this.reinstateDate = reinstateDate;
	}

	private List<RemedialTrainingDetail> remedialDetailList;


	public List<RemedialTrainingDetail> getRemedialDetailList() {
		return remedialDetailList;
	}

	public void setRemedialDetailList(List<RemedialTrainingDetail> remedialDetailList) {
		this.remedialDetailList = remedialDetailList;
	}

	public String getEmployeeStatus() {
		return employeeStatus;
	}

	public void setEmployeeStatus(String employeeStatus) {
		this.employeeStatus = employeeStatus;
	}

	public String getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(String effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public String getRevocationLength() {
		return revocationLength;
	}

	public void setRevocationLength(String revocationLength) {
		this.revocationLength = revocationLength;
	}

	public Integer getNoOfDays() {
		return noOfDays;
	}

	public void setNoOfDays(Integer noOfDays) {
		this.noOfDays = noOfDays;
	}

	public String getEapDate() {
		return eapDate;
	}

	public void setEapDate(String eapDate) {
		this.eapDate = eapDate;
	}

	public String getEapRequired() {
		return eapRequired;
	}

	public void setEapRequired(String eapRequired) {
		this.eapRequired = eapRequired;
	}

	public String getFtxEvent() {
		return ftxEvent;
	}

	public void setFtxEvent(String ftxEvent) {
		this.ftxEvent = ftxEvent;
	}

	public Calendar getEvntDate() {
		return evntDate;
	}

	public void setEvntDate(Calendar evntDate) {
		this.evntDate = evntDate;
	}

	public String getOffcNbr() {
		return offcNbr;
	}

	public void setOffcNbr(String offcNbr) {
		this.offcNbr = offcNbr;
	}

	public String getRegFlag() {
		return regFlag;
	}

	public void setRegFlag(String regFlag) {
		this.regFlag = regFlag;
	}
 
}
