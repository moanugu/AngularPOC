package com.uprr.lic.decert.rest.model;

public class FaxRemedialDetailRequest  {

  private String employeeID;

  private String employeeName;

  private String remedialDate;

  private String remedialReceive;

  private String remedialEffect;

  private Integer eventDetailID;

  private Integer dcrtEmplStatID;

  private String respMgrId;

  public String getEmployeeID() {
    return employeeID;
  }

  public void setEmployeeID(final String employeeID) {
	  this.employeeID = employeeID;
  }

  public String getEmployeeName() {
    return employeeName;
  }

  public void setEmployeeName(final String employeeName) {
	  this.employeeName = employeeName;
  }

  public String getRemedialDate() {
    return remedialDate;
  }

  public void setRemedialDate(final String remedialDate) {
	  this.remedialDate = remedialDate;
  }

  public String getRemedialReceive() {
    return remedialReceive;
  }

  public void setRemedialReceive(final String remedialReceive) {
	  this.remedialReceive = remedialReceive;
  }

  public String getRemedialEffect() {
    return remedialEffect;
  }

  public void setRemedialEffect(final String remedialEffect) {
	  this.remedialEffect = remedialEffect;
  }

  public Integer getEventDetailID() {
    return eventDetailID;
  }

  public void setEventDetailID(final Integer eventDetailID) {
	  this.eventDetailID = eventDetailID;
  }

  public Integer getDcrtEmplStatID() {
    return dcrtEmplStatID;
  }

  public void setDcrtEmplStatID(final Integer dcrtEmplStatID) {
    this.dcrtEmplStatID = dcrtEmplStatID;
  }

  /**
   * @return the respMgrId
   */
  public String getRespMgrId() {
    return respMgrId;
  }

  /**
   * @param respMgrId the respMgrId to set
   */
  public void setRespMgrId(String respMgrId) {
    this.respMgrId = respMgrId;
  }

}
