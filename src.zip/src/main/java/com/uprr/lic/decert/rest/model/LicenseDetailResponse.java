package com.uprr.lic.decert.rest.model;

import java.util.Calendar;

import com.uprr.lic.util.DecertificationApplicationConstant;

public class LicenseDetailResponse {

	private String jobType;

	private String assignedManager = "-";

	private String licenseStartDate;

	private String licenseIssueDate;

	private String licenseExpirationDate;

	private String lastSkillRide = "-";

	private String skillRideConductedBy = "-";

	private String licenseClassCode;

	private String certFlag;

	private Integer licenseDtlID;

	private Calendar crtnDate;

	public String getJobType() {
		return jobType;
	}

	public void setJobType(final String jobType) {
		this.jobType = jobType;
	}

	public String getAssignedManager() {
		return assignedManager;
	}

	public void setAssignedManager(final String assignedManager) {
		this.assignedManager = assignedManager;
	}

	public String getLicenseStartDate() {
		return licenseStartDate;
	}
	
	public void setLicenseStartDate(final String licenseStartDate) {
		this.licenseStartDate = licenseStartDate;
	}

	public void setLicenseStartDate(final Calendar licenseStartDate) {
		if(licenseStartDate != null) {
			 //licenseStartDate = DateUtil.getDateAsString(licenseStartDate);
		} else {
			this.licenseStartDate = DecertificationApplicationConstant.HYPHEN_STRING;
		}
	}

	public String getLicenseExpirationDate() {
		return licenseExpirationDate;
	}

	public void setLicenseExpirationDate(String licenseExpirationDate) {
			this.licenseExpirationDate = licenseExpirationDate;
	}

	public String getLastSkillRide() {
		return lastSkillRide;
	}

	public void setLastSkillRide(final String lastSkillRide) {
		this.lastSkillRide = lastSkillRide;
	}

	public String getSkillRideConductedBy() {
		return skillRideConductedBy;
	}

	public void setSkillRideConductedBy(final String skillRideConductedBy) {
		this.skillRideConductedBy = skillRideConductedBy;
	}

	public String getLicenseClassCode() {
		return licenseClassCode;
	}

	public void setLicenseClassCode(final String licenseClassCode) {
		this.licenseClassCode = licenseClassCode;
	}

	public Integer getLicenseDtlID() {
		return licenseDtlID;
	}

	public void setLicenseDtlID(final Integer licenseDtlID) {
		this.licenseDtlID = licenseDtlID;
	}

	/**
	 * @return the licenseIssueDate
	 */
	public String getLicenseIssueDate() {
		return licenseIssueDate;
	}

	/**
	 * @param licenseIssueDate the licenseIssueDate to set
	 */
	public void setLicenseIssueDate(String licenseIssueDate) {
			this.licenseIssueDate = licenseIssueDate;
	}

	/**
	 * @return the certFlag
	 */
	public String getCertFlag() {
		return certFlag;
	}

	/**
	 * @param certFlag the certFlag to set
	 */
	public void setCertFlag(String certFlag) {
		this.certFlag = certFlag;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((licenseDtlID == null) ? 0 : licenseDtlID.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		final LicenseDetailResponse other = (LicenseDetailResponse) obj;
		if (licenseDtlID == null) {
			if (other.licenseDtlID != null)
				return false;
		} else if (!licenseDtlID.equals(other.licenseDtlID))
			return false;
		return true;
	}

	public Calendar getCrtnDate() {
		return crtnDate;
	}

	public void setCrtnDate(Calendar crtnDate) {
		this.crtnDate = crtnDate;
	}

}
