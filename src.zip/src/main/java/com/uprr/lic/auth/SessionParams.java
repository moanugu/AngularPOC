package com.uprr.lic.auth;

import java.util.List;

public class SessionParams {
    private String key;

    private List<String> valueList;

    public String getKey() {
      return key;
    }

    public void setKey(String key) {
      this.key = key;
    }

    public List<String> getValueList() {
      return valueList;
    }

    public void setValueList(List<String> valueList) {
      this.valueList = valueList;
    }

  }