package com.uprr.lic.auth;

import com.uprr.netcontrol.shared.components.error.NCErrorLevelEnum;
import com.uprr.netcontrol.shared.components.error.impl.NCErrorImpl;
import com.uprr.netcontrol.shared.components.error.impl.NCErrorKeyImpl;
import com.uprr.netcontrol.shared.components.exception.NCErrorRuntimeException;

public class LicUnAuthorizedAccessException extends NCErrorRuntimeException {

  private static final String ACCESS_DENIED = "Access Denied : ";

  private static final long serialVersionUID = 1L;

  public LicUnAuthorizedAccessException(String message) {
    super(ACCESS_DENIED + message, createAccessError(message));
  }

  private static NCErrorImpl createAccessError(String errorDescription) {
    return new NCErrorImpl(new NCErrorKeyImpl("0", "LICACCESS"), ACCESS_DENIED + errorDescription,
        NCErrorLevelEnum.ERROR);
  }
}