package com.uprr.lic.auth;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class SessionController {

  @Autowired
  private EQMSUserSession authSession;

  @RequestMapping(value = "/addToSession", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
  @ResponseBody
  public void addToSession(@RequestBody SessionParams sessionParams) {
    authSession.getSessionMap().put(sessionParams.getKey(), sessionParams.getValueList());
  }

  @RequestMapping(value = "/getFromSession/{key}", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
  @ResponseBody
  public Object getFromSession(@PathVariable String key) {
    if (authSession.getSessionMap().containsKey(key)) {
      return authSession.getSessionMap().get(key);
    }
    return null;
  }
}
