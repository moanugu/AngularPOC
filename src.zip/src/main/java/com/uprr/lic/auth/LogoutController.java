package com.uprr.lic.auth;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class LogoutController {

  Logger LOGGER = LoggerFactory.getLogger(LogoutController.class);

  @RequestMapping(value = "/logout", method = RequestMethod.GET)
  public void logout(HttpServletRequest request, HttpServletResponse response) {
    final HttpSession session = request.getSession(false);
    try {
      if (null != session) {
        session.invalidate();
      }
      Cookie jSessioncookie = new Cookie("JSESSIONID", null);
      jSessioncookie.setMaxAge(0);
      jSessioncookie.setPath("/lic/");
      response.addCookie(jSessioncookie);

      response.sendRedirect("/admin/logout.shtml");

    } catch (Exception e) {
      LOGGER.error("Failed to redirect to /admin/logout.shtml", e);
    }

  }
}
