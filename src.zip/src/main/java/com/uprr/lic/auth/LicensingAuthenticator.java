package com.uprr.lic.auth;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.uprr.lic.dataaccess.common.dao.impl.EqmsDao;
import com.uprr.lic.dataaccess.common.model.EqmEmplDtls;
import com.uprr.lic.dataaccess.common.model.EqmSysParm;
import com.uprr.lic.dataaccess.common.model.PersonBean;
import com.uprr.lic.dataaccess.components.common.delegate.EqmsDelegate;
import com.uprr.lic.dataaccess.components.licensing.delegate.LicensingDelegate;
import com.uprr.lic.dataaccess.masters.service.ISysParamService;
import com.uprr.lic.exception.EqmDaoException;
import com.uprr.lic.util.EQMSConstant;
import com.uprr.lic.util.EQMSMessages;
import com.uprr.lic.util.ExceptionMessage;
import com.uprr.lic.util.SysParamBean;
import com.uprr.lic.util.Util;

@Service
@Scope("prototype")
public class LicensingAuthenticator {
  private static final String ACCESS_DENIED = "Access Denied";

  private Logger logger = LoggerFactory.getLogger(LicensingAuthenticator.class);

  private static final String LDAP_SYSTEM_ADMIN = "EQM-SYSTEM-ADMIN";

  private static final String LDAP_USER = "EQM-USER";

  private static final String LDAP_MANAGER = "EQM_Manager";

  private String m_feedbackMessage = EQMSMessages.MESSAGE_INSUFFICIENT_ROLE;

  private List<String> localhostLdapRoles = new ArrayList<>();

  boolean m_EmplRcdFlag = true;

  boolean m_AgrmIndFlag = true;

  private List<String> m_ldapRoleList = new ArrayList<String>();

  private static String AGREEMENT_IND = null;

  @Autowired
  private EqmsDelegate eqmsDelegate;

  @Autowired
  private ISysParamService sysParamService;

  @Autowired
  private EQMSUserSessionDetail m_empRoleBean;

  @Autowired
  private LicensingDelegate licDelegate;// added for REQ-276

  @Autowired
  private EQMSUserSession authSession;

  public String validateEmployee(HttpServletRequest request) {

    m_ldapRoleList = new ArrayList<String>();
    // -- GET REQUEST OBJECT
    // printRequest(request.getHeaderNames(), request);
    // printRequest(request.getParameterNames(), request);
    // printRequest(request.getAttributeNames(), request);
    // -- GET USER ID FROM REQUEST
    String empId = getEmployeeId(request);
    final EQMSUserBean userbean = checkEmployeeSecurityAccess(empId, request);

    try {

      // -- CHECK IF EMPLOYEE INFORMATION WAS OBTAINED
      if (userbean == null && m_EmplRcdFlag == true) {

        logger.error("submitButton() :: employee not present in EQMS System"
            + "employee does not exist or does not possess " + "any secutity access to the EQMS system :: ");
        throw new LicUnAuthorizedAccessException(m_feedbackMessage);
      }

    } catch (Exception e) {
      logger.error("EXCEPTION :: loadUserBeanData() ::" + e.getMessage(), e);
      // throw new RestartResponseAtInterceptPageException(new
      // InvalidLoginPage(ExceptionMessage.EQMS002));
      throw new LicUnAuthorizedAccessException(ExceptionMessage.EQMS002);
    }

    return empId;
  }

  private String getEmployeeId(HttpServletRequest request) {
    String m_empId = null;
    String m_tcsUserId = null;
    m_empId = Util.removeExtraZeroEmployeeId((String) request.getHeader("emplId"));
    if (!SessionInterceptor.IS_LOCAL_ENVIRONMENT) {
      m_tcsUserId = (String) request.getUserPrincipal().getName();
      if (m_tcsUserId == null) {
        logger.error("getEmployeeId User id is null");
        return null;
      }
    } else {
      if (request.getHeader("ldapRoleList") != null) {
        localhostLdapRoles = Arrays.asList(request.getHeader("ldapRoleList").split(","));
      }
      m_tcsUserId = "";
    }

    // -- HARDCODED EMPL IDS FOR TESTING
    m_empId = getTestEmployeeID(m_empId, m_tcsUserId);

    return m_empId;
  }

  public static String getTestEmployeeID(String m_empId, String m_tcsUserId) {
    // -- HARDCODED EMPL IDS FOR TESTING
    if (m_tcsUserId.equalsIgnoreCase("XMIE060")) {
      m_empId = "9000001";
    } else if (m_tcsUserId.equalsIgnoreCase("XMIE061")) {
      m_empId = "9000002";
    } else if (m_tcsUserId.equalsIgnoreCase("XMIE062")) {
      m_empId = "9000003";
    } else if (m_tcsUserId.equalsIgnoreCase("XMIE063")) {
      m_empId = "9000004";
    } else if (m_tcsUserId.equalsIgnoreCase("XMIE064")) {
      m_empId = "9000005";
    } else if (m_tcsUserId.equalsIgnoreCase("XMIE065")) {
      m_empId = "9000006";
    } else if (m_tcsUserId.equalsIgnoreCase("XMIE066")) {
      m_empId = "9000007";
    } else if (m_tcsUserId.equalsIgnoreCase("XMIE067")) {
      m_empId = "9000008";
    } else if (m_tcsUserId.equalsIgnoreCase("XMIE068")) {
      m_empId = "9000009";
    } else if (m_tcsUserId.equalsIgnoreCase("XMIE069")) {
      m_empId = "9000010";
    } else if (m_tcsUserId.equalsIgnoreCase("XMIE070")) {
      m_empId = "9000011";
    } else if (m_tcsUserId.equalsIgnoreCase("XMIE071")) {
      m_empId = "9000012";
    } else if (m_tcsUserId.equalsIgnoreCase("XMIE072")) {
      m_empId = "9000013";
    } else if (m_tcsUserId.equalsIgnoreCase("XMIE073")) {
      m_empId = "9000014";
    } else if (m_tcsUserId.equalsIgnoreCase("XMIE074")) {
      m_empId = "9000015";
    } else if (m_tcsUserId.equalsIgnoreCase("XMIE075")) {
      m_empId = "9000016";
    } else if (m_tcsUserId.equalsIgnoreCase("XMIE076")) {
      m_empId = "9000017";
    } else if (m_tcsUserId.equalsIgnoreCase("XMIE077")) {
      m_empId = "9000018";
    } else if (m_tcsUserId.equalsIgnoreCase("XMIE078")) {
      m_empId = "9000019";
    } else if (m_tcsUserId.equalsIgnoreCase("XMIE079")) {
      m_empId = "9000020";
    } else if (m_tcsUserId.equalsIgnoreCase("XMIE080")) {
      m_empId = "9000021";
    } else if (m_tcsUserId.equalsIgnoreCase("XMIE056")) {
      m_empId = "9000022";
    } else if (m_tcsUserId.equalsIgnoreCase("XMIE057")) {
      m_empId = "9000023";
    } else if (m_tcsUserId.equalsIgnoreCase("XMIE058")) {
      m_empId = "9000024";
    } else if (m_tcsUserId.equalsIgnoreCase("XMIE059")) {
      m_empId = "9000025";
    } else if (m_tcsUserId.equalsIgnoreCase("XMIE284")) {
      m_empId = "9000026";
    }
    return m_empId;
  }

  private EQMSUserBean checkEmployeeSecurityAccess(String emplId, HttpServletRequest request) {

    // EQMSUserBean userBean = loadUserBeanData(emplId);

    // For QC 1092 -- Announcement Display
    String loggedInUserId = EqmsDao.getValidEmployeeId(emplId);
    // TODO //DO we need announcement List or redirect to old app?
    // announcementsList =
    // m_eqmsDelegate.getAnnouncementForDisplay(loggedInUserId);
    getUserLdapRoleList(emplId, request);

    // -- CHECK IF USER HAS ANY LDAP ROLES
    if ((m_ldapRoleList == null) || (m_ldapRoleList.isEmpty())) {
      logger.warn("checkEmployeeSecurityAccess() :: ldapRoleList is null or employee does not "
          + "have the LDAP roles of USER, SYSTEM ADMIN ,MANAGER Or HR Transportation manager :: ");
      // QC# 1324 changes starts
      // Modified for SS_QC_4988 - Start.
      final Map<String, SysParamBean> sysParamMap = sysParamService.getAllSystemParameter();
      final boolean yardMasterFlag = eqmsDelegate.isLoggedInUserAsYardMaster(emplId, sysParamMap);
      // Modified for SS_QC_4988 - End.
      if (yardMasterFlag) {
        EQMSUserBean userBean = loadUserBeanData(emplId);
        userBean.setLoggedInUserAsYardMaster(true);
        authSession.setUser(userBean);
      } else {

        PersonBean personBean = null;
        personBean = getPersonBeanFromEqms(emplId);
        if (null == personBean) {
          personBean = getPersonBeanFromPeopleSoft(emplId);
        } /* Code changes for REQ-276 end */
        if (personBean != null && m_AgrmIndFlag == true) { // -- IF
          // NON-AGREEMENT
          // EMPLOYEE.
          EQMSUserBean userBean = loadUserBeanData(emplId); // --
          // CHECK
          // WHETHER
          // EMPLOYEE
          // PRESENT
          // IN
          // EQMS.
          // -- IF EMPLOYEE PRESENT IN EQMS AND HIST FLAG = N
          if (userBean != null && (EQMSConstant.VALUE_N
              .equalsIgnoreCase(eqmsDelegate.getEmployeeDetailsForLdap(emplId).getHistRcdFlag()))) {
            authSession.setUser(userBean);
            /* Code changes for REQ-276 start */
            boolean hasValidRqmt = licDelegate.isRecertificationInitiatedForEmployee(userBean.getEmplId(), null, 1);

            if (hasValidRqmt) {
              userBean.setNonEqmsUser(true);
            } else {
              logger.error("Logged-in user has no valid requirements. redirecting to Search Locomotive download page.");
              userBean.setHasMenu(false);
            } /* Code changes for REQ-276 end */
            // return userBean;
          }
          // -- IF EMPLOYEE PRESENT IN EQMS AND HIST FLAG = Y
          else if (userBean != null && (!(EQMSConstant.VALUE_N
              .equalsIgnoreCase(eqmsDelegate.getEmployeeDetailsForLdap(emplId).getHistRcdFlag())))) {
            m_feedbackMessage = EQMSMessages.MESSAGE_NO_MANAGER_ROLE;
            logger.error("Logged-in user present in EQMS but hist_rcd_flag as 'Y', redirecting to Invalid Login page.");
            throw new LicUnAuthorizedAccessException(ACCESS_DENIED);
          }
          // -- IF EMPLOYEE RECORD DOESN'T EXIST IN EQMS.
          else {
            logger.error("submitButton() :: employee not present in EQMS System"
                + "employee does not exist or does not possess ");
            m_EmplRcdFlag = false;
            authSession.setUser(userBean);
            /* Bookmarkable link changes added by xsat244 */
            // throw new
            // RestartResponseAtInterceptPageException(SearchLocomotiveDownload.class);
          }
        } else if (personBean == null && m_AgrmIndFlag == true) { // --
          // IF
          // AGREEMENT
          // EMPLOYEE
          m_EmplRcdFlag = false;
          m_feedbackMessage = EQMSMessages.MESSAGE_NO_MANAGER_ROLE;
          logger.error("Logged-in user is an agreement employee, redirecting to Invalid Login page.");
          /* Bookmarkable link changes added by xsat244 */
          throw new LicUnAuthorizedAccessException(ACCESS_DENIED);
        } else {
          // -- FOR ANY EXCEPTION FROM PEOPLESOFT
          m_EmplRcdFlag = false;
          m_feedbackMessage = EQMSMessages.MESSAGE_NO_MANAGER_ROLE;
          /* Bookmarkable link changes added by xsat244 */
          logger.error(
              "Redirect user to Invalid Login page, due to some exceptions occured while processing the details on Peopesoft.");
          throw new LicUnAuthorizedAccessException(ACCESS_DENIED);
        }
      }
    } else {

      EQMSUserBean userBean = loadUserBeanData(emplId); // --CHECK FOR
      // EMPLOYEE
      // PRESENCE IN
      // EQMS
      // --IF EMPLOYEE PRESENT IN EQMS AND HIST FLAG = N
      if (userBean != null
          && (EQMSConstant.VALUE_N.equalsIgnoreCase(eqmsDelegate.getEmployeeDetailsForLdap(emplId).getHistRcdFlag()))) {
        // IMPLEMENT THE LDAP FLOWCHART
        userBean = implementLDAP(userBean); // -- CHECK FOR THE CORRECT
        // LDAP ROLE
        if (userBean != null) { // -- IF LDAP ROLE VALID
          // EQMSUserBean userBean2 = loadUserBeanData(emplId); //
          // Commented for unnecessary calling of method twice.
          EQMSUserBean userBean2 = userBean; // To avoid repetition of
          // calling method
          // loadUserBeanData.
          // NAVIGATE USER TO THE EQMS SUMMARY PAGE.
          authSession.setUser(userBean2);
          /* Bookmarkable link changes added by xsat244. */

          return userBean2;
        } else {
          /* Bookmarkable link changes added by xsat244. */
          logger.error("If the logged-in employee has no valid roles in LDAP.");
          /* FOR INVALID LDAP ROLE */
          throw new LicUnAuthorizedAccessException(m_feedbackMessage);
        }
      }
      // -- IF EMPLOYEE PRESENT IN EQMS AND HIST FLAG = Y
      else if (userBean != null && (!(EQMSConstant.VALUE_N
          .equalsIgnoreCase(eqmsDelegate.getEmployeeDetailsForLdap(emplId).getHistRcdFlag())))) {
        m_feedbackMessage = EQMSMessages.MESSAGE_NO_MANAGER_ROLE;
        /* Bookmarkable link changes added by xsat244. */
        throw new LicUnAuthorizedAccessException(EQMSMessages.MESSAGE_NO_MANAGER_ROLE);
      }
      // -- IF EMPLOYEE RECORD DOESN'T EXIST IN EQMS.
      else {
        logger.error("submitButton() :: employee not present in EQMS System"
            + "employee does not exist or does not possess " + "any secutity access to the EQMS system :: ");

        PersonBean personBean = getPersonBeanFromPeopleSoft(emplId); // --
        // CHECK WHETHER NON - AGREEMENT EMPLOYEE FROM PEOPLESOFT
        if (personBean != null && m_AgrmIndFlag == true) { // -- IF NON AGREEMENT EMPLOYEE
          m_EmplRcdFlag = false;
          // --INSERT EMPLOYEE DETAILS INTO THE DATABASE
          insertEqmEmplDtls(emplId);
          // -- TAKE EMPLOYEE TO HOME PAGE
          EQMSUserBean userBeanAfterInsertion = loadUserBeanData(emplId);
          authSession.setUser(userBeanAfterInsertion);

        } else if (personBean == null /* && m_AgrmIndFlag == true */) { // --
          // IF
          // AGREEMENT
          // EMPLOYEE
          // or
          // value
          // is
          // null
          // in
          // peoplesoft
          m_feedbackMessage = EQMSMessages.MESSAGE_NO_MANAGER_ROLE;
          /* Bookmarkable link changes added by xsat244. */
          logger.error("Agreement Employee or No details in PeopleSoft::Redirecting user to Invalid login page.");
          throw new LicUnAuthorizedAccessException((EQMSMessages.MESSAGE_NO_MANAGER_ROLE));
        } else { // -- IF EMPLOYEE NOT PRESENT IN PEOPLESOFT OR
          // AGREEMENT INDICATOR IS NULL.
          m_feedbackMessage = ExceptionMessage.EQMS002;
          logger.error("Redirecting user to Invalid login page.");
          throw new LicUnAuthorizedAccessException(ExceptionMessage.EQMS002);
        }
      }

    }
    return null;
  }

  private void getUserLdapRoleList(String emplId, HttpServletRequest request) {
    String hrManagerRole = null;
    String hrManagerRoleName = null;
    String createOwnRole = null;
    String emplRoleSet = null;
    List<String> LDAPRoleList = new ArrayList<String>();
    List<String> rolesLst = new ArrayList<String>();
    EqmSysParm eqmSysParm = eqmsDelegate.getSystemParam(EQMSConstant.HR_TRANSPORTATION_MANAGER_ROLE);
    if (eqmSysParm != null) {
      hrManagerRole = eqmSysParm.getParmValu();
    }

    if (EQMSConstant.HR_TRANSPORTATION_MANAGER_ROLE_ON.equalsIgnoreCase(hrManagerRole)) {

      eqmSysParm = null;
      eqmSysParm = eqmsDelegate.getSystemParam(EQMSConstant.NEW_LDAP_ROLE);
      if (eqmSysParm != null) {
        hrManagerRoleName = eqmSysParm.getParmValu();
      }

      rolesLst.add(LDAP_SYSTEM_ADMIN);
      rolesLst.add(LDAP_USER);
      rolesLst.add(LDAP_MANAGER);
      rolesLst.add(hrManagerRoleName);

    } else {
      rolesLst.add(LDAP_SYSTEM_ADMIN);
      rolesLst.add(LDAP_USER);
      rolesLst.add(LDAP_MANAGER);
    }

    eqmSysParm = eqmsDelegate.getSystemParam(EQMSConstant.CREATE_OWN_LDAP_ROLE_LIST);
    if (eqmSysParm != null) {
      createOwnRole = eqmSysParm.getParmValu();
    }

    if (EQMSConstant.CREATE_OWN_LDAP_ROLE_ON.equalsIgnoreCase(createOwnRole)) {
      eqmSysParm = eqmsDelegate.getSystemParam(EQMSConstant.EMPLOYEE_ROLE_SET);
      if (eqmSysParm != null) {
        emplRoleSet = eqmSysParm.getParmValu();
      }

      try {
        if (emplRoleSet != null && !emplRoleSet.isEmpty()) {
          StringTokenizer st = new StringTokenizer(emplRoleSet, ",");
          while (st.hasMoreTokens()) {
            LDAPRoleList.add(st.nextToken());
          }

          for (final String ldapRole : rolesLst) {
            if (LDAPRoleList.contains(ldapRole)) {
              m_ldapRoleList.add(ldapRole);
              break;
            } else {
              logger.warn("getUserLdapRoleList empid=" + emplId + " does not have role =" + ldapRole);
            }
          }
        }
      } catch (Exception e) {
        logger.error("ERROR :: getUserLdapRoleList() :: " + e.getMessage() + " :: className", e);
      }

    } else {
      try {
        for (final String ldapRole : rolesLst) {
          // -- CHECK IF USER IS IN CURRENT ROLE
          if (SessionInterceptor.IS_LOCAL_ENVIRONMENT) {
            if (localhostLdapRoles.contains(ldapRole)) {
              m_ldapRoleList.add(ldapRole);
              break;
            }
          } else if (request.isUserInRole(ldapRole)) {
            m_ldapRoleList.add(ldapRole);
            break;
          } else {
            logger.warn("getUserLdapRoleList empid=" + emplId + " does not have role =" + ldapRole);
          }
        }

      } catch (Exception e) {
        logger.error("ERROR :: getUserLdapRoleList() :: " + e.getMessage() + " :: className", e);
      }

    }
  }

  private EQMSUserBean loadUserBeanData(String emplId) {
    try {
      String emplFullName = "";
      final EqmEmplDtls eqmEmplDtls = eqmsDelegate.getEmployeeDetailsForLdap(emplId);
      if (eqmEmplDtls != null) {
        emplFullName = Util.getEmployeeName(eqmEmplDtls.getEmplFirName(), eqmEmplDtls.getEmplMidName(),
            eqmEmplDtls.getEmplLastName());
        List<Integer> roleIdList = eqmsDelegate.getRoleIdListForEmpl(emplId);
        final EQMSUserBean userBean = m_empRoleBean.getUserBean(emplId, emplFullName, roleIdList);
        return userBean;
      } else
        return null;

    } catch (Exception e) {
      logger.error("EXCEPTION :: loadUserBeanData() ::" + e.getMessage(), e);
    }
    return null;
  }

  private PersonBean getPersonBeanFromEqms(String emplId) {
    EqmEmplDtls emplDtls = null;
    try {
      emplDtls = eqmsDelegate.getEmployee(emplId);
    } catch (EqmDaoException e) {
      e.printStackTrace();
    } catch (Exception e) {
      e.printStackTrace();
    }
    if (emplDtls != null) {
      if (EQMSConstant.VALUE_Y.equalsIgnoreCase(emplDtls.getAgrmNaInd())) {
        m_AgrmIndFlag = false;
        return null;
      } else {
        return new PersonBean();
      }
    } else {
      return null;
    }
  }

  private PersonBean getPersonBeanFromPeopleSoft(String emplId) {
    // TODO Need person data xmf service ready for this call
    // PersonBean personBean =
    // getPersonDataService.getEmployeeDetails(emplId);
    PersonBean personBean = null;
    if (personBean != null) {
      AGREEMENT_IND = personBean.getAgrmInd();
      if (AGREEMENT_IND != null) {
        if (!AGREEMENT_IND.equalsIgnoreCase("Y")) {
          return personBean;
        } else {
          personBean = null;
          return personBean;
        }
      } else {
        m_AgrmIndFlag = false;
        personBean = null;
        return personBean;
        /*
         * m_feedbackMessage = ExceptionMessage.EQMS002; final PageParameters pageParameters = new PageParameters();
         * pageParameters.add(EQMSConstant.ERROR_MSG, m_feedbackMessage); setResponsePage(InvalidLoginPage.class,
         * pageParameters);
         */
      }

    } else {
      m_AgrmIndFlag = false;
      m_feedbackMessage = ExceptionMessage.EQMS002;
      /* Bookmarkable link changes added by xsat244. */
      logger.error("Redirecting user to Invalid login page.");
      throw new LicUnAuthorizedAccessException(ExceptionMessage.EQMS002);
    }
  }

  // TODO call person data service to get data
  private void insertEqmEmplDtls(String empId) {

    try {
      PersonBean personBean;
      /*
       * personBean = new PersonBean(); // -- Comment personBean.setEmplId("0071125"); personBean.setActiveFlag("V"); //
       * -- Comment all setters later. personBean.setEmpFullName("Test Data"); personBean.setSvcUnitNbr(11);
       */

      // -- GET EMPLOYEE DETAILS FROM PEOPLESOFT
      // personBean = getPersonDataService.getEmployeeDetails(empId); //
      // -- Uncomment this to obtain data from peoplesoft

      // -- INSERT EMPLOYEE DETAILS INTO EQMS
      // eqmsDelegate.insertEmplDtlsFromPeopleSoft(empId, personBean);
    } catch (Exception e) {
      logger.error("EXCEPTION :: insertEqmEmplDtls() ::" + e.getMessage(), e);
      /* Bookmarkable link changes added by xsat244. */
      m_feedbackMessage = ExceptionMessage.EQMS002;
      throw new LicUnAuthorizedAccessException(ExceptionMessage.EQMS002);

    }
  }

  private EQMSUserBean implementLDAP(EQMSUserBean userBean) {
    // -- GET ROLES OF USER EXISTING IN EQMS SYSTEM
    final Set<Integer> userRoleSet = userBean.getRoleSet();

    /*
     * CHECK IF USER HAS ONLY SYSTEM ADMIN LDAP ROLE AND PROCEED ONLY IF USER HAS SYSTEM ADMIN ACCESS IN EQMS ALSO
     */

    if ((m_ldapRoleList.contains(LDAP_SYSTEM_ADMIN))
        && ((userRoleSet.isEmpty()) || (!userRoleSet.contains(EQMSConstant.ROLE_ID_SYSTEM_ADMIN)))) {
      logger.error("implementLDAP() :: employee has system admin LDAP role but "
          + "does not have the same security access in EQMS system :: ");
      userBean = null;
      m_feedbackMessage = EQMSMessages.MESSAGE_NO_EQMS_SYS_ADMIN_ROLE;

    }

    /*
     * CHECK IF USER HAS SYSTEM ADMIN ROLE IN EQMS SYSTEM AND PROCEED ONLY IF USER HAS SYSTEM ADMIN LDAP ROLE
     */
    else if ((userRoleSet.contains(EQMSConstant.ROLE_ID_SYSTEM_ADMIN))
        && (!m_ldapRoleList.contains(LDAP_SYSTEM_ADMIN))) {
      logger.error("implementLDAP() :: employee has system admin role in EQMS system but "
          + "does not have the same security access in LDAP :: ");
      userBean = null;
      m_feedbackMessage = EQMSMessages.MESSAGE_NO_LDAP_SYS_ADMIN_ROLE;

    }

    return userBean;
  }
}
