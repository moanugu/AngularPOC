package com.uprr.lic.auth;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;

@Component
@Scope(value = "session", proxyMode = ScopedProxyMode.TARGET_CLASS)
public class EQMSUserSession {
  private static final long serialVersionUID = 1L;

  Logger logger = LoggerFactory.getLogger(EQMSUserSession.class);

  private EQMSUserBean user;

  private Map<String, Object> sessionMap = new HashMap<>();

  public EQMSUserBean getUser() {
    return user;
  }

  public void setUser(EQMSUserBean user) {
    this.user = user;
  }

  public Map<String, Object> getSessionMap() {
    return sessionMap;
  }

  public void setSessionMap(Map<String, Object> sessionMap) {
    this.sessionMap = sessionMap;
  }
  
  

}