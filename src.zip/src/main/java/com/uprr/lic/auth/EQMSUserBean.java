/**
 * Classname    : EQMSUserBean
 * Description  : This class is used to get an Object for an Employee Which will remain in our session 
 * author   : Ajay Kumar Goyat
 * Date of creation : May 2008
 *
 * Change History
 * ------------------------------------------------------------  
 *   Date        Changed By        Description
 * ------------------------------------------------------------  
 * 23-May-2011   XSAT156           Modified for QC#1324. Added boolean flag as flagForYardMaster and added
 *                                 setLoggedInUserAsYardMaster(boolean flagForYardMaster),
 *                                 isLoggedInUserAsYardMaster() methods.
 *                                 
 * 02-Aug-2012   XSAT304           REQ-276    
 * 25-Jul-2013   XSAT494           Code added for AOT Navigation.   
 * ------------------------------------------------------------  
 *
 * Copyright notice : "Copyright � UPRR 2008"
 */
package com.uprr.lic.auth;

import java.io.Serializable;
import java.util.Calendar;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedSet;

import com.uprr.lic.dataaccess.components.common.model.EqmsEmplRoleAreaBean;

public class EQMSUserBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String m_emplId;

	// private Roles m_roles;

	private Map<Integer, Set<EqmsEmplRoleAreaBean>> m_emplRoleAreaMap;

	private SortedSet<Integer> m_roleModIdSet;

	private Set<Integer> m_roleSet;

	private Map<Integer, Set<Integer>> m_roleModIdMap;

	private Map<Integer, String> m_roleJobTypeMap;

	private String m_empName;

	private Map<String, Calendar> m_qualPinsCodeMap;

	private Map<Integer, Boolean> m_menuTabForUserMap;

	private boolean flagForYardMaster; // Added for QC#1324
	/* code changes for REQ-276 start */
	private boolean isNonEqmsUser;

	private boolean hasMenu = true;

	private List<String> ldapRoleList;// Added for AOT Redesign - Phase2

	public boolean isHasMenu() {
		return hasMenu;
	}

	public void setHasMenu(boolean hasMenu) {
		this.hasMenu = hasMenu;
	}
	/* code changes for REQ-276 end */

	/**
	 * @return the roleJobTypeMap
	 */
	public Map<Integer, String> getRoleJobTypeMap() {
		return m_roleJobTypeMap;
	}

	/**
	 * @param roleJobTypeMap
	 *            the roleJobTypeMap to set
	 */
	public void setRoleJobTypeMap(final Map<Integer, String> roleJobTypeMap) {
		m_roleJobTypeMap = roleJobTypeMap;
	}

	/**
	 * @return the roleModIdMap
	 */
	public Map<Integer, Set<Integer>> getRoleModIdMap() {
		return m_roleModIdMap;
	}

	/**
	 * @param roleModIdMap
	 *            the roleModIdMap to set
	 */
	public void setRoleModIdMap(final Map<Integer, Set<Integer>> roleModIdMap) {
		m_roleModIdMap = roleModIdMap;
	}

	/**
	 * @return the emplId
	 */
	public String getEmplId() {
		return m_emplId;
	}

	/**
	 * @param emplId
	 *            the emplId to set
	 */
	public void setEmplId(final String emplId) {
		m_emplId = emplId;
	}

	// /**
	// * @return the roles
	// */
	// public Roles getRoles() {
	// return m_roles;
	// }
	//
	// /**
	// * @param roles
	// * the roles to set
	// */
	// public void setRoles(final Roles roles) {
	// m_roles = roles;
	// }

	/**
	 * No Argument Constructor
	 */
	public EQMSUserBean() {
		super();
	}

	/**
	 * Constructor with Arguments
	 * 
	 * @param emplId
	 * @param roles
	 */
	// public EQMSUserBean(final String emplId, final Roles roles) {
	// if (emplId == null) {
	// throw new IllegalArgumentException("uid must be not null");
	// }
	// if (roles == null) {
	// throw new IllegalArgumentException("roles must be not null");
	// }
	//
	// m_emplId = emplId;
	// m_roles = roles;
	//
	// }

	/**
	 * Method to find that Employee has at least one role
	 * 
	 * @param roles2
	 * @return
	 */
	// public boolean hasAnyRole(final Roles roles2) {
	// return m_roles.hasAnyRole(roles2);
	// }
	//
	// /**
	// * Method to find that Employee has a particular role
	// *
	// * @param role
	// * @return
	// */
	// public boolean hasRole(final String role) {
	// return m_roles.hasRole(role);
	// }

	/**
	 * @return the roleModIdSet
	 */
	public SortedSet<Integer> getRoleModIdSet() {
		return m_roleModIdSet;
	}

	/**
	 * @param roleModIdSet
	 *            the roleModIdSet to set
	 */
	public void setRoleModIdSet(final SortedSet<Integer> roleModIdSet) {
		m_roleModIdSet = roleModIdSet;
	}

	/**
	 * @return the emplRoleAreaMap
	 */
	public Map<Integer, Set<EqmsEmplRoleAreaBean>> getEmplRoleAreaMap() {
		return m_emplRoleAreaMap;
	}

	/**
	 * @param emplRoleAreaMap
	 *            the emplRoleAreaMap to set
	 */
	public void setEmplRoleAreaMap(final Map<Integer, Set<EqmsEmplRoleAreaBean>> emplRoleAreaMap) {
		m_emplRoleAreaMap = emplRoleAreaMap;
	}

	/**
	 * @return the roleSet
	 */
	public Set<Integer> getRoleSet() {
		return m_roleSet;
	}

	/**
	 * @param roleSet
	 *            the roleSet to set
	 */
	public void setRoleSet(final Set<Integer> roleSet) {
		m_roleSet = roleSet;
	}

	/**
	 * @return the m_empName
	 */
	public String getEmpName() {
		return m_empName;
	}

	/**
	 * @param name
	 *            the m_empName to set
	 */
	public void setEmpName(final String name) {
		m_empName = name;
	}

	/**
	 * @return the m_qualPinsCodeMap
	 */
	public Map<String, Calendar> getQualPinsCodeMap() {
		return m_qualPinsCodeMap;
	}

	/**
	 * @param qualPinsCodeMap
	 *            the m_qualPinsCodeMap to set
	 */
	public void setQualPinsCodeMap(Map<String, Calendar> qualPinsCodeMap) {
		this.m_qualPinsCodeMap = qualPinsCodeMap;
	}

	/**
	 * @return the m_menuTabForUserMap
	 */
	public Map<Integer, Boolean> getMenuTabForUserMap() {
		return m_menuTabForUserMap;
	}

	/**
	 * @param tabForUserMap
	 *            the m_menuTabForUserMap to set
	 */
	public void setMenuTabForUserMap(Map<Integer, Boolean> tabForUserMap) {
		m_menuTabForUserMap = tabForUserMap;
	}

	/**
	 * 
	 * Classname / Method Name : EQMSUserBean/isLoggedInUserAsYardMaster()
	 * 
	 * @return Description : This method is used to check whether logged in user
	 *         is Yard Master or not.
	 */
	public boolean isLoggedInUserAsYardMaster() {
		return flagForYardMaster;
	}

	/**
	 * 
	 * Classname / Method Name : EQMSUserBean/setLoggedInUserAsYardMaster()
	 * 
	 * @param flagForYardMaster
	 *            Description : This method is used to set true value if logged
	 *            in user is Yard Master otherwise false.
	 */
	public void setLoggedInUserAsYardMaster(boolean flagForYardMaster) {
		this.flagForYardMaster = flagForYardMaster;
	}

	/* code changes for REQ-276 start */
	public void setNonEqmsUser(boolean isNonEqmsUser) {
		this.isNonEqmsUser = isNonEqmsUser;
	}

	public boolean isNonEqmsUser() {
		return isNonEqmsUser;
	}
	/* code changes for REQ-276 end */

	/**
	 * @return the ldapRoleList
	 */
	public List<String> getLdapRoleList() {
		return ldapRoleList;
	}

	/**
	 * @param ldapRoleList
	 *            the ldapRoleList to set
	 */
	public void setLdapRoleList(List<String> ldapRoleList) {
		this.ldapRoleList = ldapRoleList;
	}
}