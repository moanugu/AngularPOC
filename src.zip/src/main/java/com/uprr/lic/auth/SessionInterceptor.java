package com.uprr.lic.auth;

import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.uprr.lic.util.Util;
import com.uprr.ui.shared.user.ActiveUserId;

public class SessionInterceptor extends HandlerInterceptorAdapter {

  private static final Logger LOGGER = LoggerFactory.getLogger(SessionInterceptor.class);

  private static final List<String> exclusionList = Arrays.asList("/ping", "/logout", "/licensing/isStudentLicense",
      "/licensing/insertPacketPrintDocs", "/licensing/myup/generatePdf","/licensing/printLataPackets"); // Added For SS_QC#10235

  @Autowired
  private LicensingAuthenticator licensingAuthenticator;

  @Autowired
  private EQMSUserSession authSession;

  public static final boolean IS_LOCAL_ENVIRONMENT = ("local"
      .equalsIgnoreCase(System.getProperty("uprr.implementation.environment")));

  @Override
  public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) {
    System.out.println(request.getPathInfo());
    if (!exclusionList.contains(request.getPathInfo())) { //Added For SS_QC#10235
      String loggedInemployeeId = getEmployeeId(request, response);

      if (authSession != null && authSession.getUser() != null && authSession.getUser().getEmplId() != null) {
        String employeeId = Util.removeExtraZeroEmployeeId(loggedInemployeeId);
        String sessionUserId = Util.removeExtraZeroEmployeeId(authSession.getUser().getEmplId());
        if (!sessionUserId.equals(employeeId)) {
          licensingAuthenticator.validateEmployee(request);
        }
      } else {
        licensingAuthenticator.validateEmployee(request);
      }
    } else { // Added For SS_QC#10235
      LOGGER.debug("Excluding session check on Mapping ::: ", request.getPathInfo());
    }
    return true;
  }

  private String getEmployeeId(HttpServletRequest request, HttpServletResponse response) {
    if (IS_LOCAL_ENVIRONMENT) {
      if (authSession.getUser() != null && authSession.getUser().getEmplId() != null) {
        return authSession.getUser().getEmplId();
      } else {
        return request.getHeader("emplId");
      }
    } else {
      String employeeId = new ActiveUserId(request, response).getEmployeeId();
      String userID = request.getUserPrincipal().getName();
      employeeId = LicensingAuthenticator.getTestEmployeeID(employeeId, userID);
      return employeeId;
    }
  }
}