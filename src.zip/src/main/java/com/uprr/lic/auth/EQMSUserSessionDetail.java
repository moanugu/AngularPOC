package com.uprr.lic.auth;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.uprr.lic.dataaccess.components.common.delegate.EqmsDelegate;
import com.uprr.lic.dataaccess.components.common.model.EmployeeBean;
import com.uprr.lic.dataaccess.components.common.model.EqmsEmplRoleAreaBean;
import com.uprr.lic.dataaccess.components.masters.service.IRegionUnitService;
import com.uprr.lic.exception.EqmDaoException;
import com.uprr.lic.util.EQMSConstant;

/**
 * @author AG54541 To Set Object for the session which will remain in our session
 */
@Service
@Scope("prototype")
public class EQMSUserSessionDetail {
  private static final Logger logger = LoggerFactory.getLogger(EQMSUserSessionDetail.class);

  private EQMSUserBean m_eqmsUserBean = null;

  @Autowired
  private EqmsDelegate eqmsDelegate;

  @Autowired
  private IRegionUnitService regionUnitService;

  public EQMSUserBean getUserBean(final String aEmplId, final String emplFullName, final List<Integer> emplRoleSet) {
    m_eqmsUserBean = new EQMSUserBean();

    // m_roleList = new Roles();
    try {
      EmployeeBean employeeBean = null;
      if (emplRoleSet != null && !emplRoleSet.isEmpty()) {
        employeeBean = eqmsDelegate.getEmployeeDetails(aEmplId);
      } else {
        employeeBean = new EmployeeBean();
        employeeBean.setEmpName(emplFullName);
        employeeBean.setRoleIdList(new ArrayList<Integer>());
        employeeBean.setRoleJobTypeMap(new HashMap<Integer, String>());
        employeeBean.setRoleAreaIdMap(new HashMap<Integer, Integer>());
      }

      if (!employeeBean.getRoleIdList().contains(EQMSConstant.ROLE_ID_MANAGER)) {
        employeeBean.getRoleIdList().add(EQMSConstant.ROLE_ID_MANAGER);
        employeeBean.getRoleJobTypeMap().put(EQMSConstant.ROLE_ID_MANAGER, null);
      }

      Map<Integer, Set<EqmsEmplRoleAreaBean>> roleAreaMap = eqmsDelegate.getEmployeeRoleAreaMap(employeeBean);

      // -- Changes for QC 801 - Start
      if (employeeBean.getServiceUnitDDChoice() != null) {
        final EqmsEmplRoleAreaBean areaBeanForEmplSvcUnit = new EqmsEmplRoleAreaBean();

        areaBeanForEmplSvcUnit.setSvcUnitNbr(employeeBean.getServiceUnitDDChoice().getIntKey());
        areaBeanForEmplSvcUnit.setSvcUnitName(employeeBean.getServiceUnitDDChoice().getValue());
        areaBeanForEmplSvcUnit.setRegNbr(employeeBean.getRegionDDChoice().getIntKey());
        areaBeanForEmplSvcUnit.setRegName(employeeBean.getRegionDDChoice().getValue());
        areaBeanForEmplSvcUnit.setRoleId(EQMSConstant.ROLE_ID_MANAGER);

        Set<EqmsEmplRoleAreaBean> emplRoleAreaBeanSet = roleAreaMap.get(EQMSConstant.ROLE_ID_MANAGER);
        if (emplRoleAreaBeanSet == null) {
          emplRoleAreaBeanSet = new HashSet<EqmsEmplRoleAreaBean>();
          roleAreaMap.put(EQMSConstant.ROLE_ID_MANAGER, emplRoleAreaBeanSet);
        }
        emplRoleAreaBeanSet.add(areaBeanForEmplSvcUnit);
      }
      // -- Changes for QC 801 - Stop

      final Set<Integer> roleSet = new HashSet<Integer>(employeeBean.getRoleIdList());
      if (employeeBean.getRoleIdList().contains(EQMSConstant.REGION_ADMIN_ROLE_ID)
          && (roleAreaMap.containsKey(EQMSConstant.REGION_ADMIN_ROLE_ID))) {
        Set<EqmsEmplRoleAreaBean> roleAreaBeanSet = roleAreaMap.get(EQMSConstant.REGION_ADMIN_ROLE_ID);
        if (roleAreaBeanSet != null) {
          Map<Integer, List<Integer>> regionSvcMap = regionUnitService.getAllRegionSvcUnitMap();// webApplication.getRegionSvcUnitMap();
          for (EqmsEmplRoleAreaBean emplRoleAreaBean : roleAreaBeanSet) {
            emplRoleAreaBean.setSvcUnitNbrForRegionList(regionSvcMap.get(emplRoleAreaBean.getRegNbr()));
          }
          roleAreaMap.put(EQMSConstant.REGION_ADMIN_ROLE_ID, roleAreaBeanSet);
        } else if (roleSet.contains(EQMSConstant.ROLE_ID_MANAGER)) {
          roleAreaMap.put(EQMSConstant.ROLE_ID_MANAGER, new HashSet<EqmsEmplRoleAreaBean>());
        }
      }

      Map<Integer, Set<Integer>> roleModIdMap = eqmsDelegate.getEmployeeRoleModMap(employeeBean.getRoleIdList());
      SortedSet<Integer> roleModIdSet = new TreeSet<Integer>();
      Iterator<Map.Entry<Integer, Set<Integer>>> ite = roleModIdMap.entrySet().iterator();
      while (ite.hasNext()) {
        Map.Entry<Integer, Set<Integer>> pairs = (Map.Entry<Integer, Set<Integer>>) ite.next();
        roleModIdSet.addAll((Collection<? extends Integer>) pairs.getValue());
      }

      for (Integer roleid : roleSet) {
        if (!roleAreaMap.containsKey(roleid)) {
          Set<EqmsEmplRoleAreaBean> areaBean = new HashSet<EqmsEmplRoleAreaBean>();
          roleAreaMap.put(roleid, areaBean);
        }
        if (!roleModIdMap.containsKey(roleid)) {
          Set<Integer> modSet = new HashSet<Integer>();
          roleModIdMap.put(roleid, modSet);
        }
      }

      // m_eqmsUserBean.setMenuTabForUserMap(eqmsDelegate.getEQMSMenuTab(roleSet));
      m_eqmsUserBean.setEmplId(aEmplId);
      // m_eqmsUserBean.setRoles(m_roleList);
      m_eqmsUserBean.setRoleSet(roleSet);
       m_eqmsUserBean.setEmplRoleAreaMap(roleAreaMap);
      m_eqmsUserBean.setRoleModIdSet(roleModIdSet);
      m_eqmsUserBean.setRoleModIdMap(roleModIdMap);
      m_eqmsUserBean.setRoleJobTypeMap(employeeBean.getRoleJobTypeMap());
      m_eqmsUserBean.setEmpName(employeeBean.getEmpName());

      // Calling qualification service for getting qualification pinsCode
      // This should be uncommented at onsite

      Map<String, Calendar> qualPinsCodeMap = new HashMap<String, Calendar>();
      // qualPinsCodeMap = qualificationService.getPinsCode(aEmplId);
      m_eqmsUserBean.setQualPinsCodeMap(qualPinsCodeMap);

      // Code for Offshore - This should be commented at onsite
      /*
       * Map<String, Calendar> qualPinsCodeMap = new HashMap<String, Calendar>(); qualPinsCodeMap.put("er",
       * Calendar.getInstance()); qualPinsCodeMap.put("th", Calendar.getInstance()); qualPinsCodeMap.put("ASD",
       * Calendar.getInstance()); qualPinsCodeMap.put("ER", Calendar.getInstance()); qualPinsCodeMap.put("As",
       * Calendar.getInstance()); qualPinsCodeMap.put("12PA", Calendar.getInstance()); qualPinsCodeMap.put("nmh",
       * Calendar.getInstance()); qualPinsCodeMap.put("aswed1", Calendar.getInstance()); qualPinsCodeMap.put("ASDZ",
       * Calendar.getInstance()); m_eqmsUserBean.setQualPinsCodeMap(qualPinsCodeMap);
       */

    } catch (final EqmDaoException e) {
      logger.error("Error: getUserBean () :" + "::Error ::" + e.getMessage(), e);
      throw e;
    }

    catch (final Exception e) {
      logger.error("Error: getUserBean () :" + "::Error ::" + e.getMessage(), e);
    }
    return m_eqmsUserBean;
  }
}
