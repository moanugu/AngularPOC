package com.uprr.lic.error;

public class CustomRuntimeException extends RuntimeException {
    private static final long serialVersionUID = -8206367015422057188L;

    private String errorCode;
    private String requestParameter;

    public CustomRuntimeException(String messageString, String errorCode) {
        super(messageString);
        this.errorCode = errorCode;
    }

    public String getErrorCode() {
        return errorCode;
    }

    public void setRequestParameter(String requestParameter) {
        this.requestParameter = requestParameter;
    }
    
    public String getRequestParameter() {
        return requestParameter;
    }

}
