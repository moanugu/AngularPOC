package com.uprr.lic.error;

import java.util.Arrays;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.uprr.enterprise.i18n.UPRRTranslator;
import com.uprr.enterprise.upalert.ErrorData;
import com.uprr.enterprise.upalert.ErrorLevelEnum;
import com.uprr.enterprise.upalert.HttpRequestData;
import com.uprr.enterprise.upalert.response.ErrorResponse;
import com.uprr.enterprise.upalert.response.FaultResponse;
import com.uprr.lic.dataaccess.decertification.dao.DecertificationDao;
import com.uprr.lic.externalservice.xmf.service.EmailNotificationService;
import com.uprr.lic.util.EqmsUtil;

/**
 * This class is a global exception handler for all Controller classes. It is intended to work in tandem with UPAlert
 * (go/upalert) the Angular shared component for creating pop-up alerts. More information on handling exceptions is
 * detailed on the methods below.
 */
@ControllerAdvice
public class UPAlertErrorInterceptor {
  private static final Logger LOGGER = LoggerFactory.getLogger(UPAlertErrorInterceptor.class);

  private UPRRTranslator translator;

  @Autowired
  private EmailNotificationService emailNotificationService;

  public static final String DEFAULT_EXCEPTION_MESSAGE_KEY = "exception.defaultMessage";

  /**
   * @param translator
   *          the internationalization translator, used for error message translations. (Note: see go/cxi18n for an
   *          Angular component that will allow you to use/set the user's language preference as a UPRR user preference)
   */
  public UPAlertErrorInterceptor(UPRRTranslator translator) {
    this.translator = translator;
  }

  /**
   * This is a custom error interceptor. It will only catch a "CustomRuntimeException".
   * 
   * @param req
   *          The HttpServletRequest is provided by Spring
   * @param customException
   *          The thrown exception
   * @param locale
   *          The user's selected Locale, as passed by the browser (Note: see go/cxi18n for an Angular component that
   *          will allow you to use/set the user's language preference as a UPRR user preference)
   * @return ErrorResponse is the Java class that Jackson will transform into a JSON format that UPAlert can process.
   */
  @ExceptionHandler(value = { CustomRuntimeException.class })
  @ResponseStatus(HttpStatus.BAD_REQUEST) // Return Code 400
  public @ResponseBody ErrorResponse handleCustomException(HttpServletRequest req,
      final CustomRuntimeException customException, Locale locale) {
    String message = translator.lookup(customException.getErrorCode(), locale)
        .parameter("passedParameter", customException.getRequestParameter()) // replaces the ${passedParameter}
                                                                             // parameter in the message
        .text();
    ErrorData errorData = new ErrorData(message, customException, ErrorLevelEnum.ERROR);
    errorData.setErrorCode(customException.getErrorCode());
    ErrorResponse response = new ErrorResponse(errorData);
    response.setRequestData(new HttpRequestData(req));
    return response;
  }

  /**
   * This is a global exception handler. It will catch any type of uncaught exception. It is fairly generic handler,
   * only intended for catching unexpected exceptions, producing a stock, critical level error with a 500 return code
   * (see src/main/resources/i18n/messages.properties for the actual message). If you want to handle a specific error,
   * throw a custom exception and catch it in its own method above this one, as demonstrated in the sample app. It you
   * want Spring to handle a certain type of exception for some reason, you can add an "instanceOf" check in here and
   * re-throw it.
   * 
   * @param req
   *          The HttpServletRequest is provided by Spring
   * @param ex
   *          The thrown exception
   * @param locale
   *          The user's selected Locale, as passed by the browser (Note: see go/cxi18n for an Angular component that
   *          will allow you to use/set the user's language preference as a UPRR user preference)
   * @return FaultResponse is the Java class that Jackson will transform into a JSON format that UPAlert can process.
   */
  @ExceptionHandler(value = { Exception.class, RuntimeException.class })
  @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR) // Return Code 500
  public @ResponseBody FaultResponse handleUncaughtException(HttpServletRequest req, final Exception ex,
      Locale locale) {
    LOGGER.error("Unhandled Exception: " + ex.getMessage(), ex);

    //sendExceptionEmail(ex);

    FaultResponse response = new FaultResponse(new ErrorData(ex.getMessage(), ex, ErrorLevelEnum.CRITICAL));
    response.setRequestData(new HttpRequestData(req));
    return response;
  }

  private void sendExceptionEmail(final Exception ex) {
    try {
      final String environment = System.getProperty("uprr.implementation.environment").toUpperCase();
      if (!environment.equalsIgnoreCase("local")) {
        final String recipientEmail[] = { "EQMS_Angular_Rewrite@up.com" };
        final String content = EqmsUtil.parseExceptContentToString(ex);
        final StringBuilder mailSubject = new StringBuilder();
        mailSubject.append(environment);
        mailSubject.append("--Angular Rewrite--");
        mailSubject.append(ex.getClass().getSimpleName());
        mailSubject.append("--");
        mailSubject.append(ex.getMessage());
        emailNotificationService.sendEmailNotification(Arrays.asList(recipientEmail), null, null,
            mailSubject.toString(), content, DecertificationDao.EQMS_EMAIL_DESCRIPTION);
      }
    } catch (Exception e) {
      LOGGER.error("Unable to send Exception Email,", e);
    }
  }
}
