package com.uprr.lic.springconfig;

import org.springframework.context.annotation.*;

import com.uprr.netcontrol.frontend.shared.utils.spring.mvc.exceptionhandler.NCErrorGlobalExceptionHandler;
import com.uprr.netcontrol.frontend.shared.utils.spring.mvc.ping.PingController;

@Configuration
public class PingControllerConfig {
    
  @Bean
  public PingController createPingServiceController(NCErrorGlobalExceptionHandler faultIndentifier) {
    return new PingController(faultIndentifier);
  }
  
 
}
