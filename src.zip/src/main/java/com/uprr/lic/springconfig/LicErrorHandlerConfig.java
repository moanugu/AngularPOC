package com.uprr.lic.springconfig;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.*;

import com.uprr.netcontrol.frontend.shared.utils.spring.mvc.errorcode.FindNCErrorCodeDescriptionsClientRestImpl;
import com.uprr.netcontrol.frontend.shared.utils.spring.mvc.exceptionhandler.NCErrorGlobalExceptionHandler;
import com.uprr.netcontrol.shared.components.error.format.NCErrorFormatter;
import com.uprr.netcontrol.shared.components.error.format.impl.*;

@Configuration
public class LicErrorHandlerConfig {
    
    @Bean(name="errorFormatter")
    public NCErrorFormatter createErrorFormatter(@Value("${rest.error.url}") final String restServiceURL, 
            @Value("${app.name}") final String appName) {
        final FindNCErrorCodeDescriptionsClient errorClient = 
            new FindNCErrorCodeDescriptionsClientRestImpl(restServiceURL, appName);
        return new NCErrorFormatterImpl(new NCErrorCodeLookupErrorDescriptionSource(errorClient));
    }

    @Bean
    public NCErrorGlobalExceptionHandler globalExceptionHandler(NCErrorFormatter errorFormatter) {
        return new NCErrorGlobalExceptionHandler(errorFormatter);
    }
    
}
