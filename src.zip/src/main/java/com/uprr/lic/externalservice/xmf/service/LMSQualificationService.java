package com.uprr.lic.externalservice.xmf.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.uprr.lic.dataaccess.masters.service.ISysParamService;
import com.uprr.lic.exception.EqmException;
import com.uprr.lic.medical.qualification.MedicalQualificationClient;
import com.uprr.lic.medical.qualification.MedicalQualificationXmfImpl;
import com.uprr.lic.medical.qualification.Person;
import com.uprr.lic.medical.qualification.domain.MedicalQualificationRequest;
import com.uprr.lic.medical.qualification.domain.MedicalQualificationRespone;
import com.uprr.lic.person_search_learning_history_2_0.SearchLearningHistoryClient;
import com.uprr.lic.person_search_learning_history_2_0.SearchLearningHistoryClientXmfImpl;
import com.uprr.lic.person_search_learning_history_2_0.domain.LearningHistoryRequest;
import com.uprr.lic.person_search_learning_history_2_0.domain.LearningHistoryResponse;
import com.uprr.lic.util.LicensingConstant;
import com.uprr.lic.util.SysParamBean;
import com.uprr.netcontrol.frontend.client.xmf.XmfClientInvoker;

@Service("LMSQualificationService")
public class LMSQualificationService {
	private static final Logger LOGGER = LoggerFactory.getLogger(LMSQualificationService.class);

	@Autowired
	@Qualifier("secureInvokerEqm")
	XmfClientInvoker invoker;

	@Autowired
	@Qualifier("secureMedicalInvoker")
	XmfClientInvoker secureMedicalInvoker;

	
	@Autowired
	private ISysParamService sysParamService;

	public LearningHistoryResponse getLearningHistory(final String emplId, final String pinsCode,
			final String qualCategory) throws EqmException {
		return getLearningHistory(Arrays.asList(emplId), pinsCode);
	}

	public LearningHistoryResponse getLearningHistory(final List<String> emplIdList, final String pinsCode
			) {
		SearchLearningHistoryClient learningHistoryClientXmfImpl = new SearchLearningHistoryClientXmfImpl(invoker);
		LearningHistoryRequest learningRequest = new LearningHistoryRequest();

		String[] pinsCodeList = pinsCode.split(",");

		learningRequest.setEmployeeId(emplIdList);
		if (null != pinsCodeList) {
			learningRequest.setCourseIds(Arrays.asList(pinsCodeList));
		}
		learningRequest.setCourseTypes(Arrays.asList("EXAM", "COURSE"));

		try {
			LearningHistoryResponse response = learningHistoryClientXmfImpl.searchLearningHistory(learningRequest);
			return response;
		} catch (Exception ex) {
			LOGGER.error("Unable to get Employee learning history, ", ex);
			throw new EqmException("Unable to get Employee learning history, " + ex.getMessage());
		}
	}

	public MedicalQualificationRespone getMedicalQualification(final String emplId, final String pinsCode,
			Map<String, SysParamBean> sysParmMap) throws EqmException {
		return getMedicalQualification(new HashSet<String>(Arrays.asList(emplId)), pinsCode, sysParmMap);
	}

	public MedicalQualificationRespone getMedicalQualification(final Set<String> emplIds, final String pinsCode,
			Map<String, SysParamBean> sysParmMap) throws EqmException {

		List<Person> emplIdList = new ArrayList<>();
		for (Iterator<String> iterator = emplIds.iterator(); iterator.hasNext();) {
			String emplId = iterator.next();
			Person person = new Person();
			person.setEmployeeId(emplId);
			emplIdList.add(person);
		}

		return getMedicalQualification(emplIdList, pinsCode, sysParmMap);
	}

	public MedicalQualificationRespone getMedicalQualification(final List<Person> emplIdList, final String pinCodes,
			Map<String, SysParamBean> sysParmMap) {

		MedicalQualificationRequest medicalQualificationRequest = createRequest(emplIdList, pinCodes, sysParmMap);
		if (medicalQualificationRequest != null) {
			MedicalQualificationClient medicalQualificationClient = new MedicalQualificationXmfImpl(secureMedicalInvoker);
			return medicalQualificationClient.getMedicalQualifications(medicalQualificationRequest);
		} else {
			return null;
		}
	}

	private MedicalQualificationRequest createRequest(final List<Person> emplIdList, final String pinCodes,
			Map<String, SysParamBean> sysParmMap) {
		final MedicalQualificationRequest hscMedicalRequest = new MedicalQualificationRequest();

		hscMedicalRequest.getEmployeeList().addAll(emplIdList);
		boolean checkFlag = true;// this flag is for medical pinCodes is
									// available or not.If pin codes null this
									// flag always true.
		if (pinCodes != null) {
			checkFlag = false;
			MedicalQualificationRequest.QualificationFilter filter = null;
			String[] qualCodesArray = pinCodes.split(",");
			ArrayList<MedicalQualificationRequest.QualificationFilter> tempArrayList = new ArrayList<MedicalQualificationRequest.QualificationFilter>();
			for (int i = 0; i < qualCodesArray.length; i++) {
				if (getMedPins(sysParmMap).contains(qualCodesArray[i])) {
					filter = new MedicalQualificationRequest.QualificationFilter();
					filter.setCategory((short) 2);
					filter.setCode(qualCodesArray[i]);
					tempArrayList.add(filter);
					if (!checkFlag) {
						checkFlag = true;// set true if found at-least one
					}
				}
			}
			if (tempArrayList.size() > 0) {
				hscMedicalRequest.getQualificationFilterList().addAll(tempArrayList);
			} else {
				hscMedicalRequest.setQualificationCategoryFilter((short) 2);
			}
		} else {
			hscMedicalRequest.setQualificationCategoryFilter((short) 2);
		}
		if (checkFlag) {
			return hscMedicalRequest;
		} else {
			return null;
		}
	}

	private List<String> getMedPins(Map<String, SysParamBean> sysParmMap) {
		List<String> medPinsList = new ArrayList<String>();
		// -- getting Medical pins from system param table
		Map<String, SysParamBean> syaParamMap;
		// -- getting Medical pins from system param table
		// Application will not be available from scheduler.
		try {
			syaParamMap = sysParamService.getAllSystemParameter();
		} catch (Exception e) {
			syaParamMap = sysParmMap;
		}
		if (syaParamMap != null) {
			SysParamBean sysParamBean = (SysParamBean) syaParamMap.get(LicensingConstant.SYSPARAM_PINS_CODE_MED);
			if (sysParamBean != null) {
				String[] pinsCodeArr = sysParamBean.getParmValu().split(",");
				for (final String medPins : pinsCodeArr) {
					// -- adding all Medical pins to a list
					medPinsList.add(medPins.trim());
				}
			}
		}

		// -- IF STAND ALONE
		/*
		 * medPinsList.add("OP1D"); medPinsList.add("OP1Z");
		 */

		return medPinsList;
	}
}
