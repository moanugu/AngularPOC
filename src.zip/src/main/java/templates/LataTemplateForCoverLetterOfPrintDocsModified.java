/**
 * Classname    : LataTemplateForCoverLetterOfPrintDocsModified
 * Description  : Class is used as a Lata template for Cover Letter Form (LHI Instruction Set).
 * author     : Techmahindra Ltd.
 * Date of creation : Apr 12, 2016
 *
 * Change History
 * ------------------------------------------------------------  
 *   Date         Changed By    Description
 * ------------------------------------------------------------  
 *  04/12/2016    xsat671       Modified for SS_QC#5503.
 *  30/06/2016    xsat872       Modified for SS_QC#6452.  
 *  18/10/2016    xsat872       Modified for SS_QC#5427.
 *  21/04/2017    xsat872       Modified for SS_QC#8579.
 * ------------------------------------------------------------  
 *
 * Copyright notice : "Copyright UPRR 2008"
 */
package templates;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.uprr.lic.dataaccess.Licensing.model.CoverLetterForPrintDocsTemplate;
import com.uprr.lic.dataaccess.components.licensing.service.ILicensingService;
import com.uprr.lic.util.LicensingConstant;

public class LataTemplateForCoverLetterOfPrintDocsModified {

	private final Logger m_logger = LoggerFactory.getLogger(this.getClass());


  private final String fourthMarker = padSpaceTillMaxLength(5);

  /**
   * Method is used to get contents of Employee Letter (Cover Letter used in recertification) template
   *
   * @param coverLetterForPrintDocsTemplate
   * @return
   * @author xsat671
   * @since Apr 12, 2016. Modified for SS_QC#5503.
   * Modified for SS_QC#6452
   * Modified for SS_QC#5427
   * Modified for SS_QC#8579
   */ 
  // **##Whenever any content related changes done,make sure that changes made in CoverLetterTemplateForPrintDocs.vtl
  // file as well.
  public StringBuffer getBufferForLataPrintForCoverLetterOfPrintDocs(
      CoverLetterForPrintDocsTemplate coverLetterForPrintDocsTemplate, ILicensingService licensingService) {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer
        .append(padSpaceTillMaxLength(20) + "UNION PACIFIC RAILROAD COMPANY" + padSpaceTillMaxLength(20) + "\n");
    /*
     * Commented for SS_QC#5503
     * stringBuffer.append(padSpaceTillMaxLengthForDynamicFields(coverLetterForPrintDocsTemplate.getEmployeeName(),
     * 71)+"\n");
     */
    String manager = "";
   
      manager = licensingService.getSysParmValue(LicensingConstant.LICENSING_DEPT_MANAGER_NAME).getParmValu();
    //
    // stringBuffer.append(padSpaceTillMaxLengthForDynamicFields(coverLetterForPrintDocsTemplate.getAddress1(),
    // 100)+"\n");
    // stringBuffer.append(padSpaceTillMaxLengthForDynamicFields(coverLetterForPrintDocsTemplate.getAddress2(),
    // 100)+"\n");
    // -- Making Address Adjustment
    /*
     * Commented for SS_QC#5503
     * stringBuffer.append(getAddressAdjustmentForEmployee(coverLetterForPrintDocsTemplate.getAddress1(),
     * coverLetterForPrintDocsTemplate.getAddress2()));
     */

    // -- Making adjustment for City, State, Country, Zipcode
    // stringBuffer.append(coverLetterForPrintDocsTemplate.getCity()+","+coverLetterForPrintDocsTemplate.getState()+",");
    // stringBuffer.append(coverLetterForPrintDocsTemplate.getCountry()+"-"+coverLetterForPrintDocsTemplate.getZip()+".");
    /*
     * Commented for SS_QC#5503
     * stringBuffer.append(getCityStateCountryZipAdjustmentForEmployee(coverLetterForPrintDocsTemplate.getCity(),
     * coverLetterForPrintDocsTemplate.getState(), coverLetterForPrintDocsTemplate.getCountry(),
     * coverLetterForPrintDocsTemplate.getZip()));
     */

    // -- remaining template   
    // SS_QC#5503 changes start
    // SS_QC#6452 changes start
    // SS_QC#5427 changes start
    // Modified for SS_QC#8579:Start
    stringBuffer.append("\n");
    stringBuffer.append(padSpaceTillMaxLength(22) + "Certification Instructions" + padSpaceTillMaxLength(20));
    stringBuffer.append("\n");
    stringBuffer.append("Please carefully read these instructions as they have recently changed");
    stringBuffer.append("\n\n");
    stringBuffer.append("  You are a Federally certified operating employee. Your Federal Railroad");
    stringBuffer.append("\n");
    stringBuffer.append("Administration (FRA) certification(s) will expire on your upcoming");
    stringBuffer.append("\n");
    stringBuffer.append("birthday or you have been selected for the FIT(Firemen in Training) program.");
    stringBuffer.append("\n");
    stringBuffer.append("The federally mandated certification requirements must be done to complete");
    stringBuffer.append("\n");
    stringBuffer.append("your certification. Timely completion of these requirements is necessary to be");
    stringBuffer.append("\n");
    stringBuffer.append("fully qualified to work and avoid any disruption to service.");
    stringBuffer.append("\n\n");
    stringBuffer.append("  Union Pacific Railroad System Special Instructions, Item 7-B and");
    stringBuffer.append("\n");
    stringBuffer.append("Union Pacific's Certification Programs, require you to keep your");
    stringBuffer.append("\n");
    stringBuffer.append("certification(s) current for all classes of service and carry one ");
    stringBuffer.append("\n");
    stringBuffer.append("valid FRA Certificate listing each class of service, all having");
    stringBuffer.append("\n");
    stringBuffer.append("the same expiration date. Therefore, all federal certification ");
    stringBuffer.append("\n");
    stringBuffer.append("requirements are to be fulfilled prior to the expiration date ");
    stringBuffer.append("\n");
    stringBuffer.append("of your certification in any class of service, even if you are");
    stringBuffer.append("\n");
    stringBuffer.append("not currently assigned to that class of service.");
    stringBuffer.append("\n");
    stringBuffer.append("You will not be  eligible to work in any class of service without");
    stringBuffer.append("\n");
    stringBuffer.append("a valid FRA Certificate.");    
    stringBuffer.append("\n\n");
    stringBuffer.append("PLEASE NOTE: It is the individual employee's responsibility to ensure");
    stringBuffer.append("\n");
    stringBuffer.append("their certification is kept current to avoid a possible interruption ");
    stringBuffer.append("\n");
    stringBuffer.append("in service eligibility.");
    stringBuffer.append("\n\n");
    stringBuffer.append("1. Vision and Hearing Acuity Examination:");
    stringBuffer.append("\n");
    stringBuffer.append("   a.  Note: See the Superintendent Bulletin instructions for");
    stringBuffer.append("\n");
    stringBuffer.append("       scheduling examinations. You must comply with the Hours of Service");
    stringBuffer.append("\n");
    stringBuffer.append("       Law requirements pertaining to rest and for reporting the time");
    stringBuffer.append("\n");
    stringBuffer.append("       you completed the examination. You must contact Crew Management");
    stringBuffer.append("\n");
    stringBuffer.append("       Services (CMS) to report  the completion of your examination.");
    stringBuffer.append("\n");
    stringBuffer.append("   b.  Union Pacific will pay for the examination, but you are not entitled");
    stringBuffer.append("\n");
    stringBuffer.append("       to reimbursement of any wages or expenses for taking the");
    stringBuffer.append("\n");   
    stringBuffer.append("       required exam.");
    stringBuffer.append("\n");
    stringBuffer.append("   c.  ACTION REQUIRED: You must schedule your FRA certification");
    stringBuffer.append("\n");
    stringBuffer.append("       hearing & vision examinations through the eHealthSafe(eHS)");
    stringBuffer.append("\n");
    stringBuffer.append("       web portal before calling LHI (our clinic vendor)");
    stringBuffer.append("\n");
    stringBuffer.append("       or your Occupational Health Nurse.");
    stringBuffer.append("\n");
    stringBuffer.append("       Refer to the instructions for Scheduling Hearing & Vision Exam on page 3.");
    stringBuffer.append("\n");   
    // Commented for SS_QC#8579:Start
    /*
     * stringBuffer.append("       appointment at a clinic after following the instructions below.");
     * stringBuffer.append("\n"); stringBuffer.append("       From the UP homepage click on ePayroll > eHealthSafe, and"
     * ); stringBuffer.append("\n"); stringBuffer.append("       follow these instructions: ");
     * stringBuffer.append("\n"); stringBuffer.append(
     * "       i)   Click the 'My To Do List' link on the left then click"); stringBuffer.append("\n");
     * stringBuffer.append("            the 'FRA vision and hearing examination'."); stringBuffer.append("\n");
     * stringBuffer.append("       ii)  Select from the to do list your 'FRA Certification' exam.");
     * stringBuffer.append("\n"); stringBuffer.append(
     * "       iii) Click on 'approve' to see the name and telephone number of"); stringBuffer.append("\n");
     * stringBuffer.append("            your local OHN. You must contact the OHN to schedule your exam;");
     * stringBuffer.append("\n"); stringBuffer.append("                            OR"); stringBuffer.append("\n");
     * stringBuffer.append("       iv)  Click on 'reject' if you want to schedule with a clinic by");
     * stringBuffer.append("\n"); stringBuffer.append(
     * "            calling the LHI telephone number listed. You must call LHI"); stringBuffer.append("\n");
     * stringBuffer.append("            to schedule your exam. Refer to the Instructions for");
     * stringBuffer.append("\n"); stringBuffer.append("            Completing Medical Assessment form.");
     * stringBuffer.append("\n"); stringBuffer.append("       v)   If this option isn�t available or if you have ");
     * stringBuffer.append("\n"); stringBuffer.append("            questions on the medical exam please contact");
     * stringBuffer.append("\n"); stringBuffer.append("            Health & Medical at 402-544-4326, option 4.");
     */
    // Commented for SS_QC#8579:End
    stringBuffer.append("\n\n");
    stringBuffer.append("2. National Driver Register(NDR) Form: Required for all Remote, Hostler");
    stringBuffer.append("\n");
    stringBuffer.append("   and Engineer certified employees.");
    stringBuffer.append("\n");
    stringBuffer.append("   a.  Form 20119: Complete the NDR form and ");
    stringBuffer.append("\n");
    stringBuffer.append("       return to the Employee Licensing & Certification Department. ");
    stringBuffer.append("\n");
    stringBuffer.append("       Please note your signature, as the requestor, must be notarized. ");
    stringBuffer.append("\n");
    stringBuffer.append("       Form 20119, needs to be returned to:");
    stringBuffer.append("\n");
    stringBuffer.append("       Union Pacific Railroad Employee Licensing &");
    stringBuffer.append("\n");
    stringBuffer.append("       Certification Dept., 1400 Douglas Street, ");
    stringBuffer.append("\n");
    stringBuffer.append("       Stop 1010, Omaha NE 68179-1010");
    stringBuffer.append("\n");
    stringBuffer.append("       This form cannot be faxed or emailed.");
    stringBuffer.append("\n\n");
    stringBuffer.append("3. Motor Vehicle Record(MVR) Release: Required for all certified employees. ");
    stringBuffer.append("\n");
    stringBuffer.append("   a.  State Motor Vehicle Form can be accessed through the MyUP Portal");
    stringBuffer.append("\n");
    stringBuffer.append("       under the Certification section which is located on the  ");
    stringBuffer.append("\n");
    stringBuffer.append("       right hand side of the screen. Click on the 'Update' link to ");
    stringBuffer.append("\n");
    stringBuffer.append("       complete the form. Union Pacific will conduct a search of your state");
    stringBuffer.append("\n");
    stringBuffer.append("       motor vehicle driving record. If this link is not present the form ");
    stringBuffer.append("\n");
    stringBuffer.append("       can be accessed from a company computer by entering go/MVR into");
    stringBuffer.append("\n");
    stringBuffer.append("       the address bar. This form can only be submitted electronically.");
    stringBuffer.append("\n");
    stringBuffer.append("   b.  The Washington Release of Interest form will be required to fill");
    stringBuffer.append("\n");
    stringBuffer.append("       out if you currently hold a Washington State Drivers License.");
    stringBuffer.append("\n");
    stringBuffer.append("       You will automatically be directed to the form once");
    stringBuffer.append("\n");
    stringBuffer.append("       you complete the MVR Release with Washington state driving information.");
    stringBuffer.append("\n");
    stringBuffer.append("       This form does not need to be mailed in when submitted electronically.");
    stringBuffer.append("\n\n");
    stringBuffer.append("4.     Operating Rules Examination: You must successfully pass the General");
    stringBuffer.append("\n");
    stringBuffer.append("       Code of Operating Rules exam, Air Brake, Hazardous Materials ");
    stringBuffer.append("\n");
    stringBuffer.append("       and Territory Exams within the 366 days preceding your birthday.");
    stringBuffer.append("\n");
    stringBuffer.append("       Contact your manager to be scheduled into a rules class.");
    stringBuffer.append("\n\n");
    stringBuffer.append("5.     Certification Skills Evaluation Ride: A designated Supervisor");
    stringBuffer.append("\n");
    stringBuffer.append("       of Locomotive Engineers and/or designated Supervisor of");
    stringBuffer.append("\n");
    stringBuffer.append("       Remote Control Operators must accompany you on a train ride");
    stringBuffer.append("\n");
    stringBuffer.append("       and evaluate your performance. It is the responsibility ");
    stringBuffer.append("\n");
    stringBuffer.append("       of your Manager to complete this requirement and he/she will");
    stringBuffer.append("\n");
    stringBuffer.append("       do so prior to the expiration of your current license.");
    stringBuffer.append("\n\n");
    stringBuffer.append("6.     Photo: You must have a valid photo on file.  Please check your ");
    stringBuffer.append("\n");
    stringBuffer.append("       photo's expiration date in the Certification box on your MyUP Portal.");
    stringBuffer.append("\n");
    stringBuffer.append("       If your photo will expire before your birth date  ");
    stringBuffer.append("\n");
    stringBuffer.append("       contact local management to get a new photo taken.");
    stringBuffer.append("\n\n");
    stringBuffer.append("  Once you have completed all the requirements for certification, your new");
    stringBuffer.append("\n");
    stringBuffer.append("license will be mailed directly to your home approximately two weeks prior");
    stringBuffer.append("\n");
    stringBuffer.append("to expiration of your current license. If you have completed all requirements");
    stringBuffer.append("\n");
    stringBuffer.append("and you do not receive your new license prior to expiration, immediately");
    stringBuffer.append("\n");
    stringBuffer.append("notify the Employee Certification & Licensing Department or your manager.");
    stringBuffer.append("\n\n");
    stringBuffer.append("  If you have questions other than the medical examination process, ");
    stringBuffer.append("\n");
    stringBuffer.append("please contact the Employee Certification & Licensing ");
    stringBuffer.append("\n");
    stringBuffer.append("Department at 402-544-CERT (2378) or from a Bell line at 8-544-CERT (2378).");
    stringBuffer.append("\n\n");
    stringBuffer.append("\n\n");
    stringBuffer.append(padSpaceTillMaxLength(35));
    stringBuffer.append("Sincerely, ");
    stringBuffer.append("\n\n");
    stringBuffer.append(padSpaceTillMaxLength(35));
    stringBuffer.append(manager);
    stringBuffer.append("\n\n");
    stringBuffer.append(padSpaceTillMaxLength(35));
    stringBuffer.append(manager + ", Sr. Manager");
    stringBuffer.append("\n");
    stringBuffer.append(padSpaceTillMaxLength(35));
    // SS_QC#5503 changes end
    stringBuffer.append("Compliance & Continuous Improvement" + "\n\n");
    // Commented for SS_QC#8579:Start
    /*
     * stringBuffer.append("PLEASE NOTE: It is the individual employee's responsibility to ensure   ");
     * stringBuffer.append("\n"); stringBuffer.append(
     * "their certification is kept current to avoid a possible interruption "); stringBuffer.append("\n");
     * stringBuffer.append("in service eligibility.");
     */
    // Commented for SS_QC#8579:End
    // SS_QC#6452 changes end
    // SS_QC#5427 changes end
    stringBuffer.append("\n\n");
    stringBuffer.append("ENCLOSURES:" + "\n");
    stringBuffer.append(fourthMarker + "Instructions for Scheduling Hearing & Vision Exam" + "\n");
    //Modified for SS_QC#8579:End
    stringBuffer.append(fourthMarker + "NDR Request Form 20119" + "\n");
    stringBuffer.append(fourthMarker + "MVR Release Instruction Form" + "\n");// Added For SS_QC#5427
    return stringBuffer;
  }

  /**
   * Classname / Method Name : LataTemplateForCoverLetterOfPrintDocsModified/padSpaceTillMaxLengthForDynamicFields()
   * 
   * @param str
   * @param maxLength
   * @return : String Description : Method is used to make proper space adjustment in template for dynamic data.
   */
  private String padSpaceTillMaxLengthForDynamicFields(String str, int maxLength) {
    StringBuffer sb = new StringBuffer(str);
    for (int i = str.length(); i <= maxLength; i++) {
      sb.append(" ");
    }
    return sb.toString();
  }

  /**
   * Classname / Method Name : LataTemplateForCoverLetterOfPrintDocsModified/padSpaceTillMaxLength()
   * 
   * @param maxLength
   * @return : String Description : Method is used to add spaces in the template.
   */
  private String padSpaceTillMaxLength(int maxLength) {
    StringBuffer sb = new StringBuffer();
    for (int i = 0; i <= maxLength; i++) {
      sb.append(" ");
    }
    return sb.toString();
  }

  /**
   * Classname / Method Name : LataTemplateForCoverLetterOfPrintDocsModified/getAddressAdjustmentForEmployee()
   * 
   * @param addressLine1
   * @param addressLine2
   * @return : String Description : Method is used to make adjustment for Address
   */
  private String getAddressAdjustmentForEmployee(String addressLine1, String addressLine2) {
    StringBuffer sb = new StringBuffer();
    if (addressLine1 != null && !addressLine1.equals("") && !addressLine1.equals(" ")) {
      sb.append(padSpaceTillMaxLengthForDynamicFields(addressLine1, 71));
      sb.append("\n");
    }
    if (addressLine2 != null && !addressLine2.equals("") && !addressLine2.equals(" ")) {
      sb.append(padSpaceTillMaxLengthForDynamicFields(addressLine2, 71));
      sb.append("\n");
    }
    return sb.toString();
  }

  /**
   * Classname / Method Name :
   * LataTemplateForCoverLetterOfPrintDocsModified/getCityStateCountryZipAdjustmentForEmployee()
   * 
   * @param city
   * @param state
   * @param country
   * @param zipCode
   * @return : String Description : Method is used to make adjustment for City, State, Country and Zipcode.
   */
  private String getCityStateCountryZipAdjustmentForEmployee(String city, String state, String country,
      String zipCode) {
    StringBuffer sb = new StringBuffer();
    /*
     * if city != null && any one of state, country, zipcode != null --> append ',' ahead of city else --> append only
     * city
     */
    if ((city != null && !city.equals("") && !city.equals(" "))
        && ((state != null && !state.equals("") && !state.equals(" "))
            || (country != null && !country.equals("") && !country.equals(" "))
            || (zipCode != null && !zipCode.equals("") && !zipCode.equals(" ")))) {
      sb.append(city + ",");
    } else if (city != null && !city.equals("") && !city.equals(" ")) {
      sb.append(city);
    }

    /*
     * if state != null && any one of country, zipcode != null --> append ',' ahead of state else --> append only state
     */
    if ((state != null && !state.equals("") && !state.equals(" "))
        && ((country != null && !country.equals("") && !country.equals(" "))
            || (zipCode != null && !zipCode.equals("") && !zipCode.equals(" ")))) {
      sb.append(state + ",");
    } else if (state != null && !state.equals("") && !state.equals(" ")) {
      sb.append(state);
    }

    /*
     * if country != null && azipcode != null --> append '-' ahead of country else --> append only country
     */
    if ((country != null && !country.equals("") && !country.equals(" "))
        && (zipCode != null && !zipCode.equals("") && !zipCode.equals(" "))) {
      sb.append(country + "-");
    } else if (country != null && !country.equals("") && !country.equals(" ")) {
      sb.append(country);
    }

    /*
     * appending zipcode
     */
    if (zipCode != null && !zipCode.equals("") && !zipCode.equals(" ")) {
      sb.append(zipCode);
    }

    if (!((city == null || city.equals("") || city.equals(" "))
        && (state == null || state.equals("") || state.equals(" "))
        && (country == null || country.equals("") || country.equals(" "))
        && (zipCode == null || zipCode.equals("") || zipCode.equals(" ")))) {
      sb.append(".");
    }

    return sb.toString();
  }

  /*private String padSpaceTillMaxLengthAlignCenter(String str, int maxLength) {
    int initLength = str.length();
    StringBuffer sb = new StringBuffer();
    if (initLength < maxLength) {
      for (int i = 0; i < (maxLength - initLength) / 2; i++) {
        sb.append(" ");
      }
      sb.append(str);
      final int len = sb.length();
      for (int i = len; i <= maxLength; i++) {
        sb.append(" ");
      }
    }
    return sb.toString();
  }
*/
 /* public static void main(String[] args) {

    LataTemplateForCoverLetterOfPrintDocsModified lataTemplateForCoverLetter = new LataTemplateForCoverLetterOfPrintDocsModified();
  }

  private static CoverLetterForPrintDocsTemplate getTemplate() {
    CoverLetterForPrintDocsTemplate coverLetterForPrintDocsTemplate = new CoverLetterForPrintDocsTemplate();
    coverLetterForPrintDocsTemplate.setEmployeeName("Lenin, Mike R");
    coverLetterForPrintDocsTemplate.setAddress1("Satyam Computers");
    coverLetterForPrintDocsTemplate.setAddress2("Down Street,LA");
    coverLetterForPrintDocsTemplate.setCity("Ohama");
    coverLetterForPrintDocsTemplate.setState("NJ");
    coverLetterForPrintDocsTemplate.setCountry("USA");
    coverLetterForPrintDocsTemplate.setZip("0009123");
    return coverLetterForPrintDocsTemplate;
  }
*/
 
}
