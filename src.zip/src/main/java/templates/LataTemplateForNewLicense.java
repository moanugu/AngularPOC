package templates;

import com.uprr.lic.dataaccess.Licensing.model.CoverLetterForNewLicenseDetails;

public class LataTemplateForNewLicense {

	private final String firstMarker = "\t";
	private final String secondMarker = "\t\t";
	private final String thirdMarker = "\t\t\t\t\t\t";
	
	public StringBuffer getBufferForLataPrintForTempLicense(CoverLetterForNewLicenseDetails m_coverLetterForNewLicenseDetails){
		
		StringBuffer stringBuffer = new StringBuffer();
		stringBuffer.append(thirdMarker+"April 21,2009");
		stringBuffer.append("\n\n");
		stringBuffer.append(firstMarker+m_coverLetterForNewLicenseDetails.getEmployeeName());
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+m_coverLetterForNewLicenseDetails.getAddressLine1());
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+m_coverLetterForNewLicenseDetails.getAddressLine2());
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+m_coverLetterForNewLicenseDetails.getCity()+","+m_coverLetterForNewLicenseDetails.getState()+","+m_coverLetterForNewLicenseDetails.getCountry());
		stringBuffer.append("\n\n");
		stringBuffer.append(firstMarker+"Dear "+m_coverLetterForNewLicenseDetails.getEmployeeName()+":");
		stringBuffer.append("\n\n");
		stringBuffer.append(secondMarker);
		stringBuffer.append(firstMarker+"You have been selected as a candidate for engineer training.  FRA regulations require successful");
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+"completion of hearing and vision tests before you can be placed into training.  In addition, you will need to ");
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+"complete the enclosed forms for motor vehicle record searches.");
		stringBuffer.append("\n\n");
		stringBuffer.append(secondMarker);
		stringBuffer.append(firstMarker+"You have been identified as a member of class "+m_coverLetterForNewLicenseDetails.getClassNumber()+" tentatively scheduled to begin your");
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+" classroom field training at or near your work location the week of "+m_coverLetterForNewLicenseDetails.getStartDate()+". As you");
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+" advance in the training program you will receive information relative to future classroom training");
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+" locations and dates from the Salt Lake City Training Center. ");
		stringBuffer.append("\n\n");
		stringBuffer.append(secondMarker);
		stringBuffer.append(firstMarker+"YOU NEED TO IMMEDIATELY COMPLETE:");
		stringBuffer.append("\n\n");
		stringBuffer.append(firstMarker+"1) Vision and Hearing Acuity Examination:");
		stringBuffer.append("\n\n");
		stringBuffer.append(secondMarker);
		stringBuffer.append(secondMarker+"a) Refer to LHI Authorization Form.");
		stringBuffer.append("\n\n");
		stringBuffer.append(secondMarker);
		stringBuffer.append(secondMarker+"Note:  If a Mobile Testing Van is in your area, please use it to get your hearing  ");
		stringBuffer.append("\n");
		stringBuffer.append(secondMarker);
		stringBuffer.append(secondMarker+"and vision exams.  This will satisfy both your licensing requirements and your annual  ");
		stringBuffer.append("\n");
		stringBuffer.append(secondMarker);
		stringBuffer.append(secondMarker+"hearing test if done on the van. Please note, the van is equipped with a vision tester.");
		stringBuffer.append("\n\n");
		stringBuffer.append(firstMarker+"Union Pacific will pay for the testing, but you are responsible for any lost wages, mileage, and/or lodging ");
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+"costs, which may occur.  If you have any questions pertaining to the medical examination process, please ");
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+"contact LHI at 1-866-873-9261.");
		stringBuffer.append("\n\n");
		stringBuffer.append(firstMarker+"2) NDR Review: Request for a review of the National Driver Register (NDR).  Form 20119 is enclosed ");
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+"   for your use.  Please note your signature, as the requestor must be notarized.  Be sure you fill out  ");
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+"   this form in its entirety before you have it notarized.  Sign the form in the presence of the Notary.");
		stringBuffer.append("\n\n");
		stringBuffer.append(firstMarker+"3) State Driving Record Review: Complete the State Motor Vehicle Search Union Pacific will conduct a ");
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+"   search of your state motor vehicle driving record, currently at no cost to you.  Please provide your ");
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+"   drivers license number(s) and the state(s) where you have obtained a driver�s license within the past");
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+"   five years.");
		stringBuffer.append("\n\n");
		stringBuffer.append(firstMarker+"Note:  Both forms listed above must be completed by you and brought with you on the first day of ");
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+"class.  Remember the NDR Form 20119 must be notarized.  Failure to have both forms with you on the ");
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+"first day of class can result in discipline. ");
		stringBuffer.append("\n\n");
		stringBuffer.append(firstMarker+" \tAs you near your initial training date, further instructions about the Locomotive Engineer training ");
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+"process will be mailed to you from the Training Center. ");
		stringBuffer.append("\n\n");
		stringBuffer.append("\t\t\t\t\t\t\t\t");
		stringBuffer.append("Thank you,");
		stringBuffer.append("\n\n");
		stringBuffer.append("\t\t\t\t\t\t\t\t");
		stringBuffer.append(m_coverLetterForNewLicenseDetails.getSysLicDeptManagerName()+",Manager");
		stringBuffer.append("\n");
		stringBuffer.append("\t\t\t\t\t\t\t\t");
		stringBuffer.append(m_coverLetterForNewLicenseDetails.getSysLicDepartmentName());
		return stringBuffer;
	}

	public static void main(String[] args) {
		LataTemplateForNewLicense lataTemplateForNewLicense = new LataTemplateForNewLicense();

	}

	private static CoverLetterForNewLicenseDetails getTemplateDetails(){
		
		CoverLetterForNewLicenseDetails coverLetterForNewLicenseDetails = new CoverLetterForNewLicenseDetails();
		coverLetterForNewLicenseDetails.setEmployeeName("Sreekar Vanguru");
		coverLetterForNewLicenseDetails.setAddressLine1("Satyam Computers,ManikChand Icon");
		coverLetterForNewLicenseDetails.setAddressLine2("Bund Garden Road");
		coverLetterForNewLicenseDetails.setCity("Pune");
		coverLetterForNewLicenseDetails.setState("Maharastra");
		coverLetterForNewLicenseDetails.setCountry("India");
		coverLetterForNewLicenseDetails.setClassNumber("Class 2");
		coverLetterForNewLicenseDetails.setStartDate("May 20,2009");
		coverLetterForNewLicenseDetails.setSysLicDeptManagerName("L. J. Brennan");
		coverLetterForNewLicenseDetails.setSysLicDepartmentName("Engineer Certification & Licensing");
		return coverLetterForNewLicenseDetails;
	}

}
