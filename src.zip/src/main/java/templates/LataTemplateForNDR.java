/**
 * Class Name	: LataTemplateForNDR
 * Description  : Class is used as a Lata template for NDR form.
 * Created By	: Satyam Computer Services Ltd.
 * Created On	: Jun 15, 2009
 *
 * Change History
 * ------------------------------------------------------------  
 * Date			Changed By	Description
 * ------------------------------------------------------------  
 * 22 Apr 2013	xsat244		Fortify issue fix.
 *
 * ------------------------------------------------------------  
 *
 * Copyright notice : "Copyright � UPRR 2008"
 */
package templates;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.uprr.lic.dataaccess.Licensing.model.NdrTemplatePageDetail;

/**
 * To define a LATA template for NDA form.
 *
 * @since Jun 15, 2009
 */
public class LataTemplateForNDR {
	
	private final Logger m_logger = LoggerFactory.getLogger(this.getClass());

	private final String firstMarker = padSpaceTillMaxLength(1);
	private final String secondMarker = padSpaceTillMaxLength(2);
	private final String fourthMarker = padSpaceTillMaxLength(4);


	private final String pdfTitle="UNION PACIFIC RAILROAD";
	private final String pdfLocmotiveTitle="Locomotive Engineer/Remote Control Operator Certification";
	private final String pdfNDRTitle="National Driving Record Review";
	private final String to="TO: CHIEF, NATIONAL DRIVER REGISTER";
	private final String rout="ROUTING CODE: U.P.";
	private final String wasshing="WASHINGTON, D.C.";
	private final String section="In accordance with the requirements for Locomotive Engineer/Remote Control Operator";
	private final String section0="certification as mandated by the Federal Railroad Administration and contained in the Code of";
	private final String section01="Federal Regulations, 49 CFR Part 240, this request authorizes NHTSA to perform a search of the";
	private final String section02="National Driver Registration (NDR) and furnish the results of the search directly to the Union Pacific";
	private final String section03="Railroad.";
	private final String name="FULL NAME:"+"         "+"(FIRST NAME (MI) LAST NAME)";
	private final String nickname="NICK NAME/PROFESSIONAL NAME";
	private final String date="DATE OF BIRTH: (MM/DD/YY)";
	private final String height="HEIGHT:";
	private final String feet="Feet:";
	private final String inches="Inches:";
	private final String weight="WEIGHT:";
	private final String eyecolor="COLOR OF EYES:";
	private final String pounds="Pounds";
	private final String drivingLicense="DRIVER'S LICENSE NUMBER (REQUIRED):";
	private final String state="STATE:";
	private final String gender="GENDER:";
	private final String socialSecNum="Social Security Number(Optional)";
	private final String emplId="Employee ID Number(Required)";
	private final String currenAddress="CURRENT ADDRESS:Street";
	private final String city="City";
	private final String stateadd="State";
	private final String zipcode="Zip Code";
	private final String resultAddress="Results are to be furnished directly to the following address:";
	private final String licenseDepartment="UNION PACIFIC RAILROAD";
	private final String licenseDepartment1="LICENSING DEPARTMENT";
	private final String licenseDepartment2="1400 DOUGLAS ST, STOP 1010";
	private final String licenseDepartment3="OMAHA, NE 68179-1010";
	private final String signature="Signature of Requestor (employee)";
	private final String stateof="State of";
	private final String countyof="County of";
	private final String onThisDay="	    On this day personally appeared before me";
	private final String personnaly="personally known to me or proved to me on the basis of satisfactory evidence to be the person whose name";
	private final String personnaly1="subscribed to the within instrument, and acknowledge that he/she signed the same as his/her free and";
	private final String personnaly2="voluntary act and deed, for the uses and purposes therein mentioned.";
	private final String personnaly3="Given under my hand and official seal this ";
	private final String notory="Notary's Signature";

	private final String topLine = "_______________________________________________________________________________________________________________";
	private final String horizontalLineWithMultipleBorder1 = "|__________________________________________|______________|__________________|__________________________________|";
	private final String horizontalLineWithMultipleBorder2 = "|__________________________________________|______________|_____________________________________________________|";
	private final String horizontalLineWithMultipleBorder3 = "|__________________________________________|____________________________________________________________________|";
	private final String horizontalLineWithMultipleBorder4 = "|__________________________________________|__________________________|__________________|______________________|";
	private final String horizontalLineWithCenterAndEndBorder = "|_________________________________________________________|_____________________________________________________|";
	private final String horizontalLine1="______________________________________________________________________";
	private final String horizontalLine2="_____________________________________________";
	private final String horizontalLine3="___________";
	private final String horizontalLine4="_______________________";
	private final String horizontalLine5="__";
	private final String horizontalLine6="|__|";
	private final String dayof="day of";
	private final String mycomm="My commission expires";
	private final String tableRightBorder = padSpaceTillMaxLength(10)+"|";
	private final String tableRightBorder1 = padSpaceTillMaxLength(47);
	private final String tableRightBorderWithoutMarker = padSpaceTillMaxLength(11);



	public StringBuffer getBufferForLataPrintForNDR(NdrTemplatePageDetail m_ndrTemplatePageDetail){
		StringBuffer stringBuffer=new StringBuffer();
		/*stringBuffer.append(firstMarker+horizontalLine);*/
		stringBuffer.append("\n");
		stringBuffer.append(padSpaceTillMaxLength(91)+"Form 20119 (Rev 06/07)");
		stringBuffer.append("\n\n");
		stringBuffer.append(firstMarker+padSpaceTillMaxLength(91/2)+pdfTitle+padSpaceTillMaxLength(91/2));
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+padSpaceTillMaxLength(56/2)+pdfLocmotiveTitle+padSpaceTillMaxLength(56/2));
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+" "+padSpaceTillMaxLength(83/2)+pdfNDRTitle+padSpaceTillMaxLength(83/2));
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+" "+to+padSpaceTillMaxLength(32)+rout+fourthMarker+" ");
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+"     "+wasshing+tableRightBorder1+secondMarker+tableRightBorderWithoutMarker);
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+"     "+section+secondMarker+firstMarker+" ");
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+" "+section0+secondMarker+firstMarker+" ");
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+" "+section01+secondMarker+" ");
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+" "+section02+secondMarker+" ");
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+" "+section03+tableRightBorder1+secondMarker+firstMarker+tableRightBorderWithoutMarker);
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+" "+topLine);
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+"|"+name+padSpaceTillMaxLength(10)+"|"+nickname+padSpaceTillMaxLength(25)+"|");
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+"|"+padSpaceTillMaxLengthForDynamicData(m_ndrTemplatePageDetail.getEmployeeName(), 56)+"|"+padSpaceTillMaxLength(52)+"|");
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+horizontalLineWithCenterAndEndBorder);
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+"|"+date+padSpaceTillMaxLengthForDynamicData("", 16)+"|"+padSpaceTillMaxLengthForDynamicData(height+m_ndrTemplatePageDetail.getHeightFt()+":"+m_ndrTemplatePageDetail.getHeightInches(), 13)+"|"+padSpaceTillMaxLengthForDynamicData(weight, 17)+"|"+eyecolor+padSpaceTillMaxLength(19)+"|");
		stringBuffer.append("\n"+firstMarker+"|"+padSpaceTillMaxLength(41)+"|"+padSpaceTillMaxLength(13)+"|"+padSpaceTillMaxLength(17)+"|"+"  "+horizontalLine5+padSpaceTillMaxLength(8)+horizontalLine5+padSpaceTillMaxLength(7)+horizontalLine5+padSpaceTillMaxLength(8)+"|");
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+"|"+padSpaceTillMaxLengthForDynamicData(m_ndrTemplatePageDetail.getDateOfBirth(), 41)+"|"+padSpaceTillMaxLengthForDynamicData(feet+m_ndrTemplatePageDetail.getHeightFt(), 13)+"|"+padSpaceTillMaxLengthForDynamicData("", 17)+"|"+" "+horizontalLine6+"Brown"+"  "+horizontalLine6+"Blue"+"  "+horizontalLine6+"Green"+firstMarker+" |");
		stringBuffer.append("\n"+firstMarker+"|"+padSpaceTillMaxLength(41)+"|"+padSpaceTillMaxLength(13)+"|"+padSpaceTillMaxLength(17)+"|"+"  "+horizontalLine5+padSpaceTillMaxLength(29)+"|");
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+"|"+padSpaceTillMaxLengthForDynamicData("", 41)+"|"+padSpaceTillMaxLengthForDynamicData(inches+m_ndrTemplatePageDetail.getHeightInches(), 13)+"|    "+padSpaceTillMaxLengthForDynamicData(pounds, 13)+"|"+" "+horizontalLine6+"Other"+padSpaceTillMaxLength(12)+tableRightBorder);
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+horizontalLineWithMultipleBorder1);
		stringBuffer.append("\n"+firstMarker+"|"+padSpaceTillMaxLength(41)+"|"+padSpaceTillMaxLength(13)+"|"+padSpaceTillMaxLength(17)+"    "+horizontalLine5+padSpaceTillMaxLength(12)+horizontalLine5+padSpaceTillMaxLength(13)+"|");
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+"|"+padSpaceTillMaxLengthForDynamicData(drivingLicense, 41)+"|"+padSpaceTillMaxLengthForDynamicData(state, 13)+"|"+padSpaceTillMaxLengthForDynamicData(gender, 17)+"   "+horizontalLine6+"Male"+firstMarker+"     "+horizontalLine6+"Female"+padSpaceTillMaxLength(6)+"|");
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+"|"+padSpaceTillMaxLengthForDynamicData("", 41)+"|"+padSpaceTillMaxLengthForDynamicData("", 13)+"|"+padSpaceTillMaxLengthForDynamicData("", 17)+padSpaceTillMaxLength(34)+"|");
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+horizontalLineWithMultipleBorder2);

		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+"|"+padSpaceTillMaxLengthForDynamicData(socialSecNum, 41)+"|"+padSpaceTillMaxLength(18)+padSpaceTillMaxLengthForDynamicData(emplId, 29)+padSpaceTillMaxLength(18)+"|");
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+"|"+padSpaceTillMaxLengthForDynamicData("", 41)+"|"+padSpaceTillMaxLength(25)+padSpaceTillMaxLengthForDynamicData(m_ndrTemplatePageDetail.getEmployeeID(), 41)+"|");
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+horizontalLineWithMultipleBorder3);
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+"|"+padSpaceTillMaxLengthForDynamicData(currenAddress, 41)+"|"+padSpaceTillMaxLengthForDynamicData(city, 25)+"|"+padSpaceTillMaxLengthForDynamicData(stateadd, 17)+"|"+padSpaceTillMaxLengthForDynamicData(zipcode, 21)+"|");
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+"|"+padSpaceTillMaxLengthForDynamicData(m_ndrTemplatePageDetail.getAddress(), 41)+"|"+padSpaceTillMaxLengthForDynamicData(m_ndrTemplatePageDetail.getAddressCity(), 25)+"|"+padSpaceTillMaxLengthForDynamicData(m_ndrTemplatePageDetail.getAddressState(), 17)+"|"+padSpaceTillMaxLengthForDynamicData(m_ndrTemplatePageDetail.getAddressZip(), 21)+"|");
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+horizontalLineWithMultipleBorder4);
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+" "+resultAddress+secondMarker+firstMarker+"   "+licenseDepartment+secondMarker+" ");
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+" "+tableRightBorder1+fourthMarker+padSpaceTillMaxLength(16)+licenseDepartment1+secondMarker+" ");
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+" "+tableRightBorder1+fourthMarker+padSpaceTillMaxLength(16)+licenseDepartment2+firstMarker+" ");
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+" "+tableRightBorder1+fourthMarker+padSpaceTillMaxLength(16)+licenseDepartment3+secondMarker+" ");
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+" "+horizontalLine1);
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+" "+signature+tableRightBorder1+fourthMarker+" ");
		stringBuffer.append("\n");
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+" "+stateof+horizontalLine2+"__"+fourthMarker+firstMarker+" ");
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+" "+tableRightBorder1+secondMarker+firstMarker+"  }  "+"SS"+fourthMarker+firstMarker+" ");
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+" "+countyof+horizontalLine2+fourthMarker+firstMarker+"  ");
		stringBuffer.append("\n");		
		stringBuffer.append(firstMarker+" "+onThisDay+" "+horizontalLine2+horizontalLine3+"_____"+firstMarker+" ");
		stringBuffer.append("\n");		
		stringBuffer.append(firstMarker+" "+personnaly+firstMarker+" ");
		stringBuffer.append("\n");		
		stringBuffer.append(firstMarker+" "+personnaly1+secondMarker+" ");
		stringBuffer.append("\n");		
		stringBuffer.append(firstMarker+" "+personnaly2+fourthMarker+secondMarker+" ");
		stringBuffer.append("\n");		
		stringBuffer.append(firstMarker+" "+personnaly3+horizontalLine3+"______ "+dayof+" "+horizontalLine3+"______"+", "+20+"________"+".");
		stringBuffer.append("\n");
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+" "+horizontalLine2+horizontalLine3);
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+" "+notory+tableRightBorder1+fourthMarker+secondMarker+" ");
		stringBuffer.append("\n");
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+" "+horizontalLine2+horizontalLine3);
		stringBuffer.append("\n");		
		stringBuffer.append(firstMarker+" "+mycomm+tableRightBorder1+fourthMarker+secondMarker+" ");
		
		return stringBuffer;
	}

	/**
	 * Classname / Method Name : LataTemplateForNDR/padSpaceTillMaxLength()
	 * @param maxLength
	 * @return : String
	 * Description : Method is used to add spaces in NDR template.
	 */
	private String padSpaceTillMaxLength(int maxLength)	{
		StringBuffer sb = new StringBuffer();
		for(int i=0;i<=maxLength;i++){
			sb.append(" ");
		}
		return sb.toString();
	}

	/**
	 * Classname / Method Name : LataTemplateForNDR/padSpaceTillMaxLengthForDynamicData()
	 * @param str
	 * @param maxLength
	 * @return : String
	 * Description : Method is used to add proper spaces in dynamic data for NDR template.
	 */
	private String padSpaceTillMaxLengthForDynamicData(String str, int maxLength)	{
		StringBuffer sb = new StringBuffer(str);
		for(int i=str.length();i<=maxLength;i++){
			sb.append(" ");
		}
		return sb.toString();
	}

	public static void main(String[] args) {
		LataTemplateForNDR lataTemplateForNDR =	new LataTemplateForNDR();
	}

	private static NdrTemplatePageDetail getTemplateDetails(){		
		NdrTemplatePageDetail ndrTemplatePageDetail = new NdrTemplatePageDetail();
		ndrTemplatePageDetail.setEmployeeName("Bramhendra Dwivedi");
//		ndrTemplatePageDetail.setEmployeeName("ABCDEFGHIJKLMNOPQRSTUVWXYZ, ABCDEFGHIJKLMNOPQRSTUVWXYZ ");
		ndrTemplatePageDetail.setDateOfBirth("11/06/2009");
		ndrTemplatePageDetail.setSsn("100");
		ndrTemplatePageDetail.setAddress("Satyam Computers,ManikChand Icon");		
		ndrTemplatePageDetail.setHeightFt("5");
		ndrTemplatePageDetail.setHeightInches("7");
		ndrTemplatePageDetail.setLicenseNumber("Class 1");	   
		//ndrTemplatePageDetail.setStateIssuedDriverLicense("100");
		//ndrTemplatePageDetail.setPreviousLicenseNumber("200");
		ndrTemplatePageDetail.setEmployeeID("1");
		ndrTemplatePageDetail.setState("Maharstra");
		ndrTemplatePageDetail.setAddressCity("Pune");
		ndrTemplatePageDetail.setAddressZip("411014");
		ndrTemplatePageDetail.setAddress("4th Lane");
//		ndrTemplatePageDetail.setAddress("ABCDEFGHIJKLMNOPQR, ABCDEFGHIJKLMNOPQRSAAS");
		ndrTemplatePageDetail.setAddressState("Maharstra");
		//	ndrTemplatePageDetail.setStateIssuedPreviousDriverLicense("300");
		return ndrTemplatePageDetail;
	}
}
