package templates;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.uprr.lic.dataaccess.Licensing.model.License;
import com.uprr.lic.dataaccess.Licensing.model.TempLicenseTemplate;
import com.uprr.lic.dataaccess.Licensing.model.TempLicenseTemplateList;
import com.uprr.lic.util.LicensingConstant;

public class LataTemplateForTempLicense {
	
	private final Logger m_logger = LoggerFactory.getLogger(this.getClass());

	private String pdfTitle = "Union Pacific RR Temporary Engine Service License";
	private String pdfTitleCon = "Union Pacific RR Temporary Conductor License";
	private String pdfTitleGen = "Union Pacific RR Temporary Employee Service License";
	private final String validityNote = "Temporary License Valid Through :";
	private final String licenseListAsString1 = "(1-Engineer, 2-Hostler, 3-Student Engineer, " +
														"4-Student Qualified Hostler,";
	private final String licenseListAsString2 = "5-Student Hostler, 6-RCO, 7-Student RCO, 8-Freight Conductor)";
	private final String licenseListAsString3 = ", 9-Passenger Conductor)";
	//--	Page and Table properties.
//	private final String firstMarker = "\t\t";
//	private final String secondMarker = "\t";
//	private final String centerAlign = firstMarker+"\t";
	private final String firstMarker = padSpaceTillMaxLength(10);
	private final String secondMarker = padSpaceTillMaxLength(6);
	private final String centerAlign = firstMarker+padSpaceTillMaxLength(6);
	private String validityNoteTemp=null;
	
	private final String horizontalLine = "___________________________________________________________________________________________";
//	private final String blankSpace = "\t\t\t\t\t\t\t\t\t\t\t       ";
	private final String blankSpace =padSpaceTillMaxLength(88);
	
	private final String tableBorderLine = "__________________________________________________________________________";
//	private final String tableRightBorder = "\t       |";
	private final String tableRightBorder = padSpaceTillMaxLength(7)+"|";
	private final String tableRightBorderII = padSpaceTillMaxLength(6)+"|";
	private final String footerNote = "NOTE : Valid only if accompanied with photo Id.";
	private final String footerNoteLastPart1 = "All federal certification requirements must be completed per System Special Instruction  ";
	private final String footerNoteLastPart2 = "7B to be fully qualified to work and avoid any disruption to service.                    ";
	private  boolean onlyConductorLicenseFlag=true;
	
	
	
	public LataTemplateForTempLicense()
	{
	}
	
	public StringBuffer getBufferForLataPrintForTempLicense(TempLicenseTemplate m_tempLicenseTemplate)
	{
		StringBuffer sb = new StringBuffer();
		 List<License> licenseList = m_tempLicenseTemplate.getLicenseList();
	    if (!licenseList.isEmpty()) {
	      for (License license : licenseList) {
	        if (!license.getLicenseClass().equalsIgnoreCase(
	            LicensingConstant.LICENSE_CLASS_CLASS8)
	            && !license.getLicenseClass().equalsIgnoreCase(
	                LicensingConstant.LICENSE_CLASS_CLASS9)) {
	          onlyConductorLicenseFlag = false;
	        }
	      }
	    }

			
		sb.append(firstMarker+horizontalLine);
		
		//--	PDF TITLE
		sb.append("\n"+firstMarker+"|");	
		if(onlyConductorLicenseFlag){
		sb.append(firstMarker+padSpaceTillMaxLength(16)+pdfTitleCon);
		}
		else
		{
		  sb.append(firstMarker+padSpaceTillMaxLength(4)+pdfTitleGen);
		}
	    
		sb.append(padSpaceTillMaxLength(21)+"|");
		
		sb.append("\n"+firstMarker+"|");
		sb.append(blankSpace+"|");
		
		sb.append("\n");
		sb.append(firstMarker+horizontalLine);
		
		//--	VALIDITY & DATE
		sb.append("\n");
		validityNoteTemp=firstMarker+"|"+secondMarker+padSpaceTillMaxLength(30)+validityNote;
		sb.append(validityNoteTemp+padSpaceTillMaxLength(m_tempLicenseTemplate.getTempValidDate(), 17)+"|");
		
		sb.append("\n"+firstMarker+"|");
		sb.append(blankSpace+"|");
		
		//--	LICENSE TABLE : STARTS
		sb.append("\n"+firstMarker+"|");
		sb.append(secondMarker+tableBorderLine+tableRightBorder);
		
		sb.append("\n"+firstMarker+"|");
		sb.append(secondMarker+"|"+"NAME :"+
				padSpaceTillMaxLength(m_tempLicenseTemplate.getEmployeeName(), 40));
		sb.append("|  EMP ID :"+padSpaceTillMaxLength(m_tempLicenseTemplate.getEmployeeID(), 13)+"|");
		sb.append(tableRightBorder);
		
		sb.append("\n"+firstMarker+"|");
		sb.append(secondMarker+"|"+"ISSUED DATE :"+padSpaceTillMaxLength(m_tempLicenseTemplate.getIssueDate(), 33));
		sb.append(padSpaceTillMaxLength(24)+"|");
		sb.append(tableRightBorder);
		
		sb.append("\n"+firstMarker+"|");
		sb.append(secondMarker+tableBorderLine+tableRightBorder);
		
		sb.append("\n"+firstMarker+"|");
		sb.append(secondMarker+"|"+"CLASS OF SERVICE:"+
				getClassOfService(m_tempLicenseTemplate.getLicenseList())+"|");
		sb.append(tableRightBorder);
		
		sb.append("\n"+firstMarker+"|");
		sb.append(secondMarker+"|"+licenseListAsString1+"|");
		sb.append(tableRightBorder);
		
		sb.append("\n"+firstMarker+"|");
		sb.append(secondMarker+"|"+licenseListAsString2+padSpaceTillMaxLength(10)+"|");
		sb.append(tableRightBorder);
		sb.append("\n"+firstMarker+"|");
    sb.append(secondMarker+"|"+licenseListAsString3+padSpaceTillMaxLength(47)+"|");
		sb.append(tableRightBorder);
		sb.append("\n"+firstMarker+"|");
		sb.append(secondMarker+tableBorderLine+tableRightBorder);		
		//--	LICENSE TABLE : ENDS
		
		sb.append("\n"+firstMarker+"|");
		sb.append(blankSpace+"|");
		
		sb.append("\n"+firstMarker+"|");
		sb.append(blankSpace+"|");
		
		//--	RESTRICTION TABLE : STARTS
		sb.append("\n"+firstMarker+"|");
		sb.append(secondMarker+tableBorderLine+tableRightBorder);
		
		sb.append("\n"+firstMarker+"|");
		sb.append(secondMarker+"| SR NO. | CLASS |"+padSpaceTillMaxLength(1)+"LAST RIDE/OBS"+padSpaceTillMaxLength(1)+"|  EXP DATE   "+"| MEDICAL RESTRICTIONS   |");
		sb.append(tableRightBorderII);
		
		sb.append("\n"+firstMarker+"|");
		sb.append(secondMarker+tableBorderLine+tableRightBorder);
		
		for(TempLicenseTemplateList item:m_tempLicenseTemplate.getTempLicenseTemplateList())
		{
			sb.append("\n"+firstMarker+"|");
			sb.append(secondMarker+"|"+padSpaceTillMaxLengthAlignCenter(item.getSrNo().toString(), 7));
			sb.append("|"+padSpaceTillMaxLengthAlignCenter(item.getLicenseClassCode(), 6));
			sb.append("|"+padSpaceTillMaxLengthAlignCenter(item.getLastRideInfo(), 16));
			sb.append("|"+padSpaceTillMaxLengthAlignCenter(item.getExpiryDate(), 12));
			sb.append("|"+padSpaceTillMaxLengthAlignCenter(item.getMedicalRestriction(), 23)+"|");
			sb.append(tableRightBorderII);	
		}
		
		sb.append("\n"+firstMarker+"|");
		sb.append(secondMarker+tableBorderLine+tableRightBorder);		
		//--	RESTRICTION TABLE : ENDS
		
		sb.append("\n"+firstMarker+"|");
		sb.append(blankSpace+"|");
		
		sb.append("\n");
		sb.append(firstMarker+horizontalLine);
		
		//--	FOOTER
		sb.append("\n"+firstMarker+"|");		
		sb.append(footerNote+padSpaceTillMaxLength(41)+"|");
		sb.append("\n"+firstMarker+"|");  
    sb.append(footerNoteLastPart1+"|");
    sb.append("\n"+firstMarker+"|");  
    sb.append(footerNoteLastPart2+"|");
		sb.append("\n");
		sb.append(firstMarker+horizontalLine);
		
		return sb;
		
	}
	
	private String getClassOfService(List<License> licenseList)
	{
		
		String licenseClass = "";
		if(licenseList!=null){
			for(License license:licenseList)
			{
				licenseClass = licenseClass.equalsIgnoreCase("") ? 
						licenseClass + license.getLicenseClass() :
							licenseClass + ", " + license.getLicenseClass();
			}
			}
		return padSpaceTillMaxLength(licenseClass, 54);
		
	}
	
	private String padSpaceTillMaxLength(String str, int maxLength)
	{
		StringBuffer sb = new StringBuffer(str);
		for(int i=str.length();i<=maxLength;i++)
		{
			sb.append(" ");
		}
		return sb.toString();
	}
	
	private String padSpaceTillMaxLengthAlignCenter(String str, int maxLength)
	{
		int initLength = str.length();
		StringBuffer sb = new StringBuffer();
		if(initLength<maxLength)
		{
			for(int i=0;i<(maxLength-initLength)/2;i++)
			{
				sb.append(" ");
			}
			sb.append(str);
			final int len = sb.length();
			for(int i=len;i<=maxLength;i++)
			{
				sb.append(" ");
			}
		}		
		return sb.toString();
	}
	
	private String padSpaceTillMaxLength(int maxLength){
		StringBuffer sb = new StringBuffer();
		for(int i=0;i<=maxLength;i++)
		{
			sb.append(" ");
		}
		return sb.toString();
	}
	
	//--	For Testing.
	
	public static void main(String[] args) {
		LataTemplateForTempLicense template = new LataTemplateForTempLicense();
	}
	
	private static TempLicenseTemplate getTemplate()
	{
		TempLicenseTemplate tempLicenseTemplate = new TempLicenseTemplate();
		
		tempLicenseTemplate.setEmployeeID("1234567890123456");
		tempLicenseTemplate.setEmployeeName("WWWWWWWWWWWWWWWWWWW, WWWWWWWWWWWWWWWWWW W");
		tempLicenseTemplate.setIssueDate("11/30/2008");
		tempLicenseTemplate.setTempValidDate("15/10/09");
		
		List<License> licenseList = new ArrayList<License>();
		for(Integer i=1;i<=9;i++)
		{
			License license = new License();
			license.setLicenseClass(i.toString());
			licenseList.add(license);
		}
		tempLicenseTemplate.setLicenseList(licenseList);
	
		tempLicenseTemplate.setTempLicenseValidity("ONE");
		List<TempLicenseTemplateList> list = new ArrayList<TempLicenseTemplateList>();
		for(Integer i=1;i<=7;i++)
		{
			TempLicenseTemplateList item = new TempLicenseTemplateList();
			item.setSrNo(i);
			item.setLicenseClassCode(i.toString());
			item.setLastRideInfo("R4/17/2008");
			item.setMedicalRestriction("-");
			item.setExpiryDate("R4/17/2008");
			list.add(item);
		}
		tempLicenseTemplate.setTempLicenseTemplateList(list);
		
		
		return tempLicenseTemplate;
	}
	

	
}
