/**
 * Class Name   : LataTemplateForNDRModified
 * Description  : To define a LATA templet for NDR form.
 * Created By   : Techmahindra Ltd.
 * Created On   :
 *
 * Change History
 * ------------------------------------------------------------  
 * Date			Changed By		Description
 * ------------------------------------------------------------  
 * 22 Apr 2013	xsat244			Fortify issue fix.
 * 12 Apr 2016  xsat671     Modified for SS_QC#5503.
 * ------------------------------------------------------------
 * Copyright notice : "Copyright UPRR 2008"
 */
package templates;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.uprr.lic.dataaccess.Licensing.model.NdrTemplatePageDetail;
/**
 * To define a LATA templet for NDR form.
 */
public class LataTemplateForNDRModified {	
	private final Logger m_logger = LoggerFactory.getLogger(this.getClass());

	private final String firstMarker = padSpaceTillMaxLength(1);
	private final String secondMarker = padSpaceTillMaxLength(2);
//	private final String fourthMarker = padSpaceTillMaxLength(4);


	private final String pdfTitle="UNION PACIFIC RAILROAD";
	private final String pdfLocmotiveTitle="Locomotive Engineer/Remote Control Operator Certification";
	private final String pdfNDRTitle="National Driving Record Review";
	private final String to="TO:CHIEF, NATIONAL DRIVER REGISTER";
	private final String rout="ROUTING CODE: U.P.";
	private final String wasshing="WASHINGTON, D.C.";
	private final String section="In accordance with the requirements for Locomotive Engineer/Remote";
	private final String section0="Control Operator certification as mandated by the Federal Railroad";
	private final String section01="Administration and contained in the Code of Federal Regulations, 49";
	private final String section02="CFR Part 240, this request authorizes NHTSA to perform a search of";
	private final String section03="the National Driver Registration (NDR) and furnish the results of";
	private final String section04="the search directly to the Union Pacific Railroad.";
	private final String name="FULL NAME: (FIRST NAME (MI) LAST NAME)";
	private final String nickname="NICK NAME/PROFESSIONAL NAME";
	private final String date="DATE OF BIRTH: (MM/DD/YY)";
	private final String height="HEIGHT:";
	private final String feet="Feet:";
	private final String inches="Inches:";
	private final String weight="WEIGHT:";
	private final String eyecolor="COLOR OF EYES:";
	private final String pounds="Pounds";
	private final String drivingLicense="DRIVER'S LICENSE NUMBER";
	private final String required="(REQUIRED):";
	private final String state="STATE:";
	private final String gender="GENDER:";
	private final String socialSecNum="Social Security Number";
	private final String optional="(Optional)";
	private final String emplId="Employee ID Number(Required)";
	private final String currenAddress="CURRENT ADDRESS:Street";
	private final String city="City";
	private final String stateadd="State";
	private final String zipcode="Zip Code";
	private final String resultAddress="Results are to be furnished directly";
	private final String resultAddress1="to the following address:";
	private final String licenseDepartment="UNION PACIFIC RAILROAD";

  // SS_QC#5503 changes start
  private final String licenseDepartment1 = "Employee Licensing &";

  private final String licenseDepartment2 = "Certification Department";

  private final String licenseDepartment3 = "1400 DOUGLAS ST, STOP 1010";

  private final String licenseDepartment4 = "OMAHA, NE 68179-1010";

  // SS_QC#5503 changes end
	private final String signature="Signature of Requestor (employee)";
	private final String stateof="State of";
	private final String countyof="County of";
	private final String onThisDay="         On this day personally appeared before me";
	private final String personnaly="personally known to me or proved to me on the basis of satisfactory";
	private final String personnaly1="evidence to be the person whose name subscribed to the within";
	private final String personnaly2="instrument, and acknowledge that he/she signed the same as his/her";
	private final String personnaly3="free and voluntary act and deed, for the uses and purposes therein";
	private final String personnaly4="mentioned.";
	private final String personnaly5="Given under my hand and official seal this";
	private final String notory="Notary's Signature";

	private final String topLine = "____________________________________________________________________";
	private final String horizontalLineWithMultipleBorder1 = "|_________________________|____________|_________|__________________|";
	private final String horizontalLineWithMultipleBorder2 = "|_________________________|____________|____________________________|";
	private final String horizontalLineWithMultipleBorder3 = "|_________________________|_________________________________________|";
	private final String horizontalLineWithMultipleBorder4 = "|_________________________|___________|________________|____________|";
	private final String horizontalLineWithCenterAndEndBorder = "|______________________________________|____________________________|";
	private final String horizontalLine1="__________________________________________";
	private final String horizontalLine2="_____________________________________";
	private final String horizontalLine3="_________________";
	private final String horizontalLine4="________________________________________________________";
	private final String horizontalLine7="_________________";
	private final String horizontalLine5="__";
	private final String horizontalLine6="|__|";
	private final String dayof=" day";
	private final String mycomm="My commission expires";
//	private final String tableRightBorder = padSpaceTillMaxLength(10)+"|";
//	private final String tableRightBorder1 = padSpaceTillMaxLength(47);
//	private final String tableRightBorderWithoutMarker = padSpaceTillMaxLength(11);



  /**
   * To print NDR from using LATA functionality.
   *
   * @param m_ndrTemplatePageDetail
   * @return
   * @author xsat671
   * @since Apr 12, 2016. Modified for SS_QC#5503.
   */
	
  // Added the instruction so that no mismatch in future between PDF and Latter.
  // **##Whenever any content related changes done,make sure that changes made in NDRTemplate.vtl file as well. **  
	  public StringBuffer getBufferForLataPrintForNDR(NdrTemplatePageDetail m_ndrTemplatePageDetail){	
		StringBuffer stringBuffer=new StringBuffer();
		/*stringBuffer.append(firstMarker+horizontalLine);*/
		stringBuffer.append("\n");
    stringBuffer.append(padSpaceTillMaxLength(49) + "Form 20119 (Rev 09/2014)");// Modified for SS_QC#5503
		stringBuffer.append("\n\n");
		stringBuffer.append(padSpaceTillMaxLength(28)+pdfTitle+padSpaceTillMaxLength(21));
		stringBuffer.append("\n");
		stringBuffer.append(padSpaceTillMaxLength(11)+pdfLocmotiveTitle+padSpaceTillMaxLength(3));
		stringBuffer.append("\n");
		stringBuffer.append(padSpaceTillMaxLength(25)+pdfNDRTitle+padSpaceTillMaxLength(16));
		stringBuffer.append("\n");
		stringBuffer.append(secondMarker+" "+to+padSpaceTillMaxLength(14)+rout);
		stringBuffer.append("\n");
		stringBuffer.append(padSpaceTillMaxLength(5)+wasshing+padSpaceTillMaxLength(50));
		stringBuffer.append("\n");
		stringBuffer.append(padSpaceTillMaxLength(5)+section);
		stringBuffer.append("\n");
		stringBuffer.append(padSpaceTillMaxLength(2)+section0+padSpaceTillMaxLength(2));
		stringBuffer.append("\n");
		stringBuffer.append(padSpaceTillMaxLength(2)+section01+padSpaceTillMaxLength(1));
		stringBuffer.append("\n");
		stringBuffer.append(padSpaceTillMaxLength(2)+section02+padSpaceTillMaxLength(2));
		stringBuffer.append("\n");
		stringBuffer.append(padSpaceTillMaxLength(2)+section03+padSpaceTillMaxLength(3));
		stringBuffer.append("\n");
		stringBuffer.append(padSpaceTillMaxLength(2)+section04+padSpaceTillMaxLength(18));
		stringBuffer.append("\n");
		stringBuffer.append(padSpaceTillMaxLength(2)+topLine);
		stringBuffer.append("\n");
		stringBuffer.append(secondMarker+"|"+name+"|"+nickname+" "+"|");
		stringBuffer.append("\n");
		stringBuffer.append(secondMarker+"|"+padSpaceTillMaxLengthForDynamicData(m_ndrTemplatePageDetail.getEmployeeName(), 37)+"|"+padSpaceTillMaxLength(27)+"|");
		stringBuffer.append("\n");
		stringBuffer.append(secondMarker+horizontalLineWithCenterAndEndBorder);
		stringBuffer.append("\n");
    // Modified for SS_QC#5503
		stringBuffer.append(secondMarker+"|"+date+"|"+padSpaceTillMaxLengthForDynamicData(height+m_ndrTemplatePageDetail.getHeightFt()+m_ndrTemplatePageDetail.getHeightInches(), 11)+"|"+padSpaceTillMaxLengthForDynamicData(weight, 8)+"|"+eyecolor+padSpaceTillMaxLength(3)+"|");
		stringBuffer.append("\n"+secondMarker+"|"+padSpaceTillMaxLength(24)+"|"+padSpaceTillMaxLength(11)+"|"+padSpaceTillMaxLength(8)+"|"+" "+horizontalLine5+padSpaceTillMaxLength(6)+horizontalLine5+padSpaceTillMaxLength(5)+"|");
		stringBuffer.append("\n");
		stringBuffer.append(secondMarker+"|"+padSpaceTillMaxLengthForDynamicData(m_ndrTemplatePageDetail.getDateOfBirth(), 24)+"|"+padSpaceTillMaxLengthForDynamicData(feet+m_ndrTemplatePageDetail.getHeightFt(), 11)+"|"+padSpaceTillMaxLengthForDynamicData("", 8)+"|"+horizontalLine6+"Brown"+horizontalLine6+"Blue"+" |");
		stringBuffer.append("\n"+secondMarker+"|"+padSpaceTillMaxLength(24)+"|"+padSpaceTillMaxLength(11)+"|"+padSpaceTillMaxLength(8)+"|"+" "+horizontalLine5+padSpaceTillMaxLength(6)+horizontalLine5+padSpaceTillMaxLength(5)+"|");
		stringBuffer.append("\n");
		stringBuffer.append(secondMarker+"|"+padSpaceTillMaxLengthForDynamicData("", 24)+"|"+padSpaceTillMaxLengthForDynamicData(inches+m_ndrTemplatePageDetail.getHeightInches(), 11)+"| "+padSpaceTillMaxLengthForDynamicData(pounds, 7)+"|"+horizontalLine6+"Other"+horizontalLine6+"Green"+"|");
		stringBuffer.append("\n");
		stringBuffer.append(secondMarker+horizontalLineWithMultipleBorder1);
		stringBuffer.append("\n"+secondMarker+"|"+padSpaceTillMaxLength(24)+"|"+padSpaceTillMaxLength(11)+"|"+padSpaceTillMaxLength(7)+horizontalLine5+padSpaceTillMaxLength(7)+horizontalLine5+padSpaceTillMaxLength(6)+" |");
		stringBuffer.append("\n");
		stringBuffer.append(secondMarker+"|"+padSpaceTillMaxLengthForDynamicData(drivingLicense, 24)+"|"+padSpaceTillMaxLengthForDynamicData(state, 11)+"|"+padSpaceTillMaxLengthForDynamicData(gender, 6)+horizontalLine6+"Male"+firstMarker+horizontalLine6+"Female"+" |");
		stringBuffer.append("\n");
		stringBuffer.append(secondMarker+"|"+padSpaceTillMaxLengthForDynamicData(required, 24)+"|"+padSpaceTillMaxLengthForDynamicData("", 11)+"|"+padSpaceTillMaxLength(27)+"|");
		stringBuffer.append("\n");
		stringBuffer.append(secondMarker+"|"+padSpaceTillMaxLength(24)+"|"+padSpaceTillMaxLength(11)+"|"+padSpaceTillMaxLength(27)+"|");
		stringBuffer.append("\n");
		stringBuffer.append(secondMarker+horizontalLineWithMultipleBorder2);

		stringBuffer.append("\n");
		stringBuffer.append(secondMarker+"|"+padSpaceTillMaxLengthForDynamicData(socialSecNum, 24)+"|"+padSpaceTillMaxLength(6)+padSpaceTillMaxLengthForDynamicData(emplId, 29)+padSpaceTillMaxLength(3)+"|");
		stringBuffer.append("\n");
		stringBuffer.append(secondMarker+"|"+padSpaceTillMaxLengthForDynamicData(optional, 24)+"|"+padSpaceTillMaxLength(13)+padSpaceTillMaxLengthForDynamicData(m_ndrTemplatePageDetail.getEmployeeID(), 26)+"|");
		stringBuffer.append("\n");
		stringBuffer.append(secondMarker+"|"+padSpaceTillMaxLength(24)+"|"+padSpaceTillMaxLength(12)+padSpaceTillMaxLength(27)+"|");
		stringBuffer.append("\n");
		stringBuffer.append(secondMarker+horizontalLineWithMultipleBorder3);
		stringBuffer.append("\n");
		stringBuffer.append(secondMarker+"|"+padSpaceTillMaxLengthForDynamicData(currenAddress, 24)+"|"+padSpaceTillMaxLengthForDynamicData(city, 10)+"|"+padSpaceTillMaxLengthForDynamicData(stateadd, 15)+"|"+padSpaceTillMaxLengthForDynamicData(zipcode, 11)+"|");
		stringBuffer.append("\n");
		stringBuffer.append(secondMarker+"|"+padSpaceTillMaxLengthForDynamicData(m_ndrTemplatePageDetail.getAddress(), 24)+"|"+padSpaceTillMaxLengthForDynamicData(m_ndrTemplatePageDetail.getAddressCity(), 10)+"|"+padSpaceTillMaxLengthForDynamicData(m_ndrTemplatePageDetail.getAddressState(), 15)+"|"+padSpaceTillMaxLengthForDynamicData(m_ndrTemplatePageDetail.getAddressZip(), 11)+"|");
		stringBuffer.append("\n");
		stringBuffer.append(secondMarker+horizontalLineWithMultipleBorder4);
		stringBuffer.append("\n");
		stringBuffer.append(secondMarker+" "+resultAddress+padSpaceTillMaxLength(5)+licenseDepartment+padSpaceTillMaxLength(5));
		stringBuffer.append("\n");
		stringBuffer.append(secondMarker+" "+resultAddress1+padSpaceTillMaxLength(16)+licenseDepartment1+padSpaceTillMaxLength(7));
		stringBuffer.append("\n");
		stringBuffer.append(secondMarker+" "+padSpaceTillMaxLength(41)+licenseDepartment2+firstMarker);
		stringBuffer.append("\n");
		stringBuffer.append(secondMarker+" "+padSpaceTillMaxLength(41)+licenseDepartment3+padSpaceTillMaxLength(2));
		stringBuffer.append("\n");
    // SS_QC#5503 changes start
    stringBuffer.append(secondMarker + " " + padSpaceTillMaxLength(41) + licenseDepartment4 + padSpaceTillMaxLength(2));
    stringBuffer.append("\n");
    // SS_QC#5503 changes end
		stringBuffer.append(secondMarker+" "+horizontalLine1);
		stringBuffer.append("\n");
		stringBuffer.append(secondMarker+" "+signature+padSpaceTillMaxLength(36));
		stringBuffer.append("\n");
		stringBuffer.append("\n");
		stringBuffer.append(secondMarker+" "+stateof+horizontalLine2+padSpaceTillMaxLength(26));
		stringBuffer.append("\n");
		stringBuffer.append(secondMarker+" "+padSpaceTillMaxLength(45)+"}  "+"SS"+padSpaceTillMaxLength(21));
		stringBuffer.append("\n");
		stringBuffer.append(secondMarker+" "+countyof+horizontalLine2+padSpaceTillMaxLength(27));
		stringBuffer.append("\n");		
		stringBuffer.append(secondMarker+" "+onThisDay+" "+horizontalLine7);
		stringBuffer.append("\n");		
		stringBuffer.append(secondMarker+" "+personnaly+firstMarker+" ");
		stringBuffer.append("\n");		
		stringBuffer.append(secondMarker+" "+personnaly1+padSpaceTillMaxLength(8));
		stringBuffer.append("\n");		
		stringBuffer.append(secondMarker+" "+personnaly2+secondMarker+" ");
		stringBuffer.append("\n");		
		stringBuffer.append(secondMarker+" "+personnaly3+secondMarker+" ");
		stringBuffer.append("\n");		
		stringBuffer.append(secondMarker+" "+personnaly4+padSpaceTillMaxLength(60));
		stringBuffer.append("\n");		
		stringBuffer.append(secondMarker+" "+personnaly5+horizontalLine3+dayof+padSpaceTillMaxLength(5));
		stringBuffer.append("\n");
		stringBuffer.append(secondMarker+" "+"of"+" "+horizontalLine3+"______"+", "+20+"________"+"."+padSpaceTillMaxLength(36));
		stringBuffer.append("\n");
		stringBuffer.append("\n");
		stringBuffer.append(secondMarker+" "+horizontalLine4);
		stringBuffer.append("\n");
		stringBuffer.append(secondMarker+" "+notory+padSpaceTillMaxLength(52));
		stringBuffer.append("\n");
		stringBuffer.append("\n");
		stringBuffer.append(secondMarker+" "+horizontalLine4);
		stringBuffer.append("\n");		
		stringBuffer.append(secondMarker+" "+mycomm+padSpaceTillMaxLength(49));
		
		return stringBuffer;
	}

	/**
	 * Classname / Method Name : LataTemplateForNDRModified/padSpaceTillMaxLength()
	 * @param maxLength
	 * @return : String
	 * Description : Method is used to add spaces in NDR template.
	 */
	private static  String padSpaceTillMaxLength(int maxLength)	{
		StringBuffer sb = new StringBuffer();
		for(int i=0;i<=maxLength;i++){
			sb.append(" ");
		}
		return sb.toString();
	}

	/**
	 * Classname / Method Name : LataTemplateForNDRModified/padSpaceTillMaxLengthForDynamicData()
	 * @param str
	 * @param maxLength
	 * @return : String
	 * Description : Method is used to add proper spaces in dynamic data for NDR template.
	 */
	private String padSpaceTillMaxLengthForDynamicData(String str, int maxLength)	{
		StringBuffer sb = new StringBuffer(str);
		for(int i=str.length();i<=maxLength;i++){
			sb.append(" ");
		}
		return sb.toString();
	}

	 //Unused code.
	/* public static void main(String[] args) {
		LataTemplateForNDRModified lataTemplateForNDR =	new LataTemplateForNDRModified();
	}*/

	/**
	 Classname / Method Name : LataTemplateForNDRModified/NdrTemplatePageDetail()
	 *
	 * Description : temporary method to set bean
	 */
	private static NdrTemplatePageDetail getTemplateDetails(){		
		NdrTemplatePageDetail ndrTemplatePageDetail = new NdrTemplatePageDetail();
		ndrTemplatePageDetail.setEmployeeName("Bramhendra Dwivedi");
//		ndrTemplatePageDetail.setEmployeeName("ABCDEFGHIJKLMNOPQRSTUVWXYZ, ABCDEFGHIJKLMNOPQRSTUVWXYZ ");
		ndrTemplatePageDetail.setDateOfBirth("11/06/2009");
		ndrTemplatePageDetail.setSsn("100");
		ndrTemplatePageDetail.setAddress("Satyam Computers,ManikChand Icon");		
		ndrTemplatePageDetail.setHeightFt("5");
		ndrTemplatePageDetail.setHeightInches("7");
		ndrTemplatePageDetail.setLicenseNumber("Class 1");	   
		//ndrTemplatePageDetail.setStateIssuedDriverLicense("100");
		//ndrTemplatePageDetail.setPreviousLicenseNumber("200");
		ndrTemplatePageDetail.setEmployeeID("1");
		ndrTemplatePageDetail.setState("Maharstra");
		ndrTemplatePageDetail.setAddressCity("Pune");
		ndrTemplatePageDetail.setAddressZip("411014");
		ndrTemplatePageDetail.setAddress("4th Lane");
//		ndrTemplatePageDetail.setAddress("ABCDEFGHIJKLMNOPQR, ABCDEFGHIJKLMNOPQRSAAS");
		ndrTemplatePageDetail.setAddressState("Maharstra");
		//	ndrTemplatePageDetail.setStateIssuedPreviousDriverLicense("300");
		return ndrTemplatePageDetail;
	}
}
