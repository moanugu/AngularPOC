/**
 * Classname    : LataTemplateForMVRModified
 * Description  : Class is used as a Lata template for MVR form.
 * author   	: Techmahindra Ltd.
 * Date of creation : Jul 20, 2009
 *
 * Change History
 * ------------------------------------------------------------  
 *   Date         Changed By    Description
 * ------------------------------------------------------------  
 *  04/12/2016    xsat671       Modified for SS_QC#5503.
 *
 * ------------------------------------------------------------  
 *
 * Copyright notice : "Copyright UPRR 2008"
 */
package templates;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.uprr.lic.dataaccess.Licensing.model.MvrTemplateDetail;

public class LataTemplateForMVRModified {

	private final Logger m_logger = LoggerFactory.getLogger(this.getClass());

	//-- markers
	private static String firstMarker = padSpaceTillMaxLength(2);
	private static String tripleSpace = padSpaceTillMaxLength(3);	

	private static String verticalLine = "|";

	private final String endMarkersWithSpace1 = verticalLine+padSpaceTillMaxLength(37)+verticalLine;

	//-- Lines
	 //SS_QC#550 changes start
	private static String toplLine = "_____________________________________________________________________________________________";
	private static String bottomlLineWithEndBorders = "|_____________________________________________________________________________________________|";
	private static String bottomlLineWithMultipleBorders1 = "|______________________________________________________|______________________________________|";
	private static String bottomlLineWithMultipleBorders2 = "|______________________________________________________|______________________________________|";
	//-- content

	private static String heading1="Form 20999 (Rev 10/2015)";
	private static String heading2="UNION PACIFIC RAILROAD STATE MOTOR VEHICLE REQUEST FORM";
	private final String pdfSubTitle = "(as required by FRA, 49 CFR, Part 240 & 242)";
//SS_QC#550 changes end
	private static String heading3="Section 1: Biographical Information";
	private static String heading4="Section 2: For those having a motor vehicle license in the last three (3) years";
	private static String heading6="Section 3: Certification";

	/**
	 * Classname / Method Name : LataTemplateForMVR/getBufferForLataPrintForMVR()
	 * @param m_mvrTemplateDetail
	 * @return : StringBuffer
	 * Description : Method is used to get contents of MVR lata template.
	 */
	public StringBuffer getBufferForLataPrintForMVR(MvrTemplateDetail m_mvrTemplateDetail){
		StringBuffer stringBuffer=new StringBuffer();
		stringBuffer.append(padSpaceTillMaxLength(72)+heading1);
		stringBuffer.append("\n");
		stringBuffer.append(tripleSpace+toplLine);
		stringBuffer.append("\n");
    // SS_QC#5503 changes start
    stringBuffer.append(firstMarker + verticalLine + padSpaceTillMaxLengthAlignCenter(heading2, 92) + verticalLine);
    stringBuffer.append("\n");
    stringBuffer.append(firstMarker + verticalLine + padSpaceTillMaxLengthAlignCenter(pdfSubTitle, 92) + verticalLine);
    stringBuffer.append("\n");
    stringBuffer.append(firstMarker + bottomlLineWithEndBorders);
    stringBuffer.append("\n");

    // -- SECTION 1 STARTS HERE --//
    stringBuffer.append(firstMarker + verticalLine + heading3 + padSpaceTillMaxLength(57) + verticalLine);
    stringBuffer.append("\n");
    stringBuffer.append(firstMarker + bottomlLineWithEndBorders);
    stringBuffer.append("\n");
    stringBuffer.append(firstMarker + verticalLine
        + padSpaceTillMaxLengthForDynamicData("Full Legal Name (First, Middle, Last)", 53) + verticalLine
        + padSpaceTillMaxLengthForDynamicData(m_mvrTemplateDetail.getEmployeeName(), 37) + verticalLine);
    stringBuffer.append("\n");
    stringBuffer.append(firstMarker + bottomlLineWithMultipleBorders1);
    stringBuffer.append("\n");
    stringBuffer.append(firstMarker + verticalLine
        + padSpaceTillMaxLengthForDynamicData("Date of Birth (MM,DD,YY)", 53) + verticalLine
        + padSpaceTillMaxLengthForDynamicData(m_mvrTemplateDetail.getDateOfBirth(), 37) + verticalLine);
    stringBuffer.append("\n");
    stringBuffer.append(firstMarker + bottomlLineWithMultipleBorders1);
    stringBuffer.append("\n");
    stringBuffer.append(firstMarker + verticalLine
        + padSpaceTillMaxLengthForDynamicData("Employee ID: (Required) ", 53) + verticalLine
        + padSpaceTillMaxLengthForDynamicData(m_mvrTemplateDetail.getEmployeeID(), 37) + verticalLine);
    stringBuffer.append("\n");
    stringBuffer.append(firstMarker + bottomlLineWithMultipleBorders1);
    stringBuffer.append("\n");
    stringBuffer.append(firstMarker + verticalLine
        + padSpaceTillMaxLengthForDynamicData("Current Home Mailing Address", 53) + verticalLine
        + padSpaceTillMaxLengthForDynamicData(m_mvrTemplateDetail.getAddress(), 37) + verticalLine);
    stringBuffer.append("\n");
    stringBuffer.append(firstMarker + bottomlLineWithMultipleBorders1);
    stringBuffer.append("\n");
    stringBuffer.append(firstMarker + verticalLine + padSpaceTillMaxLengthForDynamicData("City, State, Zip Code", 53)
        + verticalLine + padSpaceTillMaxLengthForDynamicData(m_mvrTemplateDetail.getCityStateAndZip(), 37)
        + verticalLine);
    stringBuffer.append("\n");
    stringBuffer.append(firstMarker + bottomlLineWithMultipleBorders1);
    stringBuffer.append("\n");

    // -- SECTION 2 STARTS HERE --//
    stringBuffer.append(firstMarker + verticalLine + heading4 + padSpaceTillMaxLength(13) + verticalLine);
    stringBuffer.append("\n");
    stringBuffer.append(firstMarker + bottomlLineWithEndBorders);
    stringBuffer.append("\n");
    stringBuffer.append(firstMarker + verticalLine
        + padSpaceTillMaxLengthForDynamicData("Current Driver's License Number", 37) + padSpaceTillMaxLength(15)
        + endMarkersWithSpace1);
    stringBuffer.append("\n");
    stringBuffer.append(firstMarker + bottomlLineWithMultipleBorders2);
    stringBuffer.append("\n");
    stringBuffer.append(firstMarker + verticalLine + "State Issuing Current Driver's License"
        + padSpaceTillMaxLength(15) + endMarkersWithSpace1);
    stringBuffer.append("\n");
    stringBuffer.append(firstMarker + bottomlLineWithMultipleBorders2);
    stringBuffer.append("\n");

    stringBuffer.append(firstMarker + verticalLine
        + padSpaceTillMaxLengthForDynamicData("State Identification Number", 37) + padSpaceTillMaxLength(15)
        + endMarkersWithSpace1);
    stringBuffer.append("\n");
    stringBuffer.append(firstMarker + verticalLine + "(only applicable if you do not hold a drivers license)"
        + endMarkersWithSpace1);
    stringBuffer.append("\n");
    stringBuffer.append(firstMarker + bottomlLineWithMultipleBorders2);
    stringBuffer.append("\n");
    stringBuffer.append(firstMarker + verticalLine
        + padSpaceTillMaxLengthForDynamicData("State Issuing Identification Card", 37) + padSpaceTillMaxLength(15)
        + endMarkersWithSpace1);
    stringBuffer.append("\n");
    stringBuffer.append(firstMarker + verticalLine + "(only applicable if you do not hold a drivers license)"
        + endMarkersWithSpace1);

    stringBuffer.append("\n");
    stringBuffer.append(firstMarker + bottomlLineWithMultipleBorders2);
    stringBuffer.append("\n");

    // -- SECTION 4 STARTS HERE --//
    stringBuffer.append(firstMarker + verticalLine + heading6 + padSpaceTillMaxLength(68) + verticalLine);
    stringBuffer.append("\n");
    stringBuffer.append(firstMarker + bottomlLineWithEndBorders);
    stringBuffer.append("\n");
    stringBuffer.append(firstMarker
        + verticalLine
        + padSpaceTillMaxLengthForDynamicData(
            "I certify that the above information is complete and correct to the best of my knowledge. I", 92) + verticalLine);
    stringBuffer.append("\n");
    stringBuffer.append(firstMarker
        + verticalLine
        + padSpaceTillMaxLengthForDynamicData(
            "hereby authorize the Department of Licensing to forward my driving record to Union Pacific", 92) + verticalLine);
    stringBuffer.append("\n");
    stringBuffer.append(firstMarker
        + verticalLine
        + padSpaceTillMaxLengthForDynamicData(
            "Railroad listed below.If it becomes necessary to obtain additional driving records from a", 92) + verticalLine);
    stringBuffer.append("\n");
    stringBuffer.append(firstMarker
        + verticalLine
        + padSpaceTillMaxLengthForDynamicData(
            "state other than my issuing state, and as required by 49 CFR Part 240, I further authorize", 92) + verticalLine);
    stringBuffer.append("\n");
    stringBuffer.append(firstMarker
        + verticalLine
        + padSpaceTillMaxLengthForDynamicData(
            "Union Pacific and it's agent to obtain MVR reports from different licensing agencies as", 92) + verticalLine);
    stringBuffer.append("\n");
    stringBuffer.append(firstMarker
        + verticalLine
        + padSpaceTillMaxLengthForDynamicData(
            "necessary. This release is valid for 366 days from the date shown received by the Department", 92) + verticalLine);
    stringBuffer.append("\n");
    stringBuffer.append(firstMarker + verticalLine
        + padSpaceTillMaxLengthForDynamicData("of Licensing.", 92)
        + verticalLine);
    // SS_QC#5503 changes end
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+bottomlLineWithEndBorders);
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+verticalLine+padSpaceTillMaxLengthForDynamicData("Signature:", 53)
				+verticalLine+padSpaceTillMaxLengthForDynamicData("Date:", 37)+verticalLine);
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+bottomlLineWithMultipleBorders2);
		stringBuffer.append("\n");

		//-- SECTION AFTER THE TABLE --//
		stringBuffer.append(getMvrTemplateInfoBelowTable());		

		return stringBuffer;
	}	

  /**
   * Method is used to get the contents of MVR Template after the table ends.
   *
   * @return
   * @author xsat671
   * @since Apr 12, 2016. Modified for SS_QC#5503.
   */
	private String getMvrTemplateInfoBelowTable(){
		StringBuffer stringBuffer = new StringBuffer();
    // SS_QC#5503 changes start
    stringBuffer.append(padSpaceTillMaxLength(14)
        + padSpaceTillMaxLengthAlignCenter("Please send this form to: Union Pacific Railroad", 72));
    stringBuffer.append("\n");

    stringBuffer.append(padSpaceTillMaxLength(26)
        + padSpaceTillMaxLengthAlignCenter(padSpaceTillMaxLength(25) + "Employee Licensing & Certification Department", 72));
    stringBuffer.append("\n");
    stringBuffer.append(padSpaceTillMaxLength(14)
        + padSpaceTillMaxLengthAlignCenter(padSpaceTillMaxLength(34) + "1400 Douglas Street, Stop 1010", 72));
    stringBuffer.append("\n");
    stringBuffer.append(padSpaceTillMaxLength(14)
        + padSpaceTillMaxLengthAlignCenter(padSpaceTillMaxLength(23) + "Omaha, NE 68179-1010", 72));
    // SS_QC#5503 changes end
		return stringBuffer.toString();
	}

	/**
	 * Classname / Method Name : LataTemplateForMVRModified/padSpaceTillMaxLength()
	 * @param maxLength
	 * @return : String
	 * Description : Method is used to add spaces in MVR template.
	 */
	private static String padSpaceTillMaxLength(int maxLength)	{
		StringBuffer sb = new StringBuffer();
		for(int i=0;i<=maxLength;i++){
			sb.append(" ");
		}
		return sb.toString();
	}

	/**
	 * Classname / Method Name : LataTemplateForMVR/padSpaceTillMaxLengthForDynamicData()
	 * @param str
	 * @param maxLength
	 * @return : String
	 * Description : Method is used to adjust proper space for dynamic data in MVR template.
	 */
	private static String padSpaceTillMaxLengthForDynamicData(String str, int maxLength)	{
		StringBuffer sb = new StringBuffer(str);
		for(int i=str.length();i<=maxLength;i++){
			sb.append(" ");
		}
		return sb.toString();
	}	

	/**
	 * Classname / Method Name : LataTemplateForMedicalModified/padSpaceTillMaxLengthAlignCenter()
	 * @param str
	 * @param maxLength
	 * @return : String
	 * Description : Method is used to center align the content.
	 */
	private static String padSpaceTillMaxLengthAlignCenter(String str, int maxLength){
		int initLength = str.length();
		StringBuffer sb = new StringBuffer();
		if(initLength<maxLength)
		{
			for(int i=0;i<(maxLength-initLength)/2;i++)
			{
				sb.append(" ");
			}
			sb.append(str);
			final int len = sb.length();
			for(int i=len;i<=maxLength;i++)
			{
				sb.append(" ");
			}
		}		
		return sb.toString();
	}


	public static void main(String[] args) {
		LataTemplateForMVRModified lataTemplateForMVR = new LataTemplateForMVRModified();
		StringBuffer message = lataTemplateForMVR.getBufferForLataPrintForMVR(getTemplateDetails());
	}

	private static MvrTemplateDetail getTemplateDetails(){		
		MvrTemplateDetail mvrTemplateDetail = new MvrTemplateDetail();
		mvrTemplateDetail.setEmployeeName("Bramhendra Dwivedi");
//		mvrTemplateDetail.setEmployeeName("WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW, WWWWWWWWWWWWWWWWWWWWWWWWWWWW W");
		mvrTemplateDetail.setDateOfBirth("May 21,2009");
		mvrTemplateDetail.setSsn("100");
		mvrTemplateDetail.setAddress("Satyam Computers,ManikChand Icon");
//		mvrTemplateDetail.setAddress("WWWWWW WWWWWWWWW,WWWWWWWWWW WWWWWWWWWWWWWW WWWWWWWWWWWWWWWWWWWW");
		mvrTemplateDetail.setCityStateAndZip("Pune Maharastra 410001");
		mvrTemplateDetail.setLicenseNumber("Class 1");	   
		mvrTemplateDetail.setStateIssuedDriverLicense("100");
		mvrTemplateDetail.setPreviousLicenseNumber("200");
		mvrTemplateDetail.setEmployeeID("1");
		mvrTemplateDetail.setStateIssuedPreviousDriverLicense("300");
		return mvrTemplateDetail;
	}


}
