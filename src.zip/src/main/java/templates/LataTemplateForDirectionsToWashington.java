/**
 * Classname    : LataTemplateForDirectionsToWashington
 * Description  : Class is used as a Lata Template for Direction to Washington Employees letter.
 * author   	: Satyam Computer Services Ltd.
 * Date of creation : Jun 15, 2009
 *
 * Change History
 * ------------------------------------------------------------  
 *   Date  Changed By    Description
 * ------------------------------------------------------------  
 *
 *
 * ------------------------------------------------------------  
 *
 * Copyright notice : "Copyright � UPRR 2008"
 */
package templates;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LataTemplateForDirectionsToWashington {
	
	private final Logger m_logger = LoggerFactory.getLogger(this.getClass());

	private final String firstMarker = padSpaceTillMaxLength(14);
//	private final String secondMarker = padSpaceTillMaxLength(30);
//	private final String thirdMarker = padSpaceTillMaxLength(38);

	/**
	 * Classname / Method Name : LataTemplateForDirectionsToWashington/getBufferForLataPrintForDirectionsForWashington()
	 * @return : StringBuffer
	 * Description : Method is used to get contents of Direction to Washington state employees letter template.
	 */
	public StringBuffer getBufferForLataPrintForDirectionsForWashington(){

		StringBuffer stringBuffer = new StringBuffer();
		stringBuffer.append("\n\n");

		stringBuffer.append(firstMarker+"Note: If you have or previously had a driver's license in the state of ");
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+"Washington, you must complete UP FORM WA20001.");
		stringBuffer.append("\n\n");
		stringBuffer.append(firstMarker+"If you have a license in any other state,");
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+"ONLY use Form 20119 and Form 20999.");
		stringBuffer.append("\n\n\n");
		stringBuffer.append(firstMarker+"If you have any questions please contact");
		stringBuffer.append("\n");
		stringBuffer.append(firstMarker+"402-544-CERT (2378) or 8-544-CERT (2378).");

		return stringBuffer;
	}

	/**
	 * Classname / Method Name : LataTemplateForDirectionsToWashington/padSpaceTillMaxLength()
	 * @param maxLength
	 * @return : String
	 * Description : Method is used to add spaces in the template.
	 */
	private String padSpaceTillMaxLength(int maxLength)	{
		StringBuffer sb = new StringBuffer();
		for(int i=0;i<=maxLength;i++){
			sb.append(" ");
		}
		return sb.toString();
	}

	public static void main(String[] args) {
		LataTemplateForDirectionsToWashington lataTemplateForDirectionsToWashington = 
			new LataTemplateForDirectionsToWashington();
	}

}
