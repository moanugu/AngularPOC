/**
 * Classname    : LataTemplateForMVR
 * Description  : Class is used as a Lata template for MVR form.
 * author   	: Satyam Computer Services Ltd.
 * Date of creation : Jun 15, 2009
 *
 * Change History
 * ------------------------------------------------------------  
 *   Date  Changed By    Description
 * ------------------------------------------------------------  
 *
 *
 * ------------------------------------------------------------  
 *
 * Copyright notice : "Copyright � UPRR 2008"
 */
package templates;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.uprr.lic.dataaccess.Licensing.model.MvrTemplateDetail;

public class LataTemplateForMVR {
	
	private final Logger m_logger = LoggerFactory.getLogger(this.getClass());

	//-- spaces
	private final String firstMarker = padSpaceTillMaxLength(7);
	private final String secondMarker = padSpaceTillMaxLength(1);
	private final String thirdMarker = padSpaceTillMaxLength(46);
	private final String halfSpace = padSpaceTillMaxLength(1/2);
	private final String singleSpace = padSpaceTillMaxLength(1);
	private final String doubleSpace = padSpaceTillMaxLength(2);
	private final String tripalSpace = padSpaceTillMaxLength(3);
	private final String fourSpaces = padSpaceTillMaxLength(4);

	//-- data
	private final String pdfTitle="UNION PACIFIC RAILROAD STATE MOTOR VEHICLE FORM";
	private final String afterPdfTitle="Section 1: Biographical Information";
	private final String section2="Section 2: For those having a motor vehicle license in the last five (5) years";
	private final String section21="(required by FRA, 49CFR, Part 240)";
	private final String section3="Section 3: For those not having a motor vehicle license in the last five (5) years";
	private final String section31="I certify that I do not currently have,";
	private final String section32="nor in the last five- (5) years have I";
	private final String section33="ever had a motor vehicle driver's ";
	private final String section34="license.";
	private final String section35="I certify further I have not been";
	private final String section36="convicted of driving without a license";
	private final String section37="within the last five- (5) years.";
	private final String section4="Section 4: Certification";
	private final String section41="I certify that the above information is complete and correct to the best of my knowledge.";
	private final String section42="I hereby authorize the Department of Licensing to forward my driving record to Union Pacific";
	private final String section43="Railroad listed below.If it becomes necessary to obtain additional driving records from a state other "; 
	private final String section44="than my issuing state,and as required by 49 CFR Part 240, I further authorize Union Pacific "; 
	private final String section45="and it's agent (HireRight) to obtain MVR reports from different licensing agencies as necessary.";
	private final String section46="Signature:";
	private final String section47="Date:";
	private final String section5="California Applicants: California law affords you the right to request a copy of the driving";
	private final String section51="record sent to Union Pacific. Check the box if you want a copy sent to you.";
	private final String section52="Please send this form to: Union Pacific Railroad";
	private final String section53="Licensing Department";
	private final String section54="1400 Douglas Street, Stop 1010";
	private final String section55="Omaha, NE 68179-1010";
	private final String horizontalLine5="__";
	private final String horizontalLine6="|__|";

	//-- borders
	private final String horizontalLineWithEndBorder = "|_______________________________________________________________________________________________________________|";
	private final String horizontalLineWithCenterAndEndBorder = "|________________________________________________|______________________________________________________________|";
	private final String horizontalLine = "_______________________________________________________________________________________________________________";

	private final String tableRightBorder = padSpaceTillMaxLength(29)+"|";

	/**
	 * Classname / Method Name : LataTemplateForMVR/getBufferForLataPrintForMVR()
	 * @param m_mvrTemplateDetail
	 * @return : StringBuffer
	 * Description : Method is used to get contents of MVR lata template.
	 */
	public StringBuffer getBufferForLataPrintForMVR(MvrTemplateDetail m_mvrTemplateDetail){
		StringBuffer stringBuffer=new StringBuffer();
		stringBuffer.append(padSpaceTillMaxLength(90)+"Form 20999 (Rev 06/07)");
		stringBuffer.append("\n");
		stringBuffer.append(secondMarker+halfSpace+horizontalLine);
		stringBuffer.append("\n");
		stringBuffer.append(secondMarker+"|"+padSpaceTillMaxLength(10)+firstMarker+firstMarker+pdfTitle+padSpaceTillMaxLength(36)+"|");
		stringBuffer.append("\n");
		stringBuffer.append(secondMarker+horizontalLineWithEndBorder);
		stringBuffer.append("\n");
		stringBuffer.append(secondMarker+"|"+afterPdfTitle+thirdMarker+padSpaceTillMaxLength(28)+"|");
		stringBuffer.append("\n");
		stringBuffer.append(secondMarker+horizontalLineWithEndBorder);
		stringBuffer.append("\n");
		stringBuffer.append(secondMarker+"|"+"Full Legal Name (First, Middle, Last)"+padSpaceTillMaxLength(10)+"|"+padSpaceTillMaxLengthForDynamicData(m_mvrTemplateDetail.getEmployeeName(), 61)+"|");
		stringBuffer.append("\n");
		stringBuffer.append(secondMarker+horizontalLineWithCenterAndEndBorder);
		stringBuffer.append("\n");
		stringBuffer.append(secondMarker+"|"+"Date of Birth (MM,DD,YY)"+padSpaceTillMaxLength(23)+"|"+padSpaceTillMaxLengthForDynamicData(m_mvrTemplateDetail.getDateOfBirth(), 61)+"|");
		stringBuffer.append("\n");
		stringBuffer.append(secondMarker+horizontalLineWithCenterAndEndBorder);
		stringBuffer.append("\n");
		stringBuffer.append(secondMarker+"|"+"Social Security No."+padSpaceTillMaxLength(28)+"|"+padSpaceTillMaxLengthForDynamicData("Employee ID: "+m_mvrTemplateDetail.getEmployeeID(), 61)+"|");
		stringBuffer.append("\n");
		stringBuffer.append(secondMarker+"|"+"(Optional)"+padSpaceTillMaxLength(37)+"|"+padSpaceTillMaxLengthForDynamicData("(Required)", 61)+"|");
		stringBuffer.append("\n");
		stringBuffer.append(secondMarker+horizontalLineWithCenterAndEndBorder);
		stringBuffer.append("\n");
		stringBuffer.append(secondMarker+"|"+"Current Home Mailing Address"+padSpaceTillMaxLength(10)+firstMarker+halfSpace+"|"+padSpaceTillMaxLengthForDynamicData(m_mvrTemplateDetail.getAddress(), 61)+"|");
		stringBuffer.append("\n");
		stringBuffer.append(secondMarker+horizontalLineWithCenterAndEndBorder);
		stringBuffer.append("\n");
		stringBuffer.append(secondMarker+"|"+"City, State, Zip Code"+padSpaceTillMaxLength(26)+"|"+padSpaceTillMaxLengthForDynamicData(m_mvrTemplateDetail.getCityStateAndZip(), 61)+"|");
		stringBuffer.append("\n");
		stringBuffer.append(secondMarker+horizontalLineWithCenterAndEndBorder);
		stringBuffer.append("\n");
		stringBuffer.append(secondMarker+"|"+section2+padSpaceTillMaxLength(10)+firstMarker+firstMarker+padSpaceTillMaxLength(5)+"|");
		stringBuffer.append("\n");
		stringBuffer.append(secondMarker+"|"+section21+padSpaceTillMaxLength(10)+padSpaceTillMaxLength(10)+firstMarker+padSpaceTillMaxLength(16)+tableRightBorder);
		stringBuffer.append("\n");
		stringBuffer.append(secondMarker+horizontalLineWithEndBorder);
		stringBuffer.append("\n");
		stringBuffer.append(secondMarker+"|"+"Current Driver's License Number"+padSpaceTillMaxLength(16)+"|"+padSpaceTillMaxLengthForDynamicData(m_mvrTemplateDetail.getLicenseNumber(), 61)+"|");
		stringBuffer.append("\n");
		stringBuffer.append(secondMarker+horizontalLineWithCenterAndEndBorder);
		stringBuffer.append("\n");
		stringBuffer.append(secondMarker+"|"+"State Issuing Current Driver's License"+padSpaceTillMaxLength(9)+"|"+padSpaceTillMaxLengthForDynamicData(m_mvrTemplateDetail.getStateIssuedDriverLicense(), 61)+"|");
		stringBuffer.append("\n");
		stringBuffer.append(secondMarker+horizontalLineWithCenterAndEndBorder);
		stringBuffer.append("\n");
		stringBuffer.append(secondMarker+"|"+"Previous Driver's License Number"+padSpaceTillMaxLength(15)+"|"+padSpaceTillMaxLengthForDynamicData(m_mvrTemplateDetail.getPreviousLicenseNumber(), 61)+"|");
		stringBuffer.append("\n");
		stringBuffer.append(secondMarker+"|"+"(if applicable)"+padSpaceTillMaxLength(32)+"|"+padSpaceTillMaxLengthForDynamicData("", 61)+"|");
		stringBuffer.append("\n");
		stringBuffer.append(secondMarker+horizontalLineWithCenterAndEndBorder);
		stringBuffer.append("\n");
		stringBuffer.append(secondMarker+"|"+"State Issuing Previous Driver's License"+padSpaceTillMaxLength(8)+"|"+padSpaceTillMaxLengthForDynamicData(m_mvrTemplateDetail.getStateIssuedPreviousDriverLicense(), 61)+"|");
		stringBuffer.append("\n");
		stringBuffer.append(secondMarker+horizontalLineWithCenterAndEndBorder);
		stringBuffer.append("\n");
		stringBuffer.append(secondMarker+"|"+section3+padSpaceTillMaxLength(28)+"|");
		stringBuffer.append("\n");
		stringBuffer.append(secondMarker+horizontalLineWithEndBorder);
		stringBuffer.append("\n");
		stringBuffer.append(secondMarker+"|"+section31+firstMarker+halfSpace+"|"+padSpaceTillMaxLengthForDynamicData("", 61)+"|");
		stringBuffer.append("\n");
		stringBuffer.append(secondMarker+"|"+section32+firstMarker+singleSpace+"|"+padSpaceTillMaxLengthForDynamicData("", 61)+"|");
		stringBuffer.append("\n");
		stringBuffer.append(secondMarker+"|"+section33+padSpaceTillMaxLength(10)+doubleSpace+"|"+padSpaceTillMaxLengthForDynamicData("", 61)+"|");
		stringBuffer.append("\n");
		stringBuffer.append(secondMarker+"|"+section34+padSpaceTillMaxLength(39)+"|"+padSpaceTillMaxLengthForDynamicData("", 61)+"|");
		stringBuffer.append("\n");
		stringBuffer.append(secondMarker+horizontalLineWithCenterAndEndBorder);
		stringBuffer.append("\n");
		stringBuffer.append(secondMarker+"|"+section35+padSpaceTillMaxLength(10)+tripalSpace+"|"+padSpaceTillMaxLengthForDynamicData("", 61)+"|");
		stringBuffer.append("\n");
		stringBuffer.append(secondMarker+"|"+section36+firstMarker+singleSpace+"|"+padSpaceTillMaxLengthForDynamicData("", 61)+"|");
		stringBuffer.append("\n");
		stringBuffer.append(secondMarker+"|"+section37+padSpaceTillMaxLength(10)+fourSpaces+"|"+padSpaceTillMaxLengthForDynamicData("", 61)+"|");
		stringBuffer.append("\n");
		stringBuffer.append(secondMarker+horizontalLineWithCenterAndEndBorder);
		stringBuffer.append("\n");
		stringBuffer.append(secondMarker+"|"+section4+padSpaceTillMaxLength(24)+padSpaceTillMaxLengthForDynamicData("", 61)+"|");
		stringBuffer.append("\n");
		stringBuffer.append(secondMarker+horizontalLineWithEndBorder);
		stringBuffer.append("\n");
		stringBuffer.append(secondMarker+"|"+section41+padSpaceTillMaxLength(21)+"|");
		stringBuffer.append("\n");		
		stringBuffer.append(secondMarker+"|"+section42+padSpaceTillMaxLength(18)+"|");
		stringBuffer.append("\n");		
		stringBuffer.append(secondMarker+"|"+section43+padSpaceTillMaxLength(8)+"|");
		stringBuffer.append("\n");
		stringBuffer.append(secondMarker+"|"+section44+padSpaceTillMaxLength(18)+"|");
		stringBuffer.append("\n");
		stringBuffer.append(secondMarker+"|"+section45+padSpaceTillMaxLength(14)+"|");
		stringBuffer.append("\n");
		stringBuffer.append(secondMarker+horizontalLineWithEndBorder);
		stringBuffer.append("\n");
		stringBuffer.append(secondMarker+"|"+section46+padSpaceTillMaxLength(37)+"|"+padSpaceTillMaxLengthForDynamicData(section47, 61)+"|");
		stringBuffer.append("\n");
		stringBuffer.append(secondMarker+horizontalLineWithCenterAndEndBorder);
		stringBuffer.append("\n");
		stringBuffer.append(secondMarker+" "+firstMarker+section5+doubleSpace+horizontalLine5+firstMarker+" ");
		stringBuffer.append("\n");
		stringBuffer.append(secondMarker+" "+firstMarker+section51+padSpaceTillMaxLength(10)+firstMarker+horizontalLine6+firstMarker+" ");
		stringBuffer.append("\n");
		stringBuffer.append("\n");
		stringBuffer.append(secondMarker+" "+padSpaceTillMaxLength(10)+firstMarker+section52+padSpaceTillMaxLength(20)+firstMarker+" ");
		stringBuffer.append("\n");
		stringBuffer.append(secondMarker+" "+padSpaceTillMaxLength(30)+"  "+section53+padSpaceTillMaxLength(20)+firstMarker+" ");
		stringBuffer.append("\n");
		stringBuffer.append(secondMarker+" "+padSpaceTillMaxLength(30)+"  "+section54+padSpaceTillMaxLength(20)+" ");
		stringBuffer.append("\n");
		stringBuffer.append(secondMarker+" "+padSpaceTillMaxLength(30)+"  "+section55+padSpaceTillMaxLength(30)+" ");

		return stringBuffer;
	}	

	/**
	 * Classname / Method Name : LataTemplateForMVR/padSpaceTillMaxLength()
	 * @param maxLength
	 * @return : String
	 * Description : Method is used to add spaces in MVR template.
	 */
	private String padSpaceTillMaxLength(int maxLength)	{
		StringBuffer sb = new StringBuffer();
		for(int i=0;i<=maxLength;i++){
			sb.append(" ");
		}
		return sb.toString();
	}

	/**
	 * Classname / Method Name : LataTemplateForMVR/padSpaceTillMaxLengthForDynamicData()
	 * @param str
	 * @param maxLength
	 * @return : String
	 * Description : Method is used to adjust proper space for dynamic data in MVR template.
	 */
	private String padSpaceTillMaxLengthForDynamicData(String str, int maxLength)	{
		StringBuffer sb = new StringBuffer(str);
		for(int i=str.length();i<=maxLength;i++){
			sb.append(" ");
		}
		return sb.toString();
	}	

	public static void main(String[] args) {
		LataTemplateForMVR lataTemplateForMVR = new LataTemplateForMVR();
		StringBuffer message = lataTemplateForMVR.getBufferForLataPrintForMVR(getTemplateDetails());
		/*PrintXmfILataService lataService = new PrintXmfILataService();
		
		lataService.getIlataPrint("xcov373", "N199699", message.toString());*/
	}

	private static MvrTemplateDetail getTemplateDetails(){		
		MvrTemplateDetail mvrTemplateDetail = new MvrTemplateDetail();
		mvrTemplateDetail.setEmployeeName("Bramhendra Dwivedi");
//		mvrTemplateDetail.setEmployeeName("WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW, WWWWWWWWWWWWWWWWWWWWWWWWWWWW W");
		mvrTemplateDetail.setDateOfBirth("May 21,2009");
		mvrTemplateDetail.setSsn("100");
		mvrTemplateDetail.setAddress("Satyam Computers,ManikChand Icon");
//		mvrTemplateDetail.setAddress("WWWWWW WWWWWWWWW,WWWWWWWWWW WWWWWWWWWWWWWW WWWWWWWWWWWWWWWWWWWW");
		mvrTemplateDetail.setCityStateAndZip("Pune Maharastra 410001");
		mvrTemplateDetail.setLicenseNumber("Class 1");	   
		mvrTemplateDetail.setStateIssuedDriverLicense("100");
		mvrTemplateDetail.setPreviousLicenseNumber("200");
		mvrTemplateDetail.setEmployeeID("1");
		mvrTemplateDetail.setStateIssuedPreviousDriverLicense("300");
		return mvrTemplateDetail;
	}


}
